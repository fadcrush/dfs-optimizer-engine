# DFS Platform Backend - Complete Architecture Plan

**Date:** 2026-01-22  
**Scope:** End-to-end reconstruction for maximum NFL + NBA DFS accuracy  
**Status:** Design Phase → Implementation Phase

---

## 1. PROPOSED FILE TREE (NEW STRUCTURE)

```
f:\Dev\N_B_A_and_N_F_L\
├── backend/                          # Main backend application
│   ├── __init__.py
│   ├── main.py                       # FastAPI app entry
│   ├── core/
│   │   ├── __init__.py
│   │   ├── config.py                 # Environment + config management
│   │   ├── logging.py                # Structured logging
│   │   ├── time_utils.py             # Timezone-safe utilities
│   │   ├── exceptions.py             # Custom exceptions
│   │   └── constants.py              # Enums, constants
│   │
│   ├── db/
│   │   ├── __init__.py
│   │   ├── engine.py                 # DuckDB + optional Postgres
│   │   ├── migrations.py             # Schema initialization
│   │   ├── schema_registry.py        # Table definitions + contracts
│   │   ├── parquet_utils.py          # Parquet I/O conventions
│   │   └── query_lib.py              # Safe parameterized queries
│   │
│   ├── ingest/
│   │   ├── __init__.py
│   │   ├── base.py                   # BaseConnector + interfaces
│   │   ├── fanduel_csv.py            # FanDuel slate + player ingestion
│   │   ├── draftkings_csv.py         # DraftKings slate + player ingestion
│   │   ├── nba_api_client.py         # NBA API connector
│   │   ├── nfl_pbp_client.py         # NFL PBP ingestion
│   │   ├── results_client.py         # Contest results + actuals
│   │   ├── idempotency.py            # Dedup, idempotency keys
│   │   └── schema_drift.py           # Handle missing/extra columns
│   │
│   ├── signals/
│   │   ├── __init__.py
│   │   ├── spec.py                   # SignalSpec dataclass + types
│   │   ├── store.py                  # Signal CRUD + time-range queries
│   │   ├── decay.py                  # Confidence decay functions
│   │   ├── overrides.py              # Override rules engine
│   │   └── snapshot.py               # Decision snapshot builder (as-of time)
│   │
│   ├── derive/
│   │   ├── __init__.py
│   │   ├── canonicalize.py           # Canonical normalization (player, team, game, slate)
│   │   ├── features.py               # Feature builders (minutes, usage, pace/env)
│   │   ├── modifiers.py              # Opportunity modifiers (injuries, starters, depth)
│   │   └── builder.py                # Feature pipeline orchestrator
│   │
│   ├── projection/
│   │   ├── __init__.py
│   │   ├── models.py                 # Projection data models
│   │   ├── builder.py                # Build distributions (median, floor, ceiling, volatility)
│   │   ├── store.py                  # Store + retrieve projections with versions
│   │   └── rules.py                  # Priority hierarchy + validity windows
│   │
│   ├── evaluation/
│   │   ├── __init__.py
│   │   ├── accuracy.py               # Projection accuracy computations
│   │   ├── bias.py                   # Bias dashboards by team, position, context
│   │   ├── source_reliability.py     # Hit rate, false-positive rate, lead time
│   │   ├── feedback.py               # Self-correction loop
│   │   └── store.py                  # Truth + evaluation tables
│   │
│   ├── api/
│   │   ├── __init__.py
│   │   ├── health.py                 # GET /health
│   │   ├── slates.py                 # GET /slates, /slates/{slate_id}
│   │   ├── signals.py                # GET /slate/{slate_id}/signals
│   │   ├── projections.py            # GET/POST projections + build
│   │   ├── ingest.py                 # POST /ingest/* endpoints
│   │   ├── evaluation.py             # GET evaluation results
│   │   └── dependencies.py           # FastAPI dependency injection
│   │
│   ├── jobs/
│   │   ├── __init__.py
│   │   ├── cli.py                    # CLI entry points (Click)
│   │   ├── ingest_historical.py      # Ingest historical data
│   │   ├── ingest_slate_csv.py       # Ingest single slate
│   │   ├── ingest_results.py         # Ingest contest results + actuals
│   │   ├── build_projections.py      # Build projections as-of time T
│   │   ├── evaluate.py               # Run evaluation + source reliability update
│   │   └── backtest.py               # Nightly backtest
│   │
│   ├── tests/
│   │   ├── __init__.py
│   │   ├── conftest.py               # Pytest fixtures
│   │   ├── test_signals.py           # Signal decay, overrides, snapshot
│   │   ├── test_derive.py            # Canonicalization, features, modifiers
│   │   ├── test_projection.py        # Priority hierarchy, validity
│   │   ├── test_ingest.py            # Idempotent ingestion, schema drift
│   │   ├── test_api.py               # API smoke tests, OpenAPI
│   │   └── test_evaluation.py        # Accuracy, bias, source reliability
│   │
│   └── pyproject.toml                # Dependencies + metadata
│
├── db/
│   ├── duckdb_main.db                # Local DuckDB (dev)
│   ├── migrations/                   # Schema migration scripts
│   │   ├── 001_init_schema.sql
│   │   ├── 002_add_signal_tables.sql
│   │   └── ...
│   └── sql/
│       ├── views/                    # DuckDB views for analytics
│       └── queries/                  # Stored query patterns
│
├── data/
│   ├── raw/                          # Immutable raw data
│   │   ├── nfl_pbp/
│   │   ├── nba_api/
│   │   ├── fd_slates/
│   │   └── dk_slates/
│   ├── derived/                      # Versioned derived tables
│   │   ├── players/
│   │   ├── teams/
│   │   ├── games/
│   │   └── slates/
│   └── operational/                  # Time-versioned snapshots
│       ├── lineups/
│       ├── injuries/
│       └── ownership/
│
├── config/
│   ├── .env.template
│   ├── .env.local                    # (gitignored)
│   └── default_config.yaml
│
├── docs/
│   ├── SCHEMA.md                     # Database schema documentation
│   ├── DATA_CONTRACTS.md             # Signal specs + contracts
│   ├── API_REFERENCE.md              # OpenAPI auto-generated
│   └── MIGRATION_GUIDE.md            # How to migrate from current code
│
├── logs/
│   └── app.log
│
├── scripts/
│   ├── reset_db.sh                   # Reset DuckDB for dev
│   ├── ingest_sample_slate.sh        # Demo ingestion
│   └── run_local_demo.sh             # Full local demo
│
├── requirements.txt                  # All dependencies
├── README.md                         # Setup + run instructions
└── .gitignore
```

---

## 2. DATABASE SCHEMA (DUCKDB + OPTIONAL POSTGRES)

### Tier 1: RAW (Immutable)

```sql
-- RAW INGESTION TABLES (append-only, JSON payloads preserved)

CREATE TABLE raw_fd_slate_csv (
    raw_id BIGINT PRIMARY KEY DEFAULT nextval('raw_id_seq'),
    ingested_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    slate_date DATE,
    slate_id VARCHAR,
    contest_id VARCHAR,
    site_name VARCHAR DEFAULT 'FanDuel',
    file_hash VARCHAR,  -- idempotency
    payload JSONB,  -- entire CSV row as JSON

    UNIQUE(slate_id, contest_id, file_hash)
);

CREATE TABLE raw_dk_slate_csv (
    raw_id BIGINT PRIMARY KEY DEFAULT nextval('raw_id_seq'),
    ingested_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    slate_date DATE,
    slate_id VARCHAR,
    contest_id VARCHAR,
    site_name VARCHAR DEFAULT 'DraftKings',
    file_hash VARCHAR,
    payload JSONB,

    UNIQUE(slate_id, contest_id, file_hash)
);

CREATE TABLE raw_nba_api_responses (
    raw_id BIGINT PRIMARY KEY DEFAULT nextval('raw_id_seq'),
    ingested_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    endpoint VARCHAR,
    game_date DATE,
    query_params JSONB,
    response_payload JSONB,
    response_hash VARCHAR,

    UNIQUE(endpoint, query_params, response_hash)
);

CREATE TABLE raw_nfl_pbp (
    raw_id BIGINT PRIMARY KEY DEFAULT nextval('raw_id_seq'),
    ingested_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    season INT,
    week INT,
    game_id VARCHAR,
    payload JSONB,  -- entire PBP row
    source_hash VARCHAR,

    UNIQUE(season, week, game_id, source_hash)
);

CREATE TABLE raw_contest_results (
    raw_id BIGINT PRIMARY KEY DEFAULT nextval('raw_id_seq'),
    ingested_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    slate_id VARCHAR,
    contest_id VARCHAR,
    contest_name VARCHAR,
    entry_id VARCHAR,
    entry_lineup JSONB,
    entry_score NUMERIC(10, 2),
    entry_rank INT,
    entry_winnings NUMERIC(12, 2),
    source_file VARCHAR,
    payload JSONB,

    UNIQUE(contest_id, entry_id)
);

CREATE TABLE raw_actual_results (
    raw_id BIGINT PRIMARY KEY DEFAULT nextval('raw_id_seq'),
    ingested_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    league VARCHAR,  -- NBA, NFL
    season INT,
    game_date DATE,
    game_id VARCHAR,
    player_id VARCHAR,
    site_player_id VARCHAR,
    position VARCHAR,
    team VARCHAR,
    opponent VARCHAR,
    minutes_played NUMERIC(5, 2),
    actual_fpts NUMERIC(8, 2),
    is_starter BOOLEAN,
    payload JSONB,

    UNIQUE(game_id, player_id, league)
);
```

### Tier 2: DERIVED (Versioned, Normalized)

```sql
-- CANONICAL ENTITIES
CREATE TABLE dim_players (
    player_id VARCHAR PRIMARY KEY,
    league VARCHAR,  -- NBA, NFL
    canonical_name VARCHAR,
    position VARCHAR,
    birth_date DATE,
    height NUMERIC(5, 2),
    weight NUMERIC(5, 1),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    active BOOLEAN DEFAULT TRUE
);

CREATE TABLE dim_teams (
    team_id VARCHAR PRIMARY KEY,
    league VARCHAR,
    canonical_code VARCHAR,
    full_name VARCHAR,
    city VARCHAR,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE dim_games (
    game_id VARCHAR PRIMARY KEY,
    league VARCHAR,
    season INT,
    game_date DATE,
    game_datetime_utc TIMESTAMP WITH TIME ZONE,
    home_team_id VARCHAR REFERENCES dim_teams(team_id),
    away_team_id VARCHAR REFERENCES dim_teams(team_id),
    venue VARCHAR,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE dim_slates (
    slate_id VARCHAR PRIMARY KEY,
    league VARCHAR,
    site VARCHAR,  -- FanDuel, DraftKings
    slate_date DATE,
    slate_type VARCHAR,  -- Main, Showdown, Captain Mode, etc.
    lock_time TIMESTAMP WITH TIME ZONE,
    salary_cap INT,
    roster_slots VARCHAR[],  -- ARRAY of positions
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- SITE PLAYER MAPPINGS
CREATE TABLE fact_site_players (
    site_player_id VARCHAR PRIMARY KEY,
    slate_id VARCHAR REFERENCES dim_slates(slate_id),
    player_id VARCHAR REFERENCES dim_players(player_id),
    site VARCHAR,
    salary INT,
    position VARCHAR,
    team VARCHAR,
    game_id VARCHAR REFERENCES dim_games(game_id),
    injury_status VARCHAR,  -- O, D, GTD, null
    game_start_time TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    UNIQUE(slate_id, site_player_id)
);

-- ACTUAL GAME RESULTS (Immutable truth)
CREATE TABLE fact_actual_player_results (
    result_id BIGINT PRIMARY KEY DEFAULT nextval('result_id_seq'),
    game_id VARCHAR REFERENCES dim_games(game_id),
    player_id VARCHAR REFERENCES dim_players(player_id),
    league VARCHAR,
    position VARCHAR,
    minutes_played NUMERIC(5, 2),
    is_starter BOOLEAN,
    fpts NUMERIC(8, 2),  -- DFS points (site agnostic)
    actual_stats JSONB,  -- Raw box score
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    UNIQUE(game_id, player_id)
);
```

### Tier 3: OPERATIONAL (Time-Versioned Snapshots)

```sql
-- SIGNALS TABLE (core intelligence layer)
CREATE TABLE operational_signals (
    signal_id BIGINT PRIMARY KEY DEFAULT nextval('signal_id_seq'),
    signal_type VARCHAR,  -- injury_out, starter, ownership_projection, etc.
    entity_type VARCHAR,  -- player, game, slate, etc.
    entity_id VARCHAR,  -- player_id, game_id, etc.
    league VARCHAR,
    slate_id VARCHAR REFERENCES dim_slates(slate_id),
    timestamp_utc TIMESTAMP WITH TIME ZONE,  -- When signal was created
    source VARCHAR,  -- beatwriter, official, nba_api, model, etc.
    source_confidence NUMERIC(3, 2),  -- 0.0 - 1.0
    decay_profile VARCHAR,  -- fast (15min), medium (1h), slow (24h), none
    validity_start TIMESTAMP WITH TIME ZONE,
    validity_end TIMESTAMP WITH TIME ZONE,
    applies_to JSONB,  -- {minutes, usage, projection, ownership, ...}
    cannot_apply_to JSONB,  -- explicit deny list
    signal_payload JSONB,  -- {value, metadata, source_id, ...}
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ingested_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_signals_entity_time ON operational_signals(
    league, entity_type, entity_id, timestamp_utc DESC
);

-- STARTING LINEUP OPERATIONAL SIGNAL (special case, high cardinality)
CREATE TABLE operational_lineups (
    lineup_id BIGINT PRIMARY KEY DEFAULT nextval('lineup_id_seq'),
    game_id VARCHAR REFERENCES dim_games(game_id),
    player_id VARCHAR REFERENCES dim_players(player_id),
    league VARCHAR,
    status VARCHAR,  -- confirmed_starter, expected_starter, benched, unknown
    source_type VARCHAR,  -- official, beatwriter, model
    source_confidence NUMERIC(3, 2),
    announced_at TIMESTAMP WITH TIME ZONE,
    valid_until TIMESTAMP WITH TIME ZONE,
    minutes_ceiling_adjustment NUMERIC(3, 1),  -- e.g., +3 or -2
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_lineups_game_time ON operational_lineups(
    game_id, announced_at DESC
);

-- PROJECTION SNAPSHOTS (predictions with input hash)
CREATE TABLE operational_projections (
    projection_id BIGINT PRIMARY KEY DEFAULT nextval('projection_id_seq'),
    slate_id VARCHAR REFERENCES dim_slates(slate_id),
    site_player_id VARCHAR,
    player_id VARCHAR REFERENCES dim_players(player_id),
    build_time TIMESTAMP WITH TIME ZONE,  -- When projection was built
    as_of_time TIMESTAMP WITH TIME ZONE,  -- Data cutoff time
    version INT,  -- Schema version for reproducibility
    inputs_hash VARCHAR,  -- Hash of all input signals + parameters
    median_fpts NUMERIC(8, 2),
    floor_fpts NUMERIC(8, 2),
    ceiling_fpts NUMERIC(8, 2),
    volatility NUMERIC(5, 3),
    confidence NUMERIC(3, 2),
    projection_distribution JSONB,  -- {percentiles: {10: X, 25: Y, 50: Z, ...}}
    signal_contribution JSONB,  -- {signal_type: {value, weight}, ...}
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_projections_slate_build ON operational_projections(
    slate_id, build_time DESC
);
```

### Tier 4: EVALUATION (Truth vs Prediction)

```sql
-- PROJECTION vs ACTUAL ACCURACY
CREATE TABLE evaluation_projection_accuracy (
    accuracy_id BIGINT PRIMARY KEY DEFAULT nextval('accuracy_id_seq'),
    slate_id VARCHAR REFERENCES dim_slates(slate_id),
    player_id VARCHAR REFERENCES dim_players(player_id),
    site_player_id VARCHAR,
    league VARCHAR,
    position VARCHAR,
    game_id VARCHAR REFERENCES dim_games(game_id),
    team VARCHAR,
    projection_id BIGINT REFERENCES operational_projections(projection_id),
    projected_median NUMERIC(8, 2),
    projected_floor NUMERIC(8, 2),
    projected_ceiling NUMERIC(8, 2),
    projected_confidence NUMERIC(3, 2),
    actual_fpts NUMERIC(8, 2),
    is_starter BOOLEAN,
    error_fpts NUMERIC(8, 2),
    error_abs NUMERIC(8, 2),
    percentile_rank INT,  -- Where actual fell in distribution
    contest_finish JSONB,  -- {rank, score, winnings, ...}
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_accuracy_slate_position ON evaluation_projection_accuracy(
    slate_id, position, created_at DESC
);

-- SOURCE RELIABILITY TRACKING
CREATE TABLE evaluation_source_reliability (
    reliability_id BIGINT PRIMARY KEY DEFAULT nextval('reliability_id_seq'),
    source VARCHAR,
    signal_type VARCHAR,
    league VARCHAR,
    metric_date DATE,
    total_signals INT,
    hit_count INT,  -- Signals where actual matched prediction within threshold
    false_positive_count INT,
    avg_lead_time_minutes INT,  -- How far in advance signal was issued
    confidence_avg NUMERIC(3, 2),
    hit_rate NUMERIC(3, 2),  -- hit_count / total_signals
    false_positive_rate NUMERIC(3, 2),
    reliability_score NUMERIC(3, 2),  -- Composite reliability 0.0-1.0
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- BIAS TRACKING (by team, position, context)
CREATE TABLE evaluation_bias (
    bias_id BIGINT PRIMARY KEY DEFAULT nextval('bias_id_seq'),
    slate_id VARCHAR REFERENCES dim_slates(slate_id),
    league VARCHAR,
    bias_dimension VARCHAR,  -- team, position, game_context, slate_type
    dimension_value VARCHAR,
    total_players INT,
    avg_error NUMERIC(8, 3),  -- Signed error
    avg_error_abs NUMERIC(8, 3),
    rmse NUMERIC(8, 3),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

## 3. DATA CONTRACTS (Signal Specs)

Every signal MUST conform to this structure:

```python
# dataclass
@dataclass
class SignalSpec:
    signal_type: str  # injury_out, starter, ownership, fatigue, matchup_context, etc.
    entity_type: str  # player, game, slate
    entity_id: str  # player_id, game_id, slate_id
    league: str  # NBA, NFL

    timestamp_utc: datetime  # When signal was generated
    source: str  # beatwriter, official, nba_api, model, ownership_service, etc.
    source_confidence: float  # 0.0-1.0

    decay_profile: str  # fast (15min), medium (1h), slow (24h), none
    validity_start: datetime  # Start of validity window
    validity_end: Optional[datetime]  # End of validity window (null = open-ended)

    applies_to: List[str]  # [minutes, usage, projection, ownership, constraints]
    cannot_apply_to: List[str]  # Explicit deny list

    payload: Dict[str, Any]  # Signal-specific data
    # Examples:
    # injury_out: {reason, severity, expected_return, ...}
    # starter: {status: confirmed/expected, announces_via, confidence}
    # ownership: {projected_pct, source_model, percentile}

# Computed fields (added by system):
effective_confidence: float  # source_confidence * decay_factor(age)
is_valid_at(timestamp) -> bool
remaining_validity: timedelta
```

**Common Signal Types:**

| Type                 | Source     | Decay        | Applies To                | Cannot Apply To  |
| -------------------- | ---------- | ------------ | ------------------------- | ---------------- |
| injury_out           | official   | none         | minutes, usage            | efficiency, fppm |
| injury_in            | official   | none         | minutes, usage            | -                |
| confirmed_starter    | official   | none         | minutes, usage, ownership | efficiency       |
| expected_starter     | beatwriter | medium (1h)  | minutes, usage            | -                |
| roster_change        | official   | none         | usage, pathways           | -                |
| ownership_projection | model      | fast (15min) | ownership                 | -                |
| matchup_context      | nba_api    | slow (24h)   | projection                | -                |
| fatigue_signal       | model      | medium (1h)  | efficiency, usage         | -                |

---

## 4. STEP-BY-STEP MIGRATION PLAN

### Phase 1: Foundation (Week 1)

1. Set up new `/backend` directory structure
2. Implement `core/` modules (config, logging, time utils)
3. Implement `db/` modules (DuckDB init, schema, migrations)
4. Write tests for DB layer

### Phase 2: Ingest Layer (Week 2)

1. Implement `ingest/` connectors for FD/DK CSV
2. Implement raw table writers (append-only, idempotent)
3. Implement `idempotency.py` (dedup via file_hash)
4. Write tests for ingest layer

### Phase 3: Canonicalization + Derive (Week 2-3)

1. Implement `derive/canonicalize.py` (build dim tables)
2. Implement `derive/features.py` (minutes, usage baselines)
3. Implement `derive/modifiers.py` (injuries, starters, depth)
4. Write tests

### Phase 4: Signals + Overrides (Week 3)

1. Implement `signals/spec.py` (dataclass)
2. Implement `signals/store.py` (CRUD + time-range queries)
3. Implement `signals/decay.py` (confidence decay math)
4. Implement `signals/overrides.py` (priority hierarchy)
5. Implement `signals/snapshot.py` (decision snapshot builder)
6. Write tests for signal logic

### Phase 5: Projection + Evaluation (Week 3-4)

1. Implement `projection/models.py` and `builder.py`
2. Implement `projection/rules.py` (priority hierarchy, validity)
3. Implement `evaluation/` modules (accuracy, bias, source reliability)
4. Write tests

### Phase 6: API Layer (Week 4)

1. Implement FastAPI app in `main.py`
2. Implement all endpoints in `api/` modules
3. Ensure `/docs` and `/openapi.json` work
4. Write API smoke tests

### Phase 7: Jobs + CLI (Week 4)

1. Implement `jobs/cli.py` (Click CLI)
2. Implement all job entry points
3. Create run scripts

### Phase 8: Integration Tests + Demo (Week 4-5)

1. Write end-to-end integration tests
2. Create `run_local_demo.sh` with sample data
3. Document everything

---

## 5. KEY DESIGN DECISIONS

1. **Parquet for Raw Data**: RAW tables can optionally be exported to Parquet for archival; DuckDB views handle in-memory access.
2. **Idempotency via Hash**: Every ingestion includes a `file_hash` or `source_hash` for safe re-runs.
3. **JSONB Payloads**: Store original source data in JSONB to handle schema drift without migrations.
4. **Time-Safe All Computations**: All timestamps stored as UTC; decay functions timezone-aware.
5. **Signal Snapshot at T**: Build a complete decision state as-of a specific time T; enables auditing + reproducibility.
6. **Separated Truth vs Decision**: `fact_actual_player_results` (truth) vs `operational_projections` (decision).
7. **Source Reliability as Adaptive Weighting**: Post-slate, recompute source reliability; automatically down-weight unreliable sources.
8. **No Single-Point Projections**: Always store distributions (median, floor, ceiling, percentiles, volatility).

---

## 6. RUN COMMANDS (Preview - Will Detail After Implementation)

```bash
# Setup
python -m venv venv
source venv/bin/activate  # or venv\Scripts\activate on Windows
pip install -r requirements.txt

# Initialize DB
python -m backend.jobs.cli init-db

# Ingest sample slate
python -m backend.jobs.cli ingest-slate-csv \
  --league nba \
  --site fanduel \
  --csv-file backend/slates/sample_fd_nba.csv

# Build projections as-of time T
python -m backend.jobs.cli build-projections \
  --slate-id "nba_fanduel_20260122" \
  --as-of-time "2026-01-22T23:00:00Z"

# Ingest results + evaluate
python -m backend.jobs.cli ingest-results \
  --slate-id "nba_fanduel_20260122" \
  --results-file results.csv

python -m backend.jobs.cli evaluate \
  --slate-id "nba_fanduel_20260122"

# Run API
python -m uvicorn backend.main:app --reload --host 0.0.0.0 --port 8000
# Visit http://localhost:8000/docs

# Run tests
pytest backend/tests/ -v
```

---

## NEXT STEPS

1. Create the full file tree
2. Implement all modules in order
3. Write comprehensive tests
4. Provide working demo
5. Document API + schema

Let me proceed with **implementation** now.
