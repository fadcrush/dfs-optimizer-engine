# End-to-End DFS Platform Workflow Documentation

Complete reference for running the entire backend pipeline from data ingestion through self-correcting evaluation.

## System Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                  DFS PLATFORM BACKEND STACK                      │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                   INPUT LAYER                            │   │
│  │  FanDuel CSV | DraftKings CSV | API Feeds | Box Scores │   │
│  └────────────────────┬────────────────────────────────────┘   │
│                       │                                           │
│  ┌────────────────────▼────────────────────────────────────┐   │
│  │              INGEST & VALIDATION LAYER                  │   │
│  │  • Schema drift detection                              │   │
│  │  • Deterministic idempotency (SHA256)                  │   │
│  │  • Column validation & type coercion                   │   │
│  │  Persistence: RAW_SLATES table                         │   │
│  └────────────────────┬────────────────────────────────────┘   │
│                       │                                           │
│  ┌────────────────────▼────────────────────────────────────┐   │
│  │          CANONICALIZATION & CACHING LAYER              │   │
│  │  • Player ID normalization (league + pk)               │   │
│  │  • Team mapping & game linking                         │   │
│  │  • LRU cache for performance                           │   │
│  │  Persistence: PLAYERS, TEAMS, GAMES tables             │   │
│  └────────────────────┬────────────────────────────────────┘   │
│                       │                                           │
│  ┌────────────────────▼────────────────────────────────────┐   │
│  │            FEATURE ENGINEERING LAYER                    │   │
│  │  • Minutes & usage baselines (historical rolling avg)   │   │
│  │  • Matchup context (opponent strength, pace)           │   │
│  │  • Opportunity modifiers (starter status, depth)       │   │
│  │  Persistence: FEATURES table                           │   │
│  └────────────────────┬────────────────────────────────────┘   │
│                       │                                           │
│  ┌────────────────────▼────────────────────────────────────┐   │
│  │           SIGNALS & OVERRIDE LAYER                      │   │
│  │  • Injury tracking (confidence-weighted decay)         │   │
│  │  • Starter status (confirmed vs expected)              │   │
│  │  • Fatigue signals (game load tracking)                │   │
│  │  • 5-level priority hierarchy enforcement              │   │
│  │  Persistence: SIGNALS, DECISION_SNAPSHOTS tables       │   │
│  └────────────────────┬────────────────────────────────────┘   │
│                       │                                           │
│  ┌────────────────────▼────────────────────────────────────┐   │
│  │        PROJECTION BUILDING LAYER (Distribution-based)  │   │
│  │  • Floor: conservative estimate (10th percentile)       │   │
│  │  • Median: expected value (50th percentile)             │   │
│  │  • Ceiling: upside case (90th percentile)               │   │
│  │  • Volatility: (ceiling - floor) / median               │   │
│  │  • Confidence: signal-weighted (0.0-1.0)                │   │
│  │  • Reproducibility: inputs_hash for version control     │   │
│  │  Persistence: PROJECTIONS table                         │   │
│  └────────────────────┬────────────────────────────────────┘   │
│                       │                                           │
│  ┌────────────────────▼────────────────────────────────────┐   │
│  │                  COMPARISON LAYER                        │   │
│  │  Contest Results ingestion after games complete        │   │
│  │  Persistence: CONTEST_RESULTS table                    │   │
│  └────────────────────┬────────────────────────────────────┘   │
│                       │                                           │
│  ┌────────────────────▼────────────────────────────────────┐   │
│  │          EVALUATION & ACCURACY LAYER                    │   │
│  │  • Metrics: RMSE, MAE, Hit Rate, Bias, Correlation     │   │
│  │  • Percentile ranking vs historical                     │   │
│  │  • Dimension breakdowns (by game, position, salary)     │   │
│  │  Persistence: PROJECTION_ACCURACY, BIAS_ANALYSIS       │   │
│  └────────────────────┬────────────────────────────────────┘   │
│                       │                                           │
│  ┌────────────────────▼────────────────────────────────────┐   │
│  │     SOURCE RELIABILITY & SELF-CORRECTION LAYER          │   │
│  │  • Track source quality over time                       │   │
│  │  • Upweight accurate sources (RMSE < median)            │   │
│  │  • Downweight inaccurate sources (RMSE > 1.25x median) │   │
│  │  • Feedback loops for next slate improvements           │   │
│  │  Persistence: SOURCE_RELIABILITY, FEEDBACK_RESPONSES    │   │
│  └────────────────────────────────────────────────────────┘   │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
```

## Operational Workflows

### Workflow 1: Day-of-Slate (Pre-Contest)

**Time**: Morning before games

```
1. INGEST LATEST SLATE
   python backend/cli.py ingest-slate-csv \
       --file FanDuel-NBA-2026_01_22.csv \
       --site fanduel

   Output: Slate created (fd_nba_20260122)
           12 players validated and stored

2. BUILD PROJECTIONS AT LOCK TIME
   python backend/cli.py build-projections \
       --slate-id fd_nba_20260122 \
       --as-of-time "2026-01-22T23:59:00Z"

   Output: 12 projections with:
           - Floor/median/ceiling estimates
           - Volatility scores
           - Confidence weights
           - Reproducible inputs hash

3. EXPORT PROJECTIONS (for lineup builder)
   python backend/cli.py status

   Shows: Projection counts, confidence distribution
```

**Implementation Time**: ~2 minutes
**Automation Trigger**: Cron job 1 hour before lock
**Output**: Projections stored in database, ready for lineup optimization

---

### Workflow 2: Post-Contest (Evaluation)

**Time**: After all games complete

```
1. INGEST CONTEST RESULTS
   python backend/cli.py ingest-results \
       --file contest_results_20260122.csv

   Output: 12 actual scores recorded
           Linked to projections via player_id

2. EVALUATE PROJECTION ACCURACY
   python backend/cli.py evaluate \
       --slate-id fd_nba_20260122

   Computed Metrics:
   ├─ RMSE: 4.2 FPPG (lower is better)
   ├─ MAE: 3.1 FPPG (average miss)
   ├─ Hit Rate: 83% (correct direction)
   ├─ Bias: -0.3 FPPG (slightly conservative)
   ├─ Correlation: 0.91 (strong)
   └─ Percentile Rank: 72% (vs 30-day history)

   Source Reliability Updates:
   ├─ FanDuel Source: UPWEIGHT (RMSE = 3.8)
   ├─ DraftKings Source: DOWNWEIGHT (RMSE = 5.2)
   └─ Minutes Baseline: MAINTAIN (RMSE = 3.9)

3. STORE EVALUATION RESULTS
   Persistence: PROJECTION_ACCURACY + SOURCE_RELIABILITY

   Next slate projections will use updated weights
```

**Implementation Time**: ~1 minute
**Automation Trigger**: Cron job 2 hours after last game end
**Output**: Accuracy metrics stored, source reliability updated for next slate

---

### Workflow 3: Historical Backtest

**Time**: Weekly/after algorithm changes

```
1. SELECT DATE RANGE
   python backend/cli.py backtest \
       --from-date 2026-01-01 \
       --to-date 2026-01-31 \
       --league NBA

   Process for each slate in range:
   ├─ Load slate definition (players, salaries)
   ├─ Rebuild projections at original time
   ├─ Compare vs actual results
   ├─ Compute accuracy metrics
   ├─ Update source reliability tracking
   └─ Generate recommendation

2. GENERATE BACKTEST REPORT

   Daily Trends:
   ├─ Jan 1: RMSE 3.8, Hit Rate 85%, Bias -0.1
   ├─ Jan 8: RMSE 4.2, Hit Rate 81%, Bias +0.4
   ├─ Jan 15: RMSE 3.5, Hit Rate 87%, Bias -0.2
   ├─ Jan 22: RMSE 4.0, Hit Rate 83%, Bias -0.3
   └─ Jan 29: RMSE 3.9, Hit Rate 84%, Bias +0.1

   Overall: RMSE 3.88, Hit Rate 84%, Correlation 0.89

   Source Rankings:
   1. FanDuel Data: 0.91 reliability
   2. Minutes Baseline: 0.88 reliability
   3. Usage Baseline: 0.85 reliability
   4. Matchup Context: 0.82 reliability

   Recommendations:
   - Increase FanDuel weight to 1.2x (best performer)
   - Recalibrate usage baseline (trending low)
   - Investigate Jan 8 underperformance
   - Add fatigue signal for back-to-back games

3. IMPLEMENT CHANGES
   Based on backtest findings, update configuration
   for next projection cycle
```

**Implementation Time**: ~5 minutes (1-month range)
**Automation Trigger**: Manual or weekly scheduled
**Output**: Backtest report, optimization recommendations

---

## Detailed Command Reference

### 1. Setup Database

```bash
python backend/cli.py setup-database
```

**What It Does**:

- Creates DuckDB engine (or connects to Postgres)
- Executes 4 migrations
- Creates 18 tables
- Initializes schema registry
- Verifies all tables accessible

**Tables Created**:

```
RAW TIER (immutable ingestion):
├─ fd_slates: FanDuel slate definitions
├─ dk_slates: DraftKings slate definitions
└─ contest_results: Actual game results

DERIVED TIER (canonicalized dimensions):
├─ players: Normalized player master
├─ teams: Team master data
├─ games: Game-level metadata
└─ features: Computed features (baseline, matchup)

OPERATIONAL TIER (decision points):
├─ slates: Slate master
├─ projections: Point-in-time projections
├─ signals: Active signals and overrides
└─ decision_snapshots: Signal application audit trail

EVALUATION TIER (feedback loops):
├─ projection_accuracy: Accuracy metrics per slate
├─ source_reliability: Source quality tracking
└─ feedback_responses: Self-correction log
```

**Dry-Run**:

```bash
python backend/cli.py setup-database --dry-run
# Output: Lists migrations that would run
```

---

### 2. Ingest FanDuel Slate

```bash
python backend/cli.py ingest-slate-csv \
    --file path/to/FanDuel-NBA-2026_01_22.csv \
    --site fanduel
```

**CSV Format Expected**:

```
Id,First Name,Last Name,Position,Salary,Game,Team,Injury Indicator
```

**Processing**:

1. Read CSV
2. Validate schema (required columns)
3. Type coerce:
   - `Id` → player_id (int)
   - `Salary` → salary (int)
   - `Position` → enum (PG|SG|SF|PF|C)
   - `Game` → parse "AWAY@HOME"
4. Deduplicate via SHA256 hash of entire row
5. Insert into `fd_slates` (RAW tier)

**Validation**:

- Missing columns: SKIP row, log warning
- Invalid salary ($3,500-$12,000): SKIP, log error
- Duplicate row (same hash): SKIP with info log
- Invalid position: SKIP, log error

**Example Output**:

```
✓ Read 12 records from FanDuel-NBA-2026_01_22.csv
✓ Valid: 12
✗ Invalid: 0 (skipped)
✓ Duplicates: 0 (already ingested)
✓ Inserted: 12 new rows
✓ Created slate: fd_nba_20260122
```

**Dry-Run**:

```bash
python backend/cli.py ingest-slate-csv \
    --file sample.csv \
    --site fanduel \
    --dry-run

Output:
  Would read 12 records
  Would validate schema
  Would create slate fd_nba_20260122
  (No data persisted)
```

---

### 3. Ingest DraftKings Slate

```bash
python backend/cli.py ingest-slate-csv \
    --file path/to/DraftKings-NBA-2026_01_22.csv \
    --site draftkings
```

**CSV Format Expected**:

```
ID,First Name,Last Name,Salary,Game,Position,Injury
```

**Key Differences from FanDuel**:

- Game format: `AWAY-HOME` (e.g., LAL-BOS)
- Salary range: $3,000-$15,000
- Captain Mode support (1.5x salary, 1.5x points)
- Position-salary relationships different

**Processing**:

- Same as FanDuel (schema drift detection, dedup, validation)
- Creates slate `dk_nba_20260122`

---

### 4. Build Projections

```bash
python backend/cli.py build-projections \
    --slate-id fd_nba_20260122 \
    --as-of-time "2026-01-22T23:59:00Z"
```

**Processing Pipeline**:

```
For each player in slate:
│
├─ Step 1: LOAD SIGNALS & OVERRIDES
│  ├─ Injury signals (OUT, day-to-day, probable)
│  ├─ Starter status (confirmed starter, expected)
│  ├─ Fatigue signals (rest days, back-to-back)
│  └─ Apply 5-level priority hierarchy
│
├─ Step 2: COMPUTE MINUTES BASELINE
│  ├─ Last 30 games rolling average
│  ├─ Adjust for starter status signal
│  ├─ Apply rest day reduction (if applicable)
│  └─ Output: floor=15, ceiling=32 (range)
│
├─ Step 3: COMPUTE USAGE BASELINE
│  ├─ Last 30 games rolling average (% of team possessions)
│  ├─ Adjust for depth chart position
│  ├─ Adjust for matchup (opponent defensive rating)
│  └─ Output: floor=0.18, ceiling=0.28 (range)
│
├─ Step 4: COMPUTE MATCHUP CONTEXT
│  ├─ Opponent defensive efficiency
│  ├─ Pace of play
│  ├─ Rest differential (own team vs opponent)
│  └─ Home/away factor
│
├─ Step 5: BUILD FPPG DISTRIBUTION
│  ├─ Minutes × Usage × Efficiency = Expected FPPG
│  ├─ Historical volatility around baseline
│  ├─ Confidence score (0.0-1.0):
│  │   ├─ 0.95: All signals aligned, recent data
│  │   ├─ 0.85: Some uncertainty, older data
│  │   └─ 0.70: Multiple conflicting signals
│  └─ Output:
│     ├─ Floor: 30.0 (10th percentile)
│     ├─ Median: 45.0 (50th percentile)
│     ├─ Ceiling: 60.0 (90th percentile)
│     ├─ Volatility: (60-30)/45 = 0.67
│     └─ Confidence: 0.85
│
└─ Step 6: STORE PROJECTION
   ├─ inputs_hash: SHA256(player_id + game_id + signals + features)
   │                Ensures reproducibility
   ├─ Versioning: Track projection over time
   └─ Persist: PROJECTIONS table
```

**Output Format**:

```json
{
  "player_id": "fd_12345",
  "game_id": "game_20260122_1",
  "slate_id": "fd_nba_20260122",
  "league": "NBA",
  "floor_fppg": 30.0,
  "median_fppg": 45.0,
  "ceiling_fppg": 60.0,
  "volatility": 0.67,
  "confidence": 0.85,
  "inputs_hash": "abc123def456...",
  "created_at": "2026-01-22T23:59:00Z"
}
```

**Example Output**:

```
✓ Loaded slate: fd_nba_20260122
✓ Processing 12 players...
  ├─ LeBron James (fd_12345)
  │  └─ Projection: 45.0 ± 15.0 (conf: 0.85)
  ├─ Anthony Davis (fd_12346)
  │  └─ Projection: 42.0 ± 14.0 (conf: 0.84)
  └─ ... (10 more)
✓ Built 12 projections
✓ Average confidence: 0.84
✓ Stored in PROJECTIONS table
```

---

### 5. Ingest Contest Results

```bash
python backend/cli.py ingest-results \
    --file contest_results_20260122.csv
```

**CSV Format Expected**:

```
player_id,actual_fppg,game_id,slate_id,league
fd_12345,48.3,game_20260122_1,fd_nba_20260122,NBA
```

**Processing**:

1. Read CSV
2. Validate columns: player_id, actual_fppg, game_id, slate_id, league
3. Type coerce: actual_fppg → float
4. Lookup projection by player_id + slate_id
5. If found: Link result to projection
6. If not found: Log warning (orphaned result)
7. Insert into CONTEST_RESULTS

**Linking Logic**:

```
For each result:
├─ Find projection where:
│  ├─ projection.player_id == result.player_id
│  ├─ projection.slate_id == result.slate_id
│  └─ projection.league == result.league
└─ Create PROJECTION_ACCURACY record
   ├─ projection_id
   ├─ projected_fppg (median)
   ├─ projected_floor
   ├─ projected_ceiling
   ├─ projected_confidence
   ├─ actual_fppg
   └─ accuracy metrics (computed later)
```

**Example Output**:

```
✓ Read 12 results from contest_results_20260122.csv
✓ Valid: 12
✓ Linked to projections: 12
✗ Orphaned (no projection): 0
✓ Created PROJECTION_ACCURACY records: 12
```

---

### 6. Evaluate Accuracy

```bash
python backend/cli.py evaluate --slate-id fd_nba_20260122
```

**Metrics Computed**:

#### RMSE (Root Mean Squared Error)

```
RMSE = sqrt(sum((projected - actual)² / n))

Example:
  LeBron: proj=45.0, actual=48.3, error=3.3²=10.89
  Anthony: proj=42.0, actual=41.5, error=0.5²=0.25
  ...
  RMSE = sqrt(sum / 12) = 4.2 FPPG

Interpretation:
  < 3.5: Excellent (top 20%)
  3.5-4.5: Good (top 40%)
  4.5-5.5: Average (middle 20%)
  > 5.5: Poor (bottom 20%)
```

#### MAE (Mean Absolute Error)

```
MAE = sum(|projected - actual| / n)

Example:
  LeBron: |45.0 - 48.3| = 3.3
  Anthony: |42.0 - 41.5| = 0.5
  ...
  MAE = sum / 12 = 3.1 FPPG

Interpretation:
  Average miss per player (absolute value)
  Useful for lineups: "My projections are off by ±3.1"
```

#### Hit Rate

```
Hit Rate = correct_directions / total_players

Example:
  LeBron: proj=45.0, actual=48.3 ✓ (predicted higher than baseline)
  Anthony: proj=42.0, actual=41.5 ✓ (predicted lower than baseline)
  ...
  Hit Rate = 10/12 = 83%

Interpretation:
  How often did we get the direction right?
  > 65%: Predictive signal exists
  < 55%: No better than random
```

#### Bias

```
Bias = mean(projected - actual)

Example:
  LeBron: 45.0 - 48.3 = -3.3
  Anthony: 42.0 - 41.5 = +0.5
  ...
  Bias = sum / 12 = -0.3 FPPG

Interpretation:
  Positive bias: We overestimate points
  Negative bias: We underestimate points
  Use to calibrate: If bias = -0.3, add 0.3 to all projections
```

#### Correlation

```
Correlation = covariance(projected, actual) / (σ_projected × σ_actual)

Range: -1.0 to +1.0
  +1.0: Perfect positive correlation
  +0.90: Excellent correlation
  +0.70: Good correlation
  +0.50: Moderate correlation
  < 0.50: Weak signal

Interpretation:
  Correlation 0.91 = Strong predictive quality
  As projection increases, actual tends to increase
```

#### Percentile Rank

```
Percentile Rank = position in sorted 30-day history

Example:
  Today's RMSE: 4.2
  30-day RMSE distribution: [3.2, 3.5, 3.8, 3.9, 4.0, 4.1, 4.2, 4.3, 4.5, ...]
  Percentile: 72% (better than 72% of recent days)

Interpretation:
  > 70%: Excellent day
  50-70%: Above average
  30-50%: Average
  < 30%: Below average
```

**Source Reliability Updates**:

```
For each projection source (FanDuel, Minutes Baseline, Usage Baseline, etc.):

1. Compare today's RMSE vs 30-day rolling median
2. If RMSE < median:
   ├─ Calculate upweight factor: 1.0 + (0.10 × (1 - RMSE/median))
   └─ Apply: Next slate will use higher weight
3. If RMSE > 1.25 × median:
   ├─ Calculate downweight factor: 1.0 - (0.10 × (RMSE/median - 1.25))
   └─ Apply: Next slate will use lower weight
4. If RMSE between median and 1.25×median:
   └─ No change (maintain current weight)

Example:
  FanDuel RMSE: 3.8
  30-day median: 4.0
  Status: UPWEIGHT (3.8 < 4.0)
  New weight: 1.0 + (0.10 × (1 - 3.8/4.0)) = 1.005

  Usage Baseline RMSE: 5.2
  30-day median: 4.0
  Status: DOWNWEIGHT (5.2 > 1.25 × 4.0)
  New weight: 1.0 - (0.10 × (5.2/4.0 - 1.25)) = 0.965
```

**Example Output**:

```
✓ Loaded 12 projection-result pairs

Accuracy Metrics:
├─ RMSE: 4.2 FPPG (72nd percentile)
├─ MAE: 3.1 FPPG
├─ Hit Rate: 83%
├─ Bias: -0.3 FPPG (slightly conservative)
└─ Correlation: 0.91

Source Reliability Updates:
├─ FanDuel Data
│  ├─ RMSE: 3.8 (median: 4.0)
│  ├─ Action: UPWEIGHT
│  └─ New weight: 1.005
├─ Minutes Baseline
│  ├─ RMSE: 3.9 (median: 4.0)
│  ├─ Action: MAINTAIN
│  └─ New weight: 1.000
└─ Usage Baseline
   ├─ RMSE: 5.2 (median: 4.0)
   ├─ Action: DOWNWEIGHT
   └─ New weight: 0.965

✓ Updated source reliability scores
✓ Ready for next slate projections
```

---

### 7. Backtest

```bash
python backend/cli.py backtest \
    --from-date 2026-01-01 \
    --to-date 2026-01-31 \
    --league NBA
```

**Process**:

```
For each day in range:
│
├─ Load all slates for that day
│  ├─ FanDuel slates
│  ├─ DraftKings slates
│  └─ Count: e.g., 5 slates on 2026-01-01
│
├─ For each slate:
│  ├─ Rebuild projections at original slate lock time
│  │  (Using signals & features available at that time)
│  ├─ Load contest results for that slate
│  ├─ Compute accuracy metrics (RMSE, MAE, Hit Rate, Bias)
│  ├─ Update source reliability scores
│  └─ Record day-level results
│
└─ Generate summary report:
   ├─ Date range: Jan 1-31
   ├─ Total slates processed: 147
   ├─ Overall metrics:
   │  ├─ RMSE: 4.1 FPPG
   │  ├─ MAE: 3.0 FPPG
   │  ├─ Hit Rate: 84%
   │  ├─ Bias: -0.2 FPPG
   │  └─ Correlation: 0.90
   └─ Recommendations based on trends
```

**Day-by-Day Breakdown**:

```
2026-01-01: 5 slates, 47 players
├─ RMSE: 3.9, Hit Rate: 85%, Confidence: 0.84
├─ FanDuel: 3 slates, 28 players
│  └─ RMSE: 3.7 (upweight to 1.010)
└─ DraftKings: 2 slates, 19 players
   └─ RMSE: 4.1 (maintain at 1.000)

2026-01-08: 4 slates, 39 players
├─ RMSE: 4.4, Hit Rate: 81%, Confidence: 0.82
├─ FanDuel: 2 slates, 21 players
│  └─ RMSE: 4.2 (maintain)
└─ DraftKings: 2 slates, 18 players
   └─ RMSE: 4.6 (downweight to 0.990)

[... 29 more days ...]

2026-01-31: 5 slates, 48 players
├─ RMSE: 4.0, Hit Rate: 83%, Confidence: 0.85
├─ FanDuel: 3 slates, 29 players
│  └─ RMSE: 3.8 (upweight to 1.015)
└─ DraftKings: 2 slates, 19 players
   └─ RMSE: 4.2 (maintain)
```

**Recommendations Generated**:

```
1. FanDuel source is performing best (avg RMSE: 3.8)
   → Increase weight to 1.02x (from 1.00x)
   → Expected improvement: +0.1-0.2 RMSE

2. Usage baseline trending low (actual > projection)
   → Recalibrate: Increase by 5%
   → Impact: May reduce bias from -0.2 to -0.1

3. Anomaly detected on 2026-01-08 (RMSE: 4.4)
   → Review for external factors (trades, injuries)
   → Impact: Investigate to prevent future outliers

4. Back-to-back games showing higher volatility
   → Add fatigue signal for second night
   → Expected improvement: +0.3 confidence on B2Bs

5. Home/away split: Away games are harder to predict
   → Consider separate models for home/away
   → Impact: May improve Hit Rate to 85%
```

---

### 8. System Status

```bash
python backend/cli.py status
```

**Output**:

```
DFS Platform Backend Status
═══════════════════════════════════════════════════════════

Database: DuckDB (dev mode)
Connected: ✓ (response: 2ms)

Data Coverage
─────────────────────────────────────────────────────────
Slates (FanDuel):      147 (2026-01-01 to 2026-01-31)
Slates (DraftKings):   89 (2026-01-05 to 2026-01-31)
Players:               1,243 unique
Teams:                 30 (NBA), 32 (NFL)
Games:                 347 total

Raw Data
─────────────────────────────────────────────────────────
FanDuel Raw Rows:      3,847
DraftKings Raw Rows:   2,156
Contest Results:       3,903

Canonicalized Data
─────────────────────────────────────────────────────────
Canonical Players:     1,243
Canonical Teams:       62
Canonical Games:       347
Features Computed:     3,847

Projections
─────────────────────────────────────────────────────────
Projections Created:   3,847
Total Versions:        5,821 (some rebuilt)
Unique Inputs Hashes:  3,847 (100% reproducible)
Average Confidence:    0.84

Accuracy Tracking
─────────────────────────────────────────────────────────
Evaluations Completed: 147 slates
Total Accuracies:      3,903
RMSE (30-day avg):     4.1 FPPG
RMSE (best day):       3.5 FPPG
RMSE (worst day):      4.8 FPPG

Source Reliability
─────────────────────────────────────────────────────────
FanDuel Data:          0.910 (upweighted to 1.015x)
Minutes Baseline:      0.885 (maintained at 1.000x)
Usage Baseline:        0.842 (downweighted to 0.965x)
Matchup Context:       0.808 (maintained at 1.000x)

Feedback Responses
─────────────────────────────────────────────────────────
Bias Corrections:      12 (applied to 3 sources)
Volatility Adjustments: 8 (back-to-back games)
New Signals Added:     2 (injury confirmation, rest day)

System Health
─────────────────────────────────────────────────────────
Last Evaluation:       2026-01-31 23:45:00 UTC
Time Since Last Run:   3 minutes ago
Next Scheduled Run:    2026-02-01 08:00:00 UTC
Anomalies Detected:    None
Cache Hit Rate:        94% (player dimension caching)

Recommendations
─────────────────────────────────────────────────────────
1. Usage baseline needs recalibration (down 5%)
2. Add fatigue signal for back-to-back games
3. Consider home/away separate models
4. Investigate Jan 8 underperformance
5. Update FanDuel weight to 1.02x (best performer)

═══════════════════════════════════════════════════════════
```

---

## Database Schema Reference

### RAW Tier (Immutable Ingestion)

**`fd_slates`**

```
slate_id (PK)       | String  | fd_nba_20260122
players_json        | JSON    | [{id, name, salary, ...}]
ingested_at         | DateTime| 2026-01-22T10:30:00Z
source_hash         | String  | SHA256(csv content)
```

**`dk_slates`**

```
slate_id (PK)       | String  | dk_nba_20260122
players_json        | JSON    | [{id, name, salary, ...}]
ingested_at         | DateTime| 2026-01-22T10:30:00Z
source_hash         | String  | SHA256(csv content)
```

**`contest_results`**

```
result_id (PK)      | Int     |
player_id           | String  | fd_12345
actual_fppg         | Float   | 48.3
game_id             | String  | game_20260122_1
slate_id            | String  | fd_nba_20260122
league               | Enum    | NBA | NFL
recorded_at         | DateTime|
```

### DERIVED Tier (Canonicalized)

**`players`**

```
player_id (PK)      | String  | nba_lebron_james
canonical_name      | String  | LeBron James
league               | String  | NBA
position            | Enum    | PG | SG | SF | PF | C
created_at          | DateTime|
```

**`teams`**

```
team_id (PK)        | String  | nba_lal
canonical_name      | String  | Los Angeles Lakers
league               | String  | NBA
abbreviation        | String  | LAL
created_at          | DateTime|
```

**`games`**

```
game_id (PK)        | String  | game_20260122_1
league               | String  | NBA
date                | Date    | 2026-01-22
away_team_id        | String  | nba_gsw
home_team_id        | String  | nba_lal
created_at          | DateTime|
```

**`features`**

```
feature_id (PK)     | Int     |
player_id (FK)      | String  | fd_12345
game_id (FK)        | String  | game_20260122_1
minutes_baseline_fl | Float   | 15.0
minutes_baseline_cl | Float   | 32.0
usage_baseline_fl   | Float   | 0.18
usage_baseline_cl   | Float   | 0.28
matchup_multiplier  | Float   | 1.05
created_at          | DateTime|
```

### OPERATIONAL Tier (Decision Points)

**`slates`**

```
slate_id (PK)       | String  | fd_nba_20260122
league               | String  | NBA
date                | Date    | 2026-01-22
num_players         | Int     | 12
created_at          | DateTime|
```

**`projections`**

```
projection_id (PK)  | Int     |
player_id (FK)      | String  | fd_12345
game_id (FK)        | String  | game_20260122_1
slate_id (FK)       | String  | fd_nba_20260122
league               | String  | NBA
floor_fppg          | Float   | 30.0
median_fppg         | Float   | 45.0
ceiling_fppg        | Float   | 60.0
volatility          | Float   | 0.67
confidence          | Float   | 0.85
inputs_hash         | String  | SHA256(inputs)
created_at          | DateTime|
version             | Int     | 1
```

**`signals`**

```
signal_id (PK)      | Int     |
player_id (FK)      | String  | fd_12345
slate_id (FK)       | String  | fd_nba_20260122
signal_type         | Enum    | INJURY | STARTER | FATIGUE
confidence          | Float   | 0.95
created_at          | DateTime|
valid_from          | DateTime|
valid_until         | DateTime|
```

**`decision_snapshots`**

```
snapshot_id (PK)    | Int     |
player_id (FK)      | String  | fd_12345
slate_id (FK)       | String  | fd_nba_20260122
override_level      | Int     | 1-5 (priority)
decision            | String  | OUT | IN | STARTER | FATIGUE
applied_at          | DateTime|
inputs_hash         | String  | SHA256(signals)
```

### EVALUATION Tier (Feedback Loops)

**`projection_accuracy`**

```
accuracy_id (PK)    | Int     |
projection_id (FK)  | Int     |
player_id (FK)      | String  | fd_12345
slate_id (FK)       | String  | fd_nba_20260122
projected_fppg      | Float   | 45.0
projected_floor     | Float   | 30.0
projected_ceiling   | Float   | 60.0
projected_conf      | Float   | 0.85
actual_fppg         | Float   | 48.3
rmse_contrib        | Float   | 10.89 (error²)
mae_contrib         | Float   | 3.3 (|error|)
hit                 | Boolean | true
bias_contrib        | Float   | -3.3 (proj - actual)
computed_at         | DateTime|
```

**`source_reliability`**

```
reliability_id (PK) | Int     |
source_name         | String  | FanDuel | MinutesBaseline
league               | String  | NBA
date                | Date    | 2026-01-31
rmse                | Float   | 3.8
mae                 | Float   | 2.9
hit_rate            | Float   | 0.85
bias                | Float   | -0.1
correlation         | Float   | 0.91
reliability_score   | Float   | 0.910
weight_multiplier   | Float   | 1.015
updated_at          | DateTime|
```

**`feedback_responses`**

```
feedback_id (PK)    | Int     |
evaluation_date     | Date    | 2026-01-31
source_name         | String  | Usage Baseline
change_type         | Enum    | UPWEIGHT | DOWNWEIGHT | MAINTAIN
previous_weight     | Float   | 1.000
new_weight          | Float   | 0.965
reason              | String  | RMSE > 1.25x median
expected_improvement| Float   | 0.15 (RMSE reduction)
applied_at          | DateTime|
```

---

## Reproducibility & Version Control

### Inputs Hash

Every projection includes `inputs_hash` for reproducibility:

```
inputs_hash = SHA256(
  player_id +
  game_id +
  slate_id +
  league +
  minutes_baseline_floor +
  minutes_baseline_ceiling +
  usage_baseline_floor +
  usage_baseline_ceiling +
  fppg_baseline +
  signal_override_level +
  signal_types +
  matchup_multiplier +
  as_of_time
)
```

**Use Cases**:

1. **Debugging**: Rebuild same projection to reproduce results
2. **Versioning**: Track when inputs changed
3. **Caching**: Cache projections by inputs hash
4. **Reproducibility**: Guarantee consistent results

**Example**:

```
Slate: fd_nba_20260122
Player: LeBron James (fd_12345)

First projection build (2026-01-22T18:00Z):
  inputs_hash: abc123...
  median_fppg: 45.0

Four hours later (2026-01-22T22:00Z):
  LeBron gets injured → Signal changes → inputs_hash: xyz789...
  New median_fppg: 38.0 (based on backup minutes expectations)

Post-game (2026-01-23T01:00Z):
  Actual FPPG: 40.1
  Can identify which projection was used (by inputs_hash)
  Can debug why signal was applied (by decision snapshot)
```

---

## Performance Characteristics

| Operation           | Time  | Throughput      | Notes                      |
| ------------------- | ----- | --------------- | -------------------------- |
| CSV Ingest (FD/DK)  | 2-5s  | 1,000 rows/sec  | Validation bottleneck      |
| Canonicalization    | 100ms | 100 players/sec | LRU cache hit after 1st    |
| Feature Computation | 200ms | 50 players/sec  | Baseline aggregations      |
| Projection Build    | 400ms | 30 players/sec  | Signal + distribution math |
| Evaluation          | 500ms | 20 slates/sec   | RMSE + bias computation    |
| Backtest (1 month)  | 5min  | 30 slates/min   | Full rebuild per slate     |
| Status Check        | 1s    | -               | 10 table queries           |

---

## Next Steps for Production

1. **Database Migration**

   ```bash
   # Update config.py
   DB_ENGINE=postgresql
   DB_HOST=prod.db.internal
   DB_PORT=5432

   # Run migrations on prod
   python backend/cli.py setup-database
   ```

2. **Historical Data Load**

   ```bash
   python backend/cli.py ingest-historical \
       --sources nba-stats fanduel \
       --season 2024-25
   ```

3. **API Deployment**

   ```bash
   python backend/api/main.py
   # Or: gunicorn backend.api.main:app
   ```

4. **Automation Setup**

   ```bash
   # Cron: Daily ingest at 9 AM
   0 9 * * * python backend/cli.py ingest-historical --sources fanduel

   # Cron: Post-game evaluation at 3 AM
   0 3 * * * python backend/cli.py evaluate --all-open-slates

   # Cron: Weekly backtest
   0 2 * * 1 python backend/cli.py backtest --from-date -7 --to-date today
   ```

5. **Monitoring & Alerts**
   ```bash
   # Add to status command output
   - Alert if RMSE > 5.5 (outlier day)
   - Alert if Hit Rate < 60% (degradation)
   - Alert if source reliability drops below 0.75
   - Alert if > 10% orphaned results
   ```
