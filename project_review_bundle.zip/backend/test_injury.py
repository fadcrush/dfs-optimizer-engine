"""
Quick test of injury service
"""

import asyncio
import os
from dotenv import load_dotenv
from services.injury_service import InjuryService, get_injury_updates, check_player_status

# Load environment variables
load_dotenv()

async def main():
    print("\n" + "="*60)
    print("🏥 TESTING INJURY SERVICE")
    print("="*60)
    
    # Test 1: Get injury updates
    print("\n📋 Test 1: Fetching injury updates...")
    result = await get_injury_updates()
    
    if result['success']:
        print(f"✅ Found {result['total_injured']} injured players")
        
        if result['injuries']:
            print("\nFirst 5 injured players:")
            for injury in result['injuries'][:5]:
                print(f"   • {injury['name']} ({injury['team']}) - {injury['injury_status']}")
    
    # Test 2: Get injury report
    print("\n📋 Test 2: Generating injury report...")
    service = InjuryService()
    report = service.get_injury_report_text()
    print(report)
    
    # Test 3: Check specific player
    print("\n📋 Test 3: Checking specific player status...")
    status = await check_player_status("LeBron James")
    print(f"   LeBron James: {status['player']['injury_status']}")
    
    print("\n✅ All tests complete!")
    print("="*60 + "\n")

if __name__ == "__main__":
    asyncio.run(main())
