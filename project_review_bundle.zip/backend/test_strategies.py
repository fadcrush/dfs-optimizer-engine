"""
Test contest strategies
"""

from services.contest_strategies import ContestStrategyManager

print("\n" + "="*80)
print("🎯 CONTEST STRATEGIES TEST")
print("="*80)

manager = ContestStrategyManager()

# List all strategies
print(f"\n📋 Available strategies: {manager.list_strategies()}")

# Test each strategy
for strategy_name in ['cash', 'large_gpp', 'small_gpp']:
    strategy = manager.get_strategy(strategy_name)

# Compare strategies
print(manager.compare_strategies())

print("="*80 + "\n")