"""API endpoint reference guide."""

# API ENDPOINTS IMPLEMENTED

## Base URL

http://localhost:8000/api/v1

## Health & Documentation

GET /health - Health check
GET /health/ready - Readiness check
GET /docs - OpenAPI UI (Swagger)
GET /openapi.json - OpenAPI schema

## Slates

GET /slates - List all slates (with filtering by league, site)
GET /slates/{slate_id} - Get specific slate details
GET /slates/{slate_id}/players - List players in slate

Query params:
?league=NBA - Filter by league
?site=FanDuel - Filter by site
?position=PG - Filter by position
?min_salary=5000 - Minimum salary
?max_salary=10000 - Maximum salary
?limit=100 - Result limit
?offset=0 - Pagination offset

## Projections

GET /projections/slate/{slate_id}

- Get all projections for a slate
  ?version=v1 - Projection version
  ?position=PG - Filter by position
  ?min_confidence=0.75 - Minimum confidence

GET /projections/player/{player_id}/game/{game_id}

- Get single projection
  ?version=v1 - Projection version

POST /projections/build-slate/{slate_id}

- Trigger projection building for entire slate
  ?as_of_time=2026-01-22T18:00:00Z - Decision timestamp
  ?version=v1 - Projection version

Response includes:

- median_fppg, floor_fppg, ceiling_fppg
- volatility, confidence (0-1)
- source_signals, contributing_factors
- inputs_hash (for reproducibility)

## Signals

GET /signals/slate/{slate_id}

- Get all signals active for slate at point-in-time
  ?as_of_time=... - Timestamp (default: now)
  ?signal_type=INJURY_OUT - Filter by signal type
  ?league=NBA - Filter by league

GET /signals/player/{player_id}

- Get all signals for a player
  ?league=NBA - League
  ?as_of_time=... - Timestamp
  ?include_expired=false - Include expired signals

Signal types:

- INJURY_OUT
- INJURY_IN
- CONFIRMED_STARTER
- EXPECTED_STARTER
- FATIGUE
- OWNERSHIP_PROJECTION
- MATCHUP_CONTEXT

## Ingestion

POST /ingest/fd-csv

- Upload FanDuel CSV
  Content-Type: multipart/form-data
  Form field: file (CSV file)

POST /ingest/dk-csv

- Upload DraftKings CSV
  Content-Type: multipart/form-data
  Form field: file (CSV file)

POST /ingest/results

- Upload contest results
  Content-Type: multipart/form-data
  Form field: file (CSV with player_id, actual_fppg)
  ?slate_id=... - Slate identifier

Response:
{
"status": "success",
"valid_records": 100,
"invalid_records": 5,
"total": 105,
"errors": [...]
}

## Evaluation

GET /evaluation/accuracy

- Get aggregated accuracy metrics
  ?slate_id=... - Filter by slate
  ?league=NBA - Filter by league
  ?lookback_days=30 - Lookback window

Returns:
{
"metrics": {
"rmse": 5.23, - Root Mean Squared Error
"mae": 3.45, - Mean Absolute Error
"hit_rate": 0.72, - % within floor/ceiling
"bias": 0.8, - Mean error (over/under-projection)
"average_percentile": 50.2,
"correlation": 0.85
},
"sample_size": 150
}

GET /evaluation/bias

- Get bias metrics by dimension
  ?league=NBA - Filter by league

Returns:
{
"bias_report": {
"by_league": {...},
"by_contest_type": {...},
"overbiased_groups": {...},
"underbiased_groups": {...}
}
}

GET /evaluation/source-reliability

- Get source reliability scores
  ?league=NBA - Filter by league

Returns:
{
"sources": [
{
"source": "official",
"signal_type": "INJURY_OUT",
"hit_rate": 0.95,
"false_positive_rate": 0.02,
"confidence_score": 0.93,
"total_signals": 120
}
]
}

## Example Usage

# 1. Health check

curl http://localhost:8000/api/v1/health

# 2. List slates

curl "http://localhost:8000/api/v1/slates?league=NBA&limit=5"

# 3. Get specific slate

curl http://localhost:8000/api/v1/slates/fd_nba_20260122

# 4. Get slate players

curl "http://localhost:8000/api/v1/slates/fd_nba_20260122/players?limit=50"

# 5. Get projections

curl "http://localhost:8000/api/v1/projections/slate/fd_nba_20260122?version=v1"

# 6. Get single projection

curl "http://localhost:8000/api/v1/projections/player/lbj_123/game/game_456?version=v1"

# 7. Get signals for slate

curl "http://localhost:8000/api/v1/signals/slate/fd_nba_20260122"

# 8. Get player signals

curl "http://localhost:8000/api/v1/signals/player/lbj_123?league=NBA"

# 9. Upload FanDuel CSV

curl -F "file=@slate.csv" http://localhost:8000/api/v1/ingest/fd-csv

# 10. Get accuracy metrics

curl "http://localhost:8000/api/v1/evaluation/accuracy?league=NBA&lookback_days=7"

# 11. Get bias metrics

curl "http://localhost:8000/api/v1/evaluation/bias?league=NBA"

# 12. Get source reliability

curl "http://localhost:8000/api/v1/evaluation/source-reliability?league=NBA"
