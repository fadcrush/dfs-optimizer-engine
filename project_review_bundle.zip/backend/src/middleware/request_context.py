"""
Request context middleware — structured JSON logging for every HTTP request.

Adds:
  - X-Request-ID header to every response (generated if not provided by client)
  - Structured log entry (JSON) at request start and completion
  - ContextVar `request_id` and `run_id` for downstream use

Log fields:
  {
    "ts":          "2026-02-19T14:35:01.234Z",
    "level":       "INFO",
    "evt":         "request_complete",
    "request_id":  "a3f2b1c4",
    "method":      "POST",
    "path":        "/api/runs",
    "status":      200,
    "duration_ms": 42,
    "run_id":      "...",       # extracted from path if present
    "slate_id":    "...",       # extracted from path if present
  }

Usage (in main.py):
    from middleware.request_context import RequestContextMiddleware
    app.add_middleware(RequestContextMiddleware)
"""
from __future__ import annotations

import json
import logging
import re
import time
import uuid
from contextvars import ContextVar
from typing import Any, Dict, Optional

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

# ---------------------------------------------------------------------------
# Context variables — accessible anywhere during request handling
# ---------------------------------------------------------------------------

request_id_var: ContextVar[str] = ContextVar("request_id", default="")
run_id_var: ContextVar[Optional[str]] = ContextVar("run_id", default=None)
slate_id_var: ContextVar[Optional[str]] = ContextVar("slate_id", default=None)

# ---------------------------------------------------------------------------
# JSON log handler
# ---------------------------------------------------------------------------

_UUID_RE = re.compile(
    r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", re.I
)

# Patterns that indicate what a path segment represents
_RUN_SEGMENT_RE = re.compile(r"/runs/([^/]+)")
_RESULT_SEGMENT_RE = re.compile(r"/results/([^/]+)")
_SLATE_SEGMENT_RE = re.compile(r"/slates/([^/]+)")


def _extract_ids_from_path(path: str) -> Dict[str, Optional[str]]:
    """Best-effort extraction of run_id / slate_id from the URL path."""
    run_id: Optional[str] = None
    slate_id: Optional[str] = None

    m = _RUN_SEGMENT_RE.search(path)
    if m and _UUID_RE.match(m.group(1)):
        run_id = m.group(1)

    m = _RESULT_SEGMENT_RE.search(path)
    if m and _UUID_RE.match(m.group(1)):
        run_id = run_id or m.group(1)

    m = _SLATE_SEGMENT_RE.search(path)
    if m and _UUID_RE.match(m.group(1)):
        slate_id = m.group(1)

    return {"run_id": run_id, "slate_id": slate_id}


class _JsonFormatter(logging.Formatter):
    """Emit each log record as a single-line JSON object."""

    def format(self, record: logging.LogRecord) -> str:
        payload: Dict[str, Any] = {
            "ts": self.formatTime(record, "%Y-%m-%dT%H:%M:%S"),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        # Merge any extra dict passed as `extra={...}`
        for k, v in record.__dict__.items():
            if k not in (
                "name", "msg", "args", "levelname", "levelno", "pathname",
                "filename", "module", "exc_info", "exc_text", "stack_info",
                "lineno", "funcName", "created", "msecs", "relativeCreated",
                "thread", "threadName", "processName", "process", "message",
                "taskName",
            ) and not k.startswith("_"):
                payload[k] = v
        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str)


def configure_json_logging(level: str = "INFO") -> None:
    """
    Replace the root handler with a JSON formatter.

    Call once at application startup (e.g. in lifespan).
    """
    root = logging.getLogger()
    root.setLevel(getattr(logging, level.upper(), logging.INFO))

    # Remove any existing handlers
    for h in list(root.handlers):
        root.removeHandler(h)

    handler = logging.StreamHandler()
    handler.setFormatter(_JsonFormatter())
    root.addHandler(handler)


_access_log = logging.getLogger("dfs.access")

# ---------------------------------------------------------------------------
# Middleware
# ---------------------------------------------------------------------------


class RequestContextMiddleware(BaseHTTPMiddleware):
    """
    Starlette/FastAPI middleware that:
    1. Generates (or forwards) a request-id.
    2. Extracts run_id / slate_id from the URL.
    3. Emits a structured JSON log entry with method, path, status, duration.
    4. Attaches X-Request-ID to the response.
    """

    async def dispatch(self, request: Request, call_next) -> Response:  # type: ignore[override]
        # ── Request ID ──────────────────────────────────────────────────────
        req_id = request.headers.get("X-Request-ID") or uuid.uuid4().hex[:12]
        token_rid = request_id_var.set(req_id)

        # ── Extract IDs from path ─────────────────────────────────────────
        ids = _extract_ids_from_path(request.url.path)
        token_run = run_id_var.set(ids["run_id"])
        token_slate = slate_id_var.set(ids["slate_id"])

        # ── Time the request ─────────────────────────────────────────────
        t0 = time.monotonic()

        _access_log.info(
            "request_start",
            extra={
                "request_id": req_id,
                "method": request.method,
                "path": request.url.path,
                "run_id": ids["run_id"],
                "slate_id": ids["slate_id"],
            },
        )

        try:
            response: Response = await call_next(request)
        except Exception as exc:
            duration_ms = int((time.monotonic() - t0) * 1000)
            _access_log.error(
                "request_error",
                extra={
                    "request_id": req_id,
                    "method": request.method,
                    "path": request.url.path,
                    "duration_ms": duration_ms,
                    "error": str(exc),
                },
            )
            raise
        finally:
            request_id_var.reset(token_rid)
            run_id_var.reset(token_run)
            slate_id_var.reset(token_slate)

        duration_ms = int((time.monotonic() - t0) * 1000)
        _access_log.info(
            "request_complete",
            extra={
                "request_id": req_id,
                "method": request.method,
                "path": request.url.path,
                "status": response.status_code,
                "duration_ms": duration_ms,
                "run_id": ids["run_id"],
                "slate_id": ids["slate_id"],
            },
        )

        response.headers["X-Request-ID"] = req_id
        return response
