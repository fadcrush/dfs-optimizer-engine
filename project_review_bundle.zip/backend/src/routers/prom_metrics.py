"""
routers/prom_metrics.py — Prometheus-style metrics endpoint.

GET /api/metrics  returns plain-text Prometheus exposition format.

All counters are read directly from the DB so they reflect ground truth.
"""
from __future__ import annotations

import time
from typing import Any, List

from fastapi import APIRouter, Depends
from fastapi.responses import PlainTextResponse
from sqlalchemy import func, text
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from database.db import get_db

router = APIRouter(prefix="/api/metrics", tags=["Metrics"])

# Module-level startup time for uptime gauge
_PROCESS_START = time.time()


def _prom_line(metric: str, value: Any, labels: str = "", help_text: str = "",
               type_hint: str = "gauge") -> str:
    """Return a Prometheus exposition block for a single metric."""
    lines = []
    if help_text:
        lines.append(f"# HELP {metric} {help_text}")
    lines.append(f"# TYPE {metric} {type_hint}")
    lbl = f"{{{labels}}}" if labels else ""
    lines.append(f"{metric}{lbl} {value}")
    return "\n".join(lines)


@router.get("", response_class=PlainTextResponse, include_in_schema=True)
def prometheus_metrics(db: Session = Depends(get_db)) -> str:
    """
    Prometheus exposition format metrics.

    Metrics exported:

    - ``dfs_uptime_seconds``           — process uptime
    - ``dfs_runs_total``               — total optimizer runs
    - ``dfs_runs_queued``              — runs currently queued
    - ``dfs_runs_running``             — runs currently executing
    - ``dfs_runs_completed``           — successfully completed runs
    - ``dfs_runs_failed``              — failed runs
    - ``dfs_slates_total``             — total ingested slates
    - ``dfs_lineups_total``            — total generated lineups
    - ``dfs_lineup_entries_total``     — total lineup entry rows
    - ``dfs_players_total``            — total player rows across all slates
    """
    from models.run import Run
    from models.slate import Slate

    uptime = time.time() - _PROCESS_START
    blocks: List[str] = []

    blocks.append(_prom_line(
        "dfs_uptime_seconds", f"{uptime:.2f}",
        help_text="Process uptime in seconds",
    ))

    try:
        # Run counts by status
        status_counts = dict(
            db.query(Run.status, func.count(Run.id))
            .group_by(Run.status)
            .all()
        )
        total_runs = sum(status_counts.values())
        blocks.append(_prom_line(
            "dfs_runs_total", total_runs,
            help_text="Total optimizer runs", type_hint="counter",
        ))
        for status in ("queued", "running", "completed", "failed"):
            blocks.append(_prom_line(
                f"dfs_runs_{status}",
                status_counts.get(status, 0),
                help_text=f"Runs with status={status}",
            ))

        # Slates
        slate_count = db.query(func.count(Slate.id)).scalar() or 0
        blocks.append(_prom_line(
            "dfs_slates_total", slate_count,
            help_text="Total ingested slates", type_hint="counter",
        ))

        # Lineups
        lineup_count = db.execute(text("SELECT COUNT(*) FROM lineups")).scalar() or 0
        blocks.append(_prom_line(
            "dfs_lineups_total", lineup_count,
            help_text="Total generated lineups", type_hint="counter",
        ))

        # Lineup entries
        entry_count = db.execute(text("SELECT COUNT(*) FROM lineup_entries")).scalar() or 0
        blocks.append(_prom_line(
            "dfs_lineup_entries_total", entry_count,
            help_text="Total lineup entry rows", type_hint="counter",
        ))

        # Players
        player_count = db.execute(text("SELECT COUNT(*) FROM slate_players")).scalar() or 0
        blocks.append(_prom_line(
            "dfs_players_total", player_count,
            help_text="Total player rows across all slates", type_hint="counter",
        ))

    except SQLAlchemyError:
        blocks.append("# ERROR: DB schema not ready — run alembic upgrade head")

    return "\n\n".join(blocks) + "\n"
