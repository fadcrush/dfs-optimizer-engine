"""
Slates router — query endpoints for ingested slates.

Routes
------
GET  /api/slates                           — list recent slates
GET  /api/slates/{slate_id}                — slate metadata
GET  /api/slates/{slate_id}/players        — all players with positions/salaries
GET  /api/slates/{slate_id}/projections    — players enriched with projection rows
GET  /api/slates/{slate_id}/ownership      — players enriched with ownership rows
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from database.db import get_db
from models.ownership_model import OwnershipData
from models.player import Player
from models.projection import Projection
from models.slate import Slate

router = APIRouter(prefix="/slates", tags=["Slates"])

_DB_503 = "Database schema not ready. Run: cd backend && alembic upgrade head"


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

def _get_slate_or_404(slate_id: str, db: Session) -> Slate:
    """Return Slate or raise 404. Raises 503 if tables are absent."""
    try:
        slate: Optional[Slate] = db.get(Slate, slate_id)
    except SQLAlchemyError:
        raise HTTPException(status_code=503, detail=_DB_503)
    if slate is None:
        raise HTTPException(status_code=404, detail=f"Slate not found: '{slate_id}'")
    return slate


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@router.get("")
def list_slates(
    sport: Optional[str] = Query(None, description="Filter by sport (nba | nfl)"),
    platform: Optional[str] = Query(None, description="Filter by platform (fanduel | draftkings)"),
    limit: int = Query(20, ge=1, le=100, description="Maximum number of results"),
    db: Session = Depends(get_db),
) -> List[Dict[str, Any]]:
    """List recent slates, newest first."""
    try:
        q = db.query(Slate)
        if sport:
            q = q.filter(Slate.sport == sport)
        if platform:
            q = q.filter(Slate.platform == platform)
        slates = q.order_by(Slate.created_at.desc()).limit(limit).all()
        return [s.to_dict() for s in slates]
    except SQLAlchemyError:
        raise HTTPException(status_code=503, detail=_DB_503)


@router.get("/{slate_id}")
def get_slate(
    slate_id: str,
    db: Session = Depends(get_db),
) -> Dict[str, Any]:
    """Return metadata for a single slate."""
    slate = _get_slate_or_404(slate_id, db)
    return slate.to_dict()


@router.get("/{slate_id}/players")
def get_slate_players(
    slate_id: str,
    db: Session = Depends(get_db),
) -> List[Dict[str, Any]]:
    """Return all players for a slate (salary, position, team snapshot)."""
    _get_slate_or_404(slate_id, db)
    try:
        players = (
            db.query(Player)
            .filter(Player.slate_id == slate_id)
            .order_by(Player.salary.desc())
            .all()
        )
    except SQLAlchemyError:
        raise HTTPException(status_code=503, detail=_DB_503)
    return [p.to_dict() for p in players]


@router.get("/{slate_id}/projections")
def get_slate_projections(
    slate_id: str,
    db: Session = Depends(get_db),
) -> List[Dict[str, Any]]:
    """
    Return players for a slate enriched with their projection figures.

    Only players that have a corresponding Projection row are returned.
    """
    _get_slate_or_404(slate_id, db)
    try:
        rows = (
            db.query(Player, Projection)
            .join(Projection, Projection.player_id == Player.id)
            .filter(Player.slate_id == slate_id)
            .order_by(Projection.projection.desc())
            .all()
        )
    except SQLAlchemyError:
        raise HTTPException(status_code=503, detail=_DB_503)

    result: List[Dict[str, Any]] = []
    for player, proj in rows:
        d = player.to_dict()
        d.update(
            {
                "projection": proj.projection,
                "floor": proj.floor,
                "ceiling": proj.ceiling,
                "value": proj.value,
                "injury_status": proj.injury_status,
                "ownership_pct": proj.ownership_pct,
            }
        )
        result.append(d)
    return result


@router.get("/{slate_id}/ownership")
def get_slate_ownership(
    slate_id: str,
    db: Session = Depends(get_db),
) -> List[Dict[str, Any]]:
    """Return ownership data for a slate, sorted by ownership_pct descending."""
    _get_slate_or_404(slate_id, db)
    try:
        rows = (
            db.query(Player, OwnershipData)
            .join(OwnershipData, OwnershipData.player_id == Player.id)
            .filter(Player.slate_id == slate_id)
            .order_by(OwnershipData.ownership_pct.desc())
            .all()
        )
    except SQLAlchemyError:
        raise HTTPException(status_code=503, detail=_DB_503)

    return [
        {
            "player_id": player.id,
            "name": player.name,
            "position": player.position,
            "team": player.team,
            "salary": player.salary,
            "ownership_pct": own.ownership_pct,
            "source": own.source,
        }
        for player, own in rows
    ]
