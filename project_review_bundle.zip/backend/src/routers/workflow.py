"""
Complete DFS Workflow - ONE-CLICK SOLUTION!
Upload slate -> Projections -> Ownership -> Optimized Lineups -> Platform CSV
"""

from typing import Optional
import logging
from fastapi import APIRouter, UploadFile, File, Depends, HTTPException, Query
from sqlalchemy.orm import Session
import uuid

from database.db import get_db
from models.user import User
from services.auth import get_current_user_id
from services.file_service import save_slate_file, save_projection_file
from services.projection_service import generate_projections, projections_to_csv
from services.ownership_service import generate_ownership_predictions, ownership_to_csv
from services.optimizer_service import generate_lineups
from services.professional_optimizer import format_lineups_for_fanduel_csv

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/workflow", tags=["Complete Workflow"])


@router.post("/complete")
async def complete_dfs_workflow(
    slate: UploadFile = File(...),
    num_lineups: int = Query(default=150, ge=1, le=150),
    platform: str = Query(default="fanduel", pattern="^(fanduel|draftkings)$"),
    contest_type: str = Query(default="small_gpp", pattern="^(cash|large_gpp|small_gpp|satellite|showdown)$"),
    max_exposure: float = Query(default=0.35, ge=0.0, le=1.0),
    min_salary: int = Query(default=49000, ge=0, le=60000),
    max_salary: int = Query(default=60000, ge=0, le=60000),
    user_id: Optional[str] = Depends(get_current_user_id),
    db: Session = Depends(get_db)
):
    """
    Complete DFS Workflow - All steps in one API call

    1. Uploads your slate
    2. Generates projections
    3. Predicts ownership
    4. Optimizes lineups
    5. Exports platform-ready CSV
    """
    if not user_id:
        user_id = "demo-user"

    logger.info("Starting complete DFS workflow")

    # Validate file
    if not slate.filename.endswith('.csv'):
        raise HTTPException(status_code=400, detail="Slate must be a CSV file")

    try:
        # Step 1: Save slate
        logger.info("Step 1/5: Uploading slate...")
        slate_info = await save_slate_file(slate)
        slate_path = slate_info['file_path']

        # Step 2: Generate projections
        logger.info("Step 2/5: Generating projections...")
        projections_result = await generate_projections(slate_path, user_id)

        if not projections_result['success']:
            raise HTTPException(status_code=500, detail="Projection generation failed")

        # Save projections to CSV
        proj_csv = projections_to_csv(projections_result['projections'])
        proj_file_id = str(uuid.uuid4())[:8]
        proj_file_info = await save_projection_file(proj_csv, proj_file_id)
        proj_file_path = proj_file_info['file_path']

        # Step 3: Predict ownership
        logger.info("Step 3/5: Simulating ownership...")
        ownership_result = await generate_ownership_predictions(proj_file_path, user_id)
        own_file_info = None

        if not ownership_result['success']:
            logger.warning("Ownership prediction failed, continuing with defaults")
            ownership_result = None
        else:
            own_csv = ownership_to_csv(ownership_result['ownership_predictions'])
            own_file_id = str(uuid.uuid4())[:8]
            own_file_info = await save_projection_file(own_csv, own_file_id)

        # Step 4: Merge ownership into projections
        if ownership_result and ownership_result['success']:
            logger.info("Step 4/5: Merging ownership into projections...")
            import pandas as pd

            proj_df = pd.read_csv(proj_file_path)
            proj_df.columns = [c.lower() for c in proj_df.columns]

            own_df = pd.DataFrame(ownership_result['ownership_predictions'])
            own_df.columns = [c.lower() for c in own_df.columns]

            merged_df = proj_df.merge(
                own_df[['name', 'predicted_ownership', 'leverage']],
                on='name',
                how='left'
            )

            if 'predicted_ownership' in merged_df.columns:
                merged_df['ownership'] = merged_df['predicted_ownership'].fillna(0.50)
                merged_df = merged_df.drop(columns=['predicted_ownership'], errors='ignore')

            merged_csv = merged_df.to_csv(index=False)
            merged_file_id = str(uuid.uuid4())[:8]
            merged_file_info = await save_projection_file(merged_csv, merged_file_id)
            proj_file_path = merged_file_info['file_path']
        else:
            logger.info("Step 4/5: Skipping ownership merge (using defaults)")

        # Step 5: Optimize lineups
        logger.info("Step 5/5: Optimizing lineups...")
        optimizer_result = await generate_lineups(
            proj_file_path,
            num_lineups=num_lineups,
            max_exposure=max_exposure,
            min_salary=min_salary,
            max_salary=max_salary,
            platform=platform,
            contest_type=contest_type,
            user_id=user_id
        )

        if not optimizer_result['success']:
            raise HTTPException(status_code=500, detail="Lineup optimization failed")

        # Save lineups to platform CSV
        lineups_list = optimizer_result.get('lineups_raw', optimizer_result['lineups'])
        lineups_csv = format_lineups_for_fanduel_csv(lineups_list, platform)
        lineups_file_id = str(uuid.uuid4())[:8]
        lineups_file_info = await save_projection_file(lineups_csv, lineups_file_id)

        # Update user stats
        if user_id != "demo-user":
            try:
                user = db.query(User).filter(User.id == user_id).first()
                if user:
                    user.projections_generated += 1
                    user.lineups_generated += len(optimizer_result['lineups'])
                    db.commit()
            except:
                pass

        logger.info("Complete workflow finished successfully")

        return {
            "message": f"Complete! {num_lineups} optimized lineups ready for {platform.upper()}!",
            "workflow_steps": {
                "1_slate": {
                    "status": "complete",
                    "file": slate_info['file_name'],
                    "players": len(projections_result['projections'])
                },
                "2_projections": {
                    "status": "complete",
                    "file": proj_file_info['file_name'],
                    "players_with_history": projections_result['stats']['players_with_history'],
                    "avg_projection": projections_result['stats']['avg_projection']
                },
                "3_ownership": {
                    "status": "complete" if ownership_result else "skipped",
                    "file": own_file_info['file_name'] if own_file_info else None,
                    "high_owned": ownership_result['stats']['high_owned_count'] if ownership_result else None,
                    "low_owned": ownership_result['stats']['low_owned_count'] if ownership_result else None
                },
                "4_optimization": {
                    "status": "complete",
                    "lineups_generated": len(optimizer_result['lineups']),
                    "avg_projection": optimizer_result['stats']['avg_projection'],
                    "avg_salary": optimizer_result['stats']['avg_salary']
                }
            },
            "download_files": {
                "projections": proj_file_info['file_name'],
                "ownership": own_file_info['file_name'] if own_file_info else None,
                "lineups_fanduel_csv": lineups_file_info['file_name']
            },
            "lineups_preview": optimizer_result['lineups'][:5],
            "stats": optimizer_result['stats'],
            "top_leverage_plays": ownership_result['stats']['top_leverage_plays'] if ownership_result else [],
            "ready_to_upload": f"Download '{lineups_file_info['file_name']}' and upload to {platform.title()}!"
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Workflow failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Workflow failed: {str(e)}")
