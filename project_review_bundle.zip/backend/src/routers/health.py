"""
Health endpoints.

GET /api/health     — quick liveness probe (also defined inline in main.py)
GET /api/health/db  — DB connectivity + schema presence check
GET /api/health/metrics  — basic runtime counters
"""

from __future__ import annotations

import os
import time
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends
from sqlalchemy import func, text
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from database.db import get_db

router = APIRouter(prefix="/api/health", tags=["Health"])

_REQUIRED_TABLES: List[str] = [
    "slates",
    "slate_players",
    "projections",
    "ownership_data",
    "runs",
    "lineups",
    "lineup_entries",
]

# Startup timestamp for uptime calculation
_START_TIME: float = time.time()


@router.get("/db")
def health_db(db: Session = Depends(get_db)) -> Dict[str, Any]:
    """
    Database health check.

    Verifies connectivity, checks that all required DFS schema tables exist,
    and reports the current Alembic migration revision.

    Returns 200 with ``status='ok'`` when all tables are present.
    Returns 200 with ``status='degraded'`` when tables are missing
    (expected in a fresh environment before ``alembic upgrade head``).
    Returns 200 with ``status='error'`` when the DB is unreachable.
    """
    # ── Connectivity ──────────────────────────────────────────────────────────
    try:
        db.execute(text("SELECT 1"))
    except SQLAlchemyError as exc:
        return {
            "status": "error",
            "connection": str(exc),
            "missing_tables": _REQUIRED_TABLES,
            "alembic_revision": None,
        }

    # ── Table existence (try a cheap SELECT on each required table) ───────────
    missing: List[str] = []
    for tbl in _REQUIRED_TABLES:
        try:
            db.execute(text(f"SELECT 1 FROM {tbl} LIMIT 1"))
        except SQLAlchemyError:
            missing.append(tbl)

    # ── Alembic migration revision ────────────────────────────────────────────
    alembic_rev: Optional[str] = None
    try:
        row = db.execute(
            text("SELECT version_num FROM alembic_version")
        ).fetchone()
        if row:
            alembic_rev = row[0]
    except SQLAlchemyError:
        pass  # alembic_version table may not exist in dev DuckDB

    result: Dict[str, Any] = {
        "status": "ok" if not missing else "degraded",
        "connection": "ok",
        "missing_tables": missing,
        "alembic_revision": alembic_rev,
    }
    if missing:
        result["hint"] = (
            "Some DFS schema tables are absent. "
            "Run: cd backend && alembic upgrade head"
        )
    return result


@router.get("/metrics")
def health_metrics(db: Session = Depends(get_db)) -> Dict[str, Any]:
    """
    Basic runtime counters — useful for dashboards and alerting.

    Returns counts directly from the DB so numbers are always current.
    Responds with zeroes if DB schema is not ready.
    """
    uptime_s = int(time.time() - _START_TIME)

    base: Dict[str, Any] = {
        "uptime_seconds": uptime_s,
        "environment": os.getenv("ENVIRONMENT", "development"),
        "db_required": os.getenv("DB_REQUIRED", "false").lower() in ("1", "true", "yes"),
        "counts": {},
    }

    try:
        from models.run import Run
        from models.slate import Slate

        counts: Dict[str, int] = {}

        # Total slates
        counts["slates"] = db.query(func.count(Slate.id)).scalar() or 0

        # Run counts by status
        from models.run import STATUS_QUEUED, STATUS_RUNNING, STATUS_COMPLETED, STATUS_FAILED
        rows = (
            db.query(Run.status, func.count(Run.id))
            .group_by(Run.status)
            .all()
        )
        by_status: Dict[str, int] = {r: 0 for r in [STATUS_QUEUED, STATUS_RUNNING, STATUS_COMPLETED, STATUS_FAILED]}
        for status, cnt in rows:
            by_status[status] = cnt
        counts["runs_total"] = sum(by_status.values())
        counts["runs_queued"] = by_status[STATUS_QUEUED]
        counts["runs_running"] = by_status[STATUS_RUNNING]
        counts["runs_completed"] = by_status[STATUS_COMPLETED]
        counts["runs_failed"] = by_status[STATUS_FAILED]

        base["counts"] = counts
        base["status"] = "ok"
    except SQLAlchemyError:
        base["status"] = "degraded"
        base["hint"] = "DB schema not ready — run alembic upgrade head"

    return base
