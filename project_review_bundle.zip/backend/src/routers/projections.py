"""
Projections Routes - Generate DFS projections via API!
"""

from typing import Optional, List, Dict, Any
from fastapi import APIRouter, UploadFile, File, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from datetime import datetime
import io
import re

import pandas as pd

from database.db import get_db
from models.user import User
from services.auth import get_current_user_id
from services.file_service import save_slate_file, save_projection_file
from services.projection_service import generate_projections, projections_to_csv

router = APIRouter(prefix="/projections", tags=["Projections"])


# ---------------------------------------------------------------------------
# Slate CSV parsing helpers
# ---------------------------------------------------------------------------

def _detect_platform(columns: List[str]) -> str:
    """Detect DFS platform from CSV column headers."""
    cols_lower = [c.lower() for c in columns]
    if any(k in cols_lower for k in ("nickname", "fppg", "injury indicator")):
        return "fanduel"
    if any(k in cols_lower for k in ("roster position", "avgpointspergame")):
        return "draftkings"
    return "fanduel"


def _detect_sport(df: pd.DataFrame, columns: List[str]) -> str:
    """Detect sport from CSV content."""
    pos_col = next((c for c in columns if c.lower() == "position"), None)
    if pos_col and len(df) > 0:
        positions = set(df[pos_col].dropna().str.upper().unique())
        nfl_positions = {"QB", "RB", "WR", "TE", "K", "DST", "DEF"}
        if positions & nfl_positions:
            return "nfl"
    return "nba"


_INJURY_MAP = {"O": "OUT", "Q": "QUESTIONABLE", "D": "DOUBTFUL", "P": "PROBABLE"}


def _safe_float(val: Any, default: float = 0.0) -> float:
    """Convert a value to float, treating NaN/None/empty as *default*."""
    import math
    try:
        f = float(val)
        return default if math.isnan(f) or math.isinf(f) else f
    except (ValueError, TypeError):
        return default


def _safe_int(val: Any, default: int = 0) -> int:
    """Convert a value to int, treating NaN/None/empty as *default*."""
    return int(_safe_float(val, float(default)))


def _safe_str(val: Any, default: str = "") -> str:
    """Convert a value to str, treating NaN/None as *default*."""
    import math
    if val is None:
        return default
    try:
        if isinstance(val, float) and math.isnan(val):
            return default
    except (ValueError, TypeError):
        pass
    s = str(val).strip()
    return s if s and s.lower() != "nan" else default


def _parse_players(df: pd.DataFrame, platform: str) -> List[Dict[str, Any]]:
    """Parse player rows from a slate CSV into Player-shaped dicts."""
    players: List[Dict[str, Any]] = []
    for _, row in df.iterrows():
        if platform == "fanduel":
            name = _safe_str(row.get("Nickname", row.get("Name", "")), "Unknown")
            pid = _safe_str(row.get("Id", row.get("ID", "")))
            position = _safe_str(row.get("Position", ""), "UTIL")
            salary = _safe_int(row.get("Salary", 0))
            team = _safe_str(row.get("Team", ""))
            opponent = _safe_str(row.get("Opponent", ""))
            game = _safe_str(row.get("Game", ""))
            fppg = _safe_float(row.get("FPPG", 0))
            injury_raw = _safe_str(row.get("Injury Indicator", "")).upper()
        else:
            name = _safe_str(row.get("Name", ""), "Unknown")
            pid = _safe_str(row.get("ID", row.get("Id", "")))
            position = _safe_str(row.get("Position", row.get("Roster Position", "")), "UTIL")
            salary = _safe_int(row.get("Salary", 0))
            team = _safe_str(row.get("TeamAbbrev", row.get("Team", "")))
            game_info = _safe_str(row.get("Game Info", ""))
            opponent = ""
            if game_info and team:
                teams_in_game = re.findall(r"[A-Z]{2,4}", game_info.split(" ")[0])
                for t in teams_in_game:
                    if t != team:
                        opponent = t
                        break
            game = game_info
            fppg = _safe_float(row.get("AvgPointsPerGame", 0))
            injury_raw = ""

        injury_status = _INJURY_MAP.get(injury_raw)
        projection = round(fppg, 2)
        value = round(projection / (salary / 1000), 2) if salary > 0 else 0

        players.append({
            "id": pid,
            "name": name,
            "position": position,
            "positions": [p.strip() for p in position.split("/")],
            "team": team,
            "opponent": opponent,
            "salary": salary,
            "projection": projection,
            "floor": round(projection * 0.7, 2),
            "ceiling": round(projection * 1.4, 2),
            "ownership": 0,
            "value": value,
            "leverage": 0,
            "game": game,
            "injuryStatus": injury_status,
            "isLocked": False,
            "isFaded": False,
        })
    return players


def _parse_games(df: pd.DataFrame, platform: str) -> List[Dict[str, Any]]:
    """Extract unique games from the slate CSV."""
    game_col = "Game" if platform == "fanduel" else "Game Info"
    if game_col not in df.columns:
        return []

    seen: set = set()
    games: List[Dict[str, Any]] = []
    for raw in df[game_col].dropna().unique():
        raw_str = str(raw).strip()
        if not raw_str or raw_str in seen:
            continue
        seen.add(raw_str)

        parts = raw_str.split(" ", 1)
        matchup = parts[0] if parts else raw_str
        start_time = parts[1] if len(parts) > 1 else ""

        teams = matchup.split("@")
        away = teams[0] if len(teams) > 0 else ""
        home = teams[1] if len(teams) > 1 else ""

        games.append({
            "id": f"game-{away}-{home}",
            "homeTeam": home,
            "awayTeam": away,
            "startTime": start_time,
        })
    return games


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@router.post("/upload-slate")
async def upload_slate(
    file: UploadFile = File(...),
    user_id: Optional[str] = Depends(get_current_user_id),
    db: Session = Depends(get_db)
):
    """
    Upload a slate file (CSV from FanDuel/DraftKings).

    Parses the CSV and returns a full Slate object with players, games,
    and detected platform/sport so the frontend can display a preview.
    """
    if not user_id:
        user_id = "demo-user"

    if not file.filename or not file.filename.endswith('.csv'):
        raise HTTPException(status_code=400, detail="File must be a CSV")

    # Save file to disk
    file_info = await save_slate_file(file)

    # Parse the saved CSV to build a Slate response
    try:
        df = pd.read_csv(file_info["file_path"])
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Could not parse CSV: {e}")

    columns = list(df.columns)
    platform = _detect_platform(columns)
    sport = _detect_sport(df, columns)
    players = _parse_players(df, platform)
    games = _parse_games(df, platform)

    now = datetime.utcnow().isoformat() + "Z"

    return {
        "id": file_info["file_id"],
        "platform": platform,
        "sport": sport,
        "date": now[:10],
        "lockTime": "",
        "slateType": "Main",
        "games": games,
        "players": players,
        "fileName": file_info["file_name"],
        "uploadedAt": now,
    }

@router.post("/generate")
async def generate(
    slate_file_name: str,
    user_id: Optional[str] = Depends(get_current_user_id),
    db: Session = Depends(get_db)
):
    """
    Generate projections for an uploaded slate

    This calls your DFS algorithm to create projections!
    """
    if not user_id:
        user_id = "demo-user"
    
    # Get file path
    from services.file_service import get_file_path
    slate_path = get_file_path(slate_file_name, "slate")
    
    if not slate_path.exists():
        raise HTTPException(status_code=404, detail="Slate file not found")
    
    # Generate projections
    result = await generate_projections(str(slate_path), user_id)
    
    if not result['success']:
        raise HTTPException(status_code=500, detail=result.get('error', 'Projection generation failed'))
    
    # Update user stats (if authenticated)
    if user_id != "demo-user":
        try:
            user = db.query(User).filter(User.id == user_id).first()
            if user:
                user.slates_processed += 1
                db.commit()
        except:
            pass

    return {
        "message": "Projections generated successfully!",
        "result": result,
        "progress": "Step 2/2 complete",
    }

@router.post("/generate-from-upload")
async def generate_from_upload(
    file: UploadFile = File(...),
    user_id: Optional[str] = Depends(get_current_user_id),
    db: Session = Depends(get_db)
):
    """
    One-step: Upload slate AND generate projections

    This combines upload + generate into one API call!
    """
    # Get user if authenticated
    user = None
    if user_id:
        user = db.query(User).filter(User.id == user_id).first()
    else:
        user_id = "demo-user"
    
    # Validate file
    if not file.filename.endswith('.csv'):
        raise HTTPException(status_code=400, detail="File must be a CSV")
    
    # Save file
    file_info = await save_slate_file(file)
    
    # Generate projections
    result = await generate_projections(file_info['file_path'], user_id)
    
    if not result['success']:
        raise HTTPException(status_code=500, detail=result.get('error', 'Generation failed'))
    
    # Save projection file
    csv_data = projections_to_csv(result['projections'])
    proj_file = await save_projection_file(csv_data, file_info['file_id'])
    
    # Update user stats
    if user:
        user.slates_processed += 1
        db.commit()
    
    return {
        "message": "🎉 Projections generated successfully!",
        "slate_file": file_info,
        "projections": result['projections'][:10],  # First 10 for preview
        "stats": result['stats'],
        "total_projections": len(result['projections']),
        "download_file": proj_file['file_name'],
        "note": result.get('note', '')
    }

@router.get("/download/{file_name}")
async def download_projections(file_name: str):
    """
    Download projection results as CSV
    """
    from services.file_service import get_file_path
    
    file_path = get_file_path(file_name, "projection")
    
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="File not found")
    
    # Read file
    with open(file_path, 'r') as f:
        content = f.read()
    
    # Return as downloadable CSV
    return StreamingResponse(
        io.StringIO(content),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename={file_name}"}
    )


# ---------------------------------------------------------------------------
# DB-first upload endpoint (SaaS layer)
# ---------------------------------------------------------------------------

@router.post("/upload-slate-to-db")
async def upload_slate_to_db(
    file: UploadFile = File(...),
    sport: Optional[str] = None,
    user_id: Optional[str] = Depends(get_current_user_id),
    db: Session = Depends(get_db),
):
    """
    Upload a DFS contest slate CSV and persist it directly to the database.

    Creates rows in: slates, slate_players, projections.
    Returns: slate_id, platform, sport, player_count.

    This endpoint is the canonical ingestion path for the database-first
    SaaS architecture.  Use ``/upload-slate`` for the legacy file-based flow.
    """
    if not user_id:
        user_id = "demo-user"

    if not file.filename or not file.filename.lower().endswith(".csv"):
        raise HTTPException(status_code=400, detail="File must be a .csv")

    csv_bytes = await file.read()
    if not csv_bytes:
        raise HTTPException(status_code=400, detail="Uploaded file is empty")

    try:
        from services.projection_ingestion import ingest_projections_csv  # local import to keep top-level clean
        result = ingest_projections_csv(
            db=db,
            csv_bytes=csv_bytes,
            filename=file.filename,
            sport=sport,
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Ingestion failed: {exc}")

    return {
        "message": "Slate ingested into database successfully.",
        **result,
    }