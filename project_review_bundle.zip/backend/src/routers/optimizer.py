"""
Optimizer Routes - Generate optimized DFS lineups

Phase 7: Added async mode support with ?async=true query parameter.
"""

from typing import Optional, List, Dict, Any
from fastapi import APIRouter, UploadFile, File, Depends, HTTPException, Query, Body
from fastapi.responses import StreamingResponse, JSONResponse
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field
import uuid
import io
import pandas as pd

from database.db import get_db
from models.user import User
from services.auth import get_current_user_id
from services.file_service import save_projection_file, save_slate_file, get_file_path
from services.optimizer_service import run_fanduel_optimizer, normalize_dataframe
from core.exceptions import InjuryEnrichmentError
from services.professional_optimizer import format_lineups_for_fanduel_csv
from services.post_build_service import (
    rebuild_with_exposure_constraints,
    diversify_lineups,
    replace_player_in_lineups,
    get_contest_preset_settings
)

# Phase 7: Job imports
try:
    from jobs.models import JobParameters, create_job
    from jobs.runner import get_default_runner
    JOBS_AVAILABLE = True
except ImportError:
    JOBS_AVAILABLE = False

router = APIRouter(prefix="/optimizer", tags=["Optimizer"])


@router.post("/generate")
async def generate_lineups(
    projections_file_name: str = Query(None),
    file_name: str = Query(None),
    num_lineups: int = Query(default=150, ge=1, le=150),
    platform: str = Query(default="fanduel", pattern="^(fanduel|draftkings)$"),
    contest_type: str = Query(default="small_gpp"),
    max_exposure: float = Query(default=0.35, ge=0.0, le=1.0),
    min_salary: int = Query(default=49000, ge=0, le=60000),
    max_salary: int = Query(default=60000, ge=0, le=60000),
    async_mode: bool = Query(default=False, alias="async"),
    user_id: Optional[str] = Depends(get_current_user_id),
    db: Session = Depends(get_db),
):
    """
    Generate optimized lineups from slate or projections file
    
    Query Parameters:
    - file_name: Name of slate or projections file
    - projections_file_name: (Deprecated) Name of the projections file
    - num_lineups: Number of lineups to generate (1-150)
    - platform: 'fanduel' or 'draftkings'
    - contest_type: 'cash', 'small_gpp', 'large_gpp', or 'showdown'
    - max_exposure: Maximum exposure per player (0.0-1.0)
    - min_salary: Minimum salary for lineup
    - max_salary: Maximum salary for lineup
    - async: Set to true for background job execution
    """
    if not user_id:
        user_id = "demo-user"
    
    # Support both parameter names for backward compatibility
    file = projections_file_name or file_name
    if not file:
        raise HTTPException(status_code=400, detail="Missing required parameter: file_name or projections_file_name")
    
    try:
        # Determine if it's a slate or projections file
        from services.projection_service import generate_projections
        from pathlib import Path
        
        # Try projections first
        try:
            file_path = get_file_path(file, "projection")
            if not Path(file_path).exists():
                raise FileNotFoundError()
        except:
            # Fall back to slate file
            file_path = get_file_path(file, "slate")
            if not Path(file_path).exists():
                raise HTTPException(status_code=404, detail=f"File not found: {file}")
            
            # Generate projections from slate
            print(f"📊 Auto-generating projections from slate: {file}")
            proj_result = await generate_projections(str(file_path), user_id)
            if not proj_result.get('success'):
                raise HTTPException(status_code=400, detail="Failed to generate projections")
            
            # Save projections to temp file for optimizer
            from services.file_service import PROJECTIONS_DIR
            import uuid
            proj_filename = f"projections_{uuid.uuid4().hex[:8]}.csv"
            file_path = PROJECTIONS_DIR / proj_filename
            
            # Convert projections to CSV
            from services.projection_service import projections_to_csv
            csv_content = projections_to_csv(proj_result['projections'])
            with open(file_path, 'w') as f:
                f.write(csv_content)
        
        # Phase 7: Async mode - submit as background job
        if async_mode:
            if not JOBS_AVAILABLE:
                raise HTTPException(
                    status_code=501,
                    detail="Async mode not available - jobs module not loaded"
                )
            
            # Create job parameters
            params = JobParameters(
                type="optimizer",
                user_id=user_id,
                input_file=file_path,
                parameters={
                    "num_lineups": num_lineups,
                    "platform": platform,
                    "contest_type": contest_type,
                    "max_exposure": max_exposure,
                    "min_salary": min_salary,
                    "max_salary": max_salary,
                }
            )
            
            # Create job and submit
            job = create_job(db, params)
            runner = get_default_runner()
            runner.submit(job)
            
            return JSONResponse(
                status_code=202,
                content={"job_id": str(job.id), "status": "submitted"}
            )
        
        # Synchronous mode
        result = await run_fanduel_optimizer(
            file_path,
            num_lineups=num_lineups,
            contest_type=contest_type,
            max_exposure=max_exposure,
            min_salary=min_salary,
            max_salary=max_salary,
            user_id=user_id
        )
        return result
    except InjuryEnrichmentError as ire:
        raise HTTPException(
            status_code=503,
            detail={"code": ire.reason, "message": ire.detail, "run_id": ire.run_id},
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to generate lineups: {str(e)}")


@router.post("/optimize-from-projections")
async def optimize_from_file(
    projections: UploadFile = File(...),
    num_lineups: int = Query(default=150, ge=1, le=150),
    platform: str = Query(default="fanduel", pattern="^(fanduel|draftkings)$"),
    contest_type: str = Query(default="small_gpp"),
    max_exposure: float = Query(default=0.35, ge=0.0, le=1.0),
    min_salary: int = Query(default=49000, ge=0, le=60000),
    max_salary: int = Query(default=60000, ge=0, le=60000),
    async_mode: bool = Query(default=False, alias="async"),
    user_id: Optional[str] = Depends(get_current_user_id),
    db: Session = Depends(get_db),
):
    """
    Upload projections CSV and generate optimized lineups.

    Phase 7: Set async=true to run optimization in background and return job_id.
    When async=true, returns 202 Accepted with job_id for polling.
    When async=false (default), runs synchronously and returns lineups.
    """
    if not user_id:
        user_id = "demo-user"

    if not projections.filename.endswith(".csv"):
        raise HTTPException(status_code=400, detail="File must be a CSV")

    # Save uploaded slate
    proj_info = await save_slate_file(projections)

    # Phase 7: Async mode - submit as background job
    if async_mode:
        if not JOBS_AVAILABLE:
            raise HTTPException(
                status_code=501,
                detail="Async mode not available - jobs module not loaded"
            )

        # Create job parameters
        params = JobParameters(
            num_lineups=num_lineups,
            max_exposure=max_exposure,
            min_salary=min_salary,
            max_salary=max_salary,
            platform=platform,
        )

        # Create and submit job
        job = create_job(
            projections_path=proj_info["file_path"],
            parameters=params,
        )

        runner = get_default_runner()
        try:
            runner.submit(job)
        except Exception as e:
            # Check for circuit breaker
            if "circuit" in str(e).lower():
                raise HTTPException(status_code=503, detail=str(e))
            raise HTTPException(status_code=500, detail=f"Failed to submit job: {e}")

        # Return 202 Accepted
        return JSONResponse(
            status_code=202,
            content={
                "status": "accepted",
                "job_id": job.job_id,
                "message": f"Job submitted for {num_lineups} lineups",
                "poll_url": f"/api/jobs/{job.job_id}",
            }
        )

    # Synchronous mode (default) - existing behavior
    try:
        result = await run_fanduel_optimizer(
            projections_path=proj_info["file_path"],
            num_lineups=num_lineups,
            min_salary=min_salary,
            max_salary=max_salary,
            max_exposure=max_exposure,
            contest_type=contest_type,
        )
    except InjuryEnrichmentError as ire:
        raise HTTPException(
            status_code=503,
            detail={"code": ire.reason, "message": ire.detail, "run_id": ire.run_id},
        )

    if not result["success"]:
        # Phase 6: Return 503 if circuit breaker is open
        if result.get("circuit_open"):
            raise HTTPException(status_code=503, detail=result.get("error", "Service temporarily unavailable"))
        raise HTTPException(status_code=500, detail=result.get("error", "Optimization failed"))

    # Format CSV
    csv_data = format_lineups_for_fanduel_csv(
        result["lineups_raw"], platform
    )

    file_id = str(uuid.uuid4())[:8]
    lineups_file = await save_projection_file(csv_data, file_id)

    # Update user stats
    if user_id != "demo-user":
        user = db.query(User).filter(User.id == user_id).first()
        if user:
            user.lineups_generated += len(result["lineups"])
            db.commit()

    return {
        "message": f"{len(result['lineups'])} lineups optimized for {platform.upper()}",
        "lineups": result["lineups"][:10],
        "stats": result["stats"],
        "total_lineups": len(result["lineups"]),
        "download_file": lineups_file["file_name"],
        "algorithm": result.get("algorithm", ""),
        "note": result.get("note", ""),
        "analytics_run_id": result.get("analytics_run_id"),
    }


@router.get("/download/{file_name}")
async def download_lineups(file_name: str):
    """
    Download optimized lineups CSV
    """
    file_path = get_file_path(file_name, "projection")

    if not file_path.exists():
        raise HTTPException(status_code=404, detail="File not found")

    with open(file_path, "r") as f:
        content = f.read()

    return StreamingResponse(
        io.StringIO(content),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename={file_name}"},
    )


# =============================================================================
# POST-BUILD TOOLS ENDPOINTS
# =============================================================================

class RebuildWithExposureRequest(BaseModel):
    """Request model for exposure-based lineup regeneration"""
    lineups: List[List[Dict[str, Any]]]
    slate_file: str
    max_exposure: float = Field(ge=0.0, le=1.0)
    min_exposure: Optional[float] = Field(None, ge=0.0, le=1.0)
    locked_players: Optional[List[str]] = None
    num_lineups: Optional[int] = None
    min_salary: int = 49000
    max_salary: int = 60000
    platform: str = "fanduel"


class DiversifyRequest(BaseModel):
    """Request model for lineup diversification"""
    lineups: List[List[Dict[str, Any]]]
    min_unique_players: int = Field(default=3, ge=1, le=9)
    max_similarity: float = Field(default=0.8, ge=0.0, le=1.0)


class ReplacePlayerRequest(BaseModel):
    """Request model for player replacement"""
    lineups: List[List[Dict[str, Any]]]
    slate_file: str
    player_to_replace: str
    salary_tolerance: int = Field(default=500, ge=0, le=5000)
    preserve_stacks: bool = True
    lineup_indices: Optional[List[int]] = None


class ContestPresetRequest(BaseModel):
    """Request model for contest preset settings"""
    contest_type: str = Field(pattern="^(cash|small_gpp|large_gpp)$")
    platform: str = Field(default="fanduel", pattern="^(fanduel|draftkings)$")


@router.post("/rebuild-with-exposure")
async def rebuild_with_exposure(
    request: RebuildWithExposureRequest,
    user_id: Optional[str] = Depends(get_current_user_id)
):
    """
    Regenerate lineups with adjusted exposure constraints.
    
    Use this endpoint to rebuild your lineup portfolio with different
    exposure settings without re-uploading files or re-configuring.
    
    Request Body:
    - lineups: Original lineup set (for reference)
    - slate_file: Name of slate file to use for player pool
    - max_exposure: Maximum exposure per player (0.0-1.0)
    - min_exposure: Minimum exposure per player (optional)
    - locked_players: List of player names that must appear
    - num_lineups: Number of lineups (defaults to original count)
    - min_salary, max_salary: Salary constraints
    - platform: 'fanduel' or 'draftkings'
    
    Returns:
    - success: Boolean
    - lineups: Regenerated lineup set
    - stats: Portfolio statistics
    - message: Human-readable result
    """
    try:
        # Load slate file to get player pool
        slate_path = get_file_path(request.slate_file, "slate")
        if not slate_path.exists():
            raise HTTPException(status_code=404, detail="Slate file not found")
        
        # Read and normalize slate
        raw_df = pd.read_csv(slate_path)
        pool = normalize_dataframe(raw_df)
        
        # Call service function
        result = rebuild_with_exposure_constraints(
            original_lineups=request.lineups,
            pool=pool,
            max_exposure=request.max_exposure,
            min_exposure=request.min_exposure,
            locked_players=request.locked_players,
            num_lineups=request.num_lineups,
            min_salary=request.min_salary,
            max_salary=request.max_salary,
            platform=request.platform
        )
        
        if not result["success"]:
            raise HTTPException(status_code=400, detail=result.get("error", "Rebuild failed"))
        
        return JSONResponse(content=result)
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/diversify")
async def diversify(
    request: DiversifyRequest,
    user_id: Optional[str] = Depends(get_current_user_id)
):
    """
    Filter lineups to reduce similarity and duplicates.
    
    Use this endpoint to remove near-duplicate lineups and ensure
    your portfolio has sufficient uniqueness across entries.
    
    Request Body:
    - lineups: Original lineup set
    - min_unique_players: Minimum # of different players between lineups
    - max_similarity: Maximum allowed similarity (0.0-1.0)
    
    Returns:
    - success: Boolean
    - lineups: Filtered lineup set
    - stats: Diversification statistics (original/final counts, avg similarity)
    - message: Human-readable result
    """
    try:
        result = diversify_lineups(
            lineups=request.lineups,
            min_unique_players=request.min_unique_players,
            max_similarity=request.max_similarity
        )
        
        return JSONResponse(content=result)
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/replace-player")
async def replace_player(
    request: ReplacePlayerRequest,
    user_id: Optional[str] = Depends(get_current_user_id)
):
    """
    Replace a player across lineups with best alternative.
    
    Use this endpoint to swap out a player (e.g., late scratch, injury news)
    across all lineups while maintaining salary, position, and stacking constraints.
    
    Request Body:
    - lineups: Original lineup set
    - slate_file: Name of slate file for player pool
    - player_to_replace: Name of player to replace
    - salary_tolerance: Max salary difference (±)
    - preserve_stacks: If True, prefer same-team replacements
    - lineup_indices: Optional list of lineup indices to modify (0-based)
    
    Returns:
    - success: Boolean
    - lineups: Modified lineup set
    - replacement: Details of removed/added player
    - stats: Replacement statistics
    - message: Human-readable result
    """
    try:
        # Load slate file to get player pool
        slate_path = get_file_path(request.slate_file, "slate")
        if not slate_path.exists():
            raise HTTPException(status_code=404, detail="Slate file not found")
        
        # Read and normalize slate
        raw_df = pd.read_csv(slate_path)
        pool = normalize_dataframe(raw_df)  # Platform doesn't matter for replacement
        
        # Call service function
        result = replace_player_in_lineups(
            lineups=request.lineups,
            pool=pool,
            player_to_replace=request.player_to_replace,
            salary_tolerance=request.salary_tolerance,
            preserve_stacks=request.preserve_stacks,
            lineup_indices=request.lineup_indices
        )
        
        if not result["success"]:
            raise HTTPException(status_code=400, detail=result.get("error", "Replacement failed"))
        
        return JSONResponse(content=result)
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/apply-contest-preset")
async def apply_contest_preset(
    request: ContestPresetRequest,
    user_id: Optional[str] = Depends(get_current_user_id)
):
    """
    Get optimizer settings optimized for contest type.
    
    Use this endpoint to retrieve preset configurations for different
    contest types (cash games, small GPPs, large tournaments) without
    manually configuring exposure, salary, and ownership parameters.
    
    Request Body:
    - contest_type: 'cash', 'small_gpp', or 'large_gpp'
    - platform: 'fanduel' or 'draftkings'
    
    Returns:
    - max_exposure: Recommended exposure limit
    - min_salary, max_salary: Salary range
    - ownership_weight: Ownership weighting factor
    - description: Strategy description
    - strategy: Concise strategy statement
    """
    try:
        result = get_contest_preset_settings(
            contest_type=request.contest_type,
            platform=request.platform
        )
        
        return JSONResponse(content=result)
    
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
