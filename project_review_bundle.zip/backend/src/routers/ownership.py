"""
Ownership Routes - Generate ownership predictions via API
"""

from typing import Optional
from fastapi import APIRouter, UploadFile, File, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
import uuid
import io

from database.db import get_db
from services.auth import get_current_user_id
from services.file_service import save_projection_file, save_slate_file, get_file_path
from services.ownership_service import generate_ownership_predictions, ownership_to_csv

router = APIRouter(prefix="/ownership", tags=["Ownership"])


@router.post("/predict")
async def predict_ownership(
    projections_file_name: str = Query(None),
    file_name: str = Query(None),
    user_id: Optional[str] = Depends(get_current_user_id),
    db: Session = Depends(get_db)
):
    """
    Generate ownership predictions from projections or slate file
    
    Query Parameters:
    - file_name: Name of slate or projections file
    - projections_file_name: (Deprecated) Name of the projections file
    - user_id: Current user ID (auto-detected)
    """
    if not user_id:
        user_id = "demo-user"
    
    # Support both parameter names for backward compatibility
    file = projections_file_name or file_name
    if not file:
        raise HTTPException(status_code=400, detail="Missing required parameter: file_name or projections_file_name")
    
    try:
        # Determine if it's a slate or projections file
        from services.file_service import get_file_path
        from services.projection_service import generate_projections
        from pathlib import Path
        
        # Try projections first
        try:
            file_path = get_file_path(file, "projection")
            if not Path(file_path).exists():
                raise FileNotFoundError()
        except:
            # Fall back to slate file
            file_path = get_file_path(file, "slate")
            if not Path(file_path).exists():
                raise HTTPException(status_code=404, detail=f"File not found: {file}")
            
            # Generate projections from slate
            print(f"📊 Auto-generating projections from slate: {file}")
            proj_result = await generate_projections(str(file_path), user_id)
            if not proj_result.get('success'):
                raise HTTPException(status_code=400, detail="Failed to generate projections")
            
            # Save projections to temp file for ownership service
            from services.file_service import PROJECTIONS_DIR
            import uuid
            proj_filename = f"projections_{uuid.uuid4().hex[:8]}.csv"
            file_path = PROJECTIONS_DIR / proj_filename
            
            # Convert projections to CSV
            from services.projection_service import projections_to_csv
            csv_content = projections_to_csv(proj_result['projections'])
            with open(file_path, 'w') as f:
                f.write(csv_content)
        
        # Generate ownership predictions
        result = await generate_ownership_predictions(str(file_path), user_id=user_id)
        return result
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Ownership prediction failed: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to generate ownership: {str(e)}")
async def predict_ownership_from_file(
    projections: UploadFile = File(...),
    user_id: Optional[str] = Depends(get_current_user_id),
    db: Session = Depends(get_db)
):
    """
    Generate ownership predictions from projections CSV

    Upload your projections and get back predicted ownership percentages!

    This helps you:
    - Find leverage plays (low owned, high projection)
    - Avoid chalk (highly owned players)
    - Build GPP-winning lineups
    - Differentiate from the field
    """
    if not user_id:
        user_id = "demo-user"

    # Validate file
    if not projections.filename.endswith('.csv'):
        raise HTTPException(status_code=400, detail="File must be a CSV")

    # Save projections file
    proj_info = await save_slate_file(projections)

    # Generate ownership predictions
    result = await generate_ownership_predictions(
        proj_info['file_path'],
        user_id=user_id
    )

    if not result['success']:
        raise HTTPException(status_code=500, detail=result.get('error', 'Ownership prediction failed'))

    # Save ownership predictions to CSV
    csv_data = ownership_to_csv(result['ownership_predictions'])
    file_id = str(uuid.uuid4())[:8]
    ownership_file = await save_projection_file(csv_data, file_id)

    return {
        "message": f"Ownership predictions generated for {result['stats']['total_players']} players!",
        "projections_file": proj_info,
        "ownership_predictions": result['ownership_predictions'][:10],
        "stats": result['stats'],
        "total_players": result['stats']['total_players'],
        "download_file": ownership_file['file_name'],
        "note": "Use these ownership predictions with the optimizer for better GPP lineups!"
    }


@router.post("/predict-from-file")
async def predict_ownership(
    projections_file_name: str,
    user_id: Optional[str] = Depends(get_current_user_id),
    db: Session = Depends(get_db)
):
    """
    Generate ownership predictions from existing projections file

    Provide the filename of projections you've already generated.
    """
    if not user_id:
        user_id = "demo-user"

    # Get projections file
    proj_path = get_file_path(projections_file_name, "projection")

    if not proj_path.exists():
        raise HTTPException(status_code=404, detail="Projections file not found")

    # Generate ownership predictions
    result = await generate_ownership_predictions(
        str(proj_path),
        user_id=user_id
    )

    if not result['success']:
        raise HTTPException(status_code=500, detail=result.get('error', 'Ownership prediction failed'))

    # Save ownership predictions to CSV
    csv_data = ownership_to_csv(result['ownership_predictions'])
    file_id = str(uuid.uuid4())[:8]
    ownership_file = await save_projection_file(csv_data, file_id)

    return {
        "message": "Ownership predictions generated!",
        "ownership_predictions": result['ownership_predictions'][:10],
        "stats": result['stats'],
        "download_file": ownership_file['file_name']
    }


@router.get("/download/{file_name}")
async def download_ownership(file_name: str):
    """
    Download ownership predictions as CSV
    """
    file_path = get_file_path(file_name, "projection")

    if not file_path.exists():
        raise HTTPException(status_code=404, detail="File not found")

    with open(file_path, 'r') as f:
        content = f.read()

    return StreamingResponse(
        io.StringIO(content),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename={file_name}"}
    )


# ---------------------------------------------------------------------------
# DB-first upload endpoint (SaaS layer)
# ---------------------------------------------------------------------------

@router.post("/upload-to-db")
async def upload_ownership_to_db(
    file: UploadFile = File(...),
    slate_id: str = Query(None, description="UUID of the slate (from /projections/upload-slate-to-db)"),
    source: str = Query("upload", description="Ownership source label"),
    user_id: Optional[str] = Depends(get_current_user_id),
    db: Session = Depends(get_db),
):
    """
    Upload an ownership CSV and persist rows into ownership_data.

    Requires ``slate_id`` (the UUID returned by ``POST /projections/upload-slate-to-db``).
    Also mirrors ownership_pct into the projections table for that slate.

    Returns: matched, unmatched, total counts.
    """
    if not user_id:
        user_id = "demo-user"

    if not slate_id:
        raise HTTPException(status_code=400, detail="slate_id query parameter is required")

    if not file.filename or not file.filename.lower().endswith(".csv"):
        raise HTTPException(status_code=400, detail="File must be a .csv")

    csv_bytes = await file.read()
    if not csv_bytes:
        raise HTTPException(status_code=400, detail="Uploaded file is empty")

    try:
        from services.ownership_ingestion import ingest_ownership_csv
        result = ingest_ownership_csv(
            db=db,
            csv_bytes=csv_bytes,
            slate_id=slate_id,
            source=source,
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Ownership ingestion failed: {exc}")

    return {
        "message": f"Ownership data ingested: {result['matched']} matched, {result['unmatched']} unmatched.",
        **result,
    }
