"""
Database Management Router - Phase 1: Database Reliability
Production-grade database monitoring, backup, and validation endpoints
"""

from fastapi import APIRouter, HTTPException
from typing import Dict, Any, List

from database.db import (
    get_health_status,
    perform_data_validation,
    backup_manager,
    DataValidator
)

router = APIRouter(prefix="/api/database", tags=["Database Management"])

@router.get("/health")
async def get_database_health() -> Dict[str, Any]:
    """
    Get comprehensive database health status

    Returns connection pool stats, last health check, and overall status
    """
    try:
        health = get_health_status()
        return {
            "status": "success",
            "health": health,
            "phase": "Phase 1: Database Reliability"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Health check failed: {str(e)}")

@router.get("/validate")
async def validate_database() -> Dict[str, Any]:
    """
    Perform comprehensive data validation

    Checks table existence, row counts, and data freshness for critical tables
    """
    try:
        validation = perform_data_validation()
        return {
            "status": "success",
            "validation": validation,
            "phase": "Phase 1: Database Reliability"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Validation failed: {str(e)}")

@router.post("/backup")
async def create_database_backup() -> Dict[str, Any]:
    """
    Create a database backup

    Only works with DuckDB (file-based database)
    """
    try:
        result = backup_manager.create_backup()
        if result["status"] == "success":
            return {
                "status": "success",
                "backup": result,
                "message": "Database backup created successfully",
                "phase": "Phase 1: Database Reliability"
            }
        else:
            raise HTTPException(status_code=500, detail=result["message"])
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Backup failed: {str(e)}")

@router.get("/backups")
async def list_database_backups() -> Dict[str, Any]:
    """
    List all available database backups
    """
    try:
        backups = backup_manager.list_backups()
        return {
            "status": "success",
            "backups": backups,
            "count": len(backups),
            "phase": "Phase 1: Database Reliability"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to list backups: {str(e)}")

@router.post("/restore/{backup_name}")
async def restore_database_backup(backup_name: str) -> Dict[str, Any]:
    """
    Restore database from a backup

    WARNING: This will overwrite the current database!
    """
    try:
        result = backup_manager.restore_backup(backup_name)
        if result["status"] == "success":
            return {
                "status": "success",
                "restore": result,
                "message": "Database restored successfully. Please restart the application.",
                "warning": "Application restart required",
                "phase": "Phase 1: Database Reliability"
            }
        else:
            raise HTTPException(status_code=500, detail=result["message"])
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Restore failed: {str(e)}")

@router.get("/tables/{table_name}/validate")
async def validate_specific_table(table_name: str) -> Dict[str, Any]:
    """
    Validate a specific table

    Checks existence, row count, and data freshness
    """
    try:
        # Check if table exists
        exists = DataValidator.validate_table_exists(table_name)
        if not exists:
            return {
                "status": "error",
                "table": table_name,
                "message": "Table does not exist",
                "phase": "Phase 1: Database Reliability"
            }

        # Get row count
        row_validation = DataValidator.validate_row_count(table_name)

        # Try to validate freshness (this might fail for tables without date columns)
        try:
            freshness_validation = DataValidator.validate_data_freshness(table_name, "date")
        except:
            freshness_validation = {"status": "not_applicable", "message": "No date column found"}

        return {
            "status": "success",
            "table": table_name,
            "exists": exists,
            "row_count": row_validation,
            "freshness": freshness_validation,
            "phase": "Phase 1: Database Reliability"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Table validation failed: {str(e)}")

@router.get("/config")
async def get_database_config() -> Dict[str, Any]:
    """
    Get current database configuration (without sensitive data)
    """
    from database.db import db_config

    try:
        config_info = {
            "database_type": "duckdb" if db_config.is_duckdb() else "postgresql",
            "use_duckdb_fallback": db_config.use_duckdb_fallback,
            "pool_size": db_config.pool_size,
            "max_overflow": db_config.max_overflow,
            "pool_timeout": db_config.pool_timeout,
            "pool_recycle": db_config.pool_recycle,
            "max_retries": db_config.max_retries,
            "retry_delay": db_config.retry_delay,
            "health_check_interval": db_config.health_check_interval,
            "duckdb_path": str(db_config.duckdb_path)
        }

        return {
            "status": "success",
            "config": config_info,
            "phase": "Phase 1: Database Reliability"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get config: {str(e)}")
