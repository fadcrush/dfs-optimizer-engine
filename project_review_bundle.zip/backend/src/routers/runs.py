"""
Runs router — POST /api/runs, GET /api/runs/{run_id}

Accepts an optimizer job request, creates a Run row, and enqueues the
task via Dramatiq (async) or runs it inline (sync fallback or test mode).
"""

from __future__ import annotations

import json
from typing import Any, Dict, Optional

from fastapi import APIRouter, Body, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from database.db import get_db
from models.run import Run
from services.run_service import create_run

router = APIRouter(prefix="/runs", tags=["Runs"])


# ---------------------------------------------------------------------------
# Request / response models
# ---------------------------------------------------------------------------

class CreateRunRequest(BaseModel):
    slate_id: str = Field(..., description="UUID of the target slate")
    num_lineups: int = Field(150, ge=1, le=150)
    platform: str = Field("fanduel", pattern="^(fanduel|draftkings)$")
    contest_type: str = Field(
        "small_gpp",
        description="cash | small_gpp | large_gpp | showdown",
    )
    max_exposure: float = Field(0.35, ge=0.0, le=1.0)
    min_salary: int = Field(49000, ge=0, le=60000)
    max_salary: int = Field(60000, ge=0, le=60000)
    exclude_injured: bool = Field(True)
    async_mode: bool = Field(
        True, description="When true, defer to Dramatiq worker. False = inline (dev/test)."
    )


class CreateRunResponse(BaseModel):
    run_id: str
    status: str
    async_mode: bool
    message: str


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _run_to_dict(run: Run) -> Dict[str, Any]:
    """Serialize a Run ORM row to a plain dict."""
    settings: Dict[str, Any] = {}
    try:
        if hasattr(run, "get_settings"):
            settings = run.get_settings()
    except Exception:
        pass
    return {
        "run_id": run.id,
        "slate_id": run.slate_id,
        "status": run.status,
        "num_lineups": run.num_lineups or 0,
        "settings": settings,
        "error_message": run.error_message,
        "created_at": run.created_at.isoformat() if run.created_at else None,
        "started_at": run.started_at.isoformat() if run.started_at else None,
        "completed_at": run.completed_at.isoformat() if run.completed_at else None,
    }


def _get_run_or_404(run_id: str, db: Session) -> Run:
    try:
        run: Optional[Run] = db.get(Run, run_id)
    except SQLAlchemyError:
        raise HTTPException(status_code=503, detail="Database unavailable")
    if run is None:
        raise HTTPException(status_code=404, detail=f"Run not found: '{run_id}'")
    return run


# ---------------------------------------------------------------------------
# Read endpoints
# ---------------------------------------------------------------------------

@router.get("/{run_id}")
def get_run(
    run_id: str,
    db: Session = Depends(get_db),
) -> Dict[str, Any]:
    """Return full details of an optimizer run."""
    run = _get_run_or_404(run_id, db)
    return _run_to_dict(run)


@router.get("/{run_id}/status")
def get_run_status(
    run_id: str,
    db: Session = Depends(get_db),
) -> Dict[str, Any]:
    """
    Fast polling endpoint — returns run_id, status, num_lineups.

    Designed for the frontend to poll every few seconds until status
    transitions to 'completed' or 'failed'.
    """
    run = _get_run_or_404(run_id, db)
    return {
        "run_id": run.id,
        "status": run.status,
        "num_lineups": run.num_lineups or 0,
        "error_message": run.error_message,
    }


# ---------------------------------------------------------------------------
# Create endpoint
# ---------------------------------------------------------------------------

@router.post("", response_model=CreateRunResponse)
async def create_optimizer_run(
    body: CreateRunRequest = Body(...),
    db: Session = Depends(get_db),
) -> Dict[str, Any]:
    """
    Create and (optionally) enqueue an optimizer run.

    When ``async_mode=true`` (default) the task is dispatched to a
    Dramatiq worker via Redis.  When the worker is unavailable the task
    degrades to synchronous inline execution so local dev still works.

    Poll ``GET /api/results/{run_id}/status`` for progress.
    """
    # Verify the slate exists before creating a run
    from models.slate import Slate

    slate = db.get(Slate, body.slate_id)
    if slate is None:
        raise HTTPException(
            status_code=404, detail=f"Slate not found: '{body.slate_id}'"
        )

    settings = body.model_dump(exclude={"slate_id", "async_mode"})

    run: Run = create_run(
        db=db,
        slate_id=body.slate_id,
        num_lineups=body.num_lineups,
        settings=settings,
    )

    # ------------------------------------------------------------------
    # Dispatch
    # ------------------------------------------------------------------
    dispatched_async = False

    if body.async_mode:
        try:
            from tasks.optimizer_tasks import run_optimizer_task, DRAMATIQ_AVAILABLE

            if DRAMATIQ_AVAILABLE:
                run_optimizer_task.send(
                    run_id=run.id,
                    slate_id=body.slate_id,
                    num_lineups=body.num_lineups,
                    platform=body.platform,
                    contest_type=body.contest_type,
                    max_exposure=body.max_exposure,
                    min_salary=body.min_salary,
                    max_salary=body.max_salary,
                    exclude_injured=body.exclude_injured,
                )
                dispatched_async = True
            else:
                # Fallback: run inline (blocks the request — acceptable in dev)
                run_optimizer_task(
                    run_id=run.id,
                    slate_id=body.slate_id,
                    num_lineups=body.num_lineups,
                    platform=body.platform,
                    contest_type=body.contest_type,
                    max_exposure=body.max_exposure,
                    min_salary=body.min_salary,
                    max_salary=body.max_salary,
                    exclude_injured=body.exclude_injured,
                )
        except ImportError:
            # tasks module not yet available
            pass
    else:
        # Explicit sync mode (e.g. during integration tests)
        # Wrap with a timeout to prevent runaway blocking requests.
        import concurrent.futures
        import os as _os

        _timeout = int(_os.getenv("OPTIMIZER_TIMEOUT_SECONDS", "300"))
        try:
            from tasks.optimizer_tasks import run_optimizer_task

            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as _pool:
                future = _pool.submit(
                    run_optimizer_task,
                    run_id=run.id,
                    slate_id=body.slate_id,
                    num_lineups=body.num_lineups,
                    platform=body.platform,
                    contest_type=body.contest_type,
                    max_exposure=body.max_exposure,
                    min_salary=body.min_salary,
                    max_salary=body.max_salary,
                    exclude_injured=body.exclude_injured,
                )
                try:
                    future.result(timeout=_timeout)
                except concurrent.futures.TimeoutError:
                    # Mark the run as failed so UI reflects the timeout
                    from services.run_service import fail_run
                    fail_run(db, run.id, reason=f"Optimizer timed out after {_timeout}s")
                    raise HTTPException(
                        status_code=504,
                        detail=(
                            f"Optimizer did not finish within {_timeout}s. "
                            "Increase OPTIMIZER_TIMEOUT_SECONDS or use async_mode=true."
                        ),
                    )
        except HTTPException:
            raise
        except ImportError:
            pass

    if dispatched_async:
        msg = (
            f"Run {run.id} enqueued. "
            f"Poll GET /api/results/{run.id}/status for progress."
        )
    else:
        msg = f"Run {run.id} executed synchronously."

    return {
        "run_id": run.id,
        "status": run.status,
        "async_mode": dispatched_async,
        "message": msg,
    }
