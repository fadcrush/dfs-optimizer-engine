"""
Results Router — expose post-run analytics to the frontend.

Routes
------
GET /api/results/{run_id}/status
    Return current status of a run (queued/running/completed/failed).

GET /api/results/{run_id}/exposure
    Return per-player exposure data for a completed optimizer run.
    Consumed by the LineupAnalytics React component.

Data sources tried in order for /exposure:
  1. Database (lineup_entries table)     ← new DB-first path
  2. outputs/runs/{run_id}.json          ← written by save_run_file()
  3. outputs/analytics_{run_id}.json     ← legacy fallback
"""

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import func
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from analytics import get_run_file, get_analytics_report
from database.db import get_db
from models.lineup import Lineup
from models.lineup_entry import LineupEntry
from models.player import Player
from models.projection import Projection
from models.run import Run

router = APIRouter(prefix="/results", tags=["Results"])


# ---------------------------------------------------------------------------
# Response models
# ---------------------------------------------------------------------------

class PlayerRow(BaseModel):
    """Per-player stats row in the exposure response."""
    player_id: str
    name: str
    team: str = ""
    position: str = ""
    salary: int = 0
    count: int
    exposure_pct: float
    avg_projection: float = 0.0
    leverage: Optional[float] = None  # projected − actual ownership; null until ownership data available


class RunExposureResponse(BaseModel):
    """Full response for GET /results/{run_id}/exposure."""
    run_id: str
    total_lineups: int
    players: List[PlayerRow]


class RunStatusResponse(BaseModel):
    """Full response for GET /results/{run_id}/status."""
    run_id: str
    status: str
    num_lineups: int
    slate_id: Optional[str] = None
    error_message: Optional[str] = None
    created_at: Optional[str] = None
    started_at: Optional[str] = None
    completed_at: Optional[str] = None


# ---------------------------------------------------------------------------
# DB-first exposure calculator
# ---------------------------------------------------------------------------

def _exposure_from_db(db: Session, run_id: str) -> Optional[Dict[str, Any]]:
    """
    Calculate exposure directly from lineup_entries.

    Returns None when the run does not exist in the DB, has no lineups,
    or when the DFS schema tables haven't been created yet (graceful
    degradation so the file-based fallback path still works in environments
    where `alembic upgrade head` hasn't been run).
    """
    try:
        run: Optional[Run] = db.get(Run, run_id)
        if run is None:
            return None

        total_lineups = (
            db.query(func.count(Lineup.id)).filter(Lineup.run_id == run_id).scalar() or 0
        )
        if total_lineups == 0:
            return None

        entry_counts = (
            db.query(LineupEntry.player_id, func.count(LineupEntry.id).label("cnt"))
            .join(Lineup, Lineup.id == LineupEntry.lineup_id)
            .filter(Lineup.run_id == run_id)
            .group_by(LineupEntry.player_id)
            .all()
        )
        if not entry_counts:
            return None

        player_ids = [row.player_id for row in entry_counts]
        counts_map = {row.player_id: row.cnt for row in entry_counts}

        player_rows = (
            db.query(Player, Projection)
            .outerjoin(Projection, Projection.player_id == Player.id)
            .filter(Player.id.in_(player_ids))
            .all()
        )
        meta: Dict[str, Dict[str, Any]] = {}
        for player, proj in player_rows:
            meta[player.id] = {
                "name": player.name,
                "team": player.team or "",
                "position": player.position or "",
                "salary": player.salary or 0,
                "avg_projection": (proj.projection if proj else 0.0) or 0.0,
                "ownership_pct": (proj.ownership_pct if proj else None),
            }

        players_out: List[Dict[str, Any]] = []
        for player_id, cnt in counts_map.items():
            info = meta.get(player_id, {})
            exposure_pct = round(cnt / total_lineups, 4) if total_lineups > 0 else 0.0
            avg_proj = float(info.get("avg_projection", 0.0))
            own_pct = info.get("ownership_pct")
            leverage = round(avg_proj - own_pct, 4) if own_pct is not None else None
            players_out.append({
                "player_id": player_id,
                "name": info.get("name", player_id),
                "team": info.get("team", ""),
                "position": info.get("position", ""),
                "salary": info.get("salary", 0),
                "count": cnt,
                "exposure_pct": exposure_pct,
                "avg_projection": avg_proj,
                "leverage": leverage,
            })

        players_out.sort(key=lambda r: r["exposure_pct"], reverse=True)
        return {"run_id": run_id, "total_lineups": total_lineups, "players": players_out}

    except SQLAlchemyError:
        # Tables may not exist yet (pre-migration environment) — fall through to file fallback
        try:
            db.rollback()
        except Exception:
            pass
        return None


# ---------------------------------------------------------------------------
# Legacy file adapters
# ---------------------------------------------------------------------------

def _normalise_from_run_file(data: Dict[str, Any], run_id: str) -> Dict[str, Any]:
    players: List[Dict[str, Any]] = []
    for row in data.get("players", []):
        players.append({
            "player_id": row.get("player_id", ""),
            "name": row.get("name", row.get("player_id", "")),
            "team": row.get("team", ""),
            "position": row.get("position", ""),
            "salary": int(row.get("salary", 0)),
            "count": int(row.get("count", 0)),
            "exposure_pct": float(row.get("exposure_pct", row.get("pct", 0.0))),
            "avg_projection": float(row.get("avg_projection", 0.0)),
            "leverage": row.get("leverage"),
        })
    return {
        "run_id": data.get("run_id", run_id),
        "total_lineups": int(data.get("total_lineups", 0)),
        "players": players,
    }


def _normalise_from_analytics(data: Dict[str, Any], run_id: str) -> Dict[str, Any]:
    players: List[Dict[str, Any]] = []
    for row in data.get("exposure", []):
        players.append({
            "player_id": row.get("player_id", row.get("player", "")),
            "name": row.get("player", row.get("player_id", "")),
            "team": row.get("team", ""),
            "position": row.get("position", ""),
            "salary": int(row.get("salary", 0)),
            "count": int(row.get("count", 0)),
            "exposure_pct": float(row.get("pct", row.get("exposure_pct", 0.0))),
            "avg_projection": float(row.get("avg_projection", 0.0)),
            "leverage": row.get("leverage"),
        })
    return {
        "run_id": data.get("run_id", run_id),
        "total_lineups": int(data.get("total_lineups", 0)),
        "players": players,
    }


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@router.get("/{run_id}/status", response_model=RunStatusResponse)
async def get_run_status(
    run_id: str,
    db: Session = Depends(get_db),
) -> Dict[str, Any]:
    """
    Return the current status of an optimizer run.

    Used by the frontend to poll for job completion.
    """
    try:
        run: Optional[Run] = db.get(Run, run_id)
    except SQLAlchemyError:
        raise HTTPException(status_code=404, detail=f"Run not found: '{run_id}'")
    if run is None:
        raise HTTPException(status_code=404, detail=f"Run not found: '{run_id}'")
    return {
        "run_id": run.id,
        "status": run.status,
        "num_lineups": run.num_lineups or 0,
        "slate_id": run.slate_id,
        "error_message": run.error_message,
        "created_at": run.created_at.isoformat() if run.created_at else None,
        "started_at": run.started_at.isoformat() if run.started_at else None,
        "completed_at": run.completed_at.isoformat() if run.completed_at else None,
    }


@router.get("/{run_id}/exposure", response_model=RunExposureResponse)
async def get_run_exposure(
    run_id: str,
    db: Session = Depends(get_db),
) -> Dict[str, Any]:
    """
    Return per-player exposure statistics for a completed optimizer run.

    Data sources (tried in order):
      1. Database lineup_entries — used for all DB-first runs
      2. outputs/runs/{run_id}.json — save_run_file() legacy path
      3. outputs/analytics_{run_id}.json — oldest fallback
    """
    # 1. Database (new SaaS path)
    db_result = _exposure_from_db(db, run_id)
    if db_result is not None:
        return db_result

    # 2. Structured run file
    run_data = get_run_file(run_id)
    if run_data is not None:
        return _normalise_from_run_file(run_data, run_id)

    # 3. Legacy analytics file
    analytics_data = get_analytics_report(run_id)
    if analytics_data is not None:
        return _normalise_from_analytics(analytics_data, run_id)

    raise HTTPException(
        status_code=404,
        detail=(
            f"No run data found for run_id '{run_id}'. "
            "The optimizer may not have completed, or analytics persistence may be disabled."
        ),
    )


@router.get("/{run_id}/lineups")
async def get_run_lineups(
    run_id: str,
    db: Session = Depends(get_db),
) -> Dict[str, Any]:
    """
    Return all lineups with full player details for a completed optimizer run.

    Each lineup includes lineup_id, lineup_number, total_salary, total_projection,
    and the list of players (name, position, team, salary).
    """
    try:
        run: Optional[Run] = db.get(Run, run_id)
    except SQLAlchemyError:
        raise HTTPException(status_code=503, detail="Database unavailable")
    if run is None:
        raise HTTPException(status_code=404, detail=f"Run not found: '{run_id}'")

    try:
        lineups = (
            db.query(Lineup)
            .filter(Lineup.run_id == run_id)
            .order_by(Lineup.lineup_number)
            .all()
        )
    except SQLAlchemyError:
        raise HTTPException(
            status_code=503,
            detail="Database tables not ready. Run: alembic upgrade head",
        )

    result: List[Dict[str, Any]] = []
    for lineup in lineups:
        try:
            entry_rows = (
                db.query(LineupEntry, Player)
                .join(Player, Player.id == LineupEntry.player_id)
                .filter(LineupEntry.lineup_id == lineup.id)
                .all()
            )
        except SQLAlchemyError:
            entry_rows = []

        result.append({
            "lineup_id": lineup.id,
            "lineup_number": lineup.lineup_number,
            "total_salary": lineup.total_salary,
            "total_projection": lineup.total_projection,
            "players": [
                {
                    "player_id": player.id,
                    "name": player.name,
                    "position": entry.position or player.position or "",
                    "team": player.team or "",
                    "salary": player.salary or 0,
                }
                for entry, player in entry_rows
            ],
        })

    return {"run_id": run_id, "total_lineups": len(result), "lineups": result}
