"""
Configuration Service
Manages model assumptions, parameters, and validation
"""

import json
import os
from pathlib import Path
from typing import Dict, Any, Optional
import logging
from dataclasses import dataclass
from dotenv import load_dotenv

logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

@dataclass
class ModelConfig:
    """Structured configuration object"""
    version: str
    projection_assumptions: Dict[str, Any]
    simulation_parameters: Dict[str, Any]
    opportunity_modeling: Dict[str, Any]
    optimization_settings: Dict[str, Any]
    data_quality_thresholds: Dict[str, Any]
    performance_monitoring: Dict[str, Any]
    feature_flags: Dict[str, bool]
    api_endpoints: Dict[str, Any]
    data_refresh_intervals: Dict[str, Any]
    model_validation: Dict[str, Any]
    business_rules: Dict[str, Any]
    logging_config: Dict[str, Any]


class ConfigurationService:
    """
    Professional configuration management for DFS AI
    Handles loading, validation, and access to model parameters
    """

    def __init__(self, config_path: Optional[Path] = None):
        if config_path is None:
            # Default path relative to this file
            config_path = Path(__file__).parent.parent.parent / 'config' / 'model_config.json'

        self.config_path = config_path
        self._config = None
        self._load_config()

    def _load_config(self) -> None:
        """Load configuration from JSON file"""
        try:
            if not self.config_path.exists():
                logger.warning(f"Config file not found: {self.config_path}")
                self._create_default_config()
                return

            with open(self.config_path, 'r') as f:
                config_data = json.load(f)

            # Validate configuration
            self._validate_config(config_data)

            # Convert to structured object
            self._config = ModelConfig(
                version=config_data.get('version', '1.0.0'),
                projection_assumptions=config_data.get('projection_assumptions', {}),
                simulation_parameters=config_data.get('simulation_parameters', {}),
                opportunity_modeling=config_data.get('opportunity_modeling', {}),
                optimization_settings=config_data.get('optimization_settings', {}),
                data_quality_thresholds=config_data.get('data_quality_thresholds', {}),
                performance_monitoring=config_data.get('performance_monitoring', {}),
                feature_flags=config_data.get('feature_flags', {}),
                api_endpoints=config_data.get('api_endpoints', {}),
                data_refresh_intervals=config_data.get('data_refresh_intervals', {}),
                model_validation=config_data.get('model_validation', {}),
                business_rules=config_data.get('business_rules', {}),
                logging_config=config_data.get('logging_and_monitoring', {})
            )

            logger.info(f"Loaded configuration version {self._config.version}")

        except Exception as e:
            logger.error(f"Failed to load configuration: {e}")
            self._create_default_config()

    def _validate_config(self, config_data: Dict) -> None:
        """Validate configuration structure and values"""
        required_sections = [
            'projection_assumptions', 'simulation_parameters',
            'opportunity_modeling', 'optimization_settings',
            'feature_flags', 'business_rules'
        ]

        missing_sections = []
        for section in required_sections:
            if section not in config_data:
                missing_sections.append(section)

        if missing_sections:
            raise ValueError(f"Missing required configuration sections: {missing_sections}")

        # Validate feature flags are boolean
        for flag, value in config_data.get('feature_flags', {}).items():
            if not isinstance(value, bool):
                raise ValueError(f"Feature flag {flag} must be boolean, got {type(value)}")

        # Validate business rules
        business_rules = config_data.get('business_rules', {})
        if business_rules.get('max_salary_cap', 0) <= business_rules.get('min_salary_threshold', 0):
            raise ValueError("max_salary_cap must be greater than min_salary_threshold")

    def _create_default_config(self) -> None:
        """Create default configuration if file is missing"""
        logger.warning("Creating default configuration")

        default_config = {
            "version": "1.0.0",
            "projection_assumptions": {
                "season_weight": 0.7,
                "recent_games_weight": 0.3,
                "minimum_games_threshold": 5,
                "regression_factor": 0.1,
                "injured_player_projection": 0.0
            },
            "simulation_parameters": {
                "default_simulations": 10000,
                "correlation_threshold": 0.1
            },
            "opportunity_modeling": {
                "star_player_protection": 1.05,
                "backup_boost_factor": 1.2
            },
            "optimization_settings": {
                "risk_tolerance_default": 0.5,
                "correlation_penalty_weight": 0.1
            },
            "feature_flags": {
                "enable_simulation_engine": True,
                "enable_opportunity_modeling": True
            },
            "business_rules": {
                "max_salary_cap": 60000,
                "min_salary_threshold": 49000
            }
        }

        # Save default config
        self.config_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.config_path, 'w') as f:
            json.dump(default_config, f, indent=2)

        # Load it
        self._load_config()

    def get(self, section: str, key: Optional[str] = None, default: Any = None) -> Any:
        """Get configuration value"""
        if self._config is None:
            return default

        section_data = getattr(self._config, section, None)
        if section_data is None:
            return default

        if key is None:
            return section_data

        return section_data.get(key, default)

    def is_feature_enabled(self, feature: str) -> bool:
        """Check if a feature flag is enabled"""
        return self.get('feature_flags', feature, False)

    def get_api_key(self, service: str) -> Optional[str]:
        """Get API key from environment variables"""
        key_mapping = {
            'sportsdata': 'SPORTSDATA_API_KEY',
            'odds': 'ODDS_API_KEY',
            'weather': 'OPENWEATHER_API_KEY',
            'news': 'NEWS_API_KEY'
        }

        env_var = key_mapping.get(service)
        if env_var:
            return os.getenv(env_var)

        return None

    def get_api_endpoint(self, service: str) -> Optional[str]:
        """Get API endpoint URL"""
        return self.get('api_endpoints', service)

    def get_refresh_interval(self, data_type: str) -> int:
        """Get data refresh interval in minutes"""
        return self.get('data_refresh_intervals', data_type, 60)

    def validate_business_rules(self, lineup_data: Dict) -> Dict:
        """Validate lineup against business rules"""
        violations = []

        salary = lineup_data.get('total_salary', 0)
        max_salary = self.get('business_rules', 'max_salary_cap', 60000)
        min_salary = self.get('business_rules', 'min_salary_threshold', 49000)

        if salary > max_salary:
            violations.append(f"Salary cap exceeded: {salary} > {max_salary}")
        elif salary < min_salary:
            violations.append(f"Salary below minimum: {salary} < {min_salary}")

        return {
            'valid': len(violations) == 0,
            'violations': violations
        }

    def get_model_assumptions(self) -> Dict:
        """Get all model assumptions for transparency"""
        return {
            'projection_assumptions': self.get('projection_assumptions'),
            'simulation_parameters': self.get('simulation_parameters'),
            'opportunity_modeling': self.get('opportunity_modeling'),
            'optimization_settings': self.get('optimization_settings'),
            'data_quality_thresholds': self.get('data_quality_thresholds')
        }

    def export_config_summary(self, output_path: Path) -> None:
        """Export configuration summary for documentation"""
        if self._config is None:
            return

        summary = {
            'version': self._config.version,
            'enabled_features': [k for k, v in self._config.feature_flags.items() if v],
            'key_assumptions': self.get_model_assumptions(),
            'business_rules': self._config.business_rules,
            'exported_at': str(Path(output_path).stat().st_mtime) if output_path.exists() else None
        }

        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, 'w') as f:
            json.dump(summary, f, indent=2, default=str)

        logger.info(f"Exported configuration summary to {output_path}")

    def reload_config(self) -> bool:
        """Reload configuration from file"""
        try:
            self._load_config()
            return True
        except Exception as e:
            logger.error(f"Failed to reload configuration: {e}")
            return False


# Global configuration instance
_config_service = None

def get_config_service() -> ConfigurationService:
    """Get global configuration service instance"""
    global _config_service
    if _config_service is None:
        _config_service = ConfigurationService()
    return _config_service

def get_config(section: str, key: Optional[str] = None, default: Any = None) -> Any:
    """Convenience function to get configuration values"""
    return get_config_service().get(section, key, default)

def is_feature_enabled(feature: str) -> bool:
    """Convenience function to check feature flags"""
    return get_config_service().is_feature_enabled(feature)


if __name__ == "__main__":
    # Test configuration loading
    config = get_config_service()
    print(f"Configuration loaded: {config._config is not None}")
    print(f"Simulation engine enabled: {is_feature_enabled('enable_simulation_engine')}")
    print(f"Default simulations: {get_config('simulation_parameters', 'default_simulations')}")
