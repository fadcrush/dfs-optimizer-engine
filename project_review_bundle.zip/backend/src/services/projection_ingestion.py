"""
Projection ingestion service — database-first.

Workflow:
  1. Receive raw CSV bytes + optional metadata.
  2. Parse into a normalised player list (reuses the _parse_players logic
     already proven in routers/projections.py).
  3. Create (or reuse) a Slate row.
  4. Upsert SlatePlayer rows for every player in the file.
  5. Upsert Projection rows for those players.
  6. Return a summary dict with slate_id and row counts.

Caller (router) is responsible for the HTTP layer and auth.
"""

from __future__ import annotations

import io
import math
import re
import uuid
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd
from sqlalchemy.orm import Session
from sqlalchemy.dialects.sqlite import insert as sqlite_insert

from models.slate import Slate
from models.player import Player
from models.projection import Projection


# ---------------------------------------------------------------------------
# Safe-conversion helpers  (duplicated from routers/projections.py so this
# service has zero dependencies on the router layer)
# ---------------------------------------------------------------------------

def _safe_float(val: Any, default: float = 0.0) -> float:
    try:
        f = float(val)
        return default if math.isnan(f) or math.isinf(f) else f
    except (ValueError, TypeError):
        return default


def _safe_int(val: Any, default: int = 0) -> int:
    return int(_safe_float(val, float(default)))


def _safe_str(val: Any, default: str = "") -> str:
    if val is None:
        return default
    try:
        if isinstance(val, float) and math.isnan(val):
            return default
    except (ValueError, TypeError):
        pass
    s = str(val).strip()
    return s if s and s.lower() != "nan" else default


_INJURY_MAP = {"O": "OUT", "Q": "QUESTIONABLE", "D": "DOUBTFUL", "P": "PROBABLE"}


# ---------------------------------------------------------------------------
# Platform / sport detection
# ---------------------------------------------------------------------------

def detect_platform(columns: List[str]) -> str:
    cols_lower = [c.lower() for c in columns]
    if any(k in cols_lower for k in ("nickname", "fppg", "injury indicator")):
        return "fanduel"
    if any(k in cols_lower for k in ("roster position", "avgpointspergame")):
        return "draftkings"
    return "fanduel"


def detect_sport(df: pd.DataFrame, columns: List[str]) -> str:
    pos_col = next((c for c in columns if c.lower() == "position"), None)
    if pos_col and len(df) > 0:
        positions = set(df[pos_col].dropna().str.upper().unique())
        nfl_positions = {"QB", "RB", "WR", "TE", "K", "DST", "DEF"}
        if positions & nfl_positions:
            return "nfl"
    return "nba"


# ---------------------------------------------------------------------------
# Row parsing
# ---------------------------------------------------------------------------

def _parse_row_fanduel(row: pd.Series) -> Dict[str, Any]:
    name = _safe_str(row.get("Nickname", row.get("Name", "")), "Unknown")
    pid = _safe_str(row.get("Id", row.get("ID", "")))
    position = _safe_str(row.get("Position", ""), "UTIL")
    salary = _safe_int(row.get("Salary", 0))
    team = _safe_str(row.get("Team", ""))
    opponent = _safe_str(row.get("Opponent", ""))
    game = _safe_str(row.get("Game", ""))
    fppg = _safe_float(row.get("FPPG", 0))
    injury_raw = _safe_str(row.get("Injury Indicator", "")).upper()
    return dict(
        external_id=pid,
        name=name,
        position=position,
        team=team,
        opponent=opponent,
        salary=salary,
        game=game,
        fppg=fppg,
        injury_status=_INJURY_MAP.get(injury_raw),
    )


def _parse_row_draftkings(row: pd.Series) -> Dict[str, Any]:
    name = _safe_str(row.get("Name", ""), "Unknown")
    pid = _safe_str(row.get("ID", row.get("Id", "")))
    position = _safe_str(
        row.get("Position", row.get("Roster Position", "")), "UTIL"
    )
    salary = _safe_int(row.get("Salary", 0))
    team = _safe_str(row.get("TeamAbbrev", row.get("Team", "")))
    game_info = _safe_str(row.get("Game Info", ""))
    opponent = ""
    if game_info and team:
        teams_in_game = re.findall(r"[A-Z]{2,4}", game_info.split(" ")[0])
        for t in teams_in_game:
            if t != team:
                opponent = t
                break
    fppg = _safe_float(row.get("AvgPointsPerGame", 0))
    return dict(
        external_id=pid,
        name=name,
        position=position,
        team=team,
        opponent=opponent,
        salary=salary,
        game=game_info,
        fppg=fppg,
        injury_status=None,
    )


def _parse_df(df: pd.DataFrame, platform: str) -> List[Dict[str, Any]]:
    """Return a list of normalised player dicts from the slate DataFrame."""
    rows: List[Dict[str, Any]] = []
    for _, row in df.iterrows():
        r = (
            _parse_row_fanduel(row)
            if platform == "fanduel"
            else _parse_row_draftkings(row)
        )
        if not r["name"] or r["name"] == "Unknown":
            continue
        fppg = r.pop("fppg")
        r["projection"] = round(fppg, 2)
        r["floor"] = round(fppg * 0.7, 2)
        r["ceiling"] = round(fppg * 1.4, 2)
        r["value"] = (
            round(r["projection"] / (r["salary"] / 1000), 2) if r["salary"] > 0 else 0.0
        )
        rows.append(r)
    return rows


# ---------------------------------------------------------------------------
# Upsert helpers  (SQLAlchemy-portable; uses merge/update pattern)
# ---------------------------------------------------------------------------

def _upsert_player(db: Session, slate_id: str, row: Dict[str, Any]) -> Player:
    """
    Find-or-create a SlatePlayer by (slate_id, external_id).
    Updates all mutable fields on conflict.
    """
    external_id = row["external_id"] or row["name"]  # fallback when no platform ID
    player = (
        db.query(Player)
        .filter_by(slate_id=slate_id, external_id=external_id)
        .first()
    )
    if player is None:
        player = Player(
            id=str(uuid.uuid4()),
            slate_id=slate_id,
            external_id=external_id,
        )
        db.add(player)

    player.name = row["name"]
    player.position = row["position"]
    player.team = row["team"]
    player.opponent = row["opponent"]
    player.salary = row["salary"]
    player.game = row["game"]
    return player


def _upsert_projection(
    db: Session, slate_id: str, player_id: str, row: Dict[str, Any]
) -> Projection:
    """Find-or-create a Projection by (slate_id, player_id)."""
    proj = (
        db.query(Projection)
        .filter_by(slate_id=slate_id, player_id=player_id)
        .first()
    )
    if proj is None:
        proj = Projection(
            id=str(uuid.uuid4()),
            slate_id=slate_id,
            player_id=player_id,
        )
        db.add(proj)

    proj.projection = row["projection"]
    proj.floor = row["floor"]
    proj.ceiling = row["ceiling"]
    proj.value = row["value"]
    proj.injury_status = row.get("injury_status")
    return proj


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def ingest_projections_csv(
    db: Session,
    csv_bytes: bytes,
    filename: str = "upload.csv",
    sport: Optional[str] = None,
    slate_date: Optional[date] = None,
) -> Dict[str, Any]:
    """
    Parse *csv_bytes*, persist a Slate + Players + Projections.

    Returns::

        {
            "slate_id": "...",
            "platform": "fanduel",
            "sport": "nba",
            "player_count": 150,
            "created": True   # False when slate already existed
        }
    """
    try:
        df = pd.read_csv(io.BytesIO(csv_bytes))
    except Exception:
        raise ValueError("CSV is empty or could not be parsed")
    if df.empty:
        raise ValueError("CSV is empty or could not be parsed")

    platform = detect_platform(df.columns.tolist())
    if sport is None:
        sport = detect_sport(df, df.columns.tolist())

    rows = _parse_df(df, platform)
    if not rows:
        raise ValueError("No valid player rows found in CSV")

    # ---- Create Slate ---------------------------------------------------
    slate = Slate(
        id=str(uuid.uuid4()),
        sport=sport,
        platform=platform,
        slate_date=slate_date,
        source_filename=filename,
        player_count=len(rows),
        created_at=datetime.now(timezone.utc).replace(tzinfo=None),
    )
    db.add(slate)
    db.flush()   # ensure slate.id is available for FK references

    # ---- Upsert Players + Projections -----------------------------------
    for row in rows:
        player = _upsert_player(db, slate.id, row)
        db.flush()   # need player.id for projection FK
        _upsert_projection(db, slate.id, player.id, row)

    db.commit()

    return {
        "slate_id": slate.id,
        "platform": platform,
        "sport": sport,
        "player_count": len(rows),
        "filename": filename,
    }
