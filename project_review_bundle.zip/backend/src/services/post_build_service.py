"""
Post-Build Service (stub).

Provides lineup post-processing helpers:
  - rebuild_with_exposure_constraints
  - diversify_lineups
  - replace_player_in_lineups
  - get_contest_preset_settings

These are feature stubs — they return safe defaults so the optimizer router
can be imported and the core endpoints operate.  Full implementations will be
added in Batch 2.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

import pandas as pd

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# rebuild_with_exposure_constraints
# ---------------------------------------------------------------------------

def rebuild_with_exposure_constraints(
    original_lineups: List[Dict[str, Any]],
    pool: pd.DataFrame,
    max_exposure: float = 0.35,
    min_exposure: float = 0.0,
    locked_players: Optional[List[str]] = None,
    num_lineups: Optional[int] = None,
    min_salary: int = 49000,
    max_salary: int = 60000,
    platform: str = "fanduel",
) -> Dict[str, Any]:
    """Rebuild *original_lineups* respecting new exposure bounds.

    Stub: returns originals unchanged until full implementation is added.
    """
    logger.warning(
        "rebuild_with_exposure_constraints is a stub – returning originals unchanged"
    )
    return {
        "success": True,
        "lineups": original_lineups,
        "total_lineups": len(original_lineups),
        "stats": {"note": "stub – no constraints applied"},
        "message": f"Returning {len(original_lineups)} original lineups (stub mode)",
    }


# ---------------------------------------------------------------------------
# diversify_lineups
# ---------------------------------------------------------------------------

def diversify_lineups(
    lineups: List[Dict[str, Any]],
    min_unique_players: int = 2,
    max_similarity: float = 0.8,
) -> Dict[str, Any]:
    """Filter *lineups* to reduce duplicates.

    Stub: returns all lineups unchanged.
    """
    logger.warning("diversify_lineups is a stub – returning all lineups unchanged")
    return {
        "success": True,
        "lineups": lineups,
        "original_count": len(lineups),
        "final_count": len(lineups),
        "stats": {"note": "stub – no diversification applied"},
        "message": f"Returning {len(lineups)} lineups (stub mode)",
    }


# ---------------------------------------------------------------------------
# replace_player_in_lineups
# ---------------------------------------------------------------------------

def replace_player_in_lineups(
    lineups: List[Dict[str, Any]],
    player_out: str,
    player_in: str,
    **kwargs: Any,
) -> Dict[str, Any]:
    """Replace *player_out* with *player_in* in all matching lineups.

    Stub: does a simple string-replace on lineup dicts.
    """
    replaced = 0
    new_lineups: List[Dict[str, Any]] = []
    for lu in lineups:
        new_lu = {
            k: (player_in if v == player_out else v) for k, v in lu.items()
        }
        if new_lu != lu:
            replaced += 1
        new_lineups.append(new_lu)

    return {
        "success": True,
        "lineups": new_lineups,
        "replaced_count": replaced,
        "message": f"Replaced '{player_out}' with '{player_in}' in {replaced} lineups",
    }


# ---------------------------------------------------------------------------
# get_contest_preset_settings
# ---------------------------------------------------------------------------

_PRESETS: Dict[str, Dict[str, Any]] = {
    "cash": {
        "contest_type": "cash",
        "max_exposure": 0.60,
        "min_salary": 59000,
        "max_salary": 60000,
        "num_lineups": 20,
    },
    "small_gpp": {
        "contest_type": "small_gpp",
        "max_exposure": 0.35,
        "min_salary": 58000,
        "max_salary": 60000,
        "num_lineups": 50,
    },
    "large_gpp": {
        "contest_type": "large_gpp",
        "max_exposure": 0.25,
        "min_salary": 57000,
        "max_salary": 60000,
        "num_lineups": 150,
    },
    "showdown": {
        "contest_type": "showdown",
        "max_exposure": 0.30,
        "min_salary": 49000,
        "max_salary": 60000,
        "num_lineups": 20,
    },
}


def get_contest_preset_settings(
    contest_type: str, platform: str = "fanduel"
) -> Dict[str, Any]:
    """Return preset optimizer settings for *contest_type*."""
    preset = _PRESETS.get(contest_type, _PRESETS["small_gpp"]).copy()
    preset["platform"] = platform
    return {"success": True, "settings": preset}
