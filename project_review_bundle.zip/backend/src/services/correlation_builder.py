"""
Correlation Matrix Builder Service

Builds empirical correlation matrices from historical game logs for:
- Teammate correlations (same-game stacking)
- Opponent correlations (game stacks)
- Position-based correlations
- Vegas-adjusted correlations

Used by the simulation engine for realistic correlated outcome sampling.
"""

import numpy as np
import pandas as pd
from scipy import stats
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from pathlib import Path
import duckdb
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

DUCKDB_PATH = Path(__file__).parent.parent.parent / "data" / "dfs_master.duckdb"


@dataclass
class CorrelationConfig:
    """Configuration for correlation calculations"""
    min_shared_games: int = 10  # Minimum games together to calculate correlation
    lookback_days: int = 180    # Days of history to use
    decay_half_life: int = 30   # Half-life for time-weighted correlations

    # Default correlation priors (used when insufficient data)
    teammate_prior: float = 0.15
    opponent_prior: float = 0.05
    same_position_prior: float = 0.08
    cross_position_prior: float = 0.03


class CorrelationBuilder:
    """
    Builds correlation matrices from historical game data
    """

    def __init__(self, config: CorrelationConfig = None):
        self.config = config or CorrelationConfig()
        self.game_correlations: Dict[str, Dict[str, float]] = {}
        self.position_correlations: Dict[Tuple[str, str], float] = {}
        self.team_correlations: Dict[str, Dict[str, float]] = {}

    def load_game_logs(self, lookback_days: int = None) -> pd.DataFrame:
        """Load game logs from database"""

        lookback = lookback_days or self.config.lookback_days

        if not DUCKDB_PATH.exists():
            logger.warning("Database not found, returning empty DataFrame")
            return pd.DataFrame()

        try:
            conn = duckdb.connect(str(DUCKDB_PATH), read_only=True)

            query = """
            SELECT
                player_name,
                team,
                opponent,
                date as game_date,
                position,
                fd_points,
                dk_points,
                minutes
            FROM player_game_logs
            WHERE date >= CURRENT_DATE - INTERVAL ? DAY
              AND fd_points IS NOT NULL
              AND minutes >= 10
            ORDER BY date DESC
            """

            df = conn.execute(query, [lookback]).fetchdf()
            conn.close()

            logger.info(f"Loaded {len(df)} game logs for correlation analysis")
            return df

        except Exception as e:
            logger.error(f"Error loading game logs: {e}")
            return pd.DataFrame()

    def build_teammate_correlations(self, df: pd.DataFrame) -> Dict[str, Dict[str, float]]:
        """
        Calculate correlations between teammates from same-game performances

        Returns:
            Nested dict: {player1: {player2: correlation, ...}, ...}
        """

        if df.empty:
            return {}

        correlations = {}

        # Group by team and game date to find teammates
        grouped = df.groupby(['team', 'game_date'])

        # Build player-game matrix for each team
        team_players = df.groupby('team')['player_name'].unique().to_dict()

        for team, players in team_players.items():
            players = list(players)
            if len(players) < 2:
                continue

            # Get all games for this team
            team_df = df[df['team'] == team].copy()

            # Pivot to get player performances per game
            pivot = team_df.pivot_table(
                index='game_date',
                columns='player_name',
                values='fd_points',
                aggfunc='first'
            )

            # Calculate pairwise correlations
            for i, p1 in enumerate(players):
                if p1 not in pivot.columns:
                    continue

                if p1 not in correlations:
                    correlations[p1] = {}

                for p2 in players[i+1:]:
                    if p2 not in pivot.columns:
                        continue

                    # Get shared games
                    shared = pivot[[p1, p2]].dropna()

                    if len(shared) >= self.config.min_shared_games:
                        corr, _ = stats.pearsonr(shared[p1], shared[p2])
                        if not np.isnan(corr):
                            correlations[p1][p2] = float(corr)

                            if p2 not in correlations:
                                correlations[p2] = {}
                            correlations[p2][p1] = float(corr)
                    else:
                        # Use prior for insufficient data
                        correlations[p1][p2] = self.config.teammate_prior
                        if p2 not in correlations:
                            correlations[p2] = {}
                        correlations[p2][p1] = self.config.teammate_prior

        self.team_correlations = correlations
        logger.info(f"Built teammate correlations for {len(correlations)} players")
        return correlations

    def build_opponent_correlations(self, df: pd.DataFrame) -> Dict[str, Dict[str, float]]:
        """
        Calculate correlations between opponents in the same game

        Returns:
            Nested dict of player-opponent correlations
        """

        if df.empty:
            return {}

        correlations = {}

        # Create game identifier
        df = df.copy()
        df['game_id'] = df.apply(
            lambda r: '_'.join(sorted([r['team'], r['opponent']])) + '_' + str(r['game_date']),
            axis=1
        )

        # Group by game
        for game_id, game_df in df.groupby('game_id'):
            teams = game_df['team'].unique()
            if len(teams) != 2:
                continue

            team1_players = game_df[game_df['team'] == teams[0]]['player_name'].tolist()
            team2_players = game_df[game_df['team'] == teams[1]]['player_name'].tolist()

            # Cross-team correlations (opponents)
            for p1 in team1_players:
                if p1 not in correlations:
                    correlations[p1] = {}
                for p2 in team2_players:
                    # Initialize with opponent prior
                    if p2 not in correlations[p1]:
                        correlations[p1][p2] = self.config.opponent_prior

        # Calculate actual correlations for players with enough shared games
        game_pivot = df.pivot_table(
            index='game_id',
            columns='player_name',
            values='fd_points',
            aggfunc='first'
        )

        # Update with empirical correlations where we have enough data
        players = list(game_pivot.columns)
        for i, p1 in enumerate(players):
            for p2 in players[i+1:]:
                # Check if they're on different teams
                p1_teams = df[df['player_name'] == p1]['team'].unique()
                p2_teams = df[df['player_name'] == p2]['team'].unique()

                # If any team overlap, skip (they're teammates)
                if len(set(p1_teams) & set(p2_teams)) > 0:
                    continue

                shared = game_pivot[[p1, p2]].dropna()
                if len(shared) >= self.config.min_shared_games:
                    corr, _ = stats.pearsonr(shared[p1], shared[p2])
                    if not np.isnan(corr):
                        if p1 not in correlations:
                            correlations[p1] = {}
                        if p2 not in correlations:
                            correlations[p2] = {}
                        correlations[p1][p2] = float(corr)
                        correlations[p2][p1] = float(corr)

        self.game_correlations = correlations
        logger.info(f"Built opponent correlations for {len(correlations)} players")
        return correlations

    def build_position_correlations(self, df: pd.DataFrame) -> Dict[Tuple[str, str], float]:
        """
        Calculate position-based correlation priors

        Returns:
            Dict mapping position pairs to correlation coefficients
        """

        if df.empty:
            return {}

        # Normalize positions
        pos_map = {
            'PG': 'PG', 'SG': 'SG', 'SF': 'SF', 'PF': 'PF', 'C': 'C',
            'G': 'G', 'F': 'F', 'UTIL': 'UTIL',
            'PG/SG': 'G', 'SG/SF': 'G', 'SF/PF': 'F', 'PF/C': 'F'
        }

        df = df.copy()
        df['pos_clean'] = df['position'].apply(
            lambda x: pos_map.get(str(x).split('/')[0], 'UTIL') if pd.notna(x) else 'UTIL'
        )

        positions = ['PG', 'SG', 'SF', 'PF', 'C']
        correlations = {}

        # Group by game and calculate position correlations
        for game_date, game_df in df.groupby('game_date'):
            for team in game_df['team'].unique():
                team_df = game_df[game_df['team'] == team]

                for pos1 in positions:
                    for pos2 in positions:
                        pos1_fp = team_df[team_df['pos_clean'] == pos1]['fd_points'].values
                        pos2_fp = team_df[team_df['pos_clean'] == pos2]['fd_points'].values

                        if len(pos1_fp) > 0 and len(pos2_fp) > 0:
                            key = (pos1, pos2)
                            if key not in correlations:
                                correlations[key] = []

                            # Use mean if multiple players at position
                            correlations[key].append((np.mean(pos1_fp), np.mean(pos2_fp)))

        # Calculate final correlations
        final_correlations = {}
        for key, values in correlations.items():
            if len(values) >= 20:
                x = [v[0] for v in values]
                y = [v[1] for v in values]
                corr, _ = stats.pearsonr(x, y)
                if not np.isnan(corr):
                    final_correlations[key] = float(corr)
                else:
                    final_correlations[key] = self.config.cross_position_prior
            else:
                # Use prior
                if key[0] == key[1]:
                    final_correlations[key] = self.config.same_position_prior
                else:
                    final_correlations[key] = self.config.cross_position_prior

        self.position_correlations = final_correlations
        logger.info(f"Built position correlations for {len(final_correlations)} position pairs")
        return final_correlations

    def get_correlation(self,
                        player1: str,
                        player2: str,
                        team1: str = None,
                        team2: str = None,
                        pos1: str = None,
                        pos2: str = None,
                        same_game: bool = False) -> float:
        """
        Get correlation between two players

        Args:
            player1, player2: Player names
            team1, team2: Team abbreviations
            pos1, pos2: Positions
            same_game: Whether players are in the same game

        Returns:
            Correlation coefficient
        """

        # Check for direct correlation
        if player1 in self.team_correlations:
            if player2 in self.team_correlations[player1]:
                return self.team_correlations[player1][player2]

        if player1 in self.game_correlations:
            if player2 in self.game_correlations[player1]:
                return self.game_correlations[player1][player2]

        # Fall back to position-based correlation
        if pos1 and pos2:
            pos_key = (pos1.split('/')[0], pos2.split('/')[0])
            if pos_key in self.position_correlations:
                base_corr = self.position_correlations[pos_key]
            else:
                base_corr = self.config.cross_position_prior
        else:
            base_corr = self.config.cross_position_prior

        # Adjust based on relationship
        if team1 and team2:
            if team1 == team2:
                # Teammates - boost correlation
                return max(base_corr, self.config.teammate_prior)
            elif same_game:
                # Opponents in same game - slight positive correlation
                return max(base_corr, self.config.opponent_prior)

        return base_corr

    def build_correlation_matrix(self,
                                  players: List[Dict],
                                  slate_games: List[Dict] = None) -> np.ndarray:
        """
        Build full correlation matrix for a set of players

        Args:
            players: List of player dicts with name, team, position, game
            slate_games: Optional list of games on the slate

        Returns:
            NxN correlation matrix as numpy array
        """

        n = len(players)
        corr_matrix = np.eye(n)  # Diagonal = 1

        # Build game lookup
        game_lookup = {}
        if slate_games:
            for game in slate_games:
                home = game.get('home_team')
                away = game.get('away_team')
                if home and away:
                    game_lookup[home] = (home, away)
                    game_lookup[away] = (home, away)

        for i in range(n):
            for j in range(i + 1, n):
                p1 = players[i]
                p2 = players[j]

                # Determine if same game
                team1 = p1.get('team', p1.get('Team', ''))
                team2 = p2.get('team', p2.get('Team', ''))

                same_game = False
                if team1 in game_lookup and team2 in game_lookup:
                    same_game = game_lookup[team1] == game_lookup[team2]

                # Get correlation
                corr = self.get_correlation(
                    player1=p1.get('player_name', p1.get('Nickname', '')),
                    player2=p2.get('player_name', p2.get('Nickname', '')),
                    team1=team1,
                    team2=team2,
                    pos1=p1.get('position', p1.get('Position', '')),
                    pos2=p2.get('position', p2.get('Position', '')),
                    same_game=same_game
                )

                corr_matrix[i, j] = corr
                corr_matrix[j, i] = corr

        # Ensure matrix is positive semi-definite
        corr_matrix = self._make_positive_semidefinite(corr_matrix)

        return corr_matrix

    def _make_positive_semidefinite(self, matrix: np.ndarray) -> np.ndarray:
        """Ensure correlation matrix is positive semi-definite"""

        # Compute eigenvalues
        eigenvalues, eigenvectors = np.linalg.eigh(matrix)

        # Set negative eigenvalues to small positive value
        eigenvalues = np.maximum(eigenvalues, 1e-8)

        # Reconstruct matrix
        matrix_fixed = eigenvectors @ np.diag(eigenvalues) @ eigenvectors.T

        # Normalize to ensure diagonal is 1
        d = np.sqrt(np.diag(matrix_fixed))
        matrix_fixed = matrix_fixed / np.outer(d, d)

        return matrix_fixed

    def build_all_correlations(self) -> Dict:
        """
        Build all correlation types from database

        Returns:
            Dict containing all correlation data
        """

        df = self.load_game_logs()

        if df.empty:
            logger.warning("No game logs found, using priors only")
            return {
                'teammate': {},
                'opponent': {},
                'position': {},
                'config': self.config
            }

        teammate_corr = self.build_teammate_correlations(df)
        opponent_corr = self.build_opponent_correlations(df)
        position_corr = self.build_position_correlations(df)

        return {
            'teammate': teammate_corr,
            'opponent': opponent_corr,
            'position': position_corr,
            'config': self.config,
            'games_analyzed': len(df['game_date'].unique()),
            'players_analyzed': len(df['player_name'].unique())
        }


class VegasAdjustedCorrelations:
    """
    Adjust correlations based on Vegas lines

    Higher totals = more scoring = potentially higher correlations
    Close spreads = more competitive = different correlation patterns
    """

    def __init__(self, base_builder: CorrelationBuilder = None):
        self.base_builder = base_builder or CorrelationBuilder()

    def adjust_for_total(self,
                         base_correlation: float,
                         game_total: float,
                         league_avg_total: float = 225.0) -> float:
        """
        Adjust correlation based on game total

        Higher totals = slightly higher correlations (more fantasy points available)
        """

        if game_total <= 0:
            return base_correlation

        # Calculate adjustment factor
        total_ratio = game_total / league_avg_total

        # Adjust correlation (subtle effect)
        # High total games have ~10% higher correlations
        adjustment = 1 + (total_ratio - 1) * 0.1

        adjusted = base_correlation * adjustment

        # Clamp to valid correlation range
        return max(-1.0, min(1.0, adjusted))

    def adjust_for_spread(self,
                          base_correlation: float,
                          spread: float,
                          is_favorite: bool) -> float:
        """
        Adjust correlation based on spread

        Blowout games (large spreads) have different dynamics:
        - Favorites may rest starters
        - Underdogs may get garbage time
        """

        abs_spread = abs(spread)

        if abs_spread > 12:
            # Potential blowout - higher variance, slightly lower correlations
            return base_correlation * 0.9
        elif abs_spread < 3:
            # Close game - standard correlations
            return base_correlation
        else:
            # Moderate spread - slight adjustment
            return base_correlation * 0.95

    def get_vegas_adjusted_matrix(self,
                                   players: List[Dict],
                                   game_lines: Dict[str, Dict]) -> np.ndarray:
        """
        Build correlation matrix with Vegas adjustments

        Args:
            players: List of player dicts
            game_lines: Dict mapping game_id to {total, spread, home_team, away_team}

        Returns:
            Adjusted correlation matrix
        """

        # First build base matrix
        base_matrix = self.base_builder.build_correlation_matrix(players)

        if not game_lines:
            return base_matrix

        n = len(players)
        adjusted_matrix = base_matrix.copy()

        # Apply Vegas adjustments
        for i in range(n):
            for j in range(i + 1, n):
                p1 = players[i]
                p2 = players[j]

                # Find game for each player
                team1 = p1.get('team', '')
                team2 = p2.get('team', '')

                game1 = None
                game2 = None

                for game_id, line in game_lines.items():
                    if team1 in [line.get('home_team'), line.get('away_team')]:
                        game1 = line
                    if team2 in [line.get('home_team'), line.get('away_team')]:
                        game2 = line

                base_corr = base_matrix[i, j]

                # Apply adjustments based on Vegas lines
                if game1 and game1 == game2:
                    # Same game - apply total adjustment
                    total = game1.get('total', 225)
                    spread = game1.get('spread', 0)

                    adjusted = self.adjust_for_total(base_corr, total)
                    adjusted = self.adjust_for_spread(
                        adjusted, spread,
                        team1 == game1.get('home_team')
                    )

                    adjusted_matrix[i, j] = adjusted
                    adjusted_matrix[j, i] = adjusted

        # Ensure positive semi-definite
        adjusted_matrix = self.base_builder._make_positive_semidefinite(adjusted_matrix)

        return adjusted_matrix


# Convenience functions

def build_correlations_from_database() -> CorrelationBuilder:
    """Build correlation matrices from database"""
    builder = CorrelationBuilder()
    builder.build_all_correlations()
    return builder


def get_player_correlation(player1: str, player2: str,
                           team1: str = None, team2: str = None) -> float:
    """Get correlation between two players"""
    builder = build_correlations_from_database()
    return builder.get_correlation(player1, player2, team1, team2)
