"""
Projection Service - Integrates YOUR REAL DFS projection code!
Calls your historical database with 100K+ performances

Phase 7: Replaced hardcoded ×5 with salary-tiered get_required_multiplier()
"""

import sys
from pathlib import Path
import pandas as pd
import duckdb
from services.vegas_service import VegasOddsService

# Add parent directory to access your existing code
parent_dir = str(Path(__file__).parent.parent.parent)
sys.path.insert(0, parent_dir)

# Path to your DuckDB database — use centralized resolver
from db.engine import get_canonical_db_path
DUCKDB_PATH = get_canonical_db_path()

# =============================================================================
# SALARY-TIERED MULTIPLIER (replaces hardcoded ×5)
# =============================================================================
# Import canonical multiplier function from player_pool
try:
    from analysis.nba.player_pool import get_required_multiplier
    MULTIPLIER_FUNC_AVAILABLE = True
except ImportError:
    MULTIPLIER_FUNC_AVAILABLE = False
    get_required_multiplier = None


def _get_salary_tiered_multiplier(salary: float, player_name: str = "") -> float:
    """
    Get salary-tiered multiplier using the canonical get_required_multiplier function.

    Salary tiers (replaces hardcoded ×5):
    - < $4,500: 5.0x (high variance value plays)
    - $4,500 - $6,500: 4.75x (mid-tier role players)
    - > $6,500: 4.5x (stable star usage)

    This ensures value calculations are accurate across salary ranges.
    """
    if MULTIPLIER_FUNC_AVAILABLE and get_required_multiplier:
        # Use canonical function with empty signals (signal adjustments happen elsewhere)
        player = {"name": player_name, "salary": salary}
        return get_required_multiplier(player, salary, signals=[])
    else:
        # Fallback: Apply salary tiers directly
        if salary < 4500:
            return 5.0
        elif salary <= 6500:
            return 4.75
        else:
            return 4.5

async def generate_projections(slate_file_path: str, user_id: str) -> dict:
    """
    Generate projections using YOUR ACTUAL projection algorithm
    This integrates with your 100K+ performance database
    """
    
    print(f"🎯 Generating REAL projections for user {user_id}")
    print(f"📄 Slate file: {slate_file_path}")
    print(f"🗄️  Database: {DUCKDB_PATH}")
    
    try:
        # Read the slate file
        slate_df = pd.read_csv(slate_file_path)
        print(f"✅ Loaded slate: {len(slate_df)} players")
        
        # Parse injury status from FanDuel slate
        if 'Injury Indicator' in slate_df.columns:
            print(f"✅ Found injury data in slate!")
            
            # Count injuries
            out_count = len(slate_df[slate_df['Injury Indicator'] == 'O'])
            q_count = len(slate_df[slate_df['Injury Indicator'] == 'Q'])
            p_count = len(slate_df[slate_df['Injury Indicator'] == 'P'])
            
            print(f"   OUT: {out_count} players")
            print(f"   QUESTIONABLE: {q_count} players")
            print(f"   PROBABLE: {p_count} players")
        else:
            print(f"⚠️  No injury column found (DraftKings slate?)")
            slate_df['Injury Indicator'] = ''
        # Connect to your DuckDB database
        if not DUCKDB_PATH.exists():
            print(f"⚠️  DuckDB not found at {DUCKDB_PATH}")
            print("📌 Using simplified projections for now")
            return await generate_simple_projections(slate_df, slate_file_path)
        
        # Prefer read_only=True: DuckDB allows many concurrent readers when no
        # writer holds the exclusive lock.  generate_projections() only issues
        # SELECT queries against the historical performance table — it never
        # mutates the database — so read-only mode is both safe and correct.
        # If the file is already locked by a writer (e.g. an ETL job), we fall
        # back to a standard connection so the query can still proceed once the
        # lock is released.  Writes (e.g. ETL / schema bootstrap) should use a
        # separate dedicated connection, not this service path.
        try:
            conn = duckdb.connect(str(DUCKDB_PATH), read_only=True)
        except Exception as conn_err:
            print(f"⚠️  Read-only connection failed ({conn_err}), retrying read-write...")
            try:
                conn = duckdb.connect(str(DUCKDB_PATH), read_only=False)
            except Exception as retry_err:
                print(f"❌ DuckDB connection failed: {retry_err}")
                print("📌 Falling back to simple projections")
                return await generate_simple_projections(slate_df, slate_file_path)
        
        print(f"✅ Connected to DuckDB database")
        
        # Load Vegas odds
        vegas_service = VegasOddsService()
        vegas_games = vegas_service.get_nba_odds()

        # Create team total lookup
        team_totals = {}
        for game in vegas_games:
            team_totals[game['home_team']] = game.get('home_implied_points')
            team_totals[game['away_team']] = game.get('away_implied_points')

        print(f"✅ Loaded Vegas odds for {len(vegas_games)} games")
        if team_totals:
            print(f"   High-scoring teams: {[t for t, total in team_totals.items() if total and total > 115]}")

        # Get recent performance data from last 30 days
        query = """
        SELECT 
            player_name,
            AVG(actual_fpts) as avg_fp,
            COUNT(*) as games_played,
            MAX(actual_fpts) as max_fp,
            MIN(actual_fpts) as min_fp,
            STDDEV(actual_fpts) as std_fp
        FROM contest_results
        WHERE contest_date >= CURRENT_DATE - INTERVAL '90 days'
        GROUP BY player_name
        HAVING COUNT(*) >= 3
        """
        
        historical_data = conn.execute(query).df()
        print(f"✅ Loaded historical data: {len(historical_data)} players")
        
        # Generate projections for each player in slate
        projections = []
        
        for _, player in slate_df.iterrows():
            # Get player info from slate
            player_name = player.get('Nickname', player.get('Name', 'Unknown'))
            position = player.get('Position', 'UTIL')
            salary = player.get('Salary', 0)
            team = player.get('Team', '')
            opponent = player.get('Opponent', '')
            
             # Look up historical performance
            
        
        # Look up historical performance
            hist = historical_data[historical_data['player_name'] == player_name]
            
            if len(hist) > 0:
                # Use actual historical data
                avg_fp = float(hist.iloc[0]['avg_fp'])
                max_fp = float(hist.iloc[0]['max_fp'])
                min_fp = float(hist.iloc[0]['min_fp'])
                std_fp = float(hist.iloc[0]['std_fp'])
                games = int(hist.iloc[0]['games_played'])
                
                # Calculate projection with slight regression to salary
                # Uses salary-tiered multiplier: <$4.5K=5.0x, $4.5K-6.5K=4.75x, >$6.5K=4.5x
                multiplier = _get_salary_tiered_multiplier(salary, player_name)
                projection = (avg_fp * 0.7) + ((salary / 1000) * multiplier * 0.3)
                
                # VEGAS ADJUSTMENT (team total)
                team = player.get('Team', '')
                if team in team_totals and team_totals[team]:
                    team_total = team_totals[team]
                    league_avg = 112.0  # NBA average
                    vegas_factor = team_total / league_avg
                    
                    old_projection = projection
                    projection *= vegas_factor
                    
                    if abs(vegas_factor - 1.0) > 0.05:  # Only print if >5% adjustment
                        print(f"   💰 {player_name} Vegas adjustment: {old_projection:.1f} → {projection:.1f} (Team total: {team_total})")

                # INJURY ADJUSTMENT (from FanDuel slate)
                injury_status = player.get('Injury Indicator', '')
                
                if injury_status == 'O':  # OUT
                    projection = 0.0
                    floor = 0.0
                    ceiling = 0.0
                    print(f"   ⚠️  {player_name} is OUT - projection set to 0")
                elif injury_status == 'Q':  # QUESTIONABLE
                    projection *= 0.70  # Reduce by 30%
                    floor *= 0.70
                    ceiling *= 0.70
                    print(f"   ⚠️  {player_name} is QUESTIONABLE - reduced projection")
                elif injury_status == 'P':  # PROBABLE
                    projection *= 0.90  # Reduce by 10%
                    floor *= 0.90
                    ceiling *= 0.90
                # Calculate floor and ceiling
                floor = max(min_fp, projection - std_fp)
                ceiling = min(max_fp * 1.1, projection + std_fp * 1.5)
                
            else:
                # No historical data - use salary-based estimate
                # Uses salary-tiered multiplier: <$4.5K=5.0x, $4.5K-6.5K=4.75x, >$6.5K=4.5x
                multiplier = _get_salary_tiered_multiplier(salary, player_name)
                projection = (salary / 1000) * multiplier
                floor = projection * 0.7
                ceiling = projection * 1.4
                games = 0
            
            # Calculate value
            value = (projection / (salary / 1000)) if salary > 0 else 0
            
            projections.append({
                "id": player.get('Id', player.get('ID', '')),  # ← ADD THIS!
                "name": player_name,
                "position": position,
                "team": team,
                "opponent": opponent,
                "salary": int(salary),
                "projection": round(projection, 2),
                "floor": round(floor, 2),
                "ceiling": round(ceiling, 2),
                "value": round(value, 2),
                "games_played": int(games)
            })
        
        # Close database connection
        conn.close()
        
        # Sort by projection
        projections.sort(key=lambda x: x['projection'], reverse=True)
        
        print(f"✅ Generated {len(projections)} REAL projections using your database!")
        
        # Calculate stats
        total_salary = slate_df['Salary'].sum() if 'Salary' in slate_df.columns else 0
        avg_projection = sum(p['projection'] for p in projections) / len(projections)
        
        # Find players with historical data
        with_data = len([p for p in projections if p['games_played'] > 0])
        
        return {
            "success": True,
            "projections": projections,
            "stats": {
                "total_players": len(projections),
                "players_with_history": with_data,
                "players_without_history": len(projections) - with_data,
                "avg_projection": round(avg_projection, 2),
                "total_salary_available": int(total_salary),
                "slate_file": Path(slate_file_path).name,
                "database_used": "dfs_master.duckdb ✅"
            },
            "algorithm": "YOUR REAL ALGORITHM: Historical 30-day average + salary regression",
            "data_source": f"100K+ performances from {DUCKDB_PATH.name}"
        }
        
    except Exception as e:
        print(f"❌ Projection generation failed: {e}")
        import traceback
        traceback.print_exc()
        
        # Fallback to simple projections
        print("⚠️  Falling back to simple projections")
        slate_df = pd.read_csv(slate_file_path)
        return await generate_simple_projections(slate_df, slate_file_path)

async def generate_simple_projections(slate_df: pd.DataFrame, slate_file_path: str) -> dict:
    """
    Fallback: Simple salary-based projections
    Used when database is not available
    """
    
    projections = []
    
    for _, player in slate_df.iterrows():
        player_name = player.get('Nickname', player.get('Name', 'Unknown'))
        position = player.get('Position', 'UTIL')
        salary = player.get('Salary', 0)
        team = player.get('Team', '')
        opponent = player.get('Opponent', '')
        
        # Simple projection: uses salary-tiered multiplier
        # <$4.5K=5.0x, $4.5K-6.5K=4.75x, >$6.5K=4.5x (replaces hardcoded ×5)
        multiplier = _get_salary_tiered_multiplier(salary, player_name)
        base_projection = (salary / 1000) * multiplier
        
        projections.append({
            "id": player.get('Id', player.get('ID', '')),  # ← ADD THIS!
            "name": player_name,
            "position": position,
            "team": team,
            "opponent": opponent,
            "salary": int(salary),
            "projection": round(base_projection, 2),
            "floor": round(base_projection * 0.7, 2),
            "ceiling": round(base_projection * 1.4, 2),
            "value": round(base_projection / (salary / 1000), 2) if salary > 0 else 0,
            "games_played": 0
        })
    
    projections.sort(key=lambda x: x['projection'], reverse=True)
    
    total_salary = slate_df['Salary'].sum() if 'Salary' in slate_df.columns else 0
    avg_projection = sum(p['projection'] for p in projections) / len(projections)
    
    return {
        "success": True,
        "projections": projections,
        "stats": {
            "total_players": len(projections),
            "players_with_history": 0,  # Fallback has no historical data
            "players_without_history": len(projections),
            "avg_projection": round(avg_projection, 2),
            "total_salary_available": int(total_salary),
            "slate_file": Path(slate_file_path).name,
            "database_used": "None (fallback mode)"
        },
        "algorithm": "Fallback: Simple salary-based projection",
        "note": "DuckDB database not found or busy - using simplified projections"
    }

def projections_to_csv(projections: list) -> str:
    """
    Convert projections list to CSV string
    """
    if not projections:
        return ""
    
    df = pd.DataFrame(projections)
    return df.to_csv(index=False)


