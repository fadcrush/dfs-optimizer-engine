"""
The Odds API Service - Complete Integration
Provides live Vegas odds, game totals, spreads, and moneylines
"""

import requests
import json
import logging
from typing import Dict, List, Optional
from datetime import datetime, timedelta
import time
from pathlib import Path
import os

logger = logging.getLogger(__name__)

class TheOddsAPIService:
    """Complete The Odds API integration with caching and error handling"""

    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.getenv('THE_ODDS_API_KEY')
        self.base_url = "https://api.the-odds-api.com/v4"
        self.cache_file = Path("data/cache/odds_cache.json")
        self.cache_duration = 300  # 5 minutes cache

        # Ensure cache directory exists
        self.cache_file.parent.mkdir(parents=True, exist_ok=True)

        if not self.api_key:
            logger.warning("THE_ODDS_API_KEY not found - using cached data only")

    def _get_cached_data(self, sport: str) -> Optional[Dict]:
        """Get cached odds data if available and fresh"""
        try:
            if not self.cache_file.exists():
                return None

            with open(self.cache_file, 'r') as f:
                cache_data = json.load(f)

            # Check if cache is fresh
            cache_time = datetime.fromisoformat(cache_data.get('timestamp', '2000-01-01'))
            if datetime.now() - cache_time > timedelta(seconds=self.cache_duration):
                return None

            return cache_data.get(sport)

        except Exception as e:
            logger.error(f"Cache read error: {e}")
            return None

    def _save_to_cache(self, sport: str, data: Dict):
        """Save data to cache"""
        try:
            cache_data = {'timestamp': datetime.now().isoformat()}

            # Load existing cache if available
            if self.cache_file.exists():
                with open(self.cache_file, 'r') as f:
                    existing = json.load(f)
                    cache_data.update(existing)

            cache_data[sport] = data

            with open(self.cache_file, 'w') as f:
                json.dump(cache_data, f, indent=2)

        except Exception as e:
            logger.error(f"Cache write error: {e}")

    def get_odds(self, sport: str = "basketball_nba", markets: str = "spreads,totals,h2h") -> Dict:
        """
        Get live odds from The Odds API

        Args:
            sport: Sport key (basketball_nba, americanfootball_nfl, etc.)
            markets: Comma-separated list of markets (spreads,totals,h2h,player_points,etc.)

        Returns:
            Dict with game odds data
        """
        # Try cache first
        cached_data = self._get_cached_data(sport)
        if cached_data:
            logger.info(f"Using cached {sport} odds data")
            return cached_data

        if not self.api_key:
            logger.error("No API key available and no cached data")
            return {}

        try:
            url = f"{self.base_url}/sports/{sport}/odds"
            params = {
                'apiKey': self.api_key,
                'regions': 'us',  # US odds
                'markets': markets,
                'oddsFormat': 'decimal',
                'dateFormat': 'iso'
            }

            logger.info(f"Fetching {sport} odds from The Odds API")
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()

            data = response.json()

            # Process and structure the data
            processed_data = self._process_odds_data(data, sport)

            # Save to cache
            self._save_to_cache(sport, processed_data)

            logger.info(f"Successfully fetched {len(processed_data)} {sport} games")
            return processed_data

        except requests.exceptions.RequestException as e:
            logger.error(f"API request failed: {e}")
            return {}
        except Exception as e:
            logger.error(f"Odds processing error: {e}")
            return {}

    def _process_odds_data(self, raw_data: List[Dict], sport: str) -> Dict:
        """Process raw odds data into structured format"""
        processed_games = {}

        for game in raw_data:
            try:
                home_team = game['home_team']
                away_team = game['away_team']
                game_key = f"{away_team}@{home_team}"

                game_data = {
                    'sport': sport,
                    'home_team': home_team,
                    'away_team': away_team,
                    'commence_time': game['commence_time'],
                    'bookmakers': []
                }

                # Process each bookmaker
                for bookmaker in game.get('bookmakers', []):
                    bookmaker_data = {
                        'name': bookmaker['title'],
                        'last_update': bookmaker.get('last_update'),
                        'markets': {}
                    }

                    # Process each market
                    for market in bookmaker.get('markets', []):
                        market_key = market['key']
                        bookmaker_data['markets'][market_key] = {
                            'outcomes': market.get('outcomes', [])
                        }

                        # Extract specific market data
                        if market_key == 'totals':
                            for outcome in market.get('outcomes', []):
                                if outcome['name'] == 'Over':
                                    bookmaker_data['markets']['over_under'] = outcome['point']
                                    bookmaker_data['markets']['over_price'] = outcome['price']
                                elif outcome['name'] == 'Under':
                                    bookmaker_data['markets']['under_price'] = outcome['price']

                        elif market_key == 'spreads':
                            for outcome in market.get('outcomes', []):
                                if outcome['name'] == home_team:
                                    bookmaker_data['markets']['home_spread'] = outcome['point']
                                    bookmaker_data['markets']['home_spread_price'] = outcome['price']
                                elif outcome['name'] == away_team:
                                    bookmaker_data['markets']['away_spread'] = outcome['point']
                                    bookmaker_data['markets']['away_spread_price'] = outcome['price']

                        elif market_key == 'h2h':
                            for outcome in market.get('outcomes', []):
                                if outcome['name'] == home_team:
                                    bookmaker_data['markets']['home_ml'] = outcome['price']
                                elif outcome['name'] == away_team:
                                    bookmaker_data['markets']['away_ml'] = outcome['price']

                    game_data['bookmakers'].append(bookmaker_data)

                # Calculate consensus lines
                game_data['consensus'] = self._calculate_consensus(game_data['bookmakers'])

                processed_games[game_key] = game_data

            except Exception as e:
                logger.error(f"Error processing game {game.get('id', 'unknown')}: {e}")
                continue

        return processed_games

    def _calculate_consensus(self, bookmakers: List[Dict]) -> Dict:
        """Calculate consensus lines across all bookmakers"""
        consensus = {
            'total': None,
            'spread': None,
            'home_ml': None,
            'away_ml': None,
            'num_books': len(bookmakers)
        }

        if not bookmakers:
            return consensus

        # Collect all lines
        totals = []
        spreads = []
        home_mls = []
        away_mls = []

        for book in bookmakers:
            markets = book.get('markets', {})

            if 'over_under' in markets:
                totals.append(markets['over_under'])

            if 'home_spread' in markets:
                spreads.append(markets['home_spread'])

            if 'home_ml' in markets:
                home_mls.append(markets['home_ml'])

            if 'away_ml' in markets:
                away_mls.append(markets['away_ml'])

        # Calculate averages
        if totals:
            consensus['total'] = round(sum(totals) / len(totals), 1)

        if spreads:
            consensus['spread'] = round(sum(spreads) / len(spreads), 1)

        if home_mls:
            consensus['home_ml'] = round(sum(home_mls) / len(home_mls), 2)

        if away_mls:
            consensus['away_ml'] = round(sum(away_mls) / len(away_mls), 2)

        return consensus

    def get_nba_odds(self) -> Dict:
        """Get NBA odds specifically"""
        return self.get_odds("basketball_nba")

    def get_nfl_odds(self) -> Dict:
        """Get NFL odds specifically"""
        return self.get_odds("americanfootball_nfl")

    def get_game_odds(self, home_team: str, away_team: str, sport: str = "basketball_nba") -> Optional[Dict]:
        """Get odds for a specific game"""
        all_odds = self.get_odds(sport)
        game_key = f"{away_team}@{home_team}"

        return all_odds.get(game_key)

    def get_player_props(self, sport: str = "basketball_nba") -> Dict:
        """Get player props odds"""
        return self.get_odds(sport, "player_points,player_rebounds,player_assists")

    def get_remaining_requests(self) -> Optional[int]:
        """Check remaining API requests (if available)"""
        if not self.api_key:
            return None

        try:
            url = f"{self.base_url}/sports"
            params = {'apiKey': self.api_key}

            response = requests.get(url, params=params, timeout=5)
            remaining = response.headers.get('x-requests-remaining')

            return int(remaining) if remaining else None

        except Exception as e:
            logger.error(f"Could not check remaining requests: {e}")
            return None

# Convenience functions for backward compatibility
def get_nba_odds() -> Dict:
    """Legacy function for NBA odds"""
    service = TheOddsAPIService()
    return service.get_nba_odds()

def get_nfl_odds() -> Dict:
    """Legacy function for NFL odds"""
    service = TheOddsAPIService()
    return service.get_nfl_odds()

if __name__ == "__main__":
    # Test the service
    service = TheOddsAPIService()

    print("Testing The Odds API Service...")
    print(f"Remaining requests: {service.get_remaining_requests()}")

    # Test NBA odds
    nba_odds = service.get_nba_odds()
    print(f"NBA games found: {len(nba_odds)}")

    if nba_odds:
        # Show first game as example
        first_game_key = list(nba_odds.keys())[0]
        game = nba_odds[first_game_key]
        consensus = game['consensus']

        print(f"Example game: {first_game_key}")
        print(f"Total: {consensus['total']}")
        print(f"Spread: {consensus['spread']}")
        print(f"Books: {consensus['num_books']}")

    # Test NFL odds
    nfl_odds = service.get_nfl_odds()
    print(f"NFL games found: {len(nfl_odds)}")
