"""
Lineup Validator - Ensures all generated lineups are valid for upload

This module validates lineups BEFORE export to prevent:
- Invalid salary totals
- Missing positions
- Duplicate players
- Invalid player IDs
- Platform-specific rule violations

CRITICAL: Run validation before every export to catch silent failures.
"""

from dataclasses import dataclass
from typing import List, Dict, Optional, Tuple
import logging

logger = logging.getLogger(__name__)


@dataclass
class ValidationResult:
    """Result of lineup validation"""
    is_valid: bool
    errors: List[str]
    warnings: List[str]
    lineup_number: int


@dataclass
class PlatformRules:
    """Platform-specific DFS rules"""
    roster_size: int
    salary_cap: int
    min_salary: int
    positions: Dict[str, int]  # Position -> Required count
    max_per_team: int
    max_per_game: int
    allow_multi_position: bool


# Platform rule definitions
FANDUEL_NBA_RULES = PlatformRules(
    roster_size=9,
    salary_cap=60000,
    min_salary=49000,
    positions={'PG': 2, 'SG': 2, 'SF': 2, 'PF': 2, 'C': 1},
    max_per_team=4,  # 4 players max from same team
    max_per_game=4,  # 4 players max from same game
    allow_multi_position=True,
)

DRAFTKINGS_NBA_RULES = PlatformRules(
    roster_size=8,
    salary_cap=50000,
    min_salary=48000,
    positions={'PG': 1, 'SG': 1, 'SF': 1, 'PF': 1, 'C': 1, 'G': 1, 'F': 1, 'UTIL': 1},
    max_per_team=4,
    max_per_game=4,
    allow_multi_position=True,
)

FANDUEL_NFL_RULES = PlatformRules(
    roster_size=9,
    salary_cap=60000,
    min_salary=50000,
    positions={'QB': 1, 'RB': 2, 'WR': 3, 'TE': 1, 'FLEX': 1, 'DEF': 1},
    max_per_team=4,
    max_per_game=4,
    allow_multi_position=False,
)


def get_rules(platform: str, sport: str) -> PlatformRules:
    """Get platform-specific rules"""
    key = f"{platform.upper()}_{sport.upper()}"

    rules_map = {
        'FANDUEL_NBA': FANDUEL_NBA_RULES,
        'DRAFTKINGS_NBA': DRAFTKINGS_NBA_RULES,
        'FANDUEL_NFL': FANDUEL_NFL_RULES,
    }

    return rules_map.get(key, FANDUEL_NBA_RULES)


class LineupValidator:
    """
    Validates DFS lineups against platform rules.

    Usage:
        validator = LineupValidator('fanduel', 'nba')
        result = validator.validate_lineup(lineup)

        if not result.is_valid:
            print(f"Lineup {result.lineup_number} invalid: {result.errors}")
    """

    def __init__(self, platform: str, sport: str):
        self.platform = platform.lower()
        self.sport = sport.lower()
        self.rules = get_rules(platform, sport)

    def validate_lineup(
        self,
        lineup: List[Dict],
        lineup_number: int = 0
    ) -> ValidationResult:
        """
        Validate a single lineup.

        Args:
            lineup: List of player dictionaries with keys:
                    - Name: Player name
                    - ID: Player ID (for export)
                    - Salary: Player salary
                    - Position/PosBucket: Player position
                    - Team: Player team
                    - Game/Opponent: Game identifier
            lineup_number: Lineup index for error reporting

        Returns:
            ValidationResult with is_valid, errors, and warnings
        """
        errors = []
        warnings = []

        # 1. Roster Size
        if len(lineup) != self.rules.roster_size:
            errors.append(
                f"Wrong roster size: {len(lineup)} (need {self.rules.roster_size})"
            )

        # 2. Salary Validation
        total_salary = sum(int(p.get('Salary', 0)) for p in lineup)

        if total_salary > self.rules.salary_cap:
            errors.append(
                f"Over salary cap: ${total_salary:,} > ${self.rules.salary_cap:,}"
            )

        if total_salary < self.rules.min_salary:
            warnings.append(
                f"Under salary floor: ${total_salary:,} < ${self.rules.min_salary:,}"
            )

        # Calculate salary remaining
        salary_remaining = self.rules.salary_cap - total_salary
        if salary_remaining > 3000:
            warnings.append(
                f"High salary remaining: ${salary_remaining:,} unused"
            )

        # 3. Position Validation
        position_counts = {}
        for player in lineup:
            pos = player.get('PosBucket', player.get('Position', '')).split('/')[0].upper()
            position_counts[pos] = position_counts.get(pos, 0) + 1

        for required_pos, required_count in self.rules.positions.items():
            actual_count = position_counts.get(required_pos, 0)
            if actual_count != required_count:
                # For flex positions (G, F, UTIL), check if filled by eligible players
                if required_pos in ['G', 'F', 'UTIL']:
                    continue  # Skip flex validation for now
                errors.append(
                    f"Wrong {required_pos} count: {actual_count} (need {required_count})"
                )

        # 4. Duplicate Players
        player_names = [p.get('Name', '') for p in lineup]
        player_ids = [str(p.get('ID', p.get('Id', ''))) for p in lineup]

        if len(player_names) != len(set(player_names)):
            duplicates = [n for n in player_names if player_names.count(n) > 1]
            errors.append(f"Duplicate players: {list(set(duplicates))}")

        # 5. Player ID Validation (critical for export)
        missing_ids = []
        for player in lineup:
            player_id = str(player.get('ID', player.get('Id', '')))
            if not player_id or player_id in ['', 'nan', 'None', '0']:
                missing_ids.append(player.get('Name', 'Unknown'))

        if missing_ids:
            errors.append(f"Missing player IDs: {missing_ids}")

        # 6. Team Stacking Rules
        team_counts = {}
        for player in lineup:
            team = player.get('Team', '')
            if team:
                team_counts[team] = team_counts.get(team, 0) + 1

        for team, count in team_counts.items():
            if count > self.rules.max_per_team:
                errors.append(
                    f"Too many from {team}: {count} (max {self.rules.max_per_team})"
                )

        # 7. Game Stacking Rules
        game_counts = {}
        for player in lineup:
            game = player.get('Game', player.get('Opponent', ''))
            if game:
                game_counts[game] = game_counts.get(game, 0) + 1

        for game, count in game_counts.items():
            if count > self.rules.max_per_game:
                errors.append(
                    f"Too many from game {game}: {count} (max {self.rules.max_per_game})"
                )

        return ValidationResult(
            is_valid=len(errors) == 0,
            errors=errors,
            warnings=warnings,
            lineup_number=lineup_number
        )

    def validate_all_lineups(
        self,
        lineups: List[List[Dict]],
        fail_fast: bool = False
    ) -> Tuple[List[ValidationResult], int, int]:
        """
        Validate all lineups in a batch.

        Args:
            lineups: List of lineups to validate
            fail_fast: If True, stop on first invalid lineup

        Returns:
            Tuple of (results, valid_count, invalid_count)
        """
        results = []
        valid_count = 0
        invalid_count = 0

        for i, lineup in enumerate(lineups):
            result = self.validate_lineup(lineup, i + 1)
            results.append(result)

            if result.is_valid:
                valid_count += 1
            else:
                invalid_count += 1

                if fail_fast:
                    logger.error(
                        f"Lineup {i + 1} validation failed: {result.errors}"
                    )
                    break

        return results, valid_count, invalid_count

    def filter_valid_lineups(
        self,
        lineups: List[List[Dict]]
    ) -> Tuple[List[List[Dict]], List[ValidationResult]]:
        """
        Filter out invalid lineups and return only valid ones.

        Args:
            lineups: List of lineups to filter

        Returns:
            Tuple of (valid_lineups, invalid_results)
        """
        valid_lineups = []
        invalid_results = []

        for i, lineup in enumerate(lineups):
            result = self.validate_lineup(lineup, i + 1)

            if result.is_valid:
                valid_lineups.append(lineup)
            else:
                invalid_results.append(result)

        if invalid_results:
            logger.warning(
                f"Filtered out {len(invalid_results)} invalid lineups"
            )

        return valid_lineups, invalid_results


def validate_before_export(
    lineups: List[List[Dict]],
    platform: str,
    sport: str
) -> Tuple[bool, List[str]]:
    """
    Convenience function to validate lineups before export.

    Args:
        lineups: List of lineups
        platform: 'fanduel' or 'draftkings'
        sport: 'nba' or 'nfl'

    Returns:
        Tuple of (all_valid, error_messages)

    Usage:
        is_valid, errors = validate_before_export(lineups, 'fanduel', 'nba')
        if not is_valid:
            for error in errors:
                print(error)
            raise ValueError("Invalid lineups - cannot export")
    """
    validator = LineupValidator(platform, sport)
    results, valid_count, invalid_count = validator.validate_all_lineups(lineups)

    error_messages = []
    for result in results:
        if not result.is_valid:
            error_messages.append(
                f"Lineup {result.lineup_number}: {', '.join(result.errors)}"
            )

    all_valid = invalid_count == 0

    if all_valid:
        logger.info(f"All {valid_count} lineups validated successfully")
    else:
        logger.error(
            f"Validation failed: {invalid_count}/{len(lineups)} lineups invalid"
        )

    return all_valid, error_messages


# Quick validation test
if __name__ == "__main__":
    # Test with sample lineup
    sample_lineup = [
        {'Name': 'Player1', 'ID': '123-456', 'Salary': 9500, 'PosBucket': 'PG', 'Team': 'LAL'},
        {'Name': 'Player2', 'ID': '123-457', 'Salary': 8000, 'PosBucket': 'PG', 'Team': 'LAL'},
        {'Name': 'Player3', 'ID': '123-458', 'Salary': 7500, 'PosBucket': 'SG', 'Team': 'GSW'},
        {'Name': 'Player4', 'ID': '123-459', 'Salary': 7000, 'PosBucket': 'SG', 'Team': 'GSW'},
        {'Name': 'Player5', 'ID': '123-460', 'Salary': 6500, 'PosBucket': 'SF', 'Team': 'BOS'},
        {'Name': 'Player6', 'ID': '123-461', 'Salary': 6000, 'PosBucket': 'SF', 'Team': 'BOS'},
        {'Name': 'Player7', 'ID': '123-462', 'Salary': 5500, 'PosBucket': 'PF', 'Team': 'MIA'},
        {'Name': 'Player8', 'ID': '123-463', 'Salary': 5000, 'PosBucket': 'PF', 'Team': 'MIA'},
        {'Name': 'Player9', 'ID': '123-464', 'Salary': 5000, 'PosBucket': 'C', 'Team': 'DEN'},
    ]

    validator = LineupValidator('fanduel', 'nba')
    result = validator.validate_lineup(sample_lineup, 1)

    print(f"Lineup valid: {result.is_valid}")
    print(f"Errors: {result.errors}")
    print(f"Warnings: {result.warnings}")
