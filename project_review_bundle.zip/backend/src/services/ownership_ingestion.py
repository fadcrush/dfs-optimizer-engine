"""
Ownership ingestion service — database-first.

Workflow:
  1. Receive raw CSV bytes + slate_id.
  2. Parse ownership percentages.
  3. Match players by name (or external_id).
  4. Upsert OwnershipData rows in the DB.
  5. Optionally mirror ownership_pct into the Projection row for the same
     (slate_id, player_id) pair so the optimizer can fetch a single row.

Expected CSV formats (both supported):
  - "Player,Own%"       — minimal
  - "Name,Ownership"    — alternate header names
  - "player_name,projected_ownership"
  - Any FanDuel / DraftKings ownership export

Column detection is case-insensitive with fuzzy matching.
"""

from __future__ import annotations

import io
import math
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd
from sqlalchemy.orm import Session

from models.player import Player
from models.projection import Projection
from models.ownership_model import OwnershipData


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _safe_float(val: Any, default: float = 0.0) -> float:
    try:
        f = float(str(val).replace("%", "").strip())
        return default if math.isnan(f) or math.isinf(f) else f
    except (ValueError, TypeError):
        return default


def _find_col(columns: List[str], candidates: List[str]) -> Optional[str]:
    """Return the first column whose lowercase name matches any candidate."""
    lc = {c.lower(): c for c in columns}
    for cand in candidates:
        if cand.lower() in lc:
            return lc[cand.lower()]
    return None


def _parse_ownership_df(df: pd.DataFrame) -> List[Tuple[str, float]]:
    """
    Return a list of (player_name, ownership_pct) tuples from the DataFrame.

    Raises ValueError if neither a name column nor an ownership column can be found.
    """
    cols = df.columns.tolist()

    name_col = _find_col(
        cols,
        [
            "Name", "Player", "player_name", "Player Name",
            "Nickname",        # FanDuel
        ]
    )
    own_col = _find_col(
        cols,
        [
            "Own%", "Ownership", "ownership", "projected_ownership",
            "Projected Ownership", "Proj Own%", "Own",
        ]
    )

    if name_col is None:
        raise ValueError(
            f"Cannot find player-name column in ownership CSV. "
            f"Columns found: {cols}"
        )
    if own_col is None:
        raise ValueError(
            f"Cannot find ownership-percentage column in ownership CSV. "
            f"Columns found: {cols}"
        )

    rows: List[Tuple[str, float]] = []
    for _, row in df.iterrows():
        name = str(row[name_col]).strip()
        if not name or name.lower() == "nan":
            continue
        pct = _safe_float(row[own_col])
        rows.append((name, pct))
    return rows


# ---------------------------------------------------------------------------
# DB helpers
# ---------------------------------------------------------------------------

def _find_player_by_name(
    db: Session, slate_id: str, name: str
) -> Optional[Player]:
    """Exact-match first; then case-insensitive."""
    player = db.query(Player).filter_by(slate_id=slate_id, name=name).first()
    if player is None:
        # Try case-insensitive  (SQLite LIKE is already case-insensitive for ASCII)
        player = (
            db.query(Player)
            .filter(Player.slate_id == slate_id)
            .filter(Player.name.ilike(name))
            .first()
        )
    return player


def _upsert_ownership(
    db: Session,
    slate_id: str,
    player_id: str,
    ownership_pct: float,
    source: str,
) -> OwnershipData:
    """Find-or-create OwnershipData; update pct on conflict."""
    existing = (
        db.query(OwnershipData)
        .filter_by(slate_id=slate_id, player_id=player_id, source=source)
        .first()
    )
    if existing is None:
        existing = OwnershipData(
            id=str(uuid.uuid4()),
            slate_id=slate_id,
            player_id=player_id,
            source=source,
            created_at=datetime.now(timezone.utc).replace(tzinfo=None),
        )
        db.add(existing)
    existing.ownership_pct = ownership_pct
    return existing


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def ingest_ownership_csv(
    db: Session,
    csv_bytes: bytes,
    slate_id: str,
    source: str = "upload",
    mirror_to_projection: bool = True,
) -> Dict[str, Any]:
    """
    Parse *csv_bytes* and persist ownership rows for *slate_id*.

    Parameters
    ----------
    db:
        SQLAlchemy session.
    csv_bytes:
        Raw bytes of the uploaded CSV.
    slate_id:
        The slate this ownership upload belongs to.
    source:
        Label stored in ownership_data.source  (default "upload").
    mirror_to_projection:
        When True, also sets Projection.ownership_pct for the same
        (slate_id, player_id) so the optimizer can read a single row.

    Returns
    -------
    dict with keys: matched, unmatched, total, slate_id
    """
    try:
        df = pd.read_csv(io.BytesIO(csv_bytes))
    except Exception:
        raise ValueError("Ownership CSV is empty or could not be parsed")
    if df.empty:
        raise ValueError("Ownership CSV is empty or could not be parsed")

    ownership_rows = _parse_ownership_df(df)

    matched: List[str] = []
    unmatched: List[str] = []

    for player_name, ownership_pct in ownership_rows:
        player = _find_player_by_name(db, slate_id, player_name)
        if player is None:
            unmatched.append(player_name)
            continue

        _upsert_ownership(db, slate_id, player.id, ownership_pct, source)

        if mirror_to_projection:
            proj = (
                db.query(Projection)
                .filter_by(slate_id=slate_id, player_id=player.id)
                .first()
            )
            if proj is not None:
                proj.ownership_pct = ownership_pct

        matched.append(player_name)

    db.commit()

    return {
        "slate_id": slate_id,
        "matched": len(matched),
        "unmatched": len(unmatched),
        "unmatched_names": unmatched,
        "total": len(ownership_rows),
    }
