"""
Caching Service for Real-Time Data

Provides intelligent caching for:
- Vegas lines (refresh every 5 minutes)
- Injury reports (refresh every 15 minutes)
- Player projections (refresh on data change)
- Ownership projections (refresh every 30 minutes)

Uses TTL-based expiration with background refresh capability.
"""

import time
import threading
import hashlib
import json
from typing import Any, Callable, Dict, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from functools import wraps
import logging
from collections import OrderedDict
import asyncio

logger = logging.getLogger(__name__)


@dataclass
class CacheEntry:
    """Single cache entry with metadata"""
    value: Any
    created_at: float
    expires_at: float
    hit_count: int = 0
    last_accessed: float = field(default_factory=time.time)
    data_hash: str = ""

    def is_expired(self) -> bool:
        return time.time() > self.expires_at

    def access(self) -> Any:
        self.hit_count += 1
        self.last_accessed = time.time()
        return self.value


@dataclass
class CacheConfig:
    """Configuration for cache behavior"""
    # TTL settings (in seconds)
    vegas_ttl: int = 300          # 5 minutes
    injury_ttl: int = 900         # 15 minutes
    projection_ttl: int = 600     # 10 minutes
    ownership_ttl: int = 1800     # 30 minutes
    player_stats_ttl: int = 3600  # 1 hour
    default_ttl: int = 600        # 10 minutes

    # Size limits
    max_entries: int = 1000
    max_memory_mb: int = 100

    # Background refresh
    enable_background_refresh: bool = True
    refresh_before_expiry_seconds: int = 60


class CacheManager:
    """
    Thread-safe cache manager with TTL support
    """

    def __init__(self, config: CacheConfig = None):
        self.config = config or CacheConfig()
        self._cache: Dict[str, CacheEntry] = {}
        self._lock = threading.RLock()
        self._refresh_callbacks: Dict[str, Callable] = {}
        self._background_thread: Optional[threading.Thread] = None
        self._stop_background = threading.Event()

        # Statistics
        self.stats = {
            'hits': 0,
            'misses': 0,
            'evictions': 0,
            'refreshes': 0
        }

        if self.config.enable_background_refresh:
            self._start_background_refresh()

    def _start_background_refresh(self):
        """Start background refresh thread"""
        self._stop_background.clear()
        self._background_thread = threading.Thread(
            target=self._background_refresh_loop,
            daemon=True
        )
        self._background_thread.start()
        logger.info("Cache background refresh started")

    def _background_refresh_loop(self):
        """Background loop to refresh near-expiring entries"""
        while not self._stop_background.is_set():
            try:
                self._check_and_refresh()
            except Exception as e:
                logger.error(f"Background refresh error: {e}")

            self._stop_background.wait(30)  # Check every 30 seconds

    def _check_and_refresh(self):
        """Check for entries needing refresh"""
        now = time.time()
        threshold = now + self.config.refresh_before_expiry_seconds

        with self._lock:
            for key, entry in list(self._cache.items()):
                if entry.expires_at < threshold and not entry.is_expired():
                    if key in self._refresh_callbacks:
                        try:
                            new_value = self._refresh_callbacks[key]()
                            self._update_entry(key, new_value, entry.expires_at - entry.created_at)
                            self.stats['refreshes'] += 1
                            logger.debug(f"Background refreshed: {key}")
                        except Exception as e:
                            logger.warning(f"Failed to refresh {key}: {e}")

    def _update_entry(self, key: str, value: Any, ttl: float):
        """Update or create cache entry"""
        now = time.time()
        data_hash = self._compute_hash(value)

        self._cache[key] = CacheEntry(
            value=value,
            created_at=now,
            expires_at=now + ttl,
            data_hash=data_hash
        )

    def _compute_hash(self, value: Any) -> str:
        """Compute hash of value for change detection"""
        try:
            serialized = json.dumps(value, sort_keys=True, default=str)
            return hashlib.md5(serialized.encode()).hexdigest()[:16]
        except (TypeError, ValueError):
            return str(hash(str(value)))[:16]

    def _evict_if_needed(self):
        """Evict entries if cache is full"""
        if len(self._cache) < self.config.max_entries:
            return

        # Evict expired entries first
        now = time.time()
        expired = [k for k, v in self._cache.items() if v.is_expired()]
        for key in expired:
            del self._cache[key]
            self.stats['evictions'] += 1

        # If still over limit, evict LRU
        if len(self._cache) >= self.config.max_entries:
            # Sort by last_accessed, evict oldest
            sorted_entries = sorted(
                self._cache.items(),
                key=lambda x: x[1].last_accessed
            )
            to_evict = len(self._cache) - self.config.max_entries + 100
            for key, _ in sorted_entries[:to_evict]:
                del self._cache[key]
                self.stats['evictions'] += 1

    def get(self, key: str) -> Tuple[Optional[Any], bool]:
        """
        Get value from cache

        Returns:
            Tuple of (value, hit) where hit is True if found and not expired
        """
        with self._lock:
            if key not in self._cache:
                self.stats['misses'] += 1
                return None, False

            entry = self._cache[key]

            if entry.is_expired():
                del self._cache[key]
                self.stats['misses'] += 1
                return None, False

            self.stats['hits'] += 1
            return entry.access(), True

    def set(self, key: str, value: Any, ttl: float = None,
            refresh_callback: Callable = None) -> None:
        """
        Set value in cache

        Args:
            key: Cache key
            value: Value to cache
            ttl: Time to live in seconds (uses default if not specified)
            refresh_callback: Optional callable to refresh value
        """
        ttl = ttl or self.config.default_ttl

        with self._lock:
            self._evict_if_needed()
            self._update_entry(key, value, ttl)

            if refresh_callback:
                self._refresh_callbacks[key] = refresh_callback

    def delete(self, key: str) -> bool:
        """Delete entry from cache"""
        with self._lock:
            if key in self._cache:
                del self._cache[key]
                self._refresh_callbacks.pop(key, None)
                return True
            return False

    def clear(self) -> None:
        """Clear all cache entries"""
        with self._lock:
            self._cache.clear()
            self._refresh_callbacks.clear()

    def get_or_set(self, key: str, factory: Callable, ttl: float = None) -> Any:
        """
        Get from cache or compute and cache value

        Args:
            key: Cache key
            factory: Callable to create value if not in cache
            ttl: Time to live

        Returns:
            Cached or newly computed value
        """
        value, hit = self.get(key)
        if hit:
            return value

        value = factory()
        self.set(key, value, ttl)
        return value

    def invalidate_pattern(self, pattern: str) -> int:
        """
        Invalidate all keys matching pattern

        Args:
            pattern: Key prefix to match

        Returns:
            Number of entries invalidated
        """
        with self._lock:
            to_delete = [k for k in self._cache.keys() if k.startswith(pattern)]
            for key in to_delete:
                del self._cache[key]
                self._refresh_callbacks.pop(key, None)
            return len(to_delete)

    def get_stats(self) -> Dict:
        """Get cache statistics"""
        with self._lock:
            total_requests = self.stats['hits'] + self.stats['misses']
            hit_rate = self.stats['hits'] / total_requests if total_requests > 0 else 0

            return {
                **self.stats,
                'entries': len(self._cache),
                'hit_rate': hit_rate,
                'refresh_callbacks': len(self._refresh_callbacks)
            }

    def stop(self):
        """Stop background refresh thread"""
        self._stop_background.set()
        if self._background_thread:
            self._background_thread.join(timeout=5)


# Singleton instance
_cache_manager: Optional[CacheManager] = None


def get_cache() -> CacheManager:
    """Get singleton cache manager"""
    global _cache_manager
    if _cache_manager is None:
        _cache_manager = CacheManager()
    return _cache_manager


# Decorator for caching function results
def cached(ttl: float = None, key_prefix: str = None):
    """
    Decorator to cache function results

    Args:
        ttl: Time to live in seconds
        key_prefix: Prefix for cache key (defaults to function name)
    """
    def decorator(func: Callable) -> Callable:
        prefix = key_prefix or func.__name__

        @wraps(func)
        def wrapper(*args, **kwargs):
            # Build cache key from function name and arguments
            key_parts = [prefix]
            if args:
                key_parts.extend(str(a) for a in args)
            if kwargs:
                key_parts.extend(f"{k}={v}" for k, v in sorted(kwargs.items()))
            cache_key = ":".join(key_parts)

            cache = get_cache()
            return cache.get_or_set(cache_key, lambda: func(*args, **kwargs), ttl)

        return wrapper
    return decorator


# Async-compatible caching
class AsyncCacheManager:
    """
    Async-compatible cache wrapper
    """

    def __init__(self, sync_cache: CacheManager = None):
        self._sync_cache = sync_cache or get_cache()
        self._async_lock = asyncio.Lock()

    async def get(self, key: str) -> Tuple[Optional[Any], bool]:
        """Async get from cache"""
        async with self._async_lock:
            return self._sync_cache.get(key)

    async def set(self, key: str, value: Any, ttl: float = None) -> None:
        """Async set in cache"""
        async with self._async_lock:
            self._sync_cache.set(key, value, ttl)

    async def get_or_set(self, key: str, factory: Callable, ttl: float = None) -> Any:
        """Async get or compute"""
        value, hit = await self.get(key)
        if hit:
            return value

        # Handle both sync and async factories
        if asyncio.iscoroutinefunction(factory):
            value = await factory()
        else:
            value = factory()

        await self.set(key, value, ttl)
        return value


# Specialized caches for DFS data
class DFSCacheService:
    """
    Specialized caching for DFS data types
    """

    def __init__(self):
        self.cache = get_cache()
        self.config = self.cache.config

    # Vegas Lines
    def get_vegas_lines(self, sport: str = 'nba') -> Tuple[Optional[Dict], bool]:
        """Get cached Vegas lines"""
        return self.cache.get(f"vegas:{sport}")

    def set_vegas_lines(self, lines: Dict, sport: str = 'nba') -> None:
        """Cache Vegas lines"""
        self.cache.set(f"vegas:{sport}", lines, self.config.vegas_ttl)

    def cache_vegas_lines(self, fetch_func: Callable, sport: str = 'nba') -> Dict:
        """Get or fetch Vegas lines"""
        return self.cache.get_or_set(
            f"vegas:{sport}",
            fetch_func,
            self.config.vegas_ttl
        )

    # Injury Reports
    def get_injuries(self, sport: str = 'nba') -> Tuple[Optional[Dict], bool]:
        """Get cached injury report"""
        return self.cache.get(f"injuries:{sport}")

    def set_injuries(self, injuries: Dict, sport: str = 'nba') -> None:
        """Cache injury report"""
        self.cache.set(f"injuries:{sport}", injuries, self.config.injury_ttl)

    def cache_injuries(self, fetch_func: Callable, sport: str = 'nba') -> Dict:
        """Get or fetch injuries"""
        return self.cache.get_or_set(
            f"injuries:{sport}",
            fetch_func,
            self.config.injury_ttl
        )

    # Projections
    def get_projections(self, slate_id: str) -> Tuple[Optional[Dict], bool]:
        """Get cached projections for a slate"""
        return self.cache.get(f"projections:{slate_id}")

    def set_projections(self, projections: Dict, slate_id: str) -> None:
        """Cache projections"""
        self.cache.set(f"projections:{slate_id}", projections, self.config.projection_ttl)

    def invalidate_projections(self, slate_id: str = None) -> int:
        """Invalidate projection cache"""
        if slate_id:
            return 1 if self.cache.delete(f"projections:{slate_id}") else 0
        return self.cache.invalidate_pattern("projections:")

    # Ownership
    def get_ownership(self, slate_id: str) -> Tuple[Optional[Dict], bool]:
        """Get cached ownership projections"""
        return self.cache.get(f"ownership:{slate_id}")

    def set_ownership(self, ownership: Dict, slate_id: str) -> None:
        """Cache ownership projections"""
        self.cache.set(f"ownership:{slate_id}", ownership, self.config.ownership_ttl)

    # Player Stats
    def get_player_stats(self, player_id: str) -> Tuple[Optional[Dict], bool]:
        """Get cached player stats"""
        return self.cache.get(f"player:{player_id}")

    def set_player_stats(self, stats: Dict, player_id: str) -> None:
        """Cache player stats"""
        self.cache.set(f"player:{player_id}", stats, self.config.player_stats_ttl)

    # Correlation Matrix
    def get_correlation_matrix(self, matrix_hash: str) -> Tuple[Optional[Any], bool]:
        """Get cached correlation matrix"""
        return self.cache.get(f"correlation:{matrix_hash}")

    def set_correlation_matrix(self, matrix: Any, matrix_hash: str) -> None:
        """Cache correlation matrix (1 hour TTL)"""
        self.cache.set(f"correlation:{matrix_hash}", matrix, 3600)

    # Statistics
    def get_cache_stats(self) -> Dict:
        """Get cache statistics"""
        return self.cache.get_stats()


# Singleton DFS cache service
_dfs_cache: Optional[DFSCacheService] = None


def get_dfs_cache() -> DFSCacheService:
    """Get singleton DFS cache service"""
    global _dfs_cache
    if _dfs_cache is None:
        _dfs_cache = DFSCacheService()
    return _dfs_cache
