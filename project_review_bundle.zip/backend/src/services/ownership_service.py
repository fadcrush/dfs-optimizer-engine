"""
Ownership Service - Wrapper for ownership simulator
Generates ownership predictions via API
"""

from pathlib import Path
import pandas as pd
from services.ownership_simulator import simulate_ownership

async def generate_ownership_predictions(
    projections_file_path: str,
    user_id: str = "demo-user"
) -> dict:
    """
    Generate ownership predictions from projections file
    
    Args:
        projections_file_path: Path to projections CSV
        user_id: User identifier
    
    Returns:
        Dict with ownership predictions and stats
    """
    
    print(f"\n🎲 Generating ownership predictions for user {user_id}")
    print(f"📄 Projections file: {projections_file_path}")
    
    try:
        # Call the ownership simulator
        result = simulate_ownership(projections_file_path)
        
        if result['success']:
            print(f"✅ Ownership predictions generated successfully!")
            return result
        else:
            print(f"❌ Ownership simulation failed")
            return {
                "success": False,
                "error": "Ownership simulation failed",
                "ownership_predictions": []
            }
    
    except Exception as e:
        print(f"❌ Error generating ownership: {e}")
        import traceback
        traceback.print_exc()
        
        return {
            "success": False,
            "error": str(e),
            "ownership_predictions": []
        }

def ownership_to_csv(ownership_predictions: list) -> str:
    """
    Convert ownership predictions to CSV
    """
    if not ownership_predictions:
        return ""
    
    df = pd.DataFrame(ownership_predictions)
    
    # Select relevant columns
    output_cols = ['id', 'name', 'position', 'salary', 'projection', 'predicted_ownership', 'leverage']
    
    # Only include columns that exist
    available_cols = [col for col in output_cols if col in df.columns]
    
    return df[available_cols].to_csv(index=False)