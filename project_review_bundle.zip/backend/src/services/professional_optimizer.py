"""
Professional DFS Lineup Optimizer using Linear Programming (PuLP)
This replaces the greedy algorithm with industry-standard optimization

Phase 3: Scales to 10k+ lineups with TRUE BATCH ISOLATION:
- No-good cuts reset per batch (prevents O(n²) LP explosion)
- Global state persisted across batches: exposure counters, lineup keys
- LP constraint count bounded by batch_size, not total_lineups
- Deterministic tie-breaker (hashlib-based, no randomness)
- Ownership-aware EV objective (opt-in, disabled by default)

Phase 4A: Production Observability (opt-in):
- Run metadata collection for post-hoc analysis
- Structured logging with run_id correlation
- Feature-flagged, disabled by default
"""

import logging
import hashlib
import json
import os
import pandas as pd
import numpy as np
from pulp import *
import time  # Must be after 'from pulp import *' to avoid shadowing
from typing import List, Dict, Optional, Callable, Tuple, Any

# Module-level logger
logger = logging.getLogger(__name__)

# =============================================================================
# FEATURE FLAGS (Phase 4A)
# =============================================================================
# All observability features are opt-in and disabled by default.
# Set environment variables to enable:
#   OPTIMIZER_STRUCTURED_LOGS=true
#   OPTIMIZER_RUN_PERSISTENCE=true

ENABLE_STRUCTURED_LOGS = os.getenv("OPTIMIZER_STRUCTURED_LOGS", "false").lower() == "true"
ENABLE_RUN_PERSISTENCE = os.getenv("OPTIMIZER_RUN_PERSISTENCE", "false").lower() == "true"

# Optimizer version for metadata
OPTIMIZER_VERSION = "3.1.0"

# Environment detection
def _get_environment() -> str:
    """Detect deployment environment from env var or default to local."""
    return os.getenv("OPTIMIZER_ENVIRONMENT", "local")


# =============================================================================
# OBSERVABILITY IMPORTS (conditional to avoid import errors if module missing)
# =============================================================================
try:
    from observability.run_metadata import (
        RunMetadata,
        InputFingerprint,
        OptimizationParameters,
        ExecutionMetrics,
        OutcomeQuality,
        OutputFingerprintData,
        RunStatus,
        create_run_id,
        get_timestamp_utc,
        compute_dict_hash,
    )
    from observability.structured_logging import StructuredOptimizerLogger
    from observability.persistence import get_default_store
    from observability.diff import OutputFingerprint as DiffOutputFingerprint
    OBSERVABILITY_AVAILABLE = True
except ImportError:
    OBSERVABILITY_AVAILABLE = False
    # Define stub types to prevent NameError when observability is disabled
    RunMetadata = None
    StructuredOptimizerLogger = None
    DiffOutputFingerprint = None

# Phase 5B6: Verification imports (separate try for graceful fallback)
try:
    from observability.verification import (
        run_verification_if_enabled,
        VerificationError,
    )
    VERIFICATION_AVAILABLE = True
except ImportError:
    VERIFICATION_AVAILABLE = False
    run_verification_if_enabled = None
    VerificationError = Exception

# Phase 6: Preflight imports (separate try for graceful fallback)
try:
    from observability.preflight import (
        run_preflight_checks,
        PreflightResult,
        PreflightError,
    )
    from observability.run_metadata import FailureReason
    PREFLIGHT_AVAILABLE = True
except ImportError:
    PREFLIGHT_AVAILABLE = False
    run_preflight_checks = None
    PreflightResult = None
    PreflightError = Exception
    FailureReason = None


def _stable_hash(s: str) -> float:
    """
    Deterministic hash returning float in [0, 1).
    Used for tie-breaking without randomness.
    """
    h = hashlib.md5(s.encode('utf-8')).hexdigest()
    return int(h[:8], 16) / (2**32)


# =============================================================================
# PHASE 6: PERFORMANCE BUDGET HELPERS
# =============================================================================

# Performance thresholds (configurable via env)
PERF_TIMEOUT_RATE_WARN = float(os.getenv("OPTIMIZER_PERF_TIMEOUT_RATE_WARN", "0.1"))  # 10%
PERF_TIMEOUT_RATE_FAIL = float(os.getenv("OPTIMIZER_PERF_TIMEOUT_RATE_FAIL", "0.3"))  # 30%
PERF_AVG_SOLVE_MS_WARN = int(os.getenv("OPTIMIZER_PERF_AVG_SOLVE_MS_WARN", "500"))    # 500ms
PERF_AVG_SOLVE_MS_FAIL = int(os.getenv("OPTIMIZER_PERF_AVG_SOLVE_MS_FAIL", "2000"))   # 2s


def _check_performance_budget(
    total_lp_solves: int,
    solver_timeouts: int,
    lp_solve_ms_avg: float,
    metadata: "RunMetadata",
) -> None:
    """
    Check performance metrics against budget thresholds.

    Logs warnings and adds to run metadata warnings list.
    Does NOT modify optimizer behavior or output.
    """
    if total_lp_solves == 0:
        return

    # Check timeout rate
    timeout_rate = solver_timeouts / total_lp_solves

    if timeout_rate >= PERF_TIMEOUT_RATE_FAIL:
        msg = f"HIGH solver timeout rate: {timeout_rate:.1%} ({solver_timeouts}/{total_lp_solves} solves)"
        logger.error(msg)
        metadata.warnings.append(f"PERF_TIMEOUT_HIGH: {msg}")
    elif timeout_rate >= PERF_TIMEOUT_RATE_WARN:
        msg = f"Elevated solver timeout rate: {timeout_rate:.1%} ({solver_timeouts}/{total_lp_solves} solves)"
        logger.warning(msg)
        metadata.warnings.append(f"PERF_TIMEOUT_WARN: {msg}")

    # Check average solve time
    if lp_solve_ms_avg >= PERF_AVG_SOLVE_MS_FAIL:
        msg = f"HIGH average LP solve time: {lp_solve_ms_avg:.0f}ms (threshold: {PERF_AVG_SOLVE_MS_FAIL}ms)"
        logger.error(msg)
        metadata.warnings.append(f"PERF_SOLVE_SLOW: {msg}")
    elif lp_solve_ms_avg >= PERF_AVG_SOLVE_MS_WARN:
        msg = f"Elevated average LP solve time: {lp_solve_ms_avg:.0f}ms (threshold: {PERF_AVG_SOLVE_MS_WARN}ms)"
        logger.warning(msg)
        metadata.warnings.append(f"PERF_SOLVE_WARN: {msg}")


# =============================================================================
# OBSERVABILITY HELPERS (Phase 4A)
# =============================================================================

def _create_run_context(
    pool: pd.DataFrame,
    num_lineups: int,
    max_exposure: float,
    min_salary: int,
    max_salary: int,
    platform: str,
    ownership: Optional[Dict[str, float]],
    ownership_weight: float,
    batch_size: int,
    seed: int,
    max_duplicate_retries: int,
    solver_time_limit_seconds: int,
) -> Optional[Any]:
    """
    Create run metadata context at optimizer entry.
    Returns None if observability is disabled or unavailable.

    This is a PASSIVE operation - no side effects on optimization.
    """
    if not OBSERVABILITY_AVAILABLE:
        return None

    run_id = create_run_id()
    timestamp_start = get_timestamp_utc()

    # Compute input fingerprint
    # Hash the pool data for reproducibility verification
    pool_hash = compute_dict_hash({
        "columns": list(pool.columns),
        "shape": list(pool.shape),
        "names": sorted(pool["Name"].tolist()) if "Name" in pool.columns else [],
    })

    ownership_hash = None
    if ownership is not None and ownership_weight > 0:
        ownership_hash = compute_dict_hash(ownership)

    input_fingerprint = InputFingerprint(
        projections_file_hash=pool_hash,
        num_players=len(pool),
        slate_platform=platform.lower(),
        ownership_hash=ownership_hash,
    )

    parameters = OptimizationParameters(
        num_lineups=num_lineups,
        batch_size=batch_size,
        max_exposure=max_exposure,
        salary_min=min_salary,
        salary_max=max_salary,
        ownership_weight=ownership_weight,
        solver_time_limit_seconds=solver_time_limit_seconds,
        random_seed=seed,
        max_duplicate_retries=max_duplicate_retries,
    )

    metadata = RunMetadata(
        run_id=run_id,
        timestamp_start=timestamp_start,
        timestamp_end=None,
        duration_ms=None,
        environment=_get_environment(),
        optimizer_version=OPTIMIZER_VERSION,
        input_fingerprint=input_fingerprint,
        parameters=parameters,
        execution=None,
        outcome=None,
        status=RunStatus.SUCCESS.value,
        warnings=[],
        fatal_error=None,
    )

    return {
        "metadata": metadata,
        "run_id": run_id,
        "start_time": time.perf_counter(),
        "lp_solve_times": [],  # Collect individual LP solve times
    }


def _finalize_run_context(
    ctx: Optional[Dict],
    lineups: List[List[Dict]],
    num_lineups_requested: int,
    batches_completed: int,
    total_lp_solves: int,
    solver_timeouts: int,
    infeasible_solves: int,
    no_good_cuts_total: int,
    duplicate_retries: int,
    player_exposure: Dict[str, int],
    fatal_error: Optional[Exception] = None,
) -> Optional[Any]:
    """
    Finalize run metadata at optimizer exit.
    Returns the finalized RunMetadata or None if observability disabled.

    This is a PASSIVE operation - no side effects on optimization.
    """
    if ctx is None or not OBSERVABILITY_AVAILABLE:
        return None

    metadata: RunMetadata = ctx["metadata"]
    start_time: float = ctx["start_time"]
    lp_solve_times: List[float] = ctx["lp_solve_times"]

    # Compute timing
    end_time = time.perf_counter()
    duration_ms = int((end_time - start_time) * 1000)
    lp_solve_ms_total = int(sum(lp_solve_times) * 1000)
    lp_solve_ms_avg = (lp_solve_ms_total / len(lp_solve_times)) if lp_solve_times else 0.0
    lp_solve_ms_max = int(max(lp_solve_times) * 1000) if lp_solve_times else 0

    # Determine status
    if fatal_error is not None:
        status = RunStatus.FAILED.value
        metadata.fatal_error = str(fatal_error)
    elif len(lineups) == 0:
        status = RunStatus.FAILED.value
    elif len(lineups) < num_lineups_requested:
        status = RunStatus.PARTIAL.value
    else:
        status = RunStatus.SUCCESS.value

    # Build execution metrics
    execution = ExecutionMetrics(
        total_lineups_requested=num_lineups_requested,
        total_lineups_generated=len(lineups),
        batches_completed=batches_completed,
        total_lp_solves=total_lp_solves,
        solver_timeouts=solver_timeouts,
        infeasible_solves=infeasible_solves,
        no_good_cuts_total=no_good_cuts_total,
        duplicate_retries=duplicate_retries,
        wall_clock_ms=duration_ms,
        lp_solve_ms_total=lp_solve_ms_total,
        lp_solve_ms_avg=lp_solve_ms_avg,
        lp_solve_ms_max=lp_solve_ms_max,
    )

    # Build outcome quality metrics (if we have lineups)
    outcome = None
    if lineups:
        projections = [sum(p.get("Projection", 0) for p in lu) for lu in lineups]
        salaries = [sum(p.get("Salary", 0) for p in lu) for lu in lineups]

        # Calculate exposure
        max_exposure_actual = 0.0
        unique_players = set()
        for lu in lineups:
            for p in lu:
                unique_players.add(p.get("Name", ""))
        if player_exposure:
            max_count = max(player_exposure.values())
            max_exposure_actual = max_count / len(lineups) if lineups else 0.0

        # Calculate std safely
        proj_std = 0.0
        if len(projections) > 1:
            mean_proj = sum(projections) / len(projections)
            variance = sum((p - mean_proj) ** 2 for p in projections) / len(projections)
            proj_std = variance ** 0.5

        outcome = OutcomeQuality(
            avg_projection=sum(projections) / len(projections) if projections else 0.0,
            projection_min=min(projections) if projections else 0.0,
            projection_max=max(projections) if projections else 0.0,
            projection_std=proj_std,
            avg_salary=sum(salaries) / len(salaries) if salaries else 0.0,
            salary_min=min(salaries) if salaries else 0,
            salary_max=max(salaries) if salaries else 0,
            max_player_exposure=max_exposure_actual,
            unique_players_used=len(unique_players),
        )

    # Phase 5A: Compute output fingerprint for replay verification
    output_fingerprint = None
    if lineups and DiffOutputFingerprint is not None:
        try:
            diff_fp = DiffOutputFingerprint.from_lineups(lineups)
            output_fingerprint = OutputFingerprintData(
                lineup_set_hash=diff_fp.lineup_set_hash,
                ordered_hash=hashlib.sha256(
                    json.dumps(diff_fp.lineup_hashes).encode("utf-8")
                ).hexdigest(),
                total_lineups=diff_fp.total_lineups,
                first_lineup_hash=diff_fp.lineup_hashes[0] if diff_fp.lineup_hashes else None,
                last_lineup_hash=diff_fp.lineup_hashes[-1] if diff_fp.lineup_hashes else None,
            )
        except Exception as e:
            logger.warning("Failed to compute output fingerprint: %s", e)

    # Update metadata
    metadata.timestamp_end = get_timestamp_utc()
    metadata.duration_ms = duration_ms
    metadata.status = status
    metadata.execution = execution
    metadata.outcome = outcome
    metadata.output_fingerprint = output_fingerprint

    # Phase 6: Performance budget warnings
    _check_performance_budget(
        total_lp_solves=total_lp_solves,
        solver_timeouts=solver_timeouts,
        lp_solve_ms_avg=lp_solve_ms_avg,
        metadata=metadata,
    )

    # Persist if enabled
    if ENABLE_RUN_PERSISTENCE:
        try:
            store = get_default_store()
            store.save(metadata)
            logger.debug("Run metadata persisted: %s", metadata.run_id)
        except Exception as e:
            # Never fail the optimizer due to persistence errors
            logger.warning("Failed to persist run metadata: %s", e)

    # Phase 5B6: Run verification if enabled (AFTER output fingerprint computed)
    if ENABLE_RUN_PERSISTENCE and VERIFICATION_AVAILABLE and run_verification_if_enabled:
        try:
            verification_result = run_verification_if_enabled(metadata.run_id)
            if verification_result is not None:
                metadata.verification = verification_result
                # Re-persist with verification result
                try:
                    store = get_default_store()
                    store.save(metadata)
                    logger.debug("Run metadata updated with verification: %s", metadata.run_id)
                except Exception as e:
                    logger.warning("Failed to persist verification result: %s", e)
        except VerificationError as e:
            # Hard fail was enabled and drift detected
            # Log but don't re-raise here - lineups are already generated
            logger.error("Verification hard fail: %s", e)
            # The exception will be re-raised by the verification module if hard fail is enabled
        except Exception as e:
            # Never fail the optimizer due to verification errors
            logger.warning("Verification failed: %s", e)

    return metadata


def optimize_lineups_lp(
    pool: pd.DataFrame,
    num_lineups: int = 150,
    max_exposure: float = 0.35,
    min_salary: int = 49000,
    max_salary: int = 60000,
    platform: str = "fanduel",
    ownership: Optional[Dict[str, float]] = None,
    ownership_weight: float = 0.0,
    batch_size: int = 500,
    progress_callback: Optional[Callable[[int, int], None]] = None,
    seed: int = 1337,
    max_duplicate_retries: int = 3,
    solver_time_limit_seconds: int = 10,
    progress_every: int = 10
) -> List[List[Dict]]:
    """
    Generate optimal DFS lineups using Linear Programming.

    CONTRACTS:
    - Each lineup is generated from a fresh LP (no state leakage)
    - Ownership affects objective ONLY when ownership_weight > 0
    - ownership_weight=0 behaves IDENTICALLY to ownership=None
    - Deterministic: same input + same seed produces same output
    - Scales to 10k+ lineups via lazy no-good cuts

    Args:
        pool: DataFrame with player data (Name, Position, Salary, Projection, PosBucket)
        num_lineups: Target number of lineups to generate
        max_exposure: Maximum exposure per player (0.0-1.0)
        min_salary: Minimum total salary
        max_salary: Maximum total salary (usually 60000)
        platform: "fanduel" or "draftkings"
        ownership: Optional dict mapping player name to predicted ownership (0.0-1.0).
                   ONLY used when ownership_weight > 0.
        ownership_weight: Weight for ownership penalty (0.0 = projection only).
                          Default 0.0 preserves baseline behavior.
        batch_size: Progress callback interval (default 500)
        progress_callback: Optional callback(current, total) for UI updates
        seed: Deterministic seed for tie-breaking (default 1337)
        max_duplicate_retries: Max retries when duplicate detected (default 3)
        solver_time_limit_seconds: Max time per LP solve (default 10s, prevents hangs)
        progress_every: Log progress every N lineups (default 10)

    Returns:
        List of lineups. May be fewer than num_lineups if space is exhausted
        (due to exposure limits + uniqueness constraints).

    Raises:
        RuntimeError: If unable to generate even the first lineup (constraint conflict)
    """
    # ==========================================================================
    # PHASE 6: PREFLIGHT CHECKS (fail-fast on invalid inputs)
    # ==========================================================================
    preflight_result = None
    if PREFLIGHT_AVAILABLE and run_preflight_checks:
        preflight_result = run_preflight_checks(
            pool=pool,
            platform=platform,
            num_lineups=num_lineups,
            max_exposure=max_exposure,
            min_salary=min_salary,
            max_salary=max_salary,
            ownership=ownership,
            ownership_weight=ownership_weight,
        )
        if not preflight_result.passed:
            # Log failures and raise
            for msg in preflight_result.failure_messages:
                logger.error("Preflight FAIL: %s", msg)
            raise PreflightError(preflight_result)
        elif preflight_result.has_warnings:
            # Log warnings but continue
            for msg in preflight_result.warning_messages:
                logger.warning("Preflight WARN: %s", msg)

    # ==========================================================================
    # PHASE 4A: RUN CONTEXT INITIALIZATION (passive, no behavior change)
    # ==========================================================================
    run_ctx = _create_run_context(
        pool=pool,
        num_lineups=num_lineups,
        max_exposure=max_exposure,
        min_salary=min_salary,
        max_salary=max_salary,
        platform=platform,
        ownership=ownership,
        ownership_weight=ownership_weight,
        batch_size=batch_size,
        seed=seed,
        max_duplicate_retries=max_duplicate_retries,
        solver_time_limit_seconds=solver_time_limit_seconds,
    )

    # Structured logger (only active when ENABLE_STRUCTURED_LOGS=true)
    slog = None
    if ENABLE_STRUCTURED_LOGS and OBSERVABILITY_AVAILABLE and run_ctx:
        slog = StructuredOptimizerLogger(run_id=run_ctx["run_id"], logger=logger)

    # ==========================================================================
    # EXISTING LOGGING (preserved, levels adjusted for noise control)
    # ==========================================================================
    logger.info("LP Optimizer started: %d lineups for %s", num_lineups, platform.upper())
    logger.info("Player pool: %d players, salary range: $%d-$%d, max exposure: %.0f%%",
                len(pool), min_salary, max_salary, max_exposure * 100)

    # OWNERSHIP MODE: Only enabled when BOTH conditions are true
    # ownership_weight == 0 MUST behave identically to no ownership
    use_ownership = ownership is not None and ownership_weight > 0
    if use_ownership:
        logger.info("Ownership mode: ENABLED (weight=%.2f)", ownership_weight)
    else:
        logger.debug("Ownership mode: disabled (projection-only)")

    # Structured log: run_start (if enabled)
    if slog:
        slog.run_start(
            num_lineups=num_lineups,
            platform=platform,
            num_players=len(pool),
            salary_min=min_salary,
            salary_max=max_salary,
            max_exposure=max_exposure,
            batch_size=batch_size,
            ownership_enabled=use_ownership,
            ownership_weight=ownership_weight,
            seed=seed,
            solver_time_limit=solver_time_limit_seconds,
        )

    # Platform configuration
    if platform.lower() == "fanduel":
        roster_size = 9
    else:  # DraftKings
        roster_size = 8

    # Pre-compute player data for stable ordering (determinism)
    player_data = pool.to_dict('records')
    # Sort by name for deterministic ordering
    player_data = sorted(player_data, key=lambda p: p['Name'])
    player_names = [p['Name'] for p in player_data]
    player_projections = {p['Name']: float(p['Projection']) for p in player_data}
    player_salaries = {p['Name']: int(p['Salary']) for p in player_data}
    player_positions = {p['Name']: p['PosBucket'] for p in player_data}

    # Pre-compute ownership values ONLY if ownership mode is active
    # Clamped to [0.001, 0.95] with default 0.12 for missing players
    DEFAULT_OWNERSHIP = 0.12
    player_ownership = {}
    if use_ownership:
        for name in player_names:
            raw_own = ownership.get(name, DEFAULT_OWNERSHIP)
            player_ownership[name] = max(0.001, min(0.95, raw_own))

    # ========================================================================
    # GLOBAL STATE - Persisted across all batches
    # ========================================================================
    # These MUST survive batch resets to maintain correctness:
    # - lineups: accumulated results
    # - generated_lineup_keys: for duplicate detection across batches
    # - player_exposure: for exposure limits (critical for fairness)
    lineups = []
    player_exposure = {name: 0 for name in player_names}
    max_uses = max(1, int(num_lineups * max_exposure))
    generated_lineup_keys = set()  # frozensets of player names

    # Global counters for logging and metrics
    solver_timeouts = 0
    total_no_good_cuts = 0  # Cumulative across all batches (for logging only)

    # Phase 4A: Additional execution metrics (passive counters)
    total_lp_solves = 0
    infeasible_solves = 0
    duplicate_retries = 0
    batches_completed = 0

    logger.info("Building %d lineups (batch_size=%d, seed=%d, time_limit=%ds)...",
                num_lineups, batch_size, seed, solver_time_limit_seconds)

    lineup_idx = 0
    space_exhausted = False

    # ========================================================================
    # OUTER BATCH LOOP - TRUE BATCH ISOLATION
    # ========================================================================
    # Why batch isolation matters:
    # - Without it, no-good cuts accumulate to O(num_lineups) constraints
    # - With batching, LP constraint count is bounded by O(batch_size)
    # - Memory and solve time remain stable even at 10,000+ lineups
    #
    # What resets per batch: batch_no_good_cuts (uniqueness constraints)
    # What persists: player_exposure, generated_lineup_keys, lineups
    while lineup_idx < num_lineups and not space_exhausted:
        batch_start = lineup_idx
        batch_end = min(lineup_idx + batch_size, num_lineups)
        batch_num = (lineup_idx // batch_size) + 1

        # ====================================================================
        # BATCH-LOCAL STATE - Reset every batch to bound LP complexity
        # ====================================================================
        batch_no_good_cuts = []  # Only grows within this batch
        batch_consecutive_failures = 0
        batch_start_time = time.perf_counter()  # Phase 4A: batch timing

        logger.debug("Starting batch %d: lineups %d-%d", batch_num, batch_start + 1, batch_end)

        # Structured log: batch_start (if enabled)
        if slog:
            slog.batch_start(
                batch_num=batch_num,
                batch_start_idx=batch_start,
                batch_end_idx=batch_end,
                lineups_so_far=len(lineups),
            )

        while lineup_idx < batch_end and not space_exhausted:
            # ================================================================
            # FRESH LP PROBLEM - No state leakage between iterations
            # ================================================================
            prob = LpProblem(f"DFS_Lineup_{lineup_idx}", LpMaximize)

            # Fresh decision variables for this iteration
            player_vars = {
                name: LpVariable(f"x_{i}", cat='Binary')
                for i, name in enumerate(player_names)
            }

            # ================================================================
            # OBJECTIVE: Projection with deterministic tie-breaker
            # Ownership penalty applied ONLY when use_ownership=True
            # Formula: score = projection * (1 - ownership_weight * ownership)
            # ================================================================
            objective_terms = []
            for i, name in enumerate(player_names):
                proj = player_projections[name]

                if use_ownership:
                    # Ownership-aware EV: penalize high-owned players
                    # This is NOT a constraint - just changes the objective
                    # When ownership_weight=0, this path is never taken
                    own = player_ownership.get(name, DEFAULT_OWNERSHIP)
                    score = proj * (1.0 - ownership_weight * own)
                else:
                    # Pure projection - no ownership influence whatsoever
                    score = proj

                # Deterministic tie-breaker: tiny epsilon based on seed + lineup_idx + player_id
                # This ensures same input always produces same output
                epsilon = _stable_hash(f"{seed}:{lineup_idx}:{i}") * 1e-6
                score += epsilon

                objective_terms.append(player_vars[name] * score)

            prob += lpSum(objective_terms), "Objective"

            # ================================================================
            # CONSTRAINTS
            # ================================================================

            # Constraint 1: Exactly roster_size players
            prob += lpSum(player_vars.values()) == roster_size, "Roster_Size"

            # Constraint 2: Salary bounds
            salary_sum = lpSum([player_vars[name] * player_salaries[name] for name in player_names])
            prob += salary_sum >= min_salary, "Min_Salary"
            prob += salary_sum <= max_salary, "Max_Salary"

            # Constraint 3: Position requirements
            if platform.lower() == "fanduel":
                for pos, count in [('PG', 2), ('SG', 2), ('SF', 2), ('PF', 2), ('C', 1)]:
                    pos_players = [name for name in player_names if player_positions[name] == pos]
                    prob += lpSum([player_vars[name] for name in pos_players]) == count, f"Pos_{pos}"
            else:  # DraftKings
                for pos in ['PG', 'SG', 'SF', 'PF', 'C']:
                    pos_players = [name for name in player_names if player_positions[name] == pos]
                    prob += lpSum([player_vars[name] for name in pos_players]) >= 1, f"Pos_{pos}_Min"
                # Guards: need 3 total (for PG, SG, G slots)
                guards = [name for name in player_names if player_positions[name] in ('PG', 'SG')]
                prob += lpSum([player_vars[name] for name in guards]) >= 3, "Guards_Min"
                # Forwards: need 3 total (for SF, PF, F slots)
                forwards = [name for name in player_names if player_positions[name] in ('SF', 'PF')]
                prob += lpSum([player_vars[name] for name in forwards]) >= 3, "Forwards_Min"

            # Constraint 4: Exposure limits (uses GLOBAL player_exposure)
            for name in player_names:
                if player_exposure[name] >= max_uses:
                    prob += player_vars[name] == 0, f"Exp_{name}"

            # Constraint 5: BATCH-LOCAL NO-GOOD CUTS
            # These only include duplicates detected within THIS batch
            # Key insight: if we generate a lineup that exists in generated_lineup_keys
            # (from a previous batch), we add it to batch_no_good_cuts and retry
            for cut_idx, cut_key in enumerate(batch_no_good_cuts):
                cut_names = list(cut_key)
                prob += lpSum([player_vars[name] for name in cut_names]) <= roster_size - 1, \
                        f"NoGood_{cut_idx}"

            # ================================================================
            # SOLVE (with time limit to prevent hangs)
            # ================================================================
            _solve_start = time.perf_counter()  # Phase 4A: LP solve timing
            prob.solve(PULP_CBC_CMD(msg=0, timeLimit=solver_time_limit_seconds))
            _solve_elapsed = time.perf_counter() - _solve_start
            total_lp_solves += 1
            if run_ctx:
                run_ctx["lp_solve_times"].append(_solve_elapsed)

            # ================================================================
            # INFEASIBILITY / TIMEOUT HANDLING
            # ================================================================
            if prob.status != LpStatusOptimal:
                status_name = LpStatus.get(prob.status, f"Unknown({prob.status})")
                infeasible_solves += 1  # Phase 4A: count infeasible solves

                # Check if this was a timeout (status 0 = Not Solved)
                is_timeout = prob.status == 0

                if is_timeout:
                    solver_timeouts += 1
                    logger.warning(
                        "Solver timeout at lineup %d/%d (limit=%ds). Treating as infeasible.",
                        lineup_idx + 1, num_lineups, solver_time_limit_seconds
                    )
                    # Structured log: solver_timeout (if enabled)
                    if slog:
                        slog.solver_timeout(
                            lineup_idx=lineup_idx,
                            batch_num=batch_num,
                            time_limit_seconds=solver_time_limit_seconds,
                            no_good_cuts_active=len(batch_no_good_cuts),
                        )
                else:
                    # Structured log: solver_infeasible (if enabled)
                    if slog:
                        slog.solver_infeasible(
                            lineup_idx=lineup_idx,
                            batch_num=batch_num,
                            lp_status=status_name,
                            no_good_cuts_active=len(batch_no_good_cuts),
                            is_first_lineup=(lineup_idx == 0 and len(batch_no_good_cuts) == 0),
                        )

                # First lineup failure = hard error (fundamental constraint issue)
                if lineup_idx == 0 and len(batch_no_good_cuts) == 0:
                    _err = RuntimeError(
                        f"Unable to generate first lineup: LP status={status_name}. "
                        f"Check constraints (salary, positions, pool size)."
                    )
                    # Structured log: run_failed (if enabled)
                    if slog:
                        slog.run_failed(
                            error=_err,
                            lineups_before_failure=len(lineups),
                            batch_num=batch_num,
                            lineup_idx=lineup_idx,
                        )
                    # Finalize metadata before raising
                    _finalize_run_context(
                        ctx=run_ctx,
                        lineups=lineups,
                        num_lineups_requested=num_lineups,
                        batches_completed=batches_completed,
                        total_lp_solves=total_lp_solves,
                        solver_timeouts=solver_timeouts,
                        infeasible_solves=infeasible_solves,
                        no_good_cuts_total=total_no_good_cuts,
                        duplicate_retries=duplicate_retries,
                        player_exposure=player_exposure,
                        fatal_error=_err,
                    )
                    raise _err

                # Later failure = space exhausted (exposure + uniqueness) or timeout
                # Return what we have - this is expected for large num_lineups with tight exposure
                logger.warning(
                    "Stopping at lineup %d/%d (status=%s, timeouts=%d). Returning %d lineups.",
                    lineup_idx + 1, num_lineups, status_name, solver_timeouts, len(lineups)
                )
                # Structured log: space_exhausted (if enabled)
                if slog:
                    slog.space_exhausted(
                        lineup_idx=lineup_idx,
                        lineups_generated=len(lineups),
                        reason="infeasible" if not is_timeout else "timeout",
                    )
                space_exhausted = True
                break

            # ================================================================
            # EXTRACT SOLUTION
            # ================================================================
            selected_names = []
            for name in player_names:
                val = player_vars[name].value()
                if val is not None and val >= 0.99:
                    selected_names.append(name)

            # Validate roster size
            if len(selected_names) != roster_size:
                raise RuntimeError(
                    f"Lineup {lineup_idx + 1} has {len(selected_names)} players, expected {roster_size}"
                )

            # Build lineup key
            lineup_key = frozenset(selected_names)

            # ================================================================
            # DUPLICATE DETECTION - Check against GLOBAL generated_lineup_keys
            # If duplicate found, add to BATCH-LOCAL no-good cuts
            # ================================================================
            if lineup_key in generated_lineup_keys:
                # Add to batch-local no-good cuts and retry
                batch_no_good_cuts.append(lineup_key)
                batch_consecutive_failures += 1
                total_no_good_cuts += 1
                duplicate_retries += 1  # Phase 4A: count duplicate retries

                if batch_consecutive_failures >= max_duplicate_retries:
                    logger.warning(
                        "Max duplicate retries (%d) reached at lineup %d. Space likely exhausted.",
                        max_duplicate_retries, lineup_idx + 1
                    )
                    # Structured log: space_exhausted (if enabled)
                    if slog:
                        slog.space_exhausted(
                            lineup_idx=lineup_idx,
                            lineups_generated=len(lineups),
                            reason="max_retries",
                        )
                    space_exhausted = True
                    break

                logger.debug("Duplicate detected at lineup %d, adding batch no-good cut (retry %d/%d)",
                            lineup_idx + 1, batch_consecutive_failures, max_duplicate_retries)
                continue  # Retry same lineup_idx with new constraint

            # SUCCESS - record this lineup in GLOBAL state
            batch_consecutive_failures = 0
            lineup = [p for p in player_data if p['Name'] in selected_names]
            generated_lineup_keys.add(lineup_key)
            lineups.append(lineup)
            for name in selected_names:
                player_exposure[name] += 1

            lineup_idx += 1

            # Progress callback for UI (at batch boundaries)
            if progress_callback and lineup_idx % batch_size == 0:
                progress_callback(lineup_idx, num_lineups)

            # Progress logging
            # Phase 4A: Changed to DEBUG for noise control in production
            # INFO level kept for first lineup and batch boundaries for visibility
            if lineup_idx == 1:
                logger.info("Progress: %d/%d lineups (batch %d, batch_cuts: %d)",
                           lineup_idx, num_lineups, batch_num, len(batch_no_good_cuts))
            elif lineup_idx % progress_every == 0:
                logger.debug("Progress: %d/%d lineups (batch %d, batch_cuts: %d)",
                            lineup_idx, num_lineups, batch_num, len(batch_no_good_cuts))

        # End of batch - log summary
        batch_lineups = lineup_idx - batch_start
        batches_completed += 1  # Phase 4A: count completed batches
        logger.info("Batch %d complete: %d lineups, %d no-good cuts",
                   batch_num, batch_lineups, len(batch_no_good_cuts))

        # Structured log: batch_complete (if enabled)
        if slog:
            slog.batch_complete(
                batch_num=batch_num,
                lineups_in_batch=batch_lineups,
                no_good_cuts_in_batch=len(batch_no_good_cuts),
            )

    logger.info("Completed: %d/%d lineups generated (total_no_good_cuts: %d, timeouts: %d)",
                len(lineups), num_lineups, total_no_good_cuts, solver_timeouts)

    # Final progress callback
    if progress_callback and len(lineups) > 0:
        progress_callback(len(lineups), num_lineups)

    # Log exposure stats at DEBUG level
    if logger.isEnabledFor(logging.DEBUG) and len(lineups) > 0:
        used_players = {name: count for name, count in player_exposure.items() if count > 0}
        if used_players:
            top_exposures = sorted(used_players.items(), key=lambda x: (-x[1], x[0]))[:10]
            logger.debug("Top exposures:")
            for name, count in top_exposures:
                pct = (count / len(lineups)) * 100
                logger.debug("  %s: %d (%.1f%%)", name, count, pct)

    # ==========================================================================
    # PHASE 4A: FINALIZE RUN CONTEXT AND STRUCTURED LOGGING
    # ==========================================================================
    # Calculate metrics for structured logging
    avg_projection = 0.0
    max_exposure_actual = 0.0
    if lineups:
        projections = [sum(p.get("Projection", 0) for p in lu) for lu in lineups]
        avg_projection = sum(projections) / len(projections) if projections else 0.0
        if player_exposure:
            max_count = max(player_exposure.values())
            max_exposure_actual = max_count / len(lineups) if lineups else 0.0

    # Structured log: run_complete (if enabled)
    if slog:
        status = "success" if len(lineups) == num_lineups else "partial"
        slog.run_complete(
            status=status,
            lineups_requested=num_lineups,
            lineups_generated=len(lineups),
            batches_completed=batches_completed,
            solver_timeouts=solver_timeouts,
            no_good_cuts_total=total_no_good_cuts,
            avg_projection=avg_projection,
            max_exposure_actual=max_exposure_actual,
        )

    # Finalize and persist metadata (if enabled)
    _finalize_run_context(
        ctx=run_ctx,
        lineups=lineups,
        num_lineups_requested=num_lineups,
        batches_completed=batches_completed,
        total_lp_solves=total_lp_solves,
        solver_timeouts=solver_timeouts,
        infeasible_solves=infeasible_solves,
        no_good_cuts_total=total_no_good_cuts,
        duplicate_retries=duplicate_retries,
        player_exposure=player_exposure,
        fatal_error=None,
    )

    return lineups


def validate_lineup(lineup: List[Dict], platform: str, min_salary: int, max_salary: int) -> bool:
    """
    Validate a lineup meets all constraints.

    Returns True if lineup is valid for the given platform.
    """
    # Check roster size
    if platform.lower() == "fanduel" and len(lineup) != 9:
        return False
    if platform.lower() == "draftkings" and len(lineup) != 8:
        return False

    # Check salary
    total_salary = sum(p['Salary'] for p in lineup)
    if total_salary < min_salary or total_salary > max_salary:
        return False

    # Check positions
    positions = [p['PosBucket'] for p in lineup]

    if platform.lower() == "fanduel":
        required = {'PG': 2, 'SG': 2, 'SF': 2, 'PF': 2, 'C': 1}
        actual = {pos: positions.count(pos) for pos in required}
        if actual != required:
            return False

    elif platform.lower() == "draftkings":
        # DraftKings: PG, SG, SF, PF, C, G, F, UTIL = 8 slots
        # Must have: ≥1 of each base position, ≥3 guards, ≥3 forwards
        pg_count = positions.count('PG')
        sg_count = positions.count('SG')
        sf_count = positions.count('SF')
        pf_count = positions.count('PF')
        c_count = positions.count('C')

        if pg_count < 1 or sg_count < 1 or sf_count < 1 or pf_count < 1 or c_count < 1:
            return False

        guards_total = pg_count + sg_count
        forwards_total = sf_count + pf_count

        if guards_total < 3 or forwards_total < 3:
            return False

    return True


def format_lineups_for_export(lineups: List[List[Dict]], platform: str) -> List[Dict]:
    """
    Format lineups for API response
    """
    
    formatted = []
    
    for i, lineup in enumerate(lineups):
        if platform.lower() == "fanduel":
    # FanDuel: PG, PG, SG, SG, SF, SF, PF, PF, C (ID:Name format)
            positions = {'PG': [], 'SG': [], 'SF': [], 'PF': [], 'C': []}
            
            for player in lineup:
                pos = player['PosBucket']
                if pos in positions:
                    # FanDuel format: ID:Name
                    player_id = str(player.get('ID', ''))
                    player_name = str(player.get('Name', ''))
                    positions[pos].append(f"{player_id}:{player_name}")
            
            formatted_lineup = {
                "lineup_num": i + 1,
                "PG": positions['PG'][0] if len(positions['PG']) > 0 else '',
                "PG_2": positions['PG'][1] if len(positions['PG']) > 1 else '',
                "SG": positions['SG'][0] if len(positions['SG']) > 0 else '',
                "SG_2": positions['SG'][1] if len(positions['SG']) > 1 else '',
                "SF": positions['SF'][0] if len(positions['SF']) > 0 else '',
                "SF_2": positions['SF'][1] if len(positions['SF']) > 1 else '',
                "PF": positions['PF'][0] if len(positions['PF']) > 0 else '',
                "PF_2": positions['PF'][1] if len(positions['PF']) > 1 else '',
                "C": positions['C'][0] if len(positions['C']) > 0 else '',
                "total_salary": sum(int(p['Salary']) for p in lineup),
                "projected_points": round(sum(float(p['Projection']) for p in lineup), 2)
            }
        
        else:  # DraftKings
            # DraftKings: PG, SG, SF, PF, C, G, F, UTIL
            used = set()
            formatted_lineup = {"lineup_num": i + 1}
            
            # Fill core positions
            for pos in ['PG', 'SG', 'SF', 'PF', 'C']:
                for player in lineup:
                    if player['Name'] not in used and player['PosBucket'] == pos:
                        formatted_lineup[pos] = player['Name']
                        used.add(player['Name'])
                        break
            
            # Fill flex positions
            remaining = [p for p in lineup if p['Name'] not in used]
            if remaining:
                formatted_lineup['G'] = remaining[0]['Name'] if len(remaining) > 0 else ''
                formatted_lineup['F'] = remaining[1]['Name'] if len(remaining) > 1 else ''
                formatted_lineup['UTIL'] = remaining[2]['Name'] if len(remaining) > 2 else ''
            
            formatted_lineup["total_salary"] = sum(int(p['Salary']) for p in lineup)
            formatted_lineup["projected_points"] = round(sum(float(p['Projection']) for p in lineup), 2)
        
        formatted.append(formatted_lineup)
    
    return formatted

def format_lineups_for_fanduel_csv(lineups: List[List[Dict]], platform: str) -> str:
    """
    Format lineups for FanDuel CSV upload
    
    FanDuel format:
    entry_id, contest_id, contest_name, entry_fee, PG, PG, SG, SG, SF, SF, PF, PF, C
    
    Each player is just their ID (already in format: 125485-203798)
    """
    
    if platform.lower() != "fanduel":
        # For DraftKings or other platforms, use simple format
        rows = []
        for i, lineup in enumerate(lineups):
            row = {"lineup_num": i + 1}
            for j, player in enumerate(lineup):
                row[f"Player_{j+1}"] = player.get('Name', '')
            rows.append(row)
        
        import pandas as pd
        df = pd.DataFrame(rows)
        return df.to_csv(index=False)
    
    # FanDuel specific format
    csv_lines = []
    
    # Header with duplicate column names (FanDuel format)
    csv_lines.append("entry_id,contest_id,contest_name,entry_fee,PG,PG,SG,SG,SF,SF,PF,PF,C")
    
    for lineup in lineups:
        # Sort players by position for FanDuel
        positions = {'PG': [], 'SG': [], 'SF': [], 'PF': [], 'C': []}
        
        for player in lineup:
            pos = player.get('PosBucket', '')
            if pos in positions:
                # Get player ID (already in format: 125485-203798)
                player_id = str(player.get('ID', player.get('Id', '')))
                positions[pos].append(player_id)
        
        # Build row with empty metadata columns (FanDuel fills these in)
        row_parts = [
            '',  # entry_id - FanDuel fills this
            '',  # contest_id - User enters when uploading
            '',  # contest_name - User selects
            '',  # entry_fee - Auto-filled
            positions['PG'][0] if len(positions['PG']) > 0 else '',
            positions['PG'][1] if len(positions['PG']) > 1 else '',
            positions['SG'][0] if len(positions['SG']) > 0 else '',
            positions['SG'][1] if len(positions['SG']) > 1 else '',
            positions['SF'][0] if len(positions['SF']) > 0 else '',
            positions['SF'][1] if len(positions['SF']) > 1 else '',
            positions['PF'][0] if len(positions['PF']) > 0 else '',
            positions['PF'][1] if len(positions['PF']) > 1 else '',
            positions['C'][0] if len(positions['C']) > 0 else ''
        ]
        
        csv_lines.append(','.join(row_parts))
    
    return '\n'.join(csv_lines)