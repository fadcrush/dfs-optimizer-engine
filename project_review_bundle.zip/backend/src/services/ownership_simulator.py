"""
Ownership Simulator - Predicts player ownership percentages for DFS contests
Uses historical data, salary, value, projections, Vegas odds, and injury data
to estimate field ownership with high accuracy

Phase 7: Enforced deterministic seeding for reproducible ownership simulations.
"""

import pandas as pd
import numpy as np
import duckdb
from pathlib import Path
from typing import Dict, List, Optional

# Path to DuckDB database — use centralized resolver
from db.engine import get_canonical_db_path
DUCKDB_PATH = get_canonical_db_path()

# Default random seed for deterministic ownership simulation
DEFAULT_OWNERSHIP_SEED = 1337


class OwnershipSimulator:
    """
    Professional ownership prediction using multiple factors.

    Determinism: All randomness is seeded for reproducible results.
    Same inputs + same seed = identical outputs across runs.
    """

    def __init__(self, random_seed: Optional[int] = None):
        """
        Initialize ownership simulator.

        Args:
            random_seed: Seed for deterministic randomness (default: 1337)
        """
        self.db_connection = None
        self.historical_variance = {}
        # Deterministic seeding: use provided seed or default
        self.random_seed = random_seed if random_seed is not None else DEFAULT_OWNERSHIP_SEED
        
    def connect_database(self):
        """Connect to historical database"""
        if DUCKDB_PATH.exists():
            try:
                self.db_connection = duckdb.connect(str(DUCKDB_PATH), read_only=True)
                print(f"✅ Connected to database for ownership analysis")
                return True
            except Exception as e:
                print(f"⚠️  Could not connect to database: {e}")
                return False
        else:
            print(f"⚠️  Database not found at {DUCKDB_PATH}")
            return False
    
    def get_player_consistency(self, player_name: str) -> float:
        """
        Get player consistency score from historical data
        More consistent players = higher ownership
        """
        if not self.db_connection:
            return 1.0
        
        try:
            query = """
            SELECT 
                STDDEV(actual_fpts) / AVG(actual_fpts) as coef_variation,
                COUNT(*) as games
            FROM contest_results
            WHERE player_name = ?
              AND contest_date >= CURRENT_DATE - INTERVAL '60 days'
            GROUP BY player_name
            HAVING COUNT(*) >= 5
            """
            
            result = self.db_connection.execute(query, [player_name]).fetchone()
            
            if result:
                cv = result[0] if result[0] else 0.5
                # Lower coefficient of variation = more consistent = higher ownership
                consistency_bonus = max(0.8, min(1.2, 1.5 - cv))
                return consistency_bonus
        
        except Exception as e:
            pass
        
        return 1.0  # Neutral if no data
    
    def calculate_salary_factor(self, salary: int) -> float:
        """
        Calculate ownership factor based on salary
        Cheaper players = higher ownership in GPPs
        """
        # Sweet spots: $4K-$5K (value plays) and $9K-$11K (studs)
        if 4000 <= salary <= 5500:
            return 1.4  # Value play range - high ownership
        elif 5500 < salary <= 7000:
            return 0.9  # Mid-tier - lower ownership
        elif 7000 < salary <= 8500:
            return 0.85  # Awkward pricing - low ownership
        elif 8500 < salary <= 11500:
            return 1.2  # Stud range - higher ownership
        else:
            return 0.8  # Super expensive - low ownership
    
    def calculate_value_factor(self, projection: float, salary: int) -> float:
        """
        Calculate ownership factor based on value (proj/salary)
        High value = high ownership
        """
        if salary == 0:
            return 1.0
        
        value = projection / (salary / 1000)
        
        # Value thresholds
        if value >= 6.0:
            return 1.5  # Exceptional value - very high ownership
        elif value >= 5.5:
            return 1.3  # Great value - high ownership
        elif value >= 5.0:
            return 1.15  # Good value - above average
        elif value >= 4.5:
            return 1.0  # Fair value - average
        else:
            return 0.85  # Poor value - low ownership
    
    def calculate_projection_factor(self, projection: float, position: str, all_projections: pd.DataFrame) -> float:
        """
        Calculate ownership based on projection relative to position
        Top projected players = higher ownership
        """
        # Get projections for same position
        pos_projections = all_projections[all_projections['position'].str.contains(position.split('/')[0], na=False)]
        
        if len(pos_projections) == 0:
            return 1.0
        
        # Calculate percentile
        percentile = (pos_projections['projection'] < projection).sum() / len(pos_projections)
        
        # Top 10% = high ownership
        if percentile >= 0.9:
            return 1.4
        elif percentile >= 0.75:
            return 1.2
        elif percentile >= 0.5:
            return 1.0
        else:
            return 0.9
    
    def calculate_position_scarcity(self, position: str, all_projections: pd.DataFrame) -> float:
        """
        If position has few good options, ownership concentrates
        """
        # Get viable players at position (projection > 20)
        pos_projections = all_projections[
            all_projections['position'].str.contains(position.split('/')[0], na=False) &
            (all_projections['projection'] > 20)
        ]
        
        viable_count = len(pos_projections)
        
        # Fewer options = higher ownership on good ones
        if viable_count <= 3:
            return 1.3  # Very scarce
        elif viable_count <= 5:
            return 1.15  # Somewhat scarce
        elif viable_count <= 8:
            return 1.0  # Normal
        else:
            return 0.95  # Plenty of options
    
    def calculate_vegas_factor(self, team: str, team_totals: Dict) -> float:
        """
        Players in high-scoring games = higher ownership
        Public LOVES game environment plays!
        
        Args:
            team: Team abbreviation
            team_totals: Pre-loaded dict of team totals (passed in)
        """
        
        team_total = team_totals.get(team)
        
        if not team_total:
            return 1.0  # No adjustment if no data
        
        # High-scoring games (115+) = higher ownership
        if team_total >= 120:
            return 1.5  # +50% ownership
        elif team_total >= 117:
            return 1.3  # +30% ownership
        elif team_total >= 115:
            return 1.15  # +15% ownership
        elif team_total >= 110:
            return 1.0  # Neutral
        elif team_total >= 105:
            return 0.90  # -10% ownership
        else:
            return 0.80  # -20% ownership
    
    def calculate_injury_boost(self, player_name: str, position: str, team: str, salary: int, projections_df: pd.DataFrame) -> float:
        """
        If a star is OUT, their backup gets MASSIVE ownership boost
        
        Example: If Jokic ($12K) is OUT, his backup goes from 5% → 40%+ ownership
        This is the PUBLIC'S #1 ownership driver!
        """
        
        # Check if any teammates are OUT
        if 'injury_status' not in projections_df.columns:
            return 1.0
        
        # Find OUT players on same team
        out_teammates = projections_df[
            (projections_df['team'] == team) & 
            (projections_df['injury_status'] == 'O')
        ]
        
        if len(out_teammates) == 0:
            return 1.0  # No injured teammates
        
        # Check if any OUT player is a star (expensive + same position group)
        for _, teammate in out_teammates.iterrows():
            teammate_salary = teammate.get('salary', 0)
            teammate_pos = str(teammate.get('position', ''))
            
            # Star = $9K+ 
            if teammate_salary >= 9000:
                # Check if positions overlap (e.g., both are big men, both are guards)
                player_pos = str(position)
                
                # Position groups
                guards = ['PG', 'SG', 'G']
                forwards = ['SF', 'PF', 'F']
                centers = ['C']
                
                # Is this player the backup?
                same_position_group = False
                
                # Check if both are guards
                if any(g in player_pos for g in guards) and any(g in teammate_pos for g in guards):
                    same_position_group = True
                
                # Check if both are forwards
                if any(f in player_pos for f in forwards) and any(f in teammate_pos for f in forwards):
                    same_position_group = True
                
                # Check if both are centers
                if 'C' in player_pos and 'C' in teammate_pos:
                    same_position_group = True
                
                if same_position_group:
                    # This player benefits from the injury!
                    # Salary determines boost amount
                    if salary < 5000:
                        return 2.5  # +150% ownership (min salary replacements are CHALK!)
                    elif salary < 6500:
                        return 2.0  # +100% ownership (value replacements)
                    elif salary < 8000:
                        return 1.6  # +60% ownership (mid-tier replacements)
                    else:
                        return 1.3  # +30% ownership (already expensive)
        
        return 1.0  # No boost
    
    def calculate_primetime_factor(self, team: str) -> float:
        """
        Players in primetime/nationally televised games = higher ownership
        Public gravitates toward marquee teams they watch
        """
        
        # Popular teams that get national TV attention
        primetime_teams = ['LAL', 'GSW', 'BOS', 'NY', 'MIA', 'DAL', 'PHI', 'CHI']
        
        if team in primetime_teams:
            return 1.15  # +15% ownership for popular teams
        
        return 1.0
    
    def simulate_ownership(self, projections_df: pd.DataFrame, num_simulations: int = 10000) -> pd.DataFrame:
        """
        Simulate ownership for all players in slate.

        DETERMINISTIC: Seeds RNG before any random operations.
        Same inputs + same seed = identical outputs.

        Args:
            projections_df: DataFrame with columns: id, name, position, salary, projection, team, injury_status
            num_simulations: Number of lineups to simulate (default 10000)

        Returns:
            DataFrame with added 'predicted_ownership' and 'leverage' columns
        """
        # =====================================================================
        # DETERMINISTIC SEEDING: Must occur BEFORE any np.random calls
        # This ensures reproducible ownership predictions across runs.
        # =====================================================================
        np.random.seed(self.random_seed)

        # Normalize column names to lowercase
        projections_df = projections_df.copy()
        projections_df.columns = [c.lower() for c in projections_df.columns]

        print(f"\n🎲 OWNERSHIP SIMULATOR v2.0 (DETERMINISTIC)")
        print(f"   Simulating {num_simulations:,} lineups (seed={self.random_seed})...")
        print(f"   Analyzing {len(projections_df)} players")

        # Connect to database
        self.connect_database()

        # Load Vegas odds ONCE (not per player!)
        print(f"   Loading Vegas odds...")
        from services.vegas_service import VegasOddsService
        vegas_service = VegasOddsService()
        vegas_games = vegas_service.get_nba_odds()

        # Create team total lookup (ONE TIME!)
        team_totals = {}
        for game in vegas_games:
            team_totals[game['home_team']] = game.get('home_implied_points')
            team_totals[game['away_team']] = game.get('away_implied_points')

        print(f"   ✅ Vegas odds cached for {len(team_totals)} teams")
        
        # Calculate base ownership for each player
        ownership_data = []
        
        for _, player in projections_df.iterrows():
            name = player.get('name', '')
            salary = int(player.get('salary', 0))
            projection = float(player.get('projection', 0))
            position = player.get('position', 'UTIL')
            team = player.get('team', '')
            injury_status = player.get('injury_status', '')
            
            # Skip injured players
            if injury_status in ['OUT', 'O', 'NA', 'SUSP']:
                ownership_data.append({
                    'name': name,
                    'predicted_ownership': 0.0,
                    'ownership_factors': 'Injured/Out',
                    'leverage': 0.0
                })
                continue
            
            # Calculate all factors
            salary_factor = self.calculate_salary_factor(salary)
            value_factor = self.calculate_value_factor(projection, salary)
            proj_factor = self.calculate_projection_factor(projection, position, projections_df)
            scarcity_factor = self.calculate_position_scarcity(position, projections_df)
            consistency_factor = self.get_player_consistency(name)
            
            # NEW FACTORS!
            # NEW FACTORS!
            vegas_factor = self.calculate_vegas_factor(team, team_totals)
            injury_boost = self.calculate_injury_boost(name, position, team, salary, projections_df)
            primetime_factor = self.calculate_primetime_factor(team)
            
            # Base ownership formula
            base_ownership = 0.15  # Start at 15% baseline
            
            # Apply ALL multipliers
            adjusted_ownership = (
                base_ownership * 
                salary_factor * 
                value_factor * 
                proj_factor * 
                scarcity_factor * 
                consistency_factor * 
                vegas_factor *
                injury_boost *
                primetime_factor
            )
            
            # Add some randomness (±5%)
            randomness = np.random.normal(1.0, 0.05)
            final_ownership = adjusted_ownership * randomness
            
            # Cap at reasonable bounds (0.5% to 90%)
            final_ownership = max(0.005, min(0.90, final_ownership))
            
            # Track factors for analysis
            factors = (
                f"Sal:{salary_factor:.2f} "
                f"Val:{value_factor:.2f} "
                f"Proj:{proj_factor:.2f} "
                f"Scar:{scarcity_factor:.2f} "
                f"Cons:{consistency_factor:.2f} "
                f"Vegas:{vegas_factor:.2f} "
                f"Inj:{injury_boost:.2f} "
                f"Prime:{primetime_factor:.2f}"
            )
            
            # Calculate leverage (projection / ownership ratio)
            leverage = projection / (final_ownership + 0.01)
            
            ownership_data.append({
                'name': name,
                'predicted_ownership': round(final_ownership, 4),
                'ownership_factors': factors,
                'leverage': round(leverage, 2)
            })
        
        # Create ownership DataFrame
        ownership_df = pd.DataFrame(ownership_data)
        
        # Merge with original projections
        result_df = projections_df.copy()
        result_df['predicted_ownership'] = result_df['name'].map(
            dict(zip(ownership_df['name'], ownership_df['predicted_ownership']))
        ).fillna(0.15)
        
        result_df['leverage'] = result_df['name'].map(
            dict(zip(ownership_df['name'], ownership_df['leverage']))
        ).fillna(0.0)
        
        print(f"\n✅ Ownership simulation complete!")
        print(f"\n   OWNERSHIP DISTRIBUTION:")
        print(f"      Chalk (>40%):      {len(result_df[result_df['predicted_ownership'] > 0.40])} players")
        print(f"      High owned (30-40%): {len(result_df[(result_df['predicted_ownership'] >= 0.30) & (result_df['predicted_ownership'] <= 0.40)])} players")
        print(f"      Medium (15-30%):   {len(result_df[(result_df['predicted_ownership'] >= 0.15) & (result_df['predicted_ownership'] < 0.30)])} players")
        print(f"      Low owned (<15%):  {len(result_df[result_df['predicted_ownership'] < 0.15])} players")
        print(f"      Contrarian (<5%):  {len(result_df[result_df['predicted_ownership'] < 0.05])} players")
        
        # Show top leverage plays
        top_leverage = result_df[result_df['projection'] > 0].nlargest(10, 'leverage')[['name', 'projection', 'predicted_ownership', 'leverage', 'team']]
        print(f"\n   TOP 10 LEVERAGE PLAYS:")
        for _, p in top_leverage.iterrows():
            print(f"      {p['name']:<25} {p['team']:<4} Proj:{p['projection']:>5.1f} Own:{p['predicted_ownership']*100:>4.1f}% Lev:{p['leverage']:>5.1f}")
        
        # Show highest owned (potential chalk)
        top_owned = result_df[result_df['predicted_ownership'] > 0].nlargest(10, 'predicted_ownership')[['name', 'salary', 'projection', 'predicted_ownership', 'team']]
        print(f"\n   POTENTIAL CHALK (Avoid in GPPs):")
        for _, p in top_owned.iterrows():
            print(f"      {p['name']:<25} ${p['salary']:<5} Proj:{p['projection']:>5.1f} Own:{p['predicted_ownership']*100:>4.1f}%")
        
        # Close database
        if self.db_connection:
            self.db_connection.close()
        
        return result_df


def simulate_ownership(projections_file_path: str) -> Dict:
    """
    Main function: Simulate ownership from projections CSV
    
    Args:
        projections_file_path: Path to projections CSV file
    
    Returns:
        Dict with ownership predictions and stats
    """
    
    print(f"\n📊 Loading projections from: {projections_file_path}")
    
    # Load projections
    proj_df = pd.read_csv(projections_file_path)
    
    # Normalize column names to lowercase
    proj_df.columns = [c.lower() for c in proj_df.columns]
    
    print(f"✅ Loaded {len(proj_df)} player projections")
    print(f"📋 Columns: {list(proj_df.columns)}")
    
    # Ensure required columns exist
    required_cols = ['name', 'position', 'salary', 'projection']
    missing_cols = [col for col in required_cols if col not in proj_df.columns]
    
    if missing_cols:
        print(f"❌ ERROR: Missing required columns: {missing_cols}")
        return {
            "success": False,
            "error": f"Missing required columns: {missing_cols}",
            "ownership_predictions": []
        }
    
    # Add team column if missing
    if 'team' not in proj_df.columns:
        proj_df['team'] = ''
    
    # Add injury_status column if missing
    if 'injury_status' not in proj_df.columns:
        proj_df['injury_status'] = ''
    
    # Ensure numeric types
    proj_df['salary'] = pd.to_numeric(proj_df['salary'], errors='coerce').fillna(0).astype(int)
    proj_df['projection'] = pd.to_numeric(proj_df['projection'], errors='coerce').fillna(0.0)
    
    # Create simulator
    simulator = OwnershipSimulator()
    
    # Run simulation
    try:
        result_df = simulator.simulate_ownership(proj_df, num_simulations=10000)
    except Exception as e:
        print(f"❌ Simulation failed: {e}")
        import traceback
        traceback.print_exc()
        return {
            "success": False,
            "error": str(e),
            "ownership_predictions": []
        }
    
    # Convert to dict format
    ownership_predictions = result_df.to_dict('records')
    
    # Calculate stats
    avg_ownership = result_df['predicted_ownership'].mean()
    high_owned = len(result_df[result_df['predicted_ownership'] > 0.30])
    low_owned = len(result_df[result_df['predicted_ownership'] < 0.15])
    
    # Get top leverage plays
    top_leverage = result_df[result_df['projection'] > 0].nlargest(10, 'leverage')[['name', 'projection', 'predicted_ownership', 'leverage']].copy()
    top_leverage['predicted_ownership'] = (top_leverage['predicted_ownership'] * 100).round(2)
    top_leverage['leverage'] = top_leverage['leverage'].round(2)
    top_leverage_list = top_leverage.to_dict('records')
    
    return {
        "success": True,
        "ownership_predictions": ownership_predictions,
        "stats": {
            "total_players": len(result_df),
            "avg_ownership": round(avg_ownership * 100, 2),
            "high_owned_count": high_owned,
            "low_owned_count": low_owned,
            "top_leverage_plays": top_leverage_list
        }
    }