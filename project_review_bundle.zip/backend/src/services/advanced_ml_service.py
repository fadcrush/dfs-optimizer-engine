"""
Advanced ML Service - XGBoost, Neural Networks, and Ensemble Methods
Provides professional-grade ML projections with multiple algorithms
"""

import pandas as pd
import numpy as np
import logging
from typing import Dict, List, Optional, Tuple
from pathlib import Path
import joblib
import xgboost as xgb
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler
import tensorflow as tf
from tensorflow import keras
import json
from datetime import datetime

logger = logging.getLogger(__name__)

class AdvancedMLService:
    """Advanced ML service with multiple algorithms and ensemble methods"""

    def __init__(self, sport: str = "NFL"):
        self.sport = sport
        self.models_dir = Path("models/saved_models")
        self.models_dir.mkdir(parents=True, exist_ok=True)
        self.scaler = StandardScaler()

        # Model configurations
        self.model_configs = {
            'xgboost': {
                'n_estimators': 1000,
                'max_depth': 6,
                'learning_rate': 0.1,
                'subsample': 0.8,
                'colsample_bytree': 0.8,
                'objective': 'reg:squarederror'
            },
            'random_forest': {
                'n_estimators': 500,
                'max_depth': 10,
                'min_samples_split': 5,
                'min_samples_leaf': 2,
                'random_state': 42
            },
            'gradient_boosting': {
                'n_estimators': 300,
                'max_depth': 5,
                'learning_rate': 0.1,
                'subsample': 0.8,
                'random_state': 42
            },
            'neural_network': {
                'hidden_layer_sizes': (100, 50, 25),
                'activation': 'relu',
                'solver': 'adam',
                'alpha': 0.001,
                'learning_rate': 'adaptive',
                'max_iter': 1000,
                'random_state': 42
            }
        }

    def train_ensemble_model(self, X: pd.DataFrame, y: pd.Series,
                           test_size: float = 0.2) -> Dict:
        """
        Train an ensemble of ML models and return the best performing one

        Args:
            X: Feature matrix
            y: Target variable (fantasy points)
            test_size: Test set size for validation

        Returns:
            Dict with trained models and performance metrics
        """
        logger.info(f"Training ensemble models for {self.sport}...")

        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=42
        )

        # Scale features for neural network
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)

        models = {}
        predictions = {}
        metrics = {}

        # Train XGBoost
        try:
            xgb_model = xgb.XGBRegressor(**self.model_configs['xgboost'])
            xgb_model.fit(X_train, y_train)
            xgb_pred = xgb_model.predict(X_test)

            models['xgboost'] = xgb_model
            predictions['xgboost'] = xgb_pred
            metrics['xgboost'] = self._calculate_metrics(y_test, xgb_pred)

            logger.info(f"XGBoost trained - MAE: {metrics['xgboost']['mae']:.3f}")

        except Exception as e:
            logger.error(f"XGBoost training failed: {e}")

        # Train Random Forest
        try:
            rf_model = RandomForestRegressor(**self.model_configs['random_forest'])
            rf_model.fit(X_train, y_train)
            rf_pred = rf_model.predict(X_test)

            models['random_forest'] = rf_model
            predictions['random_forest'] = rf_pred
            metrics['random_forest'] = self._calculate_metrics(y_test, rf_pred)

            logger.info(f"Random Forest trained - MAE: {metrics['random_forest']['mae']:.3f}")

        except Exception as e:
            logger.error(f"Random Forest training failed: {e}")

        # Train Gradient Boosting
        try:
            gb_model = GradientBoostingRegressor(**self.model_configs['gradient_boosting'])
            gb_model.fit(X_train, y_train)
            gb_pred = gb_model.predict(X_test)

            models['gradient_boosting'] = gb_model
            predictions['gradient_boosting'] = gb_pred
            metrics['gradient_boosting'] = self._calculate_metrics(y_test, gb_pred)

            logger.info(f"Gradient Boosting trained - MAE: {metrics['gradient_boosting']['mae']:.3f}")

        except Exception as e:
            logger.error(f"Gradient Boosting training failed: {e}")

        # Train Neural Network
        try:
            nn_model = MLPRegressor(**self.model_configs['neural_network'])
            nn_model.fit(X_train_scaled, y_train)
            nn_pred = nn_model.predict(X_test_scaled)

            models['neural_network'] = nn_model
            predictions['neural_network'] = nn_pred
            metrics['neural_network'] = self._calculate_metrics(y_test, nn_pred)

            logger.info(f"Neural Network trained - MAE: {metrics['neural_network']['mae']:.3f}")

        except Exception as e:
            logger.error(f"Neural Network training failed: {e}")

        # Create ensemble prediction (weighted average based on performance)
        ensemble_pred = self._create_ensemble_prediction(predictions, metrics, y_test)

        if ensemble_pred is not None:
            models['ensemble'] = None  # Ensemble is computed, not stored as single model
            predictions['ensemble'] = ensemble_pred
            metrics['ensemble'] = self._calculate_metrics(y_test, ensemble_pred)
            logger.info(f"Ensemble created - MAE: {metrics['ensemble']['mae']:.3f}")

        # Save best model
        best_model_name = min(metrics.keys(), key=lambda k: metrics[k]['mae'])
        self._save_model(models[best_model_name], best_model_name)

        return {
            'models': models,
            'predictions': predictions,
            'metrics': metrics,
            'best_model': best_model_name,
            'feature_importance': self._get_feature_importance(models, X_train.columns.tolist())
        }

    def _calculate_metrics(self, y_true: pd.Series, y_pred: np.ndarray) -> Dict:
        """Calculate comprehensive performance metrics"""
        return {
            'mae': mean_absolute_error(y_true, y_pred),
            'mse': mean_squared_error(y_true, y_pred),
            'rmse': np.sqrt(mean_squared_error(y_true, y_pred)),
            'r2': r2_score(y_true, y_pred),
            'mape': np.mean(np.abs((y_true - y_pred) / y_true)) * 100
        }

    def _create_ensemble_prediction(self, predictions: Dict, metrics: Dict,
                                  y_test: pd.Series) -> Optional[np.ndarray]:
        """Create weighted ensemble prediction based on model performance"""
        if len(predictions) < 2:
            return None

        # Calculate weights based on inverse of MAE (better models get higher weight)
        maes = {model: metrics[model]['mae'] for model in predictions.keys()}
        total_inverse_mae = sum(1/mae for mae in maes.values())

        weights = {model: (1/maes[model]) / total_inverse_mae for model in maes.keys()}

        # Weighted average prediction
        ensemble_pred = np.zeros(len(y_test))
        for model, pred in predictions.items():
            ensemble_pred += weights[model] * pred

        return ensemble_pred

    def _get_feature_importance(self, models: Dict, feature_names: List[str]) -> Dict:
        """Extract feature importance from tree-based models"""
        importance = {}

        for model_name, model in models.items():
            if model is None:
                continue

            try:
                if hasattr(model, 'feature_importances_'):
                    # Tree-based models
                    importances = model.feature_importances_
                    importance[model_name] = {
                        feature_names[i]: float(importances[i])
                        for i in range(len(feature_names))
                    }
                elif hasattr(model, 'coefs_'):
                    # Neural network
                    # Use absolute sum of weights for each feature
                    weights = np.abs(model.coefs_[0]).sum(axis=1)
                    importance[model_name] = {
                        feature_names[i]: float(weights[i])
                        for i in range(len(feature_names))
                    }
                else:
                    importance[model_name] = {}

            except Exception as e:
                logger.error(f"Could not extract feature importance for {model_name}: {e}")
                importance[model_name] = {}

        return importance

    def _save_model(self, model, model_name: str):
        """Save trained model to disk"""
        try:
            model_path = self.models_dir / f"{self.sport}_{model_name}_{datetime.now().strftime('%Y%m%d')}.joblib"
            joblib.dump(model, model_path)

            # Save scaler if neural network
            if model_name == 'neural_network':
                scaler_path = self.models_dir / f"{self.sport}_scaler_{datetime.now().strftime('%Y%m%d')}.joblib"
                joblib.dump(self.scaler, scaler_path)

            logger.info(f"Model saved: {model_path}")

        except Exception as e:
            logger.error(f"Failed to save model {model_name}: {e}")

    def load_model(self, model_name: str):
        """Load a trained model from disk"""
        try:
            # Find latest model file
            model_files = list(self.models_dir.glob(f"{self.sport}_{model_name}_*.joblib"))
            if not model_files:
                return None

            latest_model = max(model_files, key=lambda x: x.stat().st_mtime)
            model = joblib.load(latest_model)

            # Load scaler for neural network
            if model_name == 'neural_network':
                scaler_files = list(self.models_dir.glob(f"{self.sport}_scaler_*.joblib"))
                if scaler_files:
                    latest_scaler = max(scaler_files, key=lambda x: x.stat().st_mtime)
                    self.scaler = joblib.load(latest_scaler)

            logger.info(f"Loaded model: {latest_model}")
            return model

        except Exception as e:
            logger.error(f"Failed to load model {model_name}: {e}")
            return None

    def predict_with_model(self, X: pd.DataFrame, model_name: str = 'ensemble') -> np.ndarray:
        """
        Make predictions using a specific model or ensemble

        Args:
            X: Feature matrix
            model_name: Model to use ('xgboost', 'random_forest', 'ensemble', etc.)

        Returns:
            Array of predictions
        """
        if model_name == 'ensemble':
            return self._predict_ensemble(X)
        else:
            model = self.load_model(model_name)
            if model is None:
                raise ValueError(f"Model {model_name} not found")

            if model_name == 'neural_network':
                X_scaled = self.scaler.transform(X)
                return model.predict(X_scaled)
            else:
                return model.predict(X)

    def _predict_ensemble(self, X: pd.DataFrame) -> np.ndarray:
        """Make ensemble predictions using all available models"""
        predictions = []
        weights = []

        # Load all available models
        for model_name in ['xgboost', 'random_forest', 'gradient_boosting', 'neural_network']:
            model = self.load_model(model_name)
            if model is not None:
                try:
                    if model_name == 'neural_network':
                        X_scaled = self.scaler.transform(X)
                        pred = model.predict(X_scaled)
                    else:
                        pred = model.predict(X)

                    predictions.append(pred)

                    # Simple equal weighting for now (could be improved with validation performance)
                    weights.append(1.0)

                except Exception as e:
                    logger.warning(f"Failed to predict with {model_name}: {e}")

        if not predictions:
            raise ValueError("No models available for ensemble prediction")

        # Normalize weights
        total_weight = sum(weights)
        weights = [w / total_weight for w in weights]

        # Weighted average
        ensemble_pred = np.zeros(len(X))
        for pred, weight in zip(predictions, weights):
            ensemble_pred += weight * pred

        return ensemble_pred

    def validate_model_performance(self, X: pd.DataFrame, y: pd.Series,
                                 model_name: str = 'ensemble', cv_folds: int = 5) -> Dict:
        """Validate model performance using cross-validation"""
        try:
            model = self.load_model(model_name)
            if model is None:
                return {'error': f'Model {model_name} not found'}

            # Cross-validation scores
            scores = cross_val_score(model, X, y, cv=cv_folds,
                                   scoring=['neg_mean_absolute_error', 'r2'])

            return {
                'cv_mae': -scores[0].mean(),
                'cv_mae_std': scores[0].std(),
                'cv_r2': scores[1].mean(),
                'cv_r2_std': scores[1].std(),
                'cv_folds': cv_folds
            }

        except Exception as e:
            logger.error(f"Model validation failed: {e}")
            return {'error': str(e)}

    def get_model_comparison_report(self, X: pd.DataFrame, y: pd.Series) -> Dict:
        """Generate comprehensive model comparison report"""
        report = {
            'timestamp': datetime.now().isoformat(),
            'sport': self.sport,
            'dataset_size': len(X),
            'features': X.columns.tolist(),
            'models': {}
        }

        # Test each model
        for model_name in ['xgboost', 'random_forest', 'gradient_boosting', 'neural_network']:
            try:
                model = self.load_model(model_name)
                if model is None:
                    continue

                # Quick validation
                X_sample = X.head(min(1000, len(X)))
                y_sample = y.head(min(1000, len(y)))

                if model_name == 'neural_network':
                    X_scaled = self.scaler.transform(X_sample)
                    pred = model.predict(X_scaled)
                else:
                    pred = model.predict(X_sample)

                metrics = self._calculate_metrics(y_sample, pred)

                report['models'][model_name] = {
                    'available': True,
                    'metrics': metrics,
                    'sample_size': len(X_sample)
                }

            except Exception as e:
                report['models'][model_name] = {
                    'available': False,
                    'error': str(e)
                }

        # Ensemble performance
        try:
            ensemble_pred = self._predict_ensemble(X.head(min(1000, len(X))))
            ensemble_metrics = self._calculate_metrics(y.head(min(1000, len(y))), ensemble_pred)

            report['models']['ensemble'] = {
                'available': True,
                'metrics': ensemble_metrics,
                'sample_size': min(1000, len(X))
            }

        except Exception as e:
            report['models']['ensemble'] = {
                'available': False,
                'error': str(e)
            }

        return report

# Convenience functions
def train_ml_models(sport: str, features_df: pd.DataFrame, target_series: pd.Series) -> Dict:
    """Train ML models for a sport"""
    service = AdvancedMLService(sport)
    return service.train_ensemble_model(features_df, target_series)

def predict_with_best_model(sport: str, features_df: pd.DataFrame) -> np.ndarray:
    """Make predictions using the best available model"""
    service = AdvancedMLService(sport)
    return service.predict_with_model(features_df, 'ensemble')

def get_model_performance_report(sport: str, features_df: pd.DataFrame, target_series: pd.Series) -> Dict:
    """Get comprehensive model performance report"""
    service = AdvancedMLService(sport)
    return service.get_model_comparison_report(features_df, target_series)

if __name__ == "__main__":
    # Test the advanced ML service
    service = AdvancedMLService("NFL")

    # Create sample data for testing
    np.random.seed(42)
    n_samples = 1000
    n_features = 20

    X = pd.DataFrame(
        np.random.randn(n_samples, n_features),
        columns=[f'feature_{i}' for i in range(n_features)]
    )
    y = X.sum(axis=1) + np.random.randn(n_samples) * 0.1  # Simple linear relationship with noise

    print("Testing Advanced ML Service...")

    # Train models
    results = service.train_ensemble_model(X, y)

    print(f"Best model: {results['best_model']}")
    print(f"Models trained: {list(results['models'].keys())}")

    for model_name, metrics in results['metrics'].items():
        print(f"{model_name.upper()}: MAE={metrics['mae']:.3f}, R²={metrics['r2']:.3f}")

    # Test predictions
    test_pred = service.predict_with_model(X.head(10))
    print(f"Sample predictions: {test_pred[:5]}")

    print("Advanced ML Service test completed!")
