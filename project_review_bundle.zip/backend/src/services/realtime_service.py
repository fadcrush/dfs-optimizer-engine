"""
Real-Time Data Service

Handles real-time updates for:
- Injury status changes
- Vegas line movements
- Starting lineup confirmations
- Weather updates (NFL)
- Late scratches

Integrates with caching layer for efficient data management.
"""

import asyncio
import logging
from typing import Dict, List, Optional, Callable, Any
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
import httpx
import os
from pathlib import Path

from .caching_service import get_dfs_cache, DFSCacheService

logger = logging.getLogger(__name__)


class UpdateType(Enum):
    """Types of real-time updates"""
    INJURY = "injury"
    VEGAS = "vegas"
    LINEUP = "lineup"
    WEATHER = "weather"
    SCRATCH = "scratch"
    NEWS = "news"


@dataclass
class RealTimeUpdate:
    """Single real-time update"""
    update_type: UpdateType
    timestamp: datetime
    sport: str
    data: Dict
    source: str
    confidence: float = 1.0
    processed: bool = False

    def to_dict(self) -> Dict:
        return {
            'type': self.update_type.value,
            'timestamp': self.timestamp.isoformat(),
            'sport': self.sport,
            'data': self.data,
            'source': self.source,
            'confidence': self.confidence
        }


@dataclass
class InjuryUpdate:
    """Injury status update"""
    player_name: str
    team: str
    status: str  # OUT, DOUBTFUL, QUESTIONABLE, PROBABLE, AVAILABLE
    injury_type: str
    updated_at: datetime
    source: str

    @property
    def is_out(self) -> bool:
        return self.status.upper() in ['OUT', 'O']

    @property
    def is_questionable(self) -> bool:
        return self.status.upper() in ['QUESTIONABLE', 'Q', 'GTD', 'DOUBTFUL', 'D']


@dataclass
class VegasUpdate:
    """Vegas line update"""
    game_id: str
    home_team: str
    away_team: str
    spread: float
    total: float
    home_ml: int
    away_ml: int
    updated_at: datetime
    source: str

    @property
    def implied_home_win_prob(self) -> float:
        """Calculate implied probability from moneyline"""
        if self.home_ml < 0:
            return abs(self.home_ml) / (abs(self.home_ml) + 100)
        else:
            return 100 / (self.home_ml + 100)


class RealTimeService:
    """
    Service for fetching and managing real-time DFS data
    """

    def __init__(self):
        self.cache = get_dfs_cache()
        self.subscribers: Dict[UpdateType, List[Callable]] = {
            ut: [] for ut in UpdateType
        }
        self.update_history: List[RealTimeUpdate] = []
        self._running = False

        # API configuration (support multiple env var names)
        self.odds_api_key = os.getenv('THEODDS_API_KEY') or os.getenv('ODDS_API_KEY', '')
        self.sportsdata_key = os.getenv('SPORTSDATA_API_KEY', '')

    # =====================
    # Vegas Lines
    # =====================

    async def fetch_vegas_lines(self, sport: str = 'nba') -> List[VegasUpdate]:
        """Fetch current Vegas lines from API"""

        # Check cache first
        cached, hit = self.cache.get_vegas_lines(sport)
        if hit and cached:
            logger.debug(f"Vegas lines cache hit for {sport}")
            return self._parse_vegas_response(cached, sport)

        # Fetch from API
        if not self.odds_api_key:
            logger.warning("ODDS_API_KEY not configured")
            return []

        sport_key = 'basketball_nba' if sport == 'nba' else 'americanfootball_nfl'
        url = f"https://api.the-odds-api.com/v4/sports/{sport_key}/odds"

        params = {
            'apiKey': self.odds_api_key,
            'regions': 'us',
            'markets': 'spreads,totals,h2h',
            'oddsFormat': 'american'
        }

        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(url, params=params, timeout=30)
                response.raise_for_status()
                data = response.json()

            # Cache the response
            self.cache.set_vegas_lines(data, sport)

            return self._parse_vegas_response(data, sport)

        except Exception as e:
            logger.error(f"Failed to fetch Vegas lines: {e}")
            return []

    def _parse_vegas_response(self, data: List[Dict], sport: str) -> List[VegasUpdate]:
        """Parse Vegas API response into VegasUpdate objects"""
        updates = []

        for game in data:
            try:
                home_team = game.get('home_team', '')
                away_team = game.get('away_team', '')

                # Find best odds from bookmakers
                spread = 0.0
                total = 225.0 if sport == 'nba' else 45.0
                home_ml = -110
                away_ml = -110

                for bookmaker in game.get('bookmakers', []):
                    for market in bookmaker.get('markets', []):
                        if market['key'] == 'spreads':
                            for outcome in market['outcomes']:
                                if outcome['name'] == home_team:
                                    spread = outcome.get('point', 0)
                        elif market['key'] == 'totals':
                            for outcome in market['outcomes']:
                                if outcome['name'] == 'Over':
                                    total = outcome.get('point', total)
                        elif market['key'] == 'h2h':
                            for outcome in market['outcomes']:
                                if outcome['name'] == home_team:
                                    home_ml = outcome.get('price', -110)
                                else:
                                    away_ml = outcome.get('price', -110)

                updates.append(VegasUpdate(
                    game_id=game.get('id', f"{home_team}_{away_team}"),
                    home_team=home_team,
                    away_team=away_team,
                    spread=spread,
                    total=total,
                    home_ml=home_ml,
                    away_ml=away_ml,
                    updated_at=datetime.now(),
                    source='the-odds-api'
                ))

            except Exception as e:
                logger.warning(f"Failed to parse game: {e}")
                continue

        return updates

    # =====================
    # Injuries
    # =====================

    async def fetch_injuries(self, sport: str = 'nba') -> List[InjuryUpdate]:
        """Fetch current injury report"""

        # Check cache first
        cached, hit = self.cache.get_injuries(sport)
        if hit and cached:
            logger.debug(f"Injuries cache hit for {sport}")
            return self._parse_injury_response(cached)

        # Fetch from SportsData.io
        if not self.sportsdata_key:
            logger.warning("SPORTSDATA_API_KEY not configured")
            return []

        base_url = f"https://api.sportsdata.io/v3/{sport}/scores/json/InjuredPlayers"

        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    base_url,
                    params={'key': self.sportsdata_key},
                    timeout=30
                )
                response.raise_for_status()
                data = response.json()

            # Cache the response
            self.cache.set_injuries(data, sport)

            return self._parse_injury_response(data)

        except Exception as e:
            logger.error(f"Failed to fetch injuries: {e}")
            return []

    def _parse_injury_response(self, data: List[Dict]) -> List[InjuryUpdate]:
        """Parse injury API response"""
        updates = []

        for injury in data:
            try:
                updates.append(InjuryUpdate(
                    player_name=injury.get('Name', ''),
                    team=injury.get('Team', ''),
                    status=injury.get('Status', 'Unknown'),
                    injury_type=injury.get('InjuryNotes', injury.get('Injury', '')),
                    updated_at=datetime.now(),
                    source='sportsdata.io'
                ))
            except Exception as e:
                logger.warning(f"Failed to parse injury: {e}")
                continue

        return updates

    # =====================
    # Subscriptions
    # =====================

    def subscribe(self, update_type: UpdateType, callback: Callable[[RealTimeUpdate], None]):
        """Subscribe to a specific update type"""
        self.subscribers[update_type].append(callback)
        logger.info(f"Added subscriber for {update_type.value}")

    def unsubscribe(self, update_type: UpdateType, callback: Callable):
        """Unsubscribe from updates"""
        if callback in self.subscribers[update_type]:
            self.subscribers[update_type].remove(callback)

    async def _notify_subscribers(self, update: RealTimeUpdate):
        """Notify all subscribers of an update"""
        for callback in self.subscribers[update.update_type]:
            try:
                if asyncio.iscoroutinefunction(callback):
                    await callback(update)
                else:
                    callback(update)
            except Exception as e:
                logger.error(f"Subscriber callback error: {e}")

    # =====================
    # Polling Loop
    # =====================

    async def start_polling(self, sport: str = 'nba', interval_seconds: int = 60):
        """Start polling for real-time updates"""
        self._running = True
        logger.info(f"Starting real-time polling for {sport} (interval: {interval_seconds}s)")

        while self._running:
            try:
                # Fetch updates
                vegas_updates = await self.fetch_vegas_lines(sport)
                injury_updates = await self.fetch_injuries(sport)

                # Process Vegas updates
                for vegas in vegas_updates:
                    update = RealTimeUpdate(
                        update_type=UpdateType.VEGAS,
                        timestamp=vegas.updated_at,
                        sport=sport,
                        data=vegas.__dict__,
                        source=vegas.source
                    )
                    self.update_history.append(update)
                    await self._notify_subscribers(update)

                # Process injury updates
                for injury in injury_updates:
                    update = RealTimeUpdate(
                        update_type=UpdateType.INJURY,
                        timestamp=injury.updated_at,
                        sport=sport,
                        data=injury.__dict__,
                        source=injury.source
                    )
                    self.update_history.append(update)
                    await self._notify_subscribers(update)

                # Trim history to last 1000 updates
                if len(self.update_history) > 1000:
                    self.update_history = self.update_history[-1000:]

            except Exception as e:
                logger.error(f"Polling error: {e}")

            await asyncio.sleep(interval_seconds)

    def stop_polling(self):
        """Stop the polling loop"""
        self._running = False
        logger.info("Stopped real-time polling")

    # =====================
    # Data Access
    # =====================

    def get_current_vegas(self, sport: str = 'nba') -> Dict[str, VegasUpdate]:
        """Get current Vegas lines as a dict keyed by game_id"""
        cached, hit = self.cache.get_vegas_lines(sport)
        if hit and cached:
            updates = self._parse_vegas_response(cached, sport)
            return {u.game_id: u for u in updates}
        return {}

    def get_team_vegas(self, team: str, sport: str = 'nba') -> Optional[VegasUpdate]:
        """Get Vegas line for a specific team's game"""
        vegas_dict = self.get_current_vegas(sport)
        for game_id, vegas in vegas_dict.items():
            if team in [vegas.home_team, vegas.away_team]:
                return vegas
        return None

    def get_current_injuries(self, sport: str = 'nba') -> List[InjuryUpdate]:
        """Get current injury list"""
        cached, hit = self.cache.get_injuries(sport)
        if hit and cached:
            return self._parse_injury_response(cached)
        return []

    def get_team_injuries(self, team: str, sport: str = 'nba') -> List[InjuryUpdate]:
        """Get injuries for a specific team"""
        all_injuries = self.get_current_injuries(sport)
        return [i for i in all_injuries if i.team == team]

    def get_player_injury_status(self, player_name: str, sport: str = 'nba') -> Optional[InjuryUpdate]:
        """Get injury status for a specific player"""
        all_injuries = self.get_current_injuries(sport)
        for injury in all_injuries:
            if injury.player_name.lower() == player_name.lower():
                return injury
        return None

    # =====================
    # Integration Helpers
    # =====================

    def get_projection_context(self, player: Dict, sport: str = 'nba') -> Dict:
        """
        Get all relevant real-time context for a player's projection

        Returns:
            Dict with vegas, injuries, and other context data
        """
        team = player.get('team', player.get('Team', ''))
        player_name = player.get('player_name', player.get('Nickname', ''))

        context = {
            'player_name': player_name,
            'team': team,
            'injury_status': None,
            'vegas': None,
            'team_injuries': [],
            'opponent_injuries': []
        }

        # Get player's own injury status
        injury = self.get_player_injury_status(player_name, sport)
        if injury:
            context['injury_status'] = {
                'status': injury.status,
                'is_out': injury.is_out,
                'is_questionable': injury.is_questionable,
                'injury_type': injury.injury_type
            }

        # Get Vegas data
        vegas = self.get_team_vegas(team, sport)
        if vegas:
            context['vegas'] = {
                'spread': vegas.spread,
                'total': vegas.total,
                'home_team': vegas.home_team,
                'away_team': vegas.away_team,
                'implied_win_prob': vegas.implied_home_win_prob if team == vegas.home_team else 1 - vegas.implied_home_win_prob
            }

            # Get opponent
            opponent = vegas.away_team if team == vegas.home_team else vegas.home_team

            # Get team and opponent injuries
            context['team_injuries'] = [
                {'name': i.player_name, 'status': i.status}
                for i in self.get_team_injuries(team, sport)
                if i.is_out or i.is_questionable
            ]
            context['opponent_injuries'] = [
                {'name': i.player_name, 'status': i.status}
                for i in self.get_team_injuries(opponent, sport)
                if i.is_out or i.is_questionable
            ]

        return context

    def adjust_projection_for_realtime(self,
                                        base_projection: float,
                                        player: Dict,
                                        sport: str = 'nba') -> Dict:
        """
        Adjust a player projection based on real-time data

        Returns:
            Dict with adjusted projection and factors applied
        """
        context = self.get_projection_context(player, sport)
        adjusted = base_projection
        factors = []

        # Check if player is out
        if context['injury_status'] and context['injury_status']['is_out']:
            return {
                'projection': 0.0,
                'base_projection': base_projection,
                'adjustment': -base_projection,
                'factors': ['Player OUT'],
                'context': context
            }

        # Questionable status - apply discount
        if context['injury_status'] and context['injury_status']['is_questionable']:
            adjusted *= 0.85
            factors.append(f"Questionable status (-15%)")

        # Vegas total adjustment
        if context['vegas']:
            total = context['vegas']['total']
            avg_total = 225.0 if sport == 'nba' else 45.0

            if total > avg_total * 1.05:
                boost = 1 + (total - avg_total) / avg_total * 0.1
                adjusted *= boost
                factors.append(f"High total boost (+{(boost-1)*100:.1f}%)")
            elif total < avg_total * 0.95:
                reduction = 1 - (avg_total - total) / avg_total * 0.1
                adjusted *= reduction
                factors.append(f"Low total reduction ({(reduction-1)*100:.1f}%)")

        # Teammate injuries - opportunity boost
        if len(context['team_injuries']) > 0:
            # Simple boost for each teammate out
            out_count = sum(1 for i in context['team_injuries'] if i['status'].upper() in ['OUT', 'O'])
            if out_count > 0:
                boost = 1 + out_count * 0.03  # 3% per player out
                adjusted *= boost
                factors.append(f"Teammate injuries boost (+{(boost-1)*100:.1f}%)")

        return {
            'projection': adjusted,
            'base_projection': base_projection,
            'adjustment': adjusted - base_projection,
            'factors': factors,
            'context': context
        }


# Singleton instance
_realtime_service: Optional[RealTimeService] = None


def get_realtime_service() -> RealTimeService:
    """Get singleton real-time service"""
    global _realtime_service
    if _realtime_service is None:
        _realtime_service = RealTimeService()
    return _realtime_service


# Convenience functions
async def get_vegas_for_game(home_team: str, away_team: str, sport: str = 'nba') -> Optional[Dict]:
    """Get Vegas line for a specific game"""
    service = get_realtime_service()
    vegas = service.get_team_vegas(home_team, sport)
    if vegas and away_team in [vegas.home_team, vegas.away_team]:
        return {
            'spread': vegas.spread,
            'total': vegas.total,
            'home_ml': vegas.home_ml,
            'away_ml': vegas.away_ml
        }
    return None


def get_player_status(player_name: str, sport: str = 'nba') -> str:
    """Get player's current injury status"""
    service = get_realtime_service()
    injury = service.get_player_injury_status(player_name, sport)
    return injury.status if injury else 'AVAILABLE'
