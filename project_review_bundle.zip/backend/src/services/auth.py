"""
Authentication Service - JWT token auth for DFS Edge Pro
"""

from typing import Optional
from passlib.context import CryptContext
from jose import JWTError, jwt
from datetime import datetime, timedelta
import os
from dotenv import load_dotenv
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

load_dotenv()

# Password hashing — argon2 is preferred; fall back to bcrypt if argon2-cffi is absent
try:
    pwd_context = CryptContext(schemes=["argon2"], deprecated="auto")
    # Quick smoke test to ensure the handler is actually usable
    pwd_context.hash("probe")
except Exception:
    pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# JWT settings
SECRET_KEY = os.getenv("JWT_SECRET_KEY", "your-secret-key-change-this")
ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", 60 * 24 * 7))  # 7 days default

# Bearer token security scheme
security = HTTPBearer(auto_error=False)


def hash_password(password: str) -> str:
    """Hash a password for storing"""
    return pwd_context.hash(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a password against a hash"""
    return pwd_context.verify(plain_password, hashed_password)


def create_access_token(data: dict, expires_delta: timedelta = None) -> str:
    """
    Create a JWT access token

    Args:
        data: Dictionary containing user info (usually {"sub": user_id})
        expires_delta: How long until token expires

    Returns:
        Encoded JWT token string
    """
    to_encode = data.copy()

    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)

    to_encode.update({"exp": expire})

    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt


def verify_token(token: str) -> str:
    """
    Verify a JWT token and return the user_id

    Args:
        token: JWT token string

    Returns:
        user_id from the token

    Raises:
        JWTError if token is invalid
    """
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id: str = payload.get("sub")

        if user_id is None:
            raise JWTError("Invalid token payload")

        return user_id

    except JWTError:
        raise JWTError("Could not validate credentials")


def get_current_user_id(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security)
) -> Optional[str]:
    """
    FastAPI dependency to extract user_id from Bearer token.
    Returns None if no token provided (for optional auth).

    Usage:
        @router.get("/endpoint")
        async def endpoint(user_id: Optional[str] = Depends(get_current_user_id)):
            if user_id:
                # authenticated
            else:
                # anonymous
    """
    if credentials is None:
        return None

    try:
        return verify_token(credentials.credentials)
    except JWTError:
        return None


def require_auth(
    credentials: HTTPAuthorizationCredentials = Depends(HTTPBearer())
) -> str:
    """
    FastAPI dependency that requires authentication.
    Raises 401 if no valid token.

    Usage:
        @router.get("/protected")
        async def protected(user_id: str = Depends(require_auth)):
            # user_id is guaranteed to be valid
    """
    try:
        return verify_token(credentials.credentials)
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )