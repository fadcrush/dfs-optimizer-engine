"""
Uncertainty Modeling Service

Provides advanced probability distribution modeling for player projections:
- Position-specific volatility
- Matchup-adjusted variance
- Fatigue and rest-day factors
- Percentile-based floor/ceiling calculations
- Confidence intervals for projections

Replaces simple floor/ceiling with statistically rigorous distributions.
"""

import numpy as np
import pandas as pd
from scipy import stats
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from pathlib import Path
import duckdb
import logging

logger = logging.getLogger(__name__)

DUCKDB_PATH = Path(__file__).parent.parent.parent / "data" / "dfs_master.duckdb"


@dataclass
class VolatilityFactors:
    """Factors that affect projection uncertainty"""

    # Position-specific base volatility (coefficient of variation)
    position_volatility: Dict[str, float] = None

    # Matchup volatility adjustments
    matchup_adjustments: Dict[str, float] = None

    # Rest/fatigue adjustments
    rest_adjustments: Dict[int, float] = None

    # Home/away adjustments
    location_volatility: Dict[str, float] = None

    def __post_init__(self):
        # Default position volatility (from historical analysis)
        self.position_volatility = self.position_volatility or {
            'PG': 0.28,   # High variance - ball handling, assists dependent
            'SG': 0.25,   # Moderate-high - scoring variance
            'SF': 0.23,   # Moderate - versatile but inconsistent
            'PF': 0.20,   # Lower - rebounding more consistent
            'C': 0.18,    # Lowest - rebounds/blocks predictable
            'G': 0.26,    # Guard average
            'F': 0.22,    # Forward average
            'UTIL': 0.24, # Overall average
        }

        # Matchup difficulty adjustments (multiply base volatility)
        self.matchup_adjustments = self.matchup_adjustments or {
            'elite_defense': 1.20,      # More variance vs good D
            'good_defense': 1.10,
            'average_defense': 1.00,
            'weak_defense': 0.95,
            'poor_defense': 0.90,       # Less variance vs bad D
        }

        # Rest day adjustments (0 = back-to-back, 1 = normal, 2+ = well rested)
        self.rest_adjustments = self.rest_adjustments or {
            0: 1.25,    # B2B = higher variance (fatigue)
            1: 1.00,    # Normal rest
            2: 0.95,    # Well rested
            3: 0.92,    # Very well rested
            4: 0.90,    # Extended rest (more consistent)
        }

        # Location volatility
        self.location_volatility = self.location_volatility or {
            'home': 0.95,   # More consistent at home
            'away': 1.05,   # Higher variance on road
        }


class UncertaintyModel:
    """
    Main uncertainty modeling class for projection distributions
    """

    def __init__(self):
        self.factors = VolatilityFactors()
        self.historical_volatility: Dict[str, float] = {}
        self.player_consistency: Dict[str, float] = {}

    def load_historical_data(self, lookback_days: int = 90) -> None:
        """Load player-specific volatility from database"""

        if not DUCKDB_PATH.exists():
            logger.warning("Database not found, using default volatility")
            return

        try:
            conn = duckdb.connect(str(DUCKDB_PATH), read_only=True)

            query = """
            SELECT
                player_name,
                COUNT(*) as games,
                AVG(fd_points) as avg_fp,
                STDDEV(fd_points) as std_fp,
                MIN(fd_points) as min_fp,
                MAX(fd_points) as max_fp,
                PERCENTILE_CONT(0.10) WITHIN GROUP (ORDER BY fd_points) as p10,
                PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY fd_points) as p25,
                PERCENTILE_CONT(0.50) WITHIN GROUP (ORDER BY fd_points) as p50,
                PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY fd_points) as p75,
                PERCENTILE_CONT(0.90) WITHIN GROUP (ORDER BY fd_points) as p90
            FROM player_game_logs
            WHERE date >= CURRENT_DATE - INTERVAL ? DAY
              AND fd_points IS NOT NULL
              AND fd_points > 5
            GROUP BY player_name
            HAVING COUNT(*) >= 5
            """

            df = conn.execute(query, [lookback_days]).fetchdf()
            conn.close()

            for _, row in df.iterrows():
                name = row['player_name']
                if row['avg_fp'] > 0:
                    cv = row['std_fp'] / row['avg_fp']  # Coefficient of variation
                    self.historical_volatility[name] = cv
                    self.player_consistency[name] = {
                        'cv': cv,
                        'avg': row['avg_fp'],
                        'std': row['std_fp'],
                        'min': row['min_fp'],
                        'max': row['max_fp'],
                        'p10': row['p10'],
                        'p25': row['p25'],
                        'p50': row['p50'],
                        'p75': row['p75'],
                        'p90': row['p90'],
                    }

            logger.info(f"Loaded volatility data for {len(self.historical_volatility)} players")

        except Exception as e:
            logger.error(f"Error loading historical data: {e}")

    def calculate_volatility(self,
                             player_name: str,
                             position: str,
                             opponent: str = None,
                             is_home: bool = True,
                             rest_days: int = 1,
                             defense_rating: str = 'average_defense') -> float:
        """
        Calculate player-specific volatility coefficient

        Args:
            player_name: Player name
            position: Position (PG, SG, SF, PF, C)
            opponent: Opponent team (for matchup adjustment)
            is_home: Home (True) or Away (False)
            rest_days: Days since last game
            defense_rating: Opponent defense quality

        Returns:
            Volatility coefficient (standard deviation / mean)
        """

        # Start with player-specific historical volatility
        if player_name in self.historical_volatility:
            base_cv = self.historical_volatility[player_name]
        else:
            # Use position default
            pos = position.split('/')[0] if position else 'UTIL'
            base_cv = self.factors.position_volatility.get(pos, 0.24)

        # Apply matchup adjustment
        matchup_mult = self.factors.matchup_adjustments.get(defense_rating, 1.0)

        # Apply location adjustment
        location = 'home' if is_home else 'away'
        location_mult = self.factors.location_volatility.get(location, 1.0)

        # Apply rest adjustment
        rest = min(rest_days, 4)  # Cap at 4+ days
        rest_mult = self.factors.rest_adjustments.get(rest, 1.0)

        # Combined volatility
        final_cv = base_cv * matchup_mult * location_mult * rest_mult

        return final_cv

    def calculate_distribution(self,
                                projection: float,
                                player_name: str,
                                position: str,
                                opponent: str = None,
                                is_home: bool = True,
                                rest_days: int = 1,
                                defense_rating: str = 'average_defense',
                                salary: int = 5000) -> Dict:
        """
        Calculate full probability distribution for a player

        Args:
            projection: Point projection (mean)
            player_name: Player name
            position: Position
            opponent: Opponent team
            is_home: Home or away
            rest_days: Days of rest
            defense_rating: Opponent defense quality
            salary: Player salary (affects skewness)

        Returns:
            Dictionary with distribution parameters and percentiles
        """

        # Calculate volatility
        cv = self.calculate_volatility(
            player_name, position, opponent,
            is_home, rest_days, defense_rating
        )

        # Calculate standard deviation
        std_dev = projection * cv

        # Calculate skewness based on salary tier
        # Expensive players have more downside risk (high expectations)
        if salary > 10000:
            skewness = -0.8   # Heavy left skew - studs disappoint
        elif salary > 8000:
            skewness = -0.5
        elif salary > 6000:
            skewness = -0.3
        elif salary > 4500:
            skewness = -0.1   # Slight negative
        else:
            skewness = 0.3    # Cheap players can boom (positive skew)

        # Calculate percentiles using skew-normal distribution
        # This gives us realistic floor/ceiling based on actual distribution shape
        percentiles = {}
        for p in [1, 5, 10, 25, 50, 75, 90, 95, 99]:
            percentiles[f'p{p}'] = float(stats.skewnorm.ppf(
                p / 100,
                a=skewness,
                loc=projection,
                scale=std_dev
            ))

        # Ensure percentiles are non-negative
        for key in percentiles:
            percentiles[key] = max(0, percentiles[key])

        # Calculate probability of hitting various thresholds
        prob_thresholds = {}
        for threshold in [20, 30, 40, 50, 60, 70]:
            prob = 1 - stats.skewnorm.cdf(
                threshold,
                a=skewness,
                loc=projection,
                scale=std_dev
            )
            prob_thresholds[f'prob_{threshold}'] = float(prob)

        return {
            'mean': projection,
            'std_dev': std_dev,
            'cv': cv,
            'skewness': skewness,

            # Percentiles
            'floor': percentiles['p10'],      # 10th percentile
            'likely_floor': percentiles['p25'],  # 25th percentile
            'median': percentiles['p50'],
            'likely_ceiling': percentiles['p75'],
            'ceiling': percentiles['p90'],    # 90th percentile
            'upside': percentiles['p95'],     # 95th percentile

            # Full percentiles
            'percentiles': percentiles,

            # Probability thresholds
            'probabilities': prob_thresholds,

            # Confidence interval
            'ci_80': (percentiles['p10'], percentiles['p90']),
            'ci_90': (percentiles['p5'], percentiles['p95']),
            'ci_95': (percentiles['p1'], percentiles['p99']),
        }

    def add_uncertainty_to_projections(self, projections_df: pd.DataFrame) -> pd.DataFrame:
        """
        Add uncertainty metrics to a projections DataFrame

        Args:
            projections_df: DataFrame with player projections

        Returns:
            DataFrame with additional uncertainty columns
        """

        # Load historical data if not loaded
        if not self.historical_volatility:
            self.load_historical_data()

        results = []

        for _, row in projections_df.iterrows():
            # Extract player info
            player_name = row.get('player_name', row.get('Nickname', ''))
            position = str(row.get('position', row.get('Position', 'UTIL')))
            projection = float(row.get('projection', row.get('Projection', 0)))
            salary = int(row.get('salary', row.get('Salary', 5000)))
            opponent = row.get('opponent', row.get('Opponent', ''))

            # Determine home/away
            is_home = row.get('is_home', True)
            if 'Game' in row:
                # Parse from game string (e.g., "DAL@PHX")
                game = str(row['Game'])
                team = str(row.get('team', row.get('Team', '')))
                is_home = not game.startswith(team)

            # Get rest days (default to 1 if not available)
            rest_days = int(row.get('rest_days', 1))

            # Calculate distribution
            dist = self.calculate_distribution(
                projection=projection,
                player_name=player_name,
                position=position,
                opponent=opponent,
                is_home=is_home,
                rest_days=rest_days,
                salary=salary
            )

            # Create result row
            result = row.to_dict()
            result.update({
                'std_dev': dist['std_dev'],
                'cv': dist['cv'],
                'skewness': dist['skewness'],
                'floor': dist['floor'],
                'likely_floor': dist['likely_floor'],
                'median': dist['median'],
                'likely_ceiling': dist['likely_ceiling'],
                'ceiling': dist['ceiling'],
                'upside': dist['upside'],
                'prob_40': dist['probabilities'].get('prob_40', 0),
                'prob_50': dist['probabilities'].get('prob_50', 0),
                'prob_60': dist['probabilities'].get('prob_60', 0),
            })

            results.append(result)

        return pd.DataFrame(results)


class MatchupVolatilityAnalyzer:
    """
    Analyze matchup-specific volatility for more accurate uncertainty
    """

    def __init__(self):
        self.team_defense_volatility: Dict[str, Dict[str, float]] = {}

    def load_defense_volatility(self, lookback_days: int = 60) -> None:
        """Calculate how much variance each defense creates"""

        if not DUCKDB_PATH.exists():
            return

        try:
            conn = duckdb.connect(str(DUCKDB_PATH), read_only=True)

            # Get fantasy points allowed by each team, by position
            query = """
            SELECT
                opponent,
                COUNT(*) as games,
                AVG(fd_points) as avg_allowed,
                STDDEV(fd_points) as std_allowed
            FROM player_game_logs
            WHERE date >= CURRENT_DATE - INTERVAL ? DAY
              AND fd_points IS NOT NULL
            GROUP BY opponent
            HAVING COUNT(*) >= 20
            """

            df = conn.execute(query, [lookback_days]).fetchdf()
            conn.close()

            for _, row in df.iterrows():
                team = row['opponent']
                if row['avg_allowed'] > 0:
                    self.team_defense_volatility[team] = {
                        'avg_allowed': row['avg_allowed'],
                        'std_allowed': row['std_allowed'],
                        'cv_allowed': row['std_allowed'] / row['avg_allowed'],
                    }

            logger.info(f"Loaded defense volatility for {len(self.team_defense_volatility)} teams")

        except Exception as e:
            logger.error(f"Error loading defense volatility: {e}")

    def get_matchup_volatility_adjustment(self, opponent: str) -> float:
        """
        Get volatility adjustment factor for a specific opponent

        Returns:
            Multiplier for base volatility (1.0 = no adjustment)
        """

        if opponent not in self.team_defense_volatility:
            return 1.0

        team_data = self.team_defense_volatility[opponent]

        # Compare to league average CV
        league_avg_cv = 0.25  # Typical CV for fantasy points

        team_cv = team_data['cv_allowed']

        # Higher CV = defense creates more variance
        adjustment = team_cv / league_avg_cv

        # Clamp to reasonable range
        return max(0.8, min(1.3, adjustment))


# Convenience functions

def add_uncertainty(projections_df: pd.DataFrame) -> pd.DataFrame:
    """Add uncertainty modeling to projections DataFrame"""
    model = UncertaintyModel()
    model.load_historical_data()
    return model.add_uncertainty_to_projections(projections_df)


def calculate_player_distribution(
    projection: float,
    player_name: str,
    position: str,
    salary: int = 5000
) -> Dict:
    """Calculate distribution for a single player"""
    model = UncertaintyModel()
    model.load_historical_data()
    return model.calculate_distribution(
        projection=projection,
        player_name=player_name,
        position=position,
        salary=salary
    )
