# backend/services/optimizer_service.py
"""
Optimizer Service - Unified entry point for lineup optimization.
Handles column normalization, pool building, and optimizer invocation.

Phase 6: Integrated with circuit breaker for resilience.
Phase 7: Ceiling-based pruning wired before optimizer invocation.
"""

import pandas as pd
from typing import Dict, Any, Optional, List
from pathlib import Path
from datetime import date, datetime
import logging
import uuid

from services.professional_optimizer import optimize_lineups_lp, format_lineups_for_export
from analytics import build_lineup_analytics, save_analytics_report, save_run_file
from core.exceptions import InjuryEnrichmentError

# Import ceiling-based pruning function
# This runs BEFORE the optimizer to filter players by ceiling probability
try:
    import sys
    sys.path.insert(0, str(Path(__file__).parent.parent.parent))
    from analysis.nba.player_pool import filter_player_pool_by_ceiling
    CEILING_FILTER_AVAILABLE = True
except ImportError:
    CEILING_FILTER_AVAILABLE = False
    filter_player_pool_by_ceiling = None

logger = logging.getLogger(__name__)

# Phase 6: Circuit breaker imports
try:
    from observability.circuit_breaker import (
        get_circuit_breaker,
        CircuitOpenError,
    )
    from observability.preflight import PreflightError
    CIRCUIT_BREAKER_AVAILABLE = True
except ImportError:
    CIRCUIT_BREAKER_AVAILABLE = False
    CircuitOpenError = Exception
    PreflightError = Exception
    get_circuit_breaker = None


# =============================================================================
# COLUMN NORMALIZATION
# =============================================================================

# Map all known FanDuel/DraftKings column variants to canonical names
COLUMN_ALIASES = {
    # Name variants
    "nickname": "Name",
    "name": "Name",
    "player": "Name",
    "playername": "Name",
    "player_name": "Name",
    # Projection variants
    "fppg": "Projection",
    "proj": "Projection",
    "projection": "Projection",
    "fpts": "Projection",
    "points": "Projection",
    "avgpointspergame": "Projection",
    # Salary variants
    "salary": "Salary",
    "sal": "Salary",
    # Position variants
    "roster position": "Position",
    "position": "Position",
    "pos": "Position",
    # Team variants
    "teamabbrev": "Team",
    "team": "Team",
    "team_abbrev": "Team",
    # ID variants
    "id": "ID",
    "player id": "ID",
    "playerid": "ID",
    # Injury Status variants
    "injury status": "Injury Status",
    "injurystatus": "Injury Status",
    "injury_status": "Injury Status",
    "status": "Injury Status",
}

REQUIRED_COLUMNS = {"Name", "Projection", "Salary", "Position"}


def normalize_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """
    Normalize column names to canonical format.
    This is the SINGLE place where normalization happens.
    """
    # Lowercase all columns for matching
    df.columns = [str(c).strip().lower() for c in df.columns]

    # Build rename map - but avoid creating duplicates
    # Track which canonical names we've already used
    rename_map = {}
    used_canonical = set()

    for col in df.columns:
        if col in COLUMN_ALIASES:
            canonical = COLUMN_ALIASES[col]
            # Only rename if we haven't already mapped to this canonical name
            if canonical not in used_canonical:
                rename_map[col] = canonical
                used_canonical.add(canonical)

    df = df.rename(columns=rename_map)

    # Drop any remaining duplicate columns (keep first)
    df = df.loc[:, ~df.columns.duplicated(keep='first')]

    return df


def validate_columns(df: pd.DataFrame) -> None:
    """Raise ValueError if required columns are missing."""
    missing = REQUIRED_COLUMNS - set(df.columns)
    if missing:
        available = ", ".join(sorted(df.columns))
        raise ValueError(
            f"Missing required columns: {', '.join(sorted(missing))}. "
            f"Available columns: {available}"
        )


# =============================================================================
# POOL BUILDER
# =============================================================================

def enrich_with_injury_data(df: pd.DataFrame, run_id: Optional[str] = None) -> pd.DataFrame:
    """
    Enrich player pool with real-time injury data from SportsData.io.

    Only called when the uploaded CSV has no ``Injury Status`` column (e.g. DraftKings slates).
    Failure handling is controlled by two env-vars surfaced via ``core.config.Settings``:

    ``INJURY_DATA_REQUIRED`` (bool, default *False*)
        When *True*, failures are logged at ERROR level and a prominent warning
        about incomplete OUT-filtering is emitted even in *open* mode.
        Set to *True* in production.

    ``INJURY_DATA_FAIL_MODE`` (``'open'`` | ``'closed'``, default ``'open'``)
        *open*  – log WARNING with reason + run_id, set Injury Status to ``""`` and continue.
        *closed* – raise :class:`InjuryEnrichmentError`; the router converts it to HTTP 503
                   with an actionable message.

    OUT filtering is **never disabled**: the exclusion block in ``build_player_pool`` always
    runs against whatever ``Injury Status`` values are present.  In *open*-mode failures
    every player will have status ``""`` so the filter is a no-op — no players are dropped,
    but none are incorrectly kept out either.
    """
    # ── Load settings (lazy to avoid circular import) ─────────────────────────
    try:
        from core.config import get_settings
        _s = get_settings()
        fail_mode: str = _s.injury_data_fail_mode.lower()
        required: bool = _s.injury_data_required
    except Exception:
        fail_mode, required = "open", False

    # ── Actionable messages per error category ────────────────────────────────
    _MESSAGES: dict = {
        "missing_key": (
            "SPORTSDATA_API_KEY is not configured. "
            "Set SPORTSDATA_API_KEY in your .env file to enable real-time injury filtering."
        ),
        "invalid_key": (
            "SportsData.io rejected the API key (HTTP 401/403). "
            "Verify that SPORTSDATA_API_KEY is valid and has NBA-data access."
        ),
        "rate_limited": (
            "SportsData.io rate limit exceeded (HTTP 429). "
            "Wait before retrying or upgrade your API plan."
        ),
        "network_failure": (
            "Could not reach SportsData.io (connection / timeout error). "
            "Check internet connectivity and firewall rules."
        ),
        "no_module": (
            "The injury_service module is not installed. "
            "Ensure `services/injury_service.py` is present in the backend."
        ),
    }

    def _handle_failure(reason: str, exc: Optional[Exception] = None) -> pd.DataFrame:
        """
        Central failure handler for enrichment errors.

        *closed* mode: raises InjuryEnrichmentError (router → HTTP 503).
        *open*  mode: logs + returns df with empty Injury Status column.
        OUT filtering still runs — it just has nothing to exclude.
        """
        detail = _MESSAGES.get(reason) or f"Unexpected error: {exc}"

        if fail_mode == "closed":
            raise InjuryEnrichmentError(reason=reason, run_id=run_id, detail=detail)

        # open mode — decide log level based on whether data is *required*
        log_level = logging.ERROR if required else logging.WARNING
        logger.log(
            log_level,
            "Injury enrichment failed [reason=%s, run_id=%s]: %s",
            reason,
            run_id or "<pending>",
            detail,
        )
        if required:
            logger.warning(
                "INJURY_DATA_REQUIRED=True but enrichment failed — "
                "OUT filtering will be skipped for run_id=%s. "
                "Players ruled OUT by SportsData.io may appear in lineups.",
                run_id or "<pending>",
            )
        df["Injury Status"] = ""
        return df

    # ── Fast-path: module missing ─────────────────────────────────────────────
    try:
        from services.injury_service import InjuryService
    except ImportError:
        return _handle_failure("no_module")

    # ── Fast-path: API key not configured ────────────────────────────────────
    service = InjuryService()
    if not service.api_key:
        return _handle_failure("missing_key")

    # ── Attempt network fetch ─────────────────────────────────────────────────
    try:
        import requests as _requests
        logger.info("Fetching real-time injury data from SportsData.io...")
        injuries = service.get_injury_updates()
    except Exception as exc:
        # Classify by exception type / HTTP status code
        resp = getattr(exc, "response", None)
        status = resp.status_code if resp is not None else 0
        if status in (401, 403):
            return _handle_failure("invalid_key", exc)
        if status == 429:
            return _handle_failure("rate_limited", exc)
        _requests_exc = getattr(_requests, "exceptions", None)
        if _requests_exc and isinstance(exc, (_requests_exc.ConnectionError, _requests_exc.Timeout)):
            return _handle_failure("network_failure", exc)
        return _handle_failure("network_failure" if status == 0 else "unknown", exc)

    if not injuries:
        logger.warning(
            "SportsData.io returned no injury records — "
            "continuing without injury enrichment (run_id=%s)",
            run_id or "<pending>",
        )
        df["Injury Status"] = ""
        return df

    # ── Build lookup and annotate pool ────────────────────────────────────────
    injury_map: dict = {inj["name"].lower().strip(): inj["injury_status"] for inj in injuries}

    def _get_status(player_name: str) -> str:
        if pd.isna(player_name):
            return ""
        return injury_map.get(str(player_name).lower().strip(), "")

    df["Injury Status"] = df["Name"].apply(_get_status)
    matched = (df["Injury Status"] != "").sum()
    logger.info(
        "Matched injury data for %d/%d players from SportsData.io (run_id=%s)",
        matched, len(df), run_id or "<pending>",
    )
    return df


def build_player_pool(
    df: pd.DataFrame,
    platform: str = "fanduel",
    run_id: Optional[str] = None,
) -> pd.DataFrame:
    """
    Build optimizer-ready player pool from normalized DataFrame.
    Adds PosBucket for position slot assignment.

    Parameters
    ----------
    df : pd.DataFrame
        Raw slate / projections data.
    platform : str
        ``'fanduel'`` or ``'draftkings'``.
    run_id : str, optional
        Propagated from the calling optimizer function so that any
        injury-enrichment warnings / errors reference the same run ID.
    """
    df = normalize_dataframe(df)
    validate_columns(df)

    # AUTO-ENRICH WITH INJURY DATA if column missing.
    # FanDuel CSVs already include an Injury Status column.
    # DraftKings CSVs do not — so we fetch from SportsData.io.
    # OUT filtering (below) ALWAYS runs regardless of enrichment outcome.
    if "Injury Status" not in df.columns:
        logger.info("Injury Status column not found — fetching from SportsData.io (run_id=%s)...", run_id or "<pending>")
        df = enrich_with_injury_data(df, run_id=run_id)  # may raise InjuryEnrichmentError in closed mode
    else:
        logger.info("Using Injury Status column from CSV")

    # Convert numeric columns
    df["Projection"] = pd.to_numeric(df["Projection"], errors="coerce")
    df["Salary"] = pd.to_numeric(df["Salary"], errors="coerce")

    # Drop invalid rows
    df = df.dropna(subset=["Projection", "Salary", "Position"])
    df = df[df["Projection"] > 0]
    df = df[df["Salary"] > 0]

    if df.empty:
        raise ValueError("No valid players after filtering (check Projection/Salary values)")

    # INJURY FILTERING: Remove players with OUT status
    # Check if Injury Status column exists and filter out injured players
    if "Injury Status" in df.columns:
        initial_count = len(df)
        
        # Normalize injury status values (case-insensitive, strip whitespace)
        df["Injury Status"] = df["Injury Status"].fillna("").astype(str).str.strip().str.upper()
        
        # Filter out players who are OUT or ruled out
        excluded_statuses = {"OUT", "O", "INACTIVE", "DNP", "SUSPENDED", "INELIGIBLE"}
        df = df[~df["Injury Status"].isin(excluded_statuses)]
        
        filtered_count = initial_count - len(df)
        if filtered_count > 0:
            logger.info(f"Filtered out {filtered_count} injured/unavailable players (OUT, INACTIVE, etc.)")
    
    if df.empty:
        raise ValueError("No available players after injury filtering. All players may be marked as OUT.")

    # Create PosBucket from Position (take primary position)
    def get_primary_position(pos_str):
        if pd.isna(pos_str):
            return None
        pos = str(pos_str).upper().strip()
        # Handle multi-position like "PG/SG" - take first
        if "/" in pos:
            pos = pos.split("/")[0].strip()
        # Map common variants
        pos_map = {"POINT GUARD": "PG", "SHOOTING GUARD": "SG",
                   "SMALL FORWARD": "SF", "POWER FORWARD": "PF", "CENTER": "C"}
        return pos_map.get(pos, pos)

    df["PosBucket"] = df["Position"].apply(get_primary_position)

    # Validate we have all required positions for FanDuel
    if platform.lower() == "fanduel":
        required_positions = {"PG", "SG", "SF", "PF", "C"}
        available_positions = set(df["PosBucket"].dropna().unique())
        missing_positions = required_positions - available_positions
        if missing_positions:
            raise ValueError(f"Missing players for positions: {', '.join(sorted(missing_positions))}")

    # Ensure ID column exists (use index if not present)
    if "ID" not in df.columns:
        df["ID"] = df.index.astype(str)

    return df.reset_index(drop=True)


# =============================================================================
# MAIN OPTIMIZER FUNCTIONS
# =============================================================================

async def run_fanduel_optimizer(
    projections_path: str,
    num_lineups: int = 20,
    min_salary: int = 59000,
    max_salary: int = 60000,
    max_exposure: float = 0.35,
    contest_type: str = "small_gpp",
) -> Dict[str, Any]:
    """
    Run FanDuel optimizer from a projections file.

    This is the main entry point for the /api/optimizer/optimize-from-projections endpoint.

    Returns:
        {
            "success": bool,
            "lineups": [...],      # Formatted for UI preview
            "lineups_raw": [...],  # Raw for CSV export
            "stats": {...},
            "algorithm": str,
            "note": str,
            "error": str (only if success=False),
            "circuit_open": bool (only if circuit breaker blocked request)
        }
    """
    # Phase 6: Circuit breaker check (returns 503 if open)
    circuit_breaker = None
    if CIRCUIT_BREAKER_AVAILABLE and get_circuit_breaker:
        circuit_breaker = get_circuit_breaker()
        try:
            circuit_breaker.check()
        except CircuitOpenError as e:
            return {
                "success": False,
                "error": str(e),
                "circuit_open": True,
            }

    try:
        # Load CSV
        path = Path(projections_path)
        if not path.exists():
            return {
                "success": False,
                "error": f"Projections file not found: {projections_path}"
            }

        df = pd.read_csv(path)

        if df.empty:
            return {
                "success": False,
                "error": "Projections file is empty"
            }

        # Pre-generate run_id so injury-enrichment logs and post-build analytics
        # share the same identifier throughout the entire request lifecycle.
        run_id = f"run_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"

        # Build player pool (handles normalization + optional injury enrichment).
        # InjuryEnrichmentError propagates here when fail_mode='closed'.
        pool = build_player_pool(df, platform="fanduel", run_id=run_id)

        # =====================================================================
        # INJURY-BASED EXCLUSION: Remove OUT players BEFORE optimizer
        # This block ALWAYS runs — OUT filtering is never disabled.
        # In open-mode enrichment failures all statuses will be "", so the
        # filter is a no-op rather than silently producing unsafe lineups.
        # =====================================================================
        exclusion_metadata = {"excluded_count": 0, "exclusions": []}
        try:
            from analysis.nba.player_pool import exclude_out_players
            
            # Build injury map from DataFrame if Injury Status column exists
            injury_map = {}
            if "Injury Status" in pool.columns:
                for _, row in pool.iterrows():
                    name = str(row.get("Name", "")).lower().strip()
                    status = str(row.get("Injury Status", "")).strip()
                    if name and status:
                        injury_map[name] = status
            
            # Apply exclusion filter (no-op if feature flag disabled)
            pool, exclusions = exclude_out_players(
                player_pool=pool,
                injury_map=injury_map if injury_map else None,
                id_col="ID",
                name_col="Name",
                slate_date=date.today().isoformat(),
            )
            
            exclusion_metadata["excluded_count"] = len([e for e in exclusions if e.get("excluded")])
            exclusion_metadata["exclusions"] = exclusions
            
            if exclusion_metadata["excluded_count"] > 0:
                logger.info(
                    f"Injury exclusion: {exclusion_metadata['excluded_count']} players excluded, "
                    f"{len(pool)} players remain"
                )
        except ImportError:
            logger.debug("Player pool exclusion not available - continuing without injury exclusion")
        except Exception as exclusion_error:
            logger.warning(f"Injury exclusion failed (non-fatal): {exclusion_error}")

        # =====================================================================
        # CEILING-BASED PRUNING: Filter players BEFORE optimizer
        # This ensures the optimizer never sees players who cannot hit required ceiling
        # =====================================================================
        pruning_metadata = {"pruned_count": 0, "rejections": []}
        if CEILING_FILTER_AVAILABLE and filter_player_pool_by_ceiling:
            try:
                prune_result = filter_player_pool_by_ceiling(
                    players_df=pool,
                    signals=[],  # Signals passed from caller if available
                    salary_col="Salary",
                    median_col="Projection",  # Use normalized column name
                    ceiling_col="Ceiling" if "Ceiling" in pool.columns else "Projection",
                    id_col="ID",
                    required_probability=0.30,
                    slate_date=date.today().isoformat(),
                )
                pool = prune_result["filtered_player_pool"]
                pruning_metadata["pruned_count"] = len(prune_result.get("rejections", []))
                pruning_metadata["rejections"] = prune_result.get("rejections", [])
                logger.info(
                    f"Ceiling pruning complete: {pruning_metadata['pruned_count']} players removed, "
                    f"{len(pool)} players remain"
                )
            except Exception as prune_error:
                # Log but don't fail - pruning is an enhancement, not a requirement
                logger.warning(f"Ceiling pruning skipped due to error: {prune_error}")

        if pool.empty:
            return {
                "success": False,
                "error": "No players remain after ceiling-based pruning. Check projection/ceiling values."
            }

        # Run LP optimizer (receives only ceiling-qualified players)
        raw_lineups = optimize_lineups_lp(
            pool=pool,
            num_lineups=num_lineups,
            max_exposure=max_exposure,
            min_salary=min_salary,
            max_salary=max_salary,
            platform="fanduel"
        )

        if not raw_lineups:
            # Record failure for circuit breaker
            if circuit_breaker:
                circuit_breaker.record_failure()
            return {
                "success": False,
                "error": "Optimizer could not generate any valid lineups. Check salary constraints."
            }

        # Record success for circuit breaker
        if circuit_breaker:
            circuit_breaker.record_success()

        # POST-OPTIMIZATION ANALYTICS (READ-ONLY)
        # run_id was pre-generated before pool build so both enrichment logs and
        # analytics reference the same identifier.
        analytics_run_id = run_id
        try:
            slate_id = Path(projections_path).stem  # Use filename as slate identifier
            
            # Build player metadata dictionary from pool
            players_metadata = {}
            for _, row in pool.iterrows():
                player_id = str(row.get('ID', row.get('Name', '')))
                players_metadata[player_id] = {
                    'name': row.get('Name', 'Unknown'),
                    'team': row.get('Team', 'UNK'),
                    'position': row.get('Position', ''),
                    'salary': int(row.get('Salary', 0)),
                    'projection': float(row.get('Projection', 0)),
                }
            
            # Convert raw_lineups to analytics-compatible format
            lineups_for_analytics = []
            for lineup in raw_lineups:
                player_ids = [str(p.get('ID', p.get('Name', ''))) for p in lineup]
                total_salary = sum(p.get('Salary', 0) for p in lineup)
                lineups_for_analytics.append({
                    'player_ids': player_ids,
                    'total_salary': total_salary,
                })
            
            # Build immutable analytics report
            analytics_report = build_lineup_analytics(
                lineups=lineups_for_analytics,
                players=players_metadata,
                run_id=run_id,
                slate_id=slate_id,
                exclusions=exclusion_metadata.get("exclusions", []),
            )
            
            # Persist analytics (legacy report + structured run file)
            save_analytics_report(analytics_report)
            save_run_file(
                run_id=run_id,
                lineups=lineups_for_analytics,
                players=players_metadata,
            )
            logger.info(
                "Run file saved for run_id=%s (%d lineups, %d players)",
                run_id,
                analytics_report.get("total_lineups", 0),
                len(analytics_report.get("exposure", [])),
            )

        except Exception as analytics_error:
            # Analytics failure should not break optimization result
            logger.warning(f"Post-optimization analytics failed: {analytics_error}")

        # Format for UI preview
        formatted_lineups = format_lineups_for_export(raw_lineups, "fanduel")

        # Calculate stats
        stats = calculate_lineup_stats(raw_lineups)

        return {
            "success": True,
            "lineups": formatted_lineups,
            "lineups_raw": raw_lineups,
            "stats": stats,
            "analytics_run_id": analytics_run_id,
            "algorithm": "PuLP Linear Programming",
            "note": f"Generated {len(raw_lineups)} lineups for FanDuel"
        }

    except InjuryEnrichmentError:
        raise  # Propagate to router — converted to HTTP 503 with actionable detail
    except PreflightError as e:
        # Preflight failures don't count toward circuit breaker (user input issue)
        return {
            "success": False,
            "error": str(e),
            "preflight_failed": True,
        }
    except ValueError as e:
        # Record failure for circuit breaker
        if circuit_breaker:
            circuit_breaker.record_failure()
        return {
            "success": False,
            "error": str(e)
        }
    except Exception as e:
        # Record failure for circuit breaker
        if circuit_breaker:
            circuit_breaker.record_failure()
        return {
            "success": False,
            "error": f"Optimization failed: {str(e)}"
        }


async def generate_lineups(
    projections_path: str,
    num_lineups: int = 150,
    max_exposure: float = 0.35,
    min_salary: int = 49000,
    max_salary: int = 60000,
    platform: str = "fanduel",
    contest_type: str = "small_gpp",
    user_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Generate optimized lineups from projections file.

    This is the main entry point for the /api/workflow/complete endpoint.
    Supports both FanDuel and DraftKings platforms.
    """
    # Phase 6: Circuit breaker check (returns 503 if open)
    circuit_breaker = None
    if CIRCUIT_BREAKER_AVAILABLE and get_circuit_breaker:
        circuit_breaker = get_circuit_breaker()
        try:
            circuit_breaker.check()
        except CircuitOpenError as e:
            return {
                "success": False,
                "error": str(e),
                "circuit_open": True,
            }

    try:
        # Load CSV
        path = Path(projections_path)
        if not path.exists():
            return {
                "success": False,
                "error": f"Projections file not found: {projections_path}"
            }

        df = pd.read_csv(path)

        if df.empty:
            return {
                "success": False,
                "error": "Projections file is empty"
            }

        # Pre-generate run_id so injury-enrichment logs and post-build analytics
        # share the same identifier throughout the entire request lifecycle.
        run_id = f"run_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"

        # Build player pool (handles normalization + optional injury enrichment).
        # InjuryEnrichmentError propagates here when fail_mode='closed'.
        pool = build_player_pool(df, platform=platform, run_id=run_id)

        # =====================================================================
        # INJURY-BASED EXCLUSION: Remove OUT players BEFORE optimizer
        # This block ALWAYS runs — OUT filtering is never disabled.
        # In open-mode enrichment failures all statuses will be "", so the
        # filter is a no-op rather than silently producing unsafe lineups.
        # =====================================================================
        exclusion_metadata = {"excluded_count": 0, "exclusions": []}
        try:
            from analysis.nba.player_pool import exclude_out_players
            
            # Build injury map from DataFrame if Injury Status column exists
            injury_map = {}
            if "Injury Status" in pool.columns:
                for _, row in pool.iterrows():
                    name = str(row.get("Name", "")).lower().strip()
                    status = str(row.get("Injury Status", "")).strip()
                    if name and status:
                        injury_map[name] = status
            
            # Apply exclusion filter (no-op if feature flag disabled)
            pool, exclusions = exclude_out_players(
                player_pool=pool,
                injury_map=injury_map if injury_map else None,
                id_col="ID",
                name_col="Name",
                slate_date=date.today().isoformat(),
            )
            
            exclusion_metadata["excluded_count"] = len([e for e in exclusions if e.get("excluded")])
            exclusion_metadata["exclusions"] = exclusions
            
            if exclusion_metadata["excluded_count"] > 0:
                logger.info(
                    f"Injury exclusion: {exclusion_metadata['excluded_count']} players excluded, "
                    f"{len(pool)} players remain"
                )
        except ImportError:
            logger.debug("Player pool exclusion not available - continuing without injury exclusion")
        except Exception as exclusion_error:
            logger.warning(f"Injury exclusion failed (non-fatal): {exclusion_error}")

        # =====================================================================
        # CEILING-BASED PRUNING: Filter players BEFORE optimizer
        # This ensures the optimizer never sees players who cannot hit required ceiling
        # =====================================================================
        pruning_metadata = {"pruned_count": 0, "rejections": []}
        if CEILING_FILTER_AVAILABLE and filter_player_pool_by_ceiling:
            try:
                prune_result = filter_player_pool_by_ceiling(
                    players_df=pool,
                    signals=[],  # Signals passed from caller if available
                    salary_col="Salary",
                    median_col="Projection",  # Use normalized column name
                    ceiling_col="Ceiling" if "Ceiling" in pool.columns else "Projection",
                    id_col="ID",
                    required_probability=0.30,
                    slate_date=date.today().isoformat(),
                )
                pool = prune_result["filtered_player_pool"]
                pruning_metadata["pruned_count"] = len(prune_result.get("rejections", []))
                pruning_metadata["rejections"] = prune_result.get("rejections", [])
                logger.info(
                    f"Ceiling pruning complete: {pruning_metadata['pruned_count']} players removed, "
                    f"{len(pool)} players remain"
                )
            except Exception as prune_error:
                # Log but don't fail - pruning is an enhancement, not a requirement
                logger.warning(f"Ceiling pruning skipped due to error: {prune_error}")

        if pool.empty:
            return {
                "success": False,
                "error": "No players remain after ceiling-based pruning. Check projection/ceiling values."
            }

        # Run LP optimizer (receives only ceiling-qualified players)
        raw_lineups = optimize_lineups_lp(
            pool=pool,
            num_lineups=num_lineups,
            max_exposure=max_exposure,
            min_salary=min_salary,
            max_salary=max_salary,
            platform=platform
        )

        if not raw_lineups:
            # Record failure for circuit breaker
            if circuit_breaker:
                circuit_breaker.record_failure()
            return {
                "success": False,
                "error": "Optimizer could not generate any valid lineups"
            }

        # Record success for circuit breaker
        if circuit_breaker:
            circuit_breaker.record_success()

        # POST-OPTIMIZATION ANALYTICS (READ-ONLY)
        # run_id was pre-generated before pool build so both enrichment logs and
        # analytics reference the same identifier.
        analytics_run_id = run_id
        try:
            slate_id = Path(projections_path).stem  # Use filename as slate identifier
            
            # Build player metadata dictionary from pool
            players_metadata = {}
            for _, row in pool.iterrows():
                player_id = str(row.get('ID', row.get('Name', '')))
                players_metadata[player_id] = {
                    'name': row.get('Name', 'Unknown'),
                    'team': row.get('Team', 'UNK'),
                    'position': row.get('Position', ''),
                    'salary': int(row.get('Salary', 0)),
                    'projection': float(row.get('Projection', 0)),
                }
            
            # Convert raw_lineups to analytics-compatible format
            lineups_for_analytics = []
            for lineup in raw_lineups:
                player_ids = [str(p.get('ID', p.get('Name', ''))) for p in lineup]
                total_salary = sum(p.get('Salary', 0) for p in lineup)
                lineups_for_analytics.append({
                    'player_ids': player_ids,
                    'total_salary': total_salary,
                })
            
            # Build immutable analytics report
            analytics_report = build_lineup_analytics(
                lineups=lineups_for_analytics,
                players=players_metadata,
                run_id=run_id,
                slate_id=slate_id,
                exclusions=exclusion_metadata.get("exclusions", []),
            )
            
            # Persist analytics (legacy report + structured run file)
            save_analytics_report(analytics_report)
            save_run_file(
                run_id=run_id,
                lineups=lineups_for_analytics,
                players=players_metadata,
            )
            logger.info(
                "Run file saved for run_id=%s (%d lineups, %d players)",
                run_id,
                analytics_report.get("total_lineups", 0),
                len(analytics_report.get("exposure", [])),
            )

        except Exception as analytics_error:
            # Analytics failure should not break optimization result
            logger.warning(f"Post-optimization analytics failed: {analytics_error}")

        # Format for UI
        formatted_lineups = format_lineups_for_export(raw_lineups, platform)

        # Calculate stats
        stats = calculate_lineup_stats(raw_lineups)

        return {
            "success": True,
            "lineups": formatted_lineups,
            "lineups_raw": raw_lineups,
            "stats": stats,
            "analytics_run_id": analytics_run_id,
            "algorithm": "PuLP LP",
            "note": f"Generated {len(raw_lineups)} lineups"
        }

    except InjuryEnrichmentError:
        raise  # Propagate to router — converted to HTTP 503 with actionable detail
    except PreflightError as e:
        # Preflight failures don't count toward circuit breaker (user input issue)
        return {
            "success": False,
            "error": str(e),
            "preflight_failed": True,
        }
    except ValueError as e:
        # Record failure for circuit breaker
        if circuit_breaker:
            circuit_breaker.record_failure()
        return {
            "success": False,
            "error": str(e)
        }
    except Exception as e:
        # Record failure for circuit breaker
        if circuit_breaker:
            circuit_breaker.record_failure()
        return {
            "success": False,
            "error": f"Optimization failed: {str(e)}"
        }


# =============================================================================
# STATS CALCULATION
# =============================================================================

def calculate_lineup_stats(lineups: list) -> Dict[str, Any]:
    """Calculate summary statistics for generated lineups."""
    if not lineups:
        return {
            "total_lineups": 0,
            "avg_projection": 0,
            "avg_salary": 0,
            "avg_ownership": 0,
            "projection_range": "N/A",
            "max_exposure": 0,
            "platform": "fanduel",
            "database_boosts": 0,
            "optimizer_used": "PuLP LP"
        }

    projections = []
    salaries = []

    for lineup in lineups:
        lineup_proj = sum(p.get("Projection", 0) for p in lineup)
        lineup_sal = sum(p.get("Salary", 0) for p in lineup)
        projections.append(lineup_proj)
        salaries.append(lineup_sal)

    avg_proj = sum(projections) / len(projections) if projections else 0
    avg_sal = sum(salaries) / len(salaries) if salaries else 0
    min_proj = min(projections) if projections else 0
    max_proj = max(projections) if projections else 0

    # Calculate player exposure
    player_counts = {}
    for lineup in lineups:
        for player in lineup:
            name = player.get("Name", "")
            player_counts[name] = player_counts.get(name, 0) + 1

    max_exposure = max(player_counts.values()) / len(lineups) if player_counts and lineups else 0

    return {
        "total_lineups": len(lineups),
        "avg_projection": round(avg_proj, 2),
        "avg_salary": round(avg_sal, 0),
        "avg_ownership": 0,  # Would need ownership data
        "projection_range": f"{min_proj:.1f} - {max_proj:.1f}",
        "max_exposure": round(max_exposure, 2),
        "platform": "fanduel",
        "database_boosts": 0,
        "optimizer_used": "PuLP LP"
    }
