"""
Player-pool loader — database-first.

Reads SlatePlayer + Projection rows for a given slate_id and returns a
pandas DataFrame ready for the existing optimizer pipeline.

The DataFrame produced here is compatible with ``normalize_dataframe()``
in services/optimizer_service.py — using the canonical column names
``Name``, ``Projection``, ``Salary``, ``Position`` that the optimizer expects.
"""

from __future__ import annotations

from typing import Optional

import pandas as pd
from sqlalchemy.orm import Session

from models.player import Player
from models.projection import Projection
from models.slate import Slate


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def load_player_pool(
    db: Session,
    slate_id: str,
    exclude_injured: bool = False,
) -> pd.DataFrame:
    """
    Return an optimizer-ready DataFrame for *slate_id*.

    Columns included:
      - Name          — player display name
      - Position      — primary position (PG, SG …)
      - Team          — team abbreviation
      - Opponent      — opposing team abbreviation
      - Salary        — integer salary
      - Game          — game string (e.g. "BOS@MIA 07:30PM ET")
      - Projection    — projected fantasy points
      - Floor         — floor projection
      - Ceiling       — ceiling projection
      - Value         — pts per $1K salary
      - Ownership     — projected ownership %  (0.0 when unknown)
      - InjuryStatus  — injury tag or empty string
      - PlayerId      — slate_players.id  (internal UUID)
      - ExternalId    — platform's own player identifier

    Parameters
    ----------
    db:
        SQLAlchemy session.
    slate_id:
        UUID of the target slate.
    exclude_injured:
        When True, rows where InjuryStatus == "OUT" are filtered out.

    Raises
    ------
    ValueError
        When the slate does not exist or has no players with projections.
    """
    slate = db.get(Slate, slate_id)
    if slate is None:
        raise ValueError(f"Slate not found: {slate_id!r}")

    # ------------------------------------------------------------------
    # JOIN slate_players ⟵ projections
    # We use a left join so that players without projections still appear
    # (projection columns default to 0).
    # ------------------------------------------------------------------
    rows = (
        db.query(Player, Projection)
        .outerjoin(Projection, Projection.player_id == Player.id)
        .filter(Player.slate_id == slate_id)
        .all()
    )

    if not rows:
        raise ValueError(
            f"No players found for slate_id={slate_id!r}. "
            "Was the projections CSV uploaded?"
        )

    records = []
    for player, proj in rows:
        if proj is None:
            # Player uploaded without a matching projection row — use zeros.
            projection = floor = ceiling = value = 0.0
            injury_status = ""
            ownership = 0.0
        else:
            projection = proj.projection or 0.0
            floor = proj.floor or 0.0
            ceiling = proj.ceiling or 0.0
            value = proj.value or 0.0
            injury_status = proj.injury_status or ""
            ownership = proj.ownership_pct or 0.0

        record = {
            "Name": player.name,
            "Position": player.position or "UTIL",
            "Team": player.team or "",
            "Opponent": player.opponent or "",
            "Salary": player.salary or 0,
            "Game": player.game or "",
            "Projection": projection,
            "Floor": floor,
            "Ceiling": ceiling,
            "Value": value,
            "Ownership": ownership,
            "InjuryStatus": injury_status,
            "PlayerId": player.id,
            "ExternalId": player.external_id or "",
        }
        records.append(record)

    df = pd.DataFrame(records)

    if exclude_injured:
        df = df[df["InjuryStatus"].str.upper() != "OUT"].reset_index(drop=True)

    return df


def get_slate_metadata(db: Session, slate_id: str) -> dict:
    """
    Return a small summary dict for a slate.

    Useful for passing platform/sport context to the optimizer.
    """
    slate = db.get(Slate, slate_id)
    if slate is None:
        raise ValueError(f"Slate not found: {slate_id!r}")
    return {
        "id": slate.id,
        "platform": slate.platform,
        "sport": slate.sport,
        "slate_date": str(slate.slate_date) if slate.slate_date else None,
        "player_count": slate.player_count,
    }
