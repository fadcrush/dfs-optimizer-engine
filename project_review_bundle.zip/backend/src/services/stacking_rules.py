"""
Stacking Rules Engine - Build correlated lineups for GPP success
Implements professional stacking strategies used by top DFS players
"""

from typing import List, Dict, Set
import pandas as pd
from collections import defaultdict

class StackingRules:
    """
    Professional stacking logic for DFS lineup construction
    """
    
    def __init__(self, platform: str = "fanduel"):
        self.platform = platform.lower()
        
    def get_game_stacks(self, pool: pd.DataFrame, min_total: float = 220.0) -> List[Dict]:
        """
        Identify high-scoring games suitable for stacking
        
        Args:
            pool: Player pool DataFrame
            min_total: Minimum game total to consider (default 220)
        
        Returns:
            List of game stack opportunities
        """
        
        # Import Vegas service
        from services.vegas_service import VegasOddsService
        
        vegas_service = VegasOddsService()
        games = vegas_service.get_nba_odds()
        
        # Filter for high-scoring games
        high_scoring_games = []
        
        for game in games:
            total = game.get('total')
            
            if total and total >= min_total:
                high_scoring_games.append({
                    'home_team': game['home_team'],
                    'away_team': game['away_team'],
                    'total': total,
                    'home_implied': game.get('home_implied_points'),
                    'away_implied': game.get('away_implied_points')
                })
        
        print(f"\n🎲 STACKING ANALYSIS:")
        print(f"   Found {len(high_scoring_games)} high-scoring games (total ≥ {min_total})")
        
        for game in high_scoring_games:
            print(f"      {game['away_team']} @ {game['home_team']}: {game['total']} total")
        
        return high_scoring_games
    
    def build_primary_stack(self, pool: pd.DataFrame, team: str, min_players: int = 2, max_players: int = 4) -> List[Dict]:
        """
        Build primary stack from one team (same-game stack)
        
        Args:
            pool: Player pool
            team: Team to stack
            min_players: Minimum players in stack (default 2)
            max_players: Maximum players in stack (default 4)
        
        Returns:
            List of stack combinations
        """
        
        # Get players from this team
        team_players = pool[pool['Team'] == team].copy()
        
        if len(team_players) < min_players:
            return []
        
        # Sort by projection
        team_players = team_players.sort_values('Projection', ascending=False)
        
        # Build stack combinations
        stacks = []
        
        # Stack sizes: 2, 3, or 4 players
        for stack_size in range(min_players, min(max_players + 1, len(team_players) + 1)):
            # Take top N projected players
            stack_players = team_players.head(stack_size)
            
            stacks.append({
                'team': team,
                'players': stack_players['Name'].tolist(),
                'size': stack_size,
                'total_projection': stack_players['Projection'].sum(),
                'total_salary': stack_players['Salary'].sum()
            })
        
        return stacks
    
    def build_bring_back(self, pool: pd.DataFrame, primary_team: str, opponent_team: str, bring_back_count: int = 1) -> List[str]:
        """
        Build bring-back stack (counter player from opponent)
        
        In high-scoring games, use stars from BOTH teams for correlation
        
        Args:
            pool: Player pool
            primary_team: Team you're stacking
            opponent_team: Opposing team
            bring_back_count: How many opponent players (default 1)
        
        Returns:
            List of bring-back player names
        """
        
        # Get opponent's best players
        opponent_players = pool[pool['Team'] == opponent_team].copy()
        opponent_players = opponent_players.sort_values('Projection', ascending=False)
        
        # Get top N as bring-backs
        bring_backs = opponent_players.head(bring_back_count)['Name'].tolist()
        
        return bring_backs
    
    def identify_correlations(self, pool: pd.DataFrame) -> Dict[str, List[str]]:
        """
        Identify player correlations (positions that work well together)
        
        Examples:
        - PG + C (pick and roll)
        - PG + SG (backcourt)
        - PF + C (frontcourt)
        
        Returns:
            Dict mapping player names to correlated teammates
        """
        
        correlations = {}
        
        # Group by team
        for team in pool['Team'].unique():
            team_players = pool[pool['Team'] == team]
            
            for _, player in team_players.iterrows():
                player_name = player['Name']
                player_pos = str(player.get('PosBucket', player.get('Position', '')))
                
                # Find correlated positions on same team
                correlated = []
                
                for _, teammate in team_players.iterrows():
                    if teammate['Name'] == player_name:
                        continue
                    
                    teammate_pos = str(teammate.get('PosBucket', teammate.get('Position', '')))
                    
                    # Correlation rules
                    is_correlated = False
                    
                    # PG correlates with everyone (ball in hands)
                    if 'PG' in player_pos:
                        is_correlated = True
                    
                    # Big men correlate (PF + C)
                    if ('PF' in player_pos or 'C' in player_pos) and ('PF' in teammate_pos or 'C' in teammate_pos):
                        is_correlated = True
                    
                    # Guards correlate (PG + SG)
                    if ('PG' in player_pos or 'SG' in player_pos) and ('PG' in teammate_pos or 'SG' in teammate_pos):
                        is_correlated = True
                    
                    if is_correlated:
                        correlated.append(teammate['Name'])
                
                correlations[player_name] = correlated
        
        return correlations
    
    def validate_stack(self, lineup: List[str], min_same_team: int = 2) -> bool:
        """
        Validate that lineup has proper stacking
        
        Args:
            lineup: List of player names
            min_same_team: Minimum players from same team required
        
        Returns:
            True if lineup has valid stack
        """
        
        # Count players per team
        team_counts = defaultdict(int)
        
        for player in lineup:
            # Would need to look up team from pool
            # For now, simplified
            pass
        
        # Check if any team has min_same_team or more
        max_from_team = max(team_counts.values()) if team_counts else 0
        
        return max_from_team >= min_same_team
    
    def get_stacking_constraints(self, strategy: str = "balanced") -> Dict:
        """
        Get stacking constraints for different strategies
        
        Args:
            strategy: 'aggressive', 'balanced', 'conservative'
        
        Returns:
            Dict with stacking parameters
        """
        
        strategies = {
            'aggressive': {
                'min_stack_size': 3,
                'max_stack_size': 5,
                'require_bring_back': True,
                'max_from_one_team': 5,
                'min_games_stacked': 1
            },
            'balanced': {
                'min_stack_size': 2,
                'max_stack_size': 4,
                'require_bring_back': False,
                'max_from_one_team': 4,
                'min_games_stacked': 1
            },
            'conservative': {
                'min_stack_size': 2,
                'max_stack_size': 3,
                'require_bring_back': False,
                'max_from_one_team': 3,
                'min_games_stacked': 0
            }
        }
        
        return strategies.get(strategy, strategies['balanced'])


def analyze_stacking_opportunities(pool: pd.DataFrame) -> Dict:
    """
    Analyze player pool for stacking opportunities
    
    Args:
        pool: Player pool DataFrame
    
    Returns:
        Dict with stacking analysis
    """
    
    stacker = StackingRules()
    
    # Find high-scoring games
    high_scoring_games = stacker.get_game_stacks(pool, min_total=220.0)
    
    # Build potential stacks
    all_stacks = []
    
    for game in high_scoring_games:
        # Primary stacks from home team
        home_stacks = stacker.build_primary_stack(pool, game['home_team'])
        
        # Primary stacks from away team
        away_stacks = stacker.build_primary_stack(pool, game['away_team'])
        
        all_stacks.extend(home_stacks)
        all_stacks.extend(away_stacks)
    
    # Identify correlations
    correlations = stacker.identify_correlations(pool)
    
    return {
        'high_scoring_games': high_scoring_games,
        'potential_stacks': all_stacks,
        'correlations': correlations,
        'stack_count': len(all_stacks)
    }