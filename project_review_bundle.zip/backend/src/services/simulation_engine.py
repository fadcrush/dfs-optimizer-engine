"""
Monte Carlo Simulation Engine for DFS Lineup Evaluation
Professional-grade simulation framework for evaluating lineup outcomes

Phase 7: Enforced mandatory seeding for deterministic simulations.
"""

import numpy as np
import pandas as pd
import os
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, asdict
from concurrent.futures import ProcessPoolExecutor
import logging
from pathlib import Path
import json
from datetime import datetime

from projection.models import PlayerDecisionExplanation

# Optional audit trail import (graceful degradation)
try:
    from security.audit import AuditEventType
    from observability.audit_trail import bridge_audit_event
    HAS_AUDIT = True
except ImportError:
    HAS_AUDIT = False
    bridge_audit_event = None

logger = logging.getLogger(__name__)

# Default random seed for deterministic simulations
DEFAULT_SIMULATION_SEED = 1337


@dataclass
class SimulationConfig:
    """
    Configuration for Monte Carlo simulations.

    Determinism: random_seed defaults to 1337 for reproducible results.
    Same seed + same inputs = identical simulation outputs.
    """
    num_simulations: int = 10000
    random_seed: int = DEFAULT_SIMULATION_SEED  # MANDATORY: always seeded for determinism
    include_correlations: bool = True
    correlation_method: str = 'spearman'  # 'pearson' or 'spearman'
    min_correlation_threshold: float = 0.1
    game_correlation_weight: float = 0.3
    team_correlation_weight: float = 0.2
    position_correlation_weight: float = 0.1


@dataclass
class PlayerSimulation:
    """Individual player simulation results"""
    player_id: str
    player_name: str
    mean_projection: float
    std_deviation: float
    simulated_outcomes: np.ndarray
    percentile_10: float
    percentile_25: float
    percentile_75: float
    percentile_90: float
    floor_risk: float  # P(outcome < 0.8 * mean)
    ceiling_potential: float  # P(outcome > 1.2 * mean)


@dataclass
class LineupSimulation:
    """Complete lineup simulation results"""
    lineup_id: str
    total_salary: int
    player_simulations: List[PlayerSimulation]
    total_outcomes: np.ndarray
    mean_total: float
    std_total: float
    percentile_10_total: float
    percentile_25_total: float
    percentile_75_total: float
    percentile_90_total: float
    win_probability: float  # Estimated vs field
    roi_potential: float
    risk_score: float  # Volatility measure


# =============================================================================
# STARTING LINEUP OPPORTUNITY HELPER
# =============================================================================

MAX_MINUTES_DEFAULT = 38.0
TARGET_MULTIPLIER_DEFAULT = 5.0


@dataclass(frozen=True)
class PlayerStartInput:
    player_id: str
    player_name: str
    position: str
    team: str
    historical_start_rate: float
    beat_writer_confidence: float
    is_known_starter: bool = False
    is_inactive: bool = False
    max_minutes: Optional[float] = None


@dataclass(frozen=True)
class PlayerStartOutput:
    player_id: str
    player_name: str
    position: str
    start_probability: float
    expected_minutes: float


@dataclass(frozen=True)
class LineupPrediction:
    team: str
    starters: List[PlayerStartOutput]
    bench: List[PlayerStartOutput]
    volatility: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "team": self.team,
            "starters": [asdict(p) for p in self.starters],
            "bench": [asdict(p) for p in self.bench],
            "volatility": self.volatility,
        }


@dataclass(frozen=True)
class OpportunityAdjustment:
    """
    Injury-based opportunity adjustment for simulation variance.
    
    CRITICAL DESIGN PRINCIPLE:
    - Base projections (FPPM, minutes, usage) remain UNCHANGED
    - Adjustments affect ONLY variance (std_dev) in simulations
    - Represents uncertainty in replacement opportunity allocation
    
    Why adjust variance, not mean?
        When a player is OUT, replacement candidates get uncertain opportunity.
        We don't know exactly how minutes/usage will distribute, so we widen
        the range of simulated outcomes while keeping the expected value unchanged.
    
    Fields:
        minutes_delta: Expected change in minutes (positive or negative)
        usage_delta: Expected change in usage rate (positive or negative)
        source: Source of adjustment (e.g., "INJURY_REPLACEMENT", "BEAT_WRITER")
        reason: Human-readable explanation for audit trail
    
    Example:
        >>> adj = OpportunityAdjustment(
        ...     minutes_delta=8.5,
        ...     usage_delta=3.2,
        ...     source="INJURY_REPLACEMENT",
        ...     reason="Replacing injured Damian Lillard (OUT)"
        ... )
    """
    minutes_delta: float
    usage_delta: float
    source: str
    reason: str
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for audit logging."""
        return {
            "minutes_delta": self.minutes_delta,
            "usage_delta": self.usage_delta,
            "source": self.source,
            "reason": self.reason,
        }


def predict_starting_lineup_opportunity(
    team: str,
    players: List[PlayerStartInput],
) -> LineupPrediction:
    """
    Predict a starting lineup with opportunity-based probabilities.

    Inputs:
    - Team
    - Known starters
    - Inactive players
    - Beat-writer confidence scores
    - Historical start rates

    Outputs:
    - Probability-adjusted starting lineup
    - Expected minutes per player (sum = 240)
    - Volatility flag (LOW / MEDIUM / HIGH)

    Constraints:
    - Total minutes must equal 240
    - No player exceeds realistic max minutes
    - Confidence-weighted averaging (no hard locks)
    """
    if not players:
        return LineupPrediction(team=team, starters=[], bench=[], volatility="HIGH")

    active_players = [p for p in players if not p.is_inactive]
    if not active_players:
        return LineupPrediction(team=team, starters=[], bench=[], volatility="HIGH")

    scored = []
    for player in active_players:
        start_prob = _compute_start_probability(player)
        scored.append((start_prob, player))

    # Rank by probability for each position
    starters = []
    bench = []
    for pos in _unique_positions(active_players):
        pos_players = [(prob, p) for prob, p in scored if p.position == pos]
        pos_players.sort(key=lambda item: (-item[0], item[1].player_name))
        if pos_players:
            starters.append(pos_players[0])
            bench.extend(pos_players[1:])

    # Flatten and compute expected minutes
    outputs = []
    for prob, player in scored:
        max_minutes = player.max_minutes or MAX_MINUTES_DEFAULT
        expected = _expected_minutes_from_probability(prob, max_minutes)
        outputs.append(PlayerStartOutput(
            player_id=player.player_id,
            player_name=player.player_name,
            position=player.position,
            start_probability=round(prob, 4),
            expected_minutes=expected,
        ))

    outputs = _normalize_minutes(outputs, total_minutes=240.0)

    starters_out = [o for o in outputs if any(s[1].player_id == o.player_id for s in starters)]
    bench_out = [o for o in outputs if o.player_id not in {s.player_id for s in starters_out}]

    volatility = _compute_volatility_flag(outputs)

    return LineupPrediction(
        team=team,
        starters=starters_out,
        bench=bench_out,
        volatility=volatility,
    )


def _compute_start_probability(player: PlayerStartInput) -> float:
    # Weighted blend: historical rate is the anchor, beat writer adds confidence.
    history = _clamp(player.historical_start_rate, 0.0, 1.0)
    beat = _clamp(player.beat_writer_confidence, 0.0, 1.0)

    known_bonus = 0.08 if player.is_known_starter else 0.0
    inactive_penalty = 0.25 if player.is_inactive else 0.0

    prob = (history * 0.70) + (beat * 0.25) + known_bonus - inactive_penalty
    return _clamp(prob, 0.02, 0.98)


def _expected_minutes_from_probability(prob: float, max_minutes: float) -> float:
    # Use a soft blend to avoid hard locks.
    starter_minutes = max(28.0, min(max_minutes, 38.0))
    bench_minutes = max(10.0, starter_minutes * 0.55)
    return round((prob * starter_minutes) + ((1.0 - prob) * bench_minutes), 2)


def _normalize_minutes(players: List[PlayerStartOutput], total_minutes: float) -> List[PlayerStartOutput]:
    current_total = sum(p.expected_minutes for p in players)
    if current_total <= 0:
        return players

    ratio = total_minutes / current_total
    normalized = []
    for p in players:
        max_minutes = MAX_MINUTES_DEFAULT
        new_minutes = min(p.expected_minutes * ratio, max_minutes)
        normalized.append(PlayerStartOutput(
            player_id=p.player_id,
            player_name=p.player_name,
            position=p.position,
            start_probability=p.start_probability,
            expected_minutes=round(new_minutes, 2),
        ))

    # Final adjustment to hit exactly 240 by distributing residual.
    residual = total_minutes - sum(p.expected_minutes for p in normalized)
    if abs(residual) >= 0.05 and normalized:
        top_idx = max(range(len(normalized)), key=lambda i: normalized[i].expected_minutes)
        top = normalized[top_idx]
        adjusted = min(top.expected_minutes + residual, MAX_MINUTES_DEFAULT)
        normalized[top_idx] = PlayerStartOutput(
            player_id=top.player_id,
            player_name=top.player_name,
            position=top.position,
            start_probability=top.start_probability,
            expected_minutes=round(adjusted, 2),
        )

    return normalized


def _compute_volatility_flag(players: List[PlayerStartOutput]) -> str:
    if not players:
        return "HIGH"

    probs = [p.start_probability for p in players]
    spread = max(probs) - min(probs) if probs else 0.0

    if spread >= 0.55:
        return "LOW"
    if spread >= 0.30:
        return "MEDIUM"
    return "HIGH"


def _unique_positions(players: List[PlayerStartInput]) -> List[str]:
    seen = []
    for p in players:
        if p.position not in seen:
            seen.append(p.position)
    return seen


def _clamp(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))


class MonteCarloEngine:
    """
    Professional Monte Carlo simulation engine for DFS lineups.
    Evaluates 10,000+ lineup outcomes with correlation modeling.

    DETERMINISTIC: Always seeds RNG for reproducible simulations.
    Same inputs + same seed = identical outputs across runs.
    """

    def __init__(self, config: SimulationConfig = None):
        self.config = config or SimulationConfig()
        # =====================================================================
        # MANDATORY SEEDING: Always seed for determinism (no conditional)
        # Default seed is 1337 if not specified in config.
        # =====================================================================
        seed = self.config.random_seed or DEFAULT_SIMULATION_SEED
        np.random.seed(seed)
        logger.debug(f"MonteCarloEngine initialized with seed={seed}")

        self.correlation_matrix = None
        self.player_data = None
        self.game_context = None
        self.opportunity_adjustments: Dict[str, OpportunityAdjustment] = {}

    def load_player_data(self, projections_df: pd.DataFrame) -> None:
        """
        Load player projections and prepare for simulation
        """
        self.player_data = projections_df.copy()

        # Ensure required columns exist
        required_cols = ['player_id', 'player_name', 'base_projection', 'team', 'opponent', 'position']
        missing_cols = [col for col in required_cols if col not in self.player_data.columns]
        if missing_cols:
            raise ValueError(f"Missing required columns: {missing_cols}")

        # Calculate historical variance if available
        if 'historical_std' not in self.player_data.columns:
            # Estimate variance from projection ranges
            if 'ceiling' in self.player_data.columns and 'floor' in self.player_data.columns:
                self.player_data['historical_std'] = (self.player_data['ceiling'] - self.player_data['floor']) / 4  # Rough estimate
            else:
                # Default variance based on position and projection
                self.player_data['historical_std'] = self.player_data['base_projection'] * 0.25

        # Detect lineage opportunity adjustments (if present)
        # These are TEMPORARY columns added by apply_lineage_temporarily()
        
        # Preserve lineage_confidence from input if it exists
        has_lineage_confidence_input = 'lineage_confidence' in self.player_data.columns
        if has_lineage_confidence_input:
            input_lineage_confidence = self.player_data['lineage_confidence'].copy()
        
        # Initialize lineage tracking columns
        self.player_data['has_lineage'] = False
        self.player_data['lineage_confidence'] = 1.0
        
        if 'opportunity_source' in self.player_data.columns:
            # Mark players with injury replacement lineages
            lineage_mask = self.player_data['opportunity_source'] == 'INJURY_REPLACEMENT'
            self.player_data.loc[lineage_mask, 'has_lineage'] = True
            
            # Restore confidence scores from input if they were provided
            if has_lineage_confidence_input:
                self.player_data.loc[lineage_mask, 'lineage_confidence'] = (
                    input_lineage_confidence.loc[lineage_mask].fillna(1.0)
                )

        # Add game context factors
        self._add_game_context_factors()
        
        # Add lineage variance factors (injury replacements have higher variance)
        self._add_lineage_variance_factors()

        logger.info(f"Loaded {len(self.player_data)} players for simulation")

    @staticmethod
    def prune_player_pool(
        projections_df: pd.DataFrame,
        signals: Optional[List[Dict[str, Any]]] = None,
        value_threshold: float = 4.2,
        min_minutes: float = 16.0,
        min_usage: float = 0.14,
        negative_signal_threshold: float = -0.5,
    ) -> Tuple[pd.DataFrame, List[Dict[str, Any]], List[Dict[str, Any]]]:
        """
        Prune low-quality plays before optimization/simulation.

        Removes players who are unlikely to exceed value threshold, lack
        minutes/usage opportunity, or have negative/conflicting signals.
        Logs the exact reason for removal for auditability.

        Bias safeguard: pruning NEVER considers player name, star status,
        or reputation. Decisions are strictly based on opportunity, minutes,
        usage, value, and signals.
        """
        if projections_df.empty:
            return projections_df, [], []

        df = projections_df.copy()
        removals: List[Dict[str, Any]] = []

        projection_field = _pick_first_existing(
            df,
            ["base_projection", "projection", "proj", "My Proj", "My_Proj"],
        )
        ceiling_field = _pick_first_existing(df, ["ceiling", "Ceiling"])
        salary_field = _pick_first_existing(df, ["salary", "Salary"])
        minutes_field = _pick_first_existing(df, ["minutes", "Minutes", "proj_minutes"])
        usage_field = _pick_first_existing(df, ["usage", "Usage", "usage_rate"])
        name_field = _pick_first_existing(df, ["player_name", "name", "Name"])

        if projection_field is None or salary_field is None:
            logger.warning("Prune skipped: missing projection or salary field")
            return df, [], []

        signals_by_player = _index_signals_by_player_name(signals or [])

        keep_rows = []
        explanations: List[Dict[str, Any]] = []
        for idx, row in df.iterrows():
            player_name = row.get(name_field, f"player_{idx}") if name_field else f"player_{idx}"
            projection = float(row.get(projection_field) or 0.0)
            salary = float(row.get(salary_field) or 0.0)
            minutes = float(row.get(minutes_field) or 0.0) if minutes_field else None
            usage = float(row.get(usage_field) or 0.0) if usage_field else None
            ceiling = float(row.get(ceiling_field) or 0.0) if ceiling_field else None

            reasons = []

            # Value threshold: use ceiling if available, else a small uplift on projection.
            if salary > 0:
                projected_ceiling = ceiling if ceiling and ceiling > 0 else projection * 1.15
                value_ratio = projected_ceiling / (salary / 1000.0)
                if value_ratio < value_threshold:
                    reasons.append(
                        f"value_ceiling {value_ratio:.2f} < {value_threshold:.2f}"
                    )

            # Minutes/usage opportunity checks.
            if minutes is not None and minutes < min_minutes:
                reasons.append(f"minutes {minutes:.1f} < {min_minutes:.1f}")

            if usage is not None and usage < min_usage:
                reasons.append(f"usage {usage:.2f} < {min_usage:.2f}")

            # Negative or conflicting signals.
            player_signals = signals_by_player.get(str(player_name).lower(), [])
            signal_impact_summary = _summarize_signal_impact(player_signals)
            if _has_negative_or_conflicting_signal(player_signals, negative_signal_threshold):
                reasons.append("negative_or_conflicting_signal")

            if reasons:
                removals.append({
                    "player": player_name,
                    "reasons": reasons,
                })
                explanations.append(PlayerDecisionExplanation(
                    player_name=str(player_name),
                    decision="EXCLUDED",
                    projection=round(projection, 2),
                    salary=round(salary, 2),
                    value_target=round(value_threshold, 2),
                    signal_impact=signal_impact_summary,
                    minutes_expected=round(minutes or 0.0, 2),
                    final_reason=_format_final_reason(reasons),
                ).to_dict())
                logger.info("Pruned %s: %s", player_name, "; ".join(reasons))
                continue

            keep_rows.append(idx)
            explanations.append(PlayerDecisionExplanation(
                player_name=str(player_name),
                decision="INCLUDED",
                projection=round(projection, 2),
                salary=round(salary, 2),
                value_target=round(value_threshold, 2),
                signal_impact=signal_impact_summary,
                minutes_expected=round(minutes or 0.0, 2),
                final_reason="Passed value, opportunity, and signal checks.",
            ).to_dict())

        return df.loc[keep_rows].reset_index(drop=True), removals, explanations

    def _add_game_context_factors(self) -> None:
        """Add game-specific context factors that affect variance"""
        # Vegas line differential (favorite vs underdog)
        if 'vegas_spread' in self.player_data.columns:
            self.player_data['game_importance'] = np.abs(self.player_data['vegas_spread'])
        else:
            self.player_data['game_importance'] = 1.0

        # Rest days (back-to-back games increase variance)
        if 'rest_days' in self.player_data.columns:
            self.player_data['rest_factor'] = np.where(self.player_data['rest_days'] == 0, 1.2, 1.0)
        else:
            self.player_data['rest_factor'] = 1.0

        # Combine game factors (lineage factors added separately)
        self.player_data['game_variance_multiplier'] = (
            self.player_data['game_importance'] * self.player_data['rest_factor']
        )

    def _add_lineage_variance_factors(self) -> None:
        """
        Add variance multipliers for injury replacement lineages.
        
        CRITICAL DESIGN:
        - Base FPPM (mean projection) remains UNCHANGED
        - Only variance increases to model replacement volatility
        - Higher variance for lower confidence lineages
        
        Philosophy:
            "Replacement minutes are volatile - model it."
            A player stepping into a starter role has uncertain minutes allocation,
            role changes, and usage patterns. The mean stays the same (our estimate),
            but the range of outcomes widens.
        
        Variance adjustments:
        - Standard lineage (confidence >= 0.6): +12.5% variance
        - Low confidence lineage (confidence < 0.6): +20% variance
        
        Why:
        - Beat writers give us confidence in the replacement
        - High confidence = more certain, modest variance increase
        - Low confidence = speculative, wider variance increase
        """
        # Initialize lineage variance multiplier to 1.0 (no change)
        self.player_data['lineage_variance_multiplier'] = 1.0
        
        # Apply variance increases for injury replacement lineages
        lineage_mask = self.player_data['has_lineage'] == True
        
        if lineage_mask.any():
            # Standard lineage: +12.5% variance (midpoint of +10-15% range)
            standard_lineage_mask = lineage_mask & (self.player_data['lineage_confidence'] >= 0.6)
            self.player_data.loc[standard_lineage_mask, 'lineage_variance_multiplier'] = 1.125
            
            # Low confidence lineage: +20% variance (wider uncertainty)
            low_confidence_mask = lineage_mask & (self.player_data['lineage_confidence'] < 0.6)
            self.player_data.loc[low_confidence_mask, 'lineage_variance_multiplier'] = 1.20
            
            n_standard = standard_lineage_mask.sum()
            n_low_conf = low_confidence_mask.sum()
            
            logger.info(
                f"Applied lineage variance: {n_standard} standard (+12.5%), "
                f"{n_low_conf} low-confidence (+20%)"
            )
        
        # Apply opportunity-based variance adjustments (NEW)
        self._add_opportunity_variance_adjustments()
        
        # Combine all variance multipliers
        self.player_data['variance_multiplier'] = (
            self.player_data['game_variance_multiplier'] * 
            self.player_data['lineage_variance_multiplier']
        )
    
    def _add_opportunity_variance_adjustments(self) -> None:
        """
        Apply injury-based opportunity adjustments to simulation variance ONLY.
        
        SYSTEM CONTRACTS:
        - Base projections NEVER modified (FPPM, minutes, usage unchanged)
        - Adjustments affect ONLY variance (minutes_std, usage_std)
        - Fully deterministic (no random sampling)
        - All adjustments audited
        - Feature-flagged (OPTIMIZER_INJURY_OPPORTUNITY_ENABLED)
        
        How it works:
            When a player has an opportunity adjustment (e.g., replacing injured player),
            we increase the variance of their simulated outcomes based on the magnitude
            of minutes_delta and usage_delta. Larger opportunity changes = wider variance.
        
        Variance formula:
            variance_increase = sqrt(minutes_delta^2 + usage_delta^2) / 20
            new_variance_multiplier = 1.0 + variance_increase
        
        Example:
            minutes_delta = 10, usage_delta = 5
            variance_increase = sqrt(100 + 25) / 20 = sqrt(125) / 20 ≈ 0.559
            multiplier = 1.559 (≈ +56% variance)
        
        Why this works:
            Larger opportunity changes create more uncertainty in outcomes.
            The quadratic relationship captures that big changes are exponentially
            more uncertain than small changes.
        """
        # Feature flag check
        if not self._is_opportunity_adjustment_enabled():
            logger.debug(
                "Opportunity variance adjustment disabled "
                "(OPTIMIZER_INJURY_OPPORTUNITY_ENABLED=false)"
            )
            return
        
        if not self.opportunity_adjustments:
            logger.debug("No opportunity adjustments to apply")
            return
        
        # Track adjustments for audit logging
        adjustments_applied = 0
        
        for idx, row in self.player_data.iterrows():
            player_id = row['player_id']
            
            if player_id not in self.opportunity_adjustments:
                continue
            
            adjustment = self.opportunity_adjustments[player_id]
            
            # Calculate variance increase based on opportunity magnitude
            # Using Euclidean distance to combine minutes and usage deltas
            opportunity_magnitude = np.sqrt(
                adjustment.minutes_delta ** 2 + adjustment.usage_delta ** 2
            )
            
            # Scale to reasonable variance multiplier (divide by 20 for calibration)
            # This gives ~0.5 variance increase for a 10-minute change
            variance_increase = opportunity_magnitude / 20.0
            
            # New variance multiplier (additive, not multiplicative)
            # Baseline lineage_variance_multiplier is already applied
            current_multiplier = row['lineage_variance_multiplier']
            new_multiplier = current_multiplier + variance_increase
            
            # Update variance multiplier
            self.player_data.at[idx, 'lineage_variance_multiplier'] = new_multiplier
            
            # Log audit event
            if HAS_AUDIT and bridge_audit_event:
                try:
                    bridge_audit_event(
                        event_type=AuditEventType.INJURY_OPPORTUNITY_VARIANCE_APPLIED,
                        action="apply_opportunity_variance",
                        resource="simulation_variance",
                        resource_id=player_id,
                        details={
                            "player_id": player_id,
                            "player_name": row['player_name'],
                            "minutes_delta": adjustment.minutes_delta,
                            "usage_delta": adjustment.usage_delta,
                            "opportunity_magnitude": round(opportunity_magnitude, 2),
                            "variance_increase": round(variance_increase, 4),
                            "previous_multiplier": round(current_multiplier, 4),
                            "new_multiplier": round(new_multiplier, 4),
                            "source": adjustment.source,
                            "reason": adjustment.reason,
                        }
                    )
                except Exception as e:
                    logger.warning(
                        f"Failed to log opportunity variance audit for {player_id}: {e}"
                    )
            
            adjustments_applied += 1
        
        if adjustments_applied > 0:
            logger.info(
                f"Applied {adjustments_applied} opportunity variance adjustments "
                f"(feature: OPTIMIZER_INJURY_OPPORTUNITY_ENABLED)"
            )
    
    def set_opportunity_adjustments(
        self, 
        adjustments: Dict[str, OpportunityAdjustment]
    ) -> None:
        """
        Set opportunity adjustments for simulation variance.
        
        MUST be called BEFORE load_player_data() or the adjustments won't apply.
        
        Args:
            adjustments: Dict mapping player_id to OpportunityAdjustment
        
        Example:
            >>> engine = MonteCarloEngine()
            >>> adjustments = {
            ...     "1629663": OpportunityAdjustment(
            ...         minutes_delta=8.5,
            ...         usage_delta=3.2,
            ...         source="INJURY_REPLACEMENT",
            ...         reason="Replacing Damian Lillard (OUT)"
            ...     )
            ... }
            >>> engine.set_opportunity_adjustments(adjustments)
            >>> engine.load_player_data(df)
        """
        self.opportunity_adjustments = adjustments or {}
        logger.debug(f"Set {len(self.opportunity_adjustments)} opportunity adjustments")
    
    @staticmethod
    def _is_opportunity_adjustment_enabled() -> bool:
        """
        Check if opportunity variance adjustment feature is enabled.
        
        Returns:
            True if OPTIMIZER_INJURY_OPPORTUNITY_ENABLED=true, False otherwise
        """
        return os.environ.get("OPTIMIZER_INJURY_OPPORTUNITY_ENABLED", "false").lower() == "true"

    def build_correlation_matrix(self) -> None:
        """
        Build correlation matrix for realistic outcome simulation
        Considers game, team, and position correlations
        """
        if not self.config.include_correlations:
            self.correlation_matrix = None
            return

        n_players = len(self.player_data)
        correlation_matrix = np.eye(n_players)  # Start with identity matrix

        # Game-level correlations (players in same game)
        game_groups = self.player_data.groupby('game_id')
        for game_id, group in game_groups:
            if len(group) > 1:
                indices = group.index.tolist()
                # Add correlation between teammates and opponents
                for i in indices:
                    for j in indices:
                        if i != j:
                            team_i = self.player_data.loc[i, 'team']
                            team_j = self.player_data.loc[j, 'team']
                            if team_i == team_j:
                                correlation_matrix[i, j] += self.config.team_correlation_weight
                            else:
                                correlation_matrix[i, j] += self.config.game_correlation_weight

        # Position correlations (guards correlate with guards, etc.)
        position_groups = self.player_data.groupby('position')
        for pos, group in position_groups:
            if len(group) > 1:
                indices = group.index.tolist()
                for i in indices:
                    for j in indices:
                        if i != j:
                            correlation_matrix[i, j] += self.config.position_correlation_weight

        # Ensure matrix is positive semi-definite
        eigenvals = np.linalg.eigvals(correlation_matrix)
        if np.any(eigenvals < 0):
            # Regularize negative eigenvalues
            correlation_matrix += np.eye(n_players) * 0.01

        # Clip correlations to reasonable bounds
        correlation_matrix = np.clip(correlation_matrix, -0.8, 0.8)

        self.correlation_matrix = correlation_matrix
        logger.info(f"Built {n_players}x{n_players} correlation matrix")

    def simulate_player_outcomes(self, player_idx: int) -> PlayerSimulation:
        """
        Simulate outcomes for a single player.
        
        CRITICAL: Uses lineage-adjusted variance but keeps mean unchanged.
        Base FPPM never changes - only the spread of outcomes widens.
        """
        player = self.player_data.iloc[player_idx]
        mean_proj = player['base_projection']  # NEVER MODIFIED
        
        # Variance adjusted for game context AND lineage volatility
        std_dev = player['historical_std'] * player['variance_multiplier']

        # Generate random outcomes
        # Note: For single player, use simple normal distribution
        # Correlation is applied at the lineup level when simulating multiple players together
        outcomes = np.random.normal(mean_proj, std_dev, self.config.num_simulations)

        # Ensure non-negative outcomes (floor at 0)
        outcomes = np.maximum(outcomes, 0)

        # Calculate statistics
        percentiles = np.percentile(outcomes, [10, 25, 75, 90])

        floor_risk = np.mean(outcomes < 0.8 * mean_proj)
        ceiling_potential = np.mean(outcomes > 1.2 * mean_proj)

        return PlayerSimulation(
            player_id=player['player_id'],
            player_name=player['player_name'],
            mean_projection=mean_proj,
            std_deviation=std_dev,
            simulated_outcomes=outcomes,
            percentile_10=percentiles[0],
            percentile_25=percentiles[1],
            percentile_75=percentiles[2],
            percentile_90=percentiles[3],
            floor_risk=floor_risk,
            ceiling_potential=ceiling_potential
        )

    def simulate_lineup(self, lineup_players: List[Dict], lineup_id: str = "test") -> LineupSimulation:
        """
        Simulate complete lineup outcomes
        """
        player_simulations = []

        # Simulate each player
        for player in lineup_players:
            player_idx = self.player_data[self.player_data['player_id'] == player['player_id']].index[0]
            player_sim = self.simulate_player_outcomes(player_idx)
            player_simulations.append(player_sim)

        # Combine outcomes
        total_outcomes = np.sum([ps.simulated_outcomes for ps in player_simulations], axis=0)

        # Calculate lineup statistics
        mean_total = np.mean(total_outcomes)
        std_total = np.std(total_outcomes)
        percentiles_total = np.percentile(total_outcomes, [10, 25, 75, 90])

        # Estimate win probability (simplified - would need field data)
        win_probability = 0.5  # Placeholder

        # Calculate ROI potential and risk
        roi_potential = (mean_total - 0) / 1000  # Simplified
        risk_score = std_total / mean_total  # Coefficient of variation

        total_salary = sum(p.get('salary', 0) for p in lineup_players)

        return LineupSimulation(
            lineup_id=lineup_id,
            total_salary=total_salary,
            player_simulations=player_simulations,
            total_outcomes=total_outcomes,
            mean_total=mean_total,
            std_total=std_total,
            percentile_10_total=percentiles_total[0],
            percentile_25_total=percentiles_total[1],
            percentile_75_total=percentiles_total[2],
            percentile_90_total=percentiles_total[3],
            win_probability=win_probability,
            roi_potential=roi_potential,
            risk_score=risk_score
        )

    def calculate_ceiling_probability(
        self,
        player_id: str,
        ceiling_threshold: float = 1.2,
        num_simulations: Optional[int] = None,
    ) -> float:
        """
        Calculate ceiling probability for a player WITHOUT mutating state.
        
        CRITICAL GUARANTEE:
        - This function is READ-ONLY
        - No player state is modified
        - Can be called multiple times with same results
        - Safe for concurrent evaluation
        
        Args:
            player_id: Unique player identifier
            ceiling_threshold: Multiplier for ceiling (default 1.2 = 120% of projection)
            num_simulations: Number of simulations (default: use engine config)
        
        Returns:
            Probability (0.0-1.0) that player exceeds ceiling threshold
        
        Raises:
            ValueError if player not found in loaded data
        """
        # Find player in loaded data
        player_mask = self.player_data['player_id'] == player_id
        
        if not player_mask.any():
            raise ValueError(f"Player {player_id} not found in loaded player data")
        
        player = self.player_data[player_mask].iloc[0]
        
        # Extract parameters (no mutation)
        mean_proj = player['base_projection']
        std_dev = player['historical_std'] * player['variance_multiplier']
        
        # Run simulation (independent of existing simulations)
        n_sims = num_simulations or self.config.num_simulations
        outcomes = np.random.normal(mean_proj, std_dev, n_sims)
        outcomes = np.maximum(outcomes, 0)  # Floor at 0
        
        # Calculate ceiling probability
        ceiling_value = mean_proj * ceiling_threshold
        ceiling_prob = np.mean(outcomes > ceiling_value)
        
        logger.debug(
            f"Ceiling probability for {player['player_name']}: {ceiling_prob:.3f} "
            f"(threshold={ceiling_threshold}x, lineage_var={player['lineage_variance_multiplier']:.2f})"
        )
        
        return float(ceiling_prob)

    def run_lineup_comparison(self, lineups: List[List[Dict]]) -> Dict:
        """
        Compare multiple lineups through simulation
        """
        results = []

        for i, lineup in enumerate(lineups):
            sim_result = self.simulate_lineup(lineup, f"lineup_{i+1}")
            results.append(sim_result)

        # Calculate relative performance
        all_totals = np.array([r.total_outcomes for r in results])

        # Pairwise win probabilities
        win_matrix = np.zeros((len(results), len(results)))
        for i in range(len(results)):
            for j in range(len(results)):
                if i != j:
                    win_matrix[i, j] = np.mean(all_totals[i] > all_totals[j])

        return {
            'lineup_simulations': results,
            'win_probability_matrix': win_matrix,
            'best_lineup_idx': np.argmax([r.mean_total for r in results]),
            'simulation_config': self.config.__dict__
        }

    def save_simulation_results(self, results: Dict, output_path: Path) -> None:
        """
        Save simulation results for analysis
        """
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # Convert to serializable format
        serializable_results = {
            'timestamp': datetime.now().isoformat(),
            'config': self.config.__dict__,
            'lineup_results': []
        }

        for sim in results['lineup_simulations']:
            lineup_data = {
                'lineup_id': sim.lineup_id,
                'total_salary': sim.total_salary,
                'mean_total': sim.mean_total,
                'std_total': sim.std_total,
                'percentile_10_total': sim.percentile_10_total,
                'percentile_25_total': sim.percentile_25_total,
                'percentile_75_total': sim.percentile_75_total,
                'percentile_90_total': sim.percentile_90_total,
                'win_probability': sim.win_probability,
                'roi_potential': sim.roi_potential,
                'risk_score': sim.risk_score,
                'players': [
                    {
                        'player_id': ps.player_id,
                        'player_name': ps.player_name,
                        'mean_projection': ps.mean_projection,
                        'std_deviation': ps.std_deviation,
                        'percentile_10': ps.percentile_10,
                        'percentile_25': ps.percentile_25,
                        'percentile_75': ps.percentile_75,
                        'percentile_90': ps.percentile_90,
                        'floor_risk': ps.floor_risk,
                        'ceiling_potential': ps.ceiling_potential
                    } for ps in sim.player_simulations
                ]
            }
            serializable_results['lineup_results'].append(lineup_data)

        with open(output_path, 'w') as f:
            json.dump(serializable_results, f, indent=2, default=str)

        logger.info(f"Saved simulation results to {output_path}")


# Convenience functions for API integration
async def run_lineup_simulation(
    projections_df: pd.DataFrame,
    lineups: List[List[Dict]],
    num_simulations: int = 10000,
    signals: Optional[List[Dict[str, Any]]] = None,
    prune_config: Optional[Dict[str, Any]] = None,
) -> Dict:
    """
    High-level function to run lineup simulations
    """

    config = SimulationConfig(num_simulations=num_simulations)
    engine = MonteCarloEngine(config)

    try:
        prune_kwargs = prune_config or {}
        pruned_df, removals, explanations = engine.prune_player_pool(
            projections_df,
            signals=signals,
            **prune_kwargs,
        )

        engine.load_player_data(pruned_df)
        engine.build_correlation_matrix()

        results = engine.run_lineup_comparison(lineups)

        return {
            'success': True,
            'results': results,
            'config': config.__dict__,
            'pruned_count': len(removals),
            'pruned_players': removals,
            'decision_explanations': explanations,
        }

    except Exception as e:
        logger.error(f"Simulation failed: {e}")
        return {
            'success': False,
            'error': str(e)
        }


if __name__ == "__main__":
    # Example usage
    print("Monte Carlo Simulation Engine")
    print("Ready for integration with DFS pipeline")


def _pick_first_existing(df: pd.DataFrame, candidates: List[str]) -> Optional[str]:
    for field in candidates:
        if field in df.columns:
            return field
    return None


def _index_signals_by_player_name(signals: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
    indexed: Dict[str, List[Dict[str, Any]]] = {}
    for signal in signals:
        name = signal.get("player_name") or signal.get("name") or signal.get("player")
        if not name:
            continue
        key = str(name).lower()
        indexed.setdefault(key, []).append(signal)
    return indexed


def _has_negative_or_conflicting_signal(
    signals: List[Dict[str, Any]],
    negative_signal_threshold: float,
) -> bool:
    for signal in signals:
        signal_type = str(signal.get("signal_type") or signal.get("type") or "").lower()
        impact = float(signal.get("impact") or 0.0)
        status = str(signal.get("status") or signal.get("lineup_status") or "").lower()
        tags = signal.get("tags") or []
        tags_lower = [str(t).lower() for t in tags]

        if signal_type == "injury_out" or status in ("out", "not_playing", "dnp"):
            return True
        if impact <= negative_signal_threshold:
            return True
        if "conflict" in tags_lower or "contradiction" in tags_lower:
            return True

    return False


def _summarize_signal_impact(signals: List[Dict[str, Any]]) -> str:
    if not signals:
        return "No active signals"

    total = 0.0
    details = []
    for signal in signals:
        signal_type = str(signal.get("signal_type") or signal.get("type") or "unknown").lower()
        impact = float(signal.get("impact") or 0.0)
        confidence = float(signal.get("confidence") or 1.0)
        weighted = impact * confidence
        total += weighted
        details.append(f"{signal_type}:{weighted:+.2f}")

    detail_text = ", ".join(details[:3])
    if len(details) > 3:
        detail_text += f" (+{len(details) - 3} more)"

    return f"Net {total:+.2f} ({detail_text})"


def _format_final_reason(reasons: List[str]) -> str:
    if not reasons:
        return "Passed all checks."
    return "Excluded because " + "; ".join(reasons) + "."


def evaluate_player_ceiling(
    player: Dict[str, Any],
    salary: float,
    signals: Optional[List[Dict[str, Any]]] = None,
    target_multiplier: float = TARGET_MULTIPLIER_DEFAULT,
    num_simulations: int = 5000,
    explain: bool = False,
    opportunity_adjustments: Optional[List[Dict[str, Any]]] = None,
    replacement_context: Optional[Dict[str, Any]] = None,
    start_probability: Optional[float] = None,
    tenure: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Evaluate player ceiling metrics using Monte Carlo simulation with variable target multipliers.
    
    SUPPORTS VARIABLE TARGET MULTIPLIERS:
    Can receive dynamic multipliers from get_required_multiplier() based on salary tier
    and signal-based adjustments, or use default 5.0x multiplier.
    
    SUPPORTS INJURY REPLACEMENT LINEAGE ADJUSTMENTS:
    Can receive opportunity adjustments from injury replacement lineages, which are applied
    to minutes_mean and usage_mean BEFORE simulation runs. This allows injury-based
    opportunity boosts to affect ceiling probability calculations.
    
    SUPPORTS REPLACEMENT CONTEXT FROM LINEAGE MODELS:
    Can receive structured replacement lineage data (from ReplacementLineage model)
    which provides deterministic role adjustments with confidence-based scaling and
    variance tuning based on confirmation sources (lineup vs beat writer).
    
    Args:
        player: Player dict with projection, minutes, usage data
        salary: Player salary (used to compute target points)
        signals: Optional list of signal dicts (injury, lineup, role changes)
        target_multiplier: Fantasy points per $1K salary threshold (default: 5.0x)
                          Can be dynamically calculated (e.g., 4.5x for studs, 5.0x for value)
        num_simulations: Number of Monte Carlo simulations (default: 5000)
        explain: Whether to include distribution explanations in output
        opportunity_adjustments: Optional list of injury replacement opportunities from lineages.
                                Each dict contains: minutes_delta, usage_delta, confidence.
                                Applied BEFORE role signals and simulation.
        replacement_context: Optional replacement lineage context from ReplacementLineage model.
                           Dict with:
                           - 'selected_candidate': ReplacementCandidate (contains minutes_delta, usage_delta)
                           - 'confidence': Overall lineage confidence (0.0-1.0)
                           - 'sources': List of source identifiers (e.g., ["lineup_confirmed", "beat_writer"])
                           - 'out_player_name': Name of OUT player being replaced
                           Applied with deterministic variance adjustments:
                           - Lineup confirmed sources → variance reduction (0.85x)
                           - Beat writer sources only → variance increase (1.10x)
                           - Deltas scaled by candidate score and lineage confidence
    
    Returns:
        Dict with:
        - median_fp: Median fantasy points across simulations
        - pct_75: 75th percentile fantasy points
        - pct_85: 85th percentile fantasy points
        - ceiling_probability: P(reaching target_points)
        - target_points: Calculated as (salary / 1000) * target_multiplier
        - minutes_mean: Adjusted expected minutes
        - usage_mean: Adjusted expected usage rate
        - explain (optional): Distribution summaries and role adjustment reasons
    
    Logic:
    1. Extract baseline minutes, usage, projection from player data
    2. Apply injury replacement lineage adjustments (if provided)
    3. Adjust for injury-derived role signals (replacement, starter confirmation, etc.)
    4. Compute target_points = (salary / 1000) * target_multiplier
    5. Run Monte Carlo simulation using existing minutes/usage variance
    6. Return probability of reaching target_points
    
    Constraints:
    - Uses existing minutes and usage variance (no new randomness)
    - Stable seed derived from player data (deterministic per player)
    - Respects injury-adjusted role signals via _adjust_for_role_signals()
    - No hard locks on minutes/usage (bounded adjustments only)
    - Variance assumptions are NOT changed by lineage adjustments
    
    Example:
        >>> # Value play with dynamic high threshold and lineage boost
        >>> evaluate_player_ceiling(
        ...     player=player_data,
        ...     salary=4200,
        ...     target_multiplier=5.0,  # From get_required_multiplier()
        ...     signals=injury_signals,
        ...     opportunity_adjustments=[
        ...         {"minutes_delta": 10.0, "usage_delta": 3.0, "confidence": 0.6}
        ...     ]
        ... )
        {'ceiling_probability': 0.38, 'target_points': 21.0, ...}
    """
    signals = signals or []

    # =============================================================================
    # 1. EXTRACT BASELINE PLAYER METRICS
    # =============================================================================
    
    minutes_mean = _get_first_float(player, ["minutes", "Minutes", "proj_minutes"], 0.0)
    usage_mean = _get_first_float(player, ["usage", "Usage", "usage_rate"], 0.0)
    projection = _get_first_float(player, ["base_projection", "Projection", "projection"], 0.0)
    
    # Calculate baseline FPPM (fantasy points per minute) from ORIGINAL projection
    # This must be done BEFORE lineage/role adjustments to preserve production rate
    # Example: 25 FP projection / 25 minutes = 1.0 FPPM
    # If we later boost minutes to 31, we use the same 1.0 FPPM rate
    # Result: 31 minutes * 1.0 FPPM = higher production (correct)
    baseline_fppm = projection / minutes_mean if minutes_mean > 0 else 0.0

    # =============================================================================
    # 2. APPLY INJURY REPLACEMENT LINEAGE ADJUSTMENTS (BEFORE SIMULATION)
    # =============================================================================
    # If injury replacement opportunities are provided (from lineage extraction),
    # apply them to minutes_mean and usage_mean BEFORE running simulation.
    # 
    # Each adjustment is scaled by confidence:
    # - minutes_mean += minutes_delta * confidence
    # - usage_mean += usage_delta * confidence
    #
    # Multiple lineages are applied additively (cumulative opportunity boost).
    # Variance is NOT affected - only mean values change.
    #
    # This allows injury-based opportunity to flow through ceiling probability
    # calculations without bypassing the simulation.
    
    lineage_reasons: List[str] = []
    replacement_variance_adjustment: float = 1.0  # Default: no variance change
    
    # LEGACY opportunity_adjustments support (dict-based)
    if opportunity_adjustments:
        for adjustment in opportunity_adjustments:
            confidence = adjustment.get("confidence", 0.0)
            minutes_delta = adjustment.get("minutes_delta", 0.0)
            usage_delta = adjustment.get("usage_delta", 0.0)
            
            # Apply scaled adjustments
            minutes_boost = minutes_delta * confidence
            usage_boost = usage_delta * confidence
            
            minutes_mean += minutes_boost
            usage_mean += usage_boost
            
            # Track for explainability
            out_player = adjustment.get("out_player_name", "unknown")
            lineage_reasons.append(
                f"lineage_boost: +{minutes_boost:.1f} min, +{usage_boost:.3f} usage "
                f"(replaced {out_player})"
            )
    
    # NEW replacement_context support (structured ReplacementLineage model)
    if replacement_context:
        # Extract replacement data from structured lineage model
        selected = replacement_context.get("selected_candidate")
        lineage_confidence = replacement_context.get("confidence", 0.0)
        sources = replacement_context.get("sources", [])
        out_player = replacement_context.get("out_player_name", "unknown")
        
        # Only apply if this player is the selected replacement candidate
        if selected:
            selected_player_name = selected.get("player_name", "")
            current_player_name = str(player.get("player_name") or player.get("Name") or "")
            
            # Check if current player matches selected candidate
            # Case-insensitive comparison, strip whitespace
            is_selected_replacement = (
                selected_player_name.strip().lower() == current_player_name.strip().lower()
            )
            
            if is_selected_replacement:
                # Extract deltas from candidate
                # usage_delta is in percentage points (e.g., 6.0 = +6% usage)
                # Need to convert to decimal (0.06)
                minutes_delta = selected.get("minutes_delta", 0.0)
                usage_delta_pct = selected.get("usage_delta", 0.0)
                usage_delta = usage_delta_pct / 100.0  # Convert 6.0 → 0.06
                
                candidate_score = selected.get("score", 0.0)
                
                # Scale deltas by both candidate score and lineage confidence
                # candidate_score is 0-100, normalize to 0-1
                score_factor = min(1.0, max(0.0, candidate_score / 100.0))
                
                # Final scaling: score_factor * lineage_confidence
                # This ensures low-confidence or low-score replacements get smaller boosts
                scaling_factor = score_factor * lineage_confidence
                
                minutes_boost = minutes_delta * scaling_factor
                usage_boost = usage_delta * scaling_factor
                
                # Apply boosts (clamped to reasonable limits)
                minutes_mean += minutes_boost
                usage_mean += usage_boost
                
                # Clamp to reasonable ranges
                minutes_mean = min(40.0, max(0.0, minutes_mean))
                usage_mean = min(0.45, max(0.05, usage_mean))
                
                # Variance adjustment based on confirmation source
                # Lineup confirmed → tighter variance (more predictable)
                # Beat writer only → wider variance (more uncertainty)
                has_lineup_confirmed = any(
                    "lineup" in str(src).lower() or "confirmed" in str(src).lower()
                    for src in sources
                )
                has_only_beat_writer = (
                    any("beat" in str(src).lower() or "writer" in str(src).lower() for src in sources)
                    and not has_lineup_confirmed
                )
                
                if has_lineup_confirmed:
                    replacement_variance_adjustment = 0.85  # Reduce variance by 15%
                    confirmation_type = "lineup_confirmed"
                elif has_only_beat_writer:
                    replacement_variance_adjustment = 1.10  # Increase variance by 10%
                    confirmation_type = "beat_writer_only"
                else:
                    confirmation_type = "uncertain"
                
                # Track for explainability
                lineage_reasons.append(
                    f"replacement_context: +{minutes_boost:.1f} min, +{usage_boost:.3f} usage "
                    f"(replaced {out_player}, {confirmation_type}, "
                    f"score={candidate_score:.1f}, conf={lineage_confidence:.2f})"
                )

    # =============================================================================
    # 3. ADJUST FOR INJURY-DERIVED ROLE SIGNALS
    # =============================================================================
    # Applies bounded adjustments based on:
    # - Replacement opportunity (injury_out propagation)
    # - Starter confirmation (beat writers, lineup feeds)
    # - Bench role assignment
    # - Depth chart promotions
    
    minutes_mean, usage_mean, role_reasons = _adjust_for_role_signals(
        player, minutes_mean, usage_mean, signals
    )
    
    # Use baseline FPPM calculated from original projection/minutes
    # This ensures lineage/role adjustments boost production correctly
    fppm = baseline_fppm

    # =============================================================================
    # 3B. APPLY START PROBABILITY MINUTES SCALING (NEW)
    # =============================================================================
    # If start_probability is provided, scale minutes_mean so that a likely
    # starter gets full minutes while a bench player gets ~50%.
    # Formula: minutes_mean = minutes_mean * (0.5 + 0.5 * start_probability)
    # This NEVER modifies base_projection (FPPM unchanged).

    start_prob_reasons: List[str] = []

    if start_probability is not None:
        sp = max(0.0, min(1.0, start_probability))
        minutes_scale = 0.5 + 0.5 * sp
        minutes_mean = minutes_mean * minutes_scale
        minutes_mean = min(40.0, max(0.0, minutes_mean))
        start_prob_reasons.append(
            f"start_probability={sp:.3f} -> minutes_scale={minutes_scale:.3f}"
        )

    # =============================================================================
    # 4. DEFINE VARIANCE (EXISTING, NOT NEW RANDOMNESS)
    # =============================================================================
    # Uses historical variance patterns:
    # - Minutes: ~12% of mean (min 2.5 for stability)
    # - Usage: ~18% of mean (min 0.02 for stability)

    minutes_std = _get_first_float(player, ["minutes_std", "MinutesStd"], max(2.5, minutes_mean * 0.12))
    usage_std = _get_first_float(player, ["usage_std", "UsageStd"], max(0.02, usage_mean * 0.18))

    # Replacement context variance adjustment (from lineage sources)
    # - Lineup confirmed -> 0.85x (tighter, more predictable)
    # - Beat writer only -> 1.10x (wider, more uncertainty)
    # Applied BEFORE starter confirmation adjustment
    minutes_std *= replacement_variance_adjustment
    usage_std *= replacement_variance_adjustment

    # =============================================================================
    # 4B. APPLY TENURE VARIANCE MODIFIER (NEW)
    # =============================================================================
    # If tenure is provided, apply its variance_modifier to minutes_std and
    # usage_std. Stable tenure (0.95x) tightens variance; temporary tenure
    # (1.25x) widens it. Does NOT modify base_projection.

    tenure_reasons: List[str] = []

    if tenure is not None:
        variance_mod = float(tenure.get("variance_modifier", 1.0))
        tenure_bucket = tenure.get("bucket", "unknown")
        minutes_std *= variance_mod
        usage_std *= variance_mod
        tenure_reasons.append(
            f"tenure={tenure_bucket}, variance_modifier={variance_mod:.3f}"
        )

    # Starter confirmation reduces variance (more predictable minutes/usage)
    # Stacks with replacement variance adjustment
    if _has_starter_confirmation(signals):
        minutes_std *= 0.9  # -10% variance for confirmed starters
        usage_std *= 0.9

    # =============================================================================
    # 5. MONTE CARLO SIMULATION (STABLE SEED = DETERMINISTIC)
    # =============================================================================
    # Seed is derived from player ID/name, ensuring same player always gets
    # same simulation sequence (reproducible, testable)
    
    rng = np.random.default_rng(_stable_seed(player))

    # Simulate minutes distribution
    minutes_sim = rng.normal(minutes_mean, minutes_std, num_simulations)
    minutes_sim = np.clip(minutes_sim, 0.0, _get_max_minutes(player))

    # Simulate usage distribution (if player has usage)
    if usage_mean > 0:
        usage_sim = rng.normal(usage_mean, usage_std, num_simulations)
        usage_sim = np.clip(usage_sim, 0.05, 0.45)  # Realistic usage bounds
        usage_factor = usage_sim / usage_mean
    else:
        usage_sim = np.full(num_simulations, usage_mean)
        usage_factor = np.ones(num_simulations)

    # Calculate fantasy points for each simulation
    points_sim = minutes_sim * fppm * usage_factor

    # =============================================================================
    # 6. COMPUTE TARGET PROBABILITY (USING VARIABLE MULTIPLIER)
    # =============================================================================
    # target_multiplier can vary by:
    # - Salary tier (5.0x for value, 4.5x for studs)
    # - Signal adjustments (±0.25x for starter/uncertainty)
    # This is the core of the dynamic threshold system
    
    median = float(np.percentile(points_sim, 50))
    pct_75 = float(np.percentile(points_sim, 75))
    pct_85 = float(np.percentile(points_sim, 85))

    # Calculate target points from variable multiplier
    # Example: $5K salary * 4.75x multiplier = 23.75 target points
    target_points = (salary / 1000.0) * target_multiplier if salary > 0 else 0.0
    
    # Return probability of reaching target (ceiling probability)
    # This is what player pool filtering uses to prune low-ceiling players
    ceiling_prob = float(np.mean(points_sim >= target_points)) if target_points > 0 else 0.0

    # =============================================================================
    # 7. ASSEMBLE RESULTS
    # =============================================================================

    result = {
        "median_fp": round(median, 2),
        "pct_75": round(pct_75, 2),
        "pct_85": round(pct_85, 2),
        "ceiling_probability": round(ceiling_prob, 4),
        "target_points": round(target_points, 2),
        "target_multiplier": round(target_multiplier, 2),  # Include for transparency
        "minutes_mean": round(minutes_mean, 2),
        "usage_mean": round(usage_mean, 4),
    }

    # Optional: Include detailed explanations for debugging/auditing
    if explain:
        result["explain"] = {
            "minutes_distribution": _summarize_distribution(minutes_sim),
            "usage_distribution": _summarize_distribution(usage_sim),
            "lineage_adjustment_reasons": lineage_reasons,  # Injury replacement lineage boosts
            "role_adjustment_reasons": role_reasons,  # Role signal adjustments
            "start_probability_reasons": start_prob_reasons,  # Start probability scaling
            "tenure_reasons": tenure_reasons,  # Replacement tenure variance adjustment
            "fppm": round(fppm, 3),  # Fantasy points per minute
            "variance_reduction": _has_starter_confirmation(signals),  # Starter reduces variance
            "replacement_variance_adjustment": round(replacement_variance_adjustment, 3),  # Lineage variance tuning
        }

    return result


def _adjust_for_role_signals(
    player: Dict[str, Any],
    minutes_mean: float,
    usage_mean: float,
    signals: List[Dict[str, Any]],
) -> Tuple[float, float, List[str]]:
    """
    Adjust minutes and usage based on role signals.

    Rules:
    - OUT teammates increase minutes/usage (replacement opportunity)
    - STARTER confirmation slightly increases minutes/usage
    - BENCH role slightly lowers usage mean
    - Never exceed hard caps (minutes <= 40, usage <= 0.38)

    Adjustments are additive and deterministic.
    """
    del player

    reasons: List[str] = []

    for signal in signals:
        signal_type = str(signal.get("signal_type") or signal.get("type") or "").lower()
        status = str(signal.get("status") or signal.get("lineup_status") or "").lower()
        metadata = signal.get("metadata") or {}

        if signal_type in {"confirmed_starter", "expected_starter"} or status in {"confirmed", "starter", "starting"}:
            minutes_mean += 2.0
            usage_mean += 0.005
            reasons.append("starter_confirmed")

        if status in {"bench", "reserve"} or signal_type == "bench":
            usage_mean -= 0.01
            reasons.append("bench_role")

        if metadata.get("propagation") == "injury_out" or metadata.get("role") == "replacement":
            minutes_mean += 3.0
            usage_mean += 0.015
            reasons.append("replacement_opportunity")

        if signal_type == "depth_change" and metadata.get("change") == "promoted":
            minutes_mean += 2.0
            usage_mean += 0.01
            reasons.append("depth_promotion")

    minutes_mean = min(minutes_mean, 40.0)
    usage_mean = min(usage_mean, 0.38)

    minutes_mean = max(0.0, minutes_mean)
    usage_mean = max(0.05, usage_mean)

    return minutes_mean, usage_mean, sorted(set(reasons))


def _has_starter_confirmation(signals: List[Dict[str, Any]]) -> bool:
    for signal in signals:
        signal_type = str(signal.get("signal_type") or signal.get("type") or "").lower()
        status = str(signal.get("status") or signal.get("lineup_status") or "").lower()
        if signal_type in {"confirmed_starter", "expected_starter"}:
            return True
        if status in {"confirmed", "starter", "starting", "expected_starter"}:
            return True
    return False


def _summarize_distribution(values: np.ndarray) -> Dict[str, float]:
    if values.size == 0:
        return {
            "mean": 0.0,
            "std": 0.0,
            "p10": 0.0,
            "p50": 0.0,
            "p90": 0.0,
        }

    return {
        "mean": round(float(np.mean(values)), 4),
        "std": round(float(np.std(values)), 4),
        "p10": round(float(np.percentile(values, 10)), 4),
        "p50": round(float(np.percentile(values, 50)), 4),
        "p90": round(float(np.percentile(values, 90)), 4),
    }


def _get_first_float(player: Dict[str, Any], keys: List[str], default: float) -> float:
    for key in keys:
        if key in player and player[key] is not None:
            try:
                return float(player[key])
            except (TypeError, ValueError):
                continue
    return float(default)


def _get_max_minutes(player: Dict[str, Any]) -> float:
    max_minutes = _get_first_float(player, ["max_minutes", "MaxMinutes"], MAX_MINUTES_DEFAULT)
    return min(MAX_MINUTES_DEFAULT, max(24.0, max_minutes))


def _stable_seed(player: Dict[str, Any]) -> int:
    key = str(player.get("player_id") or player.get("player_name") or "seed")
    return abs(hash(key)) % (2 ** 32)
