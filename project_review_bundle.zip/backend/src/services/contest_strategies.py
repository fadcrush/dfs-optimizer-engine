"""
Contest Strategies - Different optimization strategies for different contest types
Cash games need consistency, GPPs need upside!
"""

from typing import Dict, List
from dataclasses import dataclass

@dataclass
class ContestStrategy:
    """
    Strategy configuration for different contest types
    """
    name: str
    description: str
    
    # Projection settings
    min_projection: float  # Minimum player projection to consider
    projection_weight: float  # How much to weight projection vs other factors
    floor_weight: float  # Importance of high floor (0-1)
    ceiling_weight: float  # Importance of high ceiling (0-1)
    
    # Exposure settings
    max_exposure: float  # Maximum player exposure across lineups
    min_unique_players: int  # Minimum unique players per lineup
    
    # Ownership settings
    ownership_concern: bool  # Whether to avoid high ownership
    max_chalk_ownership: float  # Maximum ownership for "chalk" players
    leverage_weight: float  # How much to prioritize leverage plays
    
    # Stacking settings
    require_stack: bool  # Must have game stack
    min_stack_size: int  # Minimum players in stack
    max_stack_size: int  # Maximum players in stack
    stack_correlation: bool  # Require correlated positions
    
    # Salary settings
    min_salary_usage: float  # Minimum % of salary cap to use
    max_salary_usage: float  # Maximum % of salary cap to use
    
    # Variance settings
    randomness: float  # How much randomness in lineup generation (0-1)
    diversity_bonus: bool  # Bonus for unique lineup constructions


class ContestStrategyManager:
    """
    Manages different contest strategies
    """
    
    def __init__(self):
        self.strategies = self._initialize_strategies()
    
    def _initialize_strategies(self) -> Dict[str, ContestStrategy]:
        """
        Initialize all contest strategy profiles
        """
        
        strategies = {}
        
        # CASH GAME STRATEGY (50/50s, Double-Ups, Head-to-Head)
        strategies['cash'] = ContestStrategy(
            name="Cash Game",
            description="Conservative strategy for 50/50s and double-ups. Prioritizes consistency and high floors.",
            
            # Projections
            min_projection=25.0,  # Only reliable players
            projection_weight=0.8,  # Heavily weight projections
            floor_weight=0.7,  # High floor is critical
            ceiling_weight=0.3,  # Ceiling less important
            
            # Exposure
            max_exposure=1.0,  # Use best players repeatedly
            min_unique_players=0,  # Allow duplicate builds
            
            # Ownership
            ownership_concern=False,  # Don't care about ownership
            max_chalk_ownership=1.0,  # Chalk is fine in cash
            leverage_weight=0.0,  # No leverage needed
            
            # Stacking
            require_stack=False,  # Stacking not required
            min_stack_size=0,
            max_stack_size=2,  # Light stacking ok
            stack_correlation=False,
            
            # Salary
            min_salary_usage=0.99,  # Use almost all salary
            max_salary_usage=1.0,  # Max out salary
            
            # Variance
            randomness=0.0,  # No randomness
            diversity_bonus=False  # Consistency over diversity
        )
        
        # LARGE GPP STRATEGY (Milly Maker, $100K+, 10K+ entries)
        strategies['large_gpp'] = ContestStrategy(
            name="Large GPP",
            description="Aggressive strategy for massive tournaments. Maximize leverage and upside.",
            
            # Projections
            min_projection=15.0,  # Allow boom/bust plays
            projection_weight=0.6,  # Balance projection with leverage
            floor_weight=0.2,  # Floor less important
            ceiling_weight=0.8,  # Ceiling is critical!
            
            # Exposure
            max_exposure=0.25,  # Diversify heavily
            min_unique_players=7,  # Force uniqueness
            
            # Ownership
            ownership_concern=True,  # Avoid chalk!
            max_chalk_ownership=0.30,  # Fade high ownership
            leverage_weight=2.0,  # Leverage is king
            
            # Stacking
            require_stack=True,  # Must have stack
            min_stack_size=3,  # Meaningful stack
            max_stack_size=5,  # Aggressive stacking
            stack_correlation=True,  # Correlated positions
            
            # Salary
            min_salary_usage=0.96,  # Can punt a bit
            max_salary_usage=1.0,
            
            # Variance
            randomness=0.4,  # High variance
            diversity_bonus=True  # Unique builds
        )
        
        # SMALL GPP STRATEGY (Single Entry, <1000 entries)
        strategies['small_gpp'] = ContestStrategy(
            name="Small GPP",
            description="Balanced strategy for smaller tournaments. Mix of safety and upside.",
            
            # Projections
            min_projection=20.0,  # Moderate floor
            projection_weight=0.7,
            floor_weight=0.5,  # Balanced
            ceiling_weight=0.5,  # Balanced
            
            # Exposure
            max_exposure=0.40,  # Moderate diversity
            min_unique_players=3,
            
            # Ownership
            ownership_concern=True,  # Some leverage
            max_chalk_ownership=0.40,
            leverage_weight=1.2,
            
            # Stacking
            require_stack=True,
            min_stack_size=2,
            max_stack_size=4,
            stack_correlation=True,
            
            # Salary
            min_salary_usage=0.98,
            max_salary_usage=1.0,
            
            # Variance
            randomness=0.2,
            diversity_bonus=True
        )
        
        # SATELLITE STRATEGY (Qualify for bigger tournaments)
        strategies['satellite'] = ContestStrategy(
            name="Satellite",
            description="Min-cash focused. Just need to finish in the money.",
            
            # Projections
            min_projection=28.0,  # High floor only
            projection_weight=0.9,
            floor_weight=0.8,  # Very high floor
            ceiling_weight=0.2,
            
            # Exposure
            max_exposure=0.80,  # Use best players
            min_unique_players=1,
            
            # Ownership
            ownership_concern=False,
            max_chalk_ownership=1.0,
            leverage_weight=0.0,
            
            # Stacking
            require_stack=False,
            min_stack_size=0,
            max_stack_size=2,
            stack_correlation=False,
            
            # Salary
            min_salary_usage=0.97,  # Save salary for safety
            max_salary_usage=1.0,
            
            # Variance
            randomness=0.1,  # Low variance
            diversity_bonus=False
        )
        
        # SHOWDOWN STRATEGY (Single game contests)
        strategies['showdown'] = ContestStrategy(
            name="Showdown",
            description="Single game strategy. Heavy stacking from both teams.",
            
            # Projections
            min_projection=18.0,
            projection_weight=0.7,
            floor_weight=0.4,
            ceiling_weight=0.6,
            
            # Exposure
            max_exposure=0.35,
            min_unique_players=2,
            
            # Ownership
            ownership_concern=True,
            max_chalk_ownership=0.35,
            leverage_weight=1.5,
            
            # Stacking
            require_stack=True,
            min_stack_size=3,
            max_stack_size=5,
            stack_correlation=True,
            
            # Salary
            min_salary_usage=0.98,
            max_salary_usage=1.0,
            
            # Variance
            randomness=0.3,
            diversity_bonus=True
        )
        
        return strategies
    
    def get_strategy(self, contest_type: str) -> ContestStrategy:
        """
        Get strategy for contest type
        
        Args:
            contest_type: 'cash', 'large_gpp', 'small_gpp', 'satellite', 'showdown'
        
        Returns:
            ContestStrategy object
        """
        
        contest_type = contest_type.lower().replace('-', '_').replace(' ', '_')
        
        if contest_type not in self.strategies:
            print(f"⚠️  Unknown contest type '{contest_type}', using 'small_gpp'")
            return self.strategies['small_gpp']
        
        strategy = self.strategies[contest_type]
        
        print(f"\n🎯 CONTEST STRATEGY: {strategy.name}")
        print(f"   {strategy.description}")
        print(f"\n   KEY SETTINGS:")
        print(f"      Floor weight: {strategy.floor_weight:.0%}")
        print(f"      Ceiling weight: {strategy.ceiling_weight:.0%}")
        print(f"      Max exposure: {strategy.max_exposure:.0%}")
        print(f"      Leverage weight: {strategy.leverage_weight:.1f}x")
        print(f"      Stacking: {'Required' if strategy.require_stack else 'Optional'}")
        print(f"      Ownership concern: {'Yes' if strategy.ownership_concern else 'No'}")
        
        return strategy
    
    def list_strategies(self) -> List[str]:
        """
        List all available strategies
        """
        return list(self.strategies.keys())
    
    def compare_strategies(self, strategies: List[str] = None) -> str:
        """
        Compare multiple strategies side by side
        """
        
        if not strategies:
            strategies = self.list_strategies()
        
        comparison = "\n📊 CONTEST STRATEGY COMPARISON\n"
        comparison += "="*80 + "\n\n"
        
        for strategy_name in strategies:
            if strategy_name in self.strategies:
                s = self.strategies[strategy_name]
                comparison += f"{s.name}:\n"
                comparison += f"  Floor/Ceiling: {s.floor_weight:.0%}/{s.ceiling_weight:.0%}\n"
                comparison += f"  Max Exposure: {s.max_exposure:.0%}\n"
                comparison += f"  Leverage: {s.leverage_weight:.1f}x\n"
                comparison += f"  Stacking: {s.min_stack_size}-{s.max_stack_size} players\n"
                comparison += f"  Ownership: {'Avoid chalk' if s.ownership_concern else 'Ignore'}\n"
                comparison += "\n"
        
        return comparison


def get_contest_strategy(contest_type: str) -> ContestStrategy:
    """
    Helper function to get contest strategy
    
    Args:
        contest_type: Type of contest
    
    Returns:
        ContestStrategy object
    """
    
    manager = ContestStrategyManager()
    return manager.get_strategy(contest_type)

def apply_strategy_filters(pool, strategy: ContestStrategy):
    """
    Apply strategy filters to player pool
    LESS AGGRESSIVE - Keep more players for diversity
    
    Args:
        pool: Player pool DataFrame
        strategy: ContestStrategy to apply
    
    Returns:
        Filtered pool
    """
    
    import pandas as pd
    
    filtered_pool = pool.copy()
    original_count = len(filtered_pool)
    
    # Filter by minimum projection (but keep at least 50% of pool)
    if 'Projection' in filtered_pool.columns:
        # Apply filter, but not too aggressively
        min_proj = strategy.min_projection
        
        # For GPPs with low min_projection, ensure we keep enough players
        if min_proj < 20.0:
            # Keep players above min OR top 60% by projection
            projection_threshold = filtered_pool['Projection'].quantile(0.40)  # Keep top 60%
            min_proj = min(min_proj, projection_threshold)
        
        filtered_pool = filtered_pool[filtered_pool['Projection'] >= min_proj]
        filtered_count = len(filtered_pool)
        
        if filtered_count < original_count:
            print(f"   📉 Filtered {original_count - filtered_count} low-projection players (below {min_proj:.1f})")
    
    # Filter by ownership (ONLY if strategy cares AND we have ownership data)
    if strategy.ownership_concern and 'Ownership' in filtered_pool.columns:
        original_count_2 = len(filtered_pool)
        
        # DON'T eliminate all chalk - just note it
        # Keep players under max chalk OR elite players (top projection)
        if len(filtered_pool) > 0:
            top_25_pct_projection = filtered_pool['Projection'].quantile(0.75)
            
            # Keep: Low owned OR elite projections
            filtered_pool = filtered_pool[
                (filtered_pool['Ownership'] <= strategy.max_chalk_ownership) |
                (filtered_pool['Projection'] >= top_25_pct_projection)
            ]
        
        filtered_count_2 = len(filtered_pool)
        
        if filtered_count_2 < original_count_2:
            print(f"   📉 Noted {original_count_2 - filtered_count_2} high-owned players (>{strategy.max_chalk_ownership:.0%})")
    
    # Safety check: Never filter below 25 players
    if len(filtered_pool) < 25:
        print(f"   ⚠️  Pool too small ({len(filtered_pool)} players), relaxing filters...")
        # Use less aggressive filters
        filtered_pool = pool.copy()
        
        # Only apply VERY basic filter
        if 'Projection' in filtered_pool.columns:
            basic_threshold = filtered_pool['Projection'].quantile(0.30)  # Keep top 70%
            filtered_pool = filtered_pool[filtered_pool['Projection'] >= basic_threshold]
            print(f"   📊 Relaxed filter: {len(filtered_pool)} players remaining")
    
    # Add leverage score
    if 'Projection' in filtered_pool.columns and 'Ownership' in filtered_pool.columns:
        filtered_pool['Leverage'] = filtered_pool['Projection'] / (filtered_pool['Ownership'] + 0.01)
    
    print(f"   ✅ Final pool: {len(filtered_pool)} players")
    
    return filtered_pool