"""
services/run_recovery.py — Stale run recovery at startup.

Detects runs stuck in 'running' status older than a configurable threshold
and marks them as 'failed' with reason 'worker crash recovery'.

Usage (from lifespan):
    from services.run_recovery import recover_stale_runs
    recovered = recover_stale_runs(db)
"""
from __future__ import annotations

import logging
import os
from datetime import datetime, timedelta, timezone
from typing import List

from sqlalchemy.orm import Session

from models.run import Run, STATUS_RUNNING, STATUS_FAILED

logger = logging.getLogger(__name__)

# Default: mark any run stuck in 'running' for > 15 min as crashed
_DEFAULT_THRESHOLD_MINUTES = int(os.getenv("STALE_RUN_THRESHOLD_MINUTES", "15"))


def _utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


def recover_stale_runs(
    db: Session,
    threshold_minutes: int = _DEFAULT_THRESHOLD_MINUTES,
) -> List[str]:
    """
    Find all runs with status='running' whose started_at is older than
    *threshold_minutes* and transition them to 'failed'.

    Returns a list of run IDs that were recovered.

    Safe to call multiple times (idempotent — only affects 'running' rows).
    """
    cutoff = _utcnow() - timedelta(minutes=threshold_minutes)

    stale: List[Run] = (
        db.query(Run)
        .filter(
            Run.status == STATUS_RUNNING,
            Run.started_at != None,
            Run.started_at < cutoff,
        )
        .all()
    )

    recovered_ids: List[str] = []
    for run in stale:
        age_minutes = (_utcnow() - run.started_at).total_seconds() / 60
        run.status = STATUS_FAILED
        run.error_message = (
            f"worker crash recovery — run was stuck in 'running' for "
            f"{age_minutes:.1f} min (threshold={threshold_minutes} min)"
        )
        run.completed_at = _utcnow()
        recovered_ids.append(run.id)
        logger.warning(
            "Stale run recovered: run_id=%s slate_id=%s age_minutes=%.1f",
            run.id, run.slate_id, age_minutes,
        )

    if recovered_ids:
        db.commit()
        logger.info(
            "Run recovery complete: %d stale run(s) marked failed.", len(recovered_ids)
        )
    else:
        logger.debug("Run recovery: no stale runs found (threshold=%d min).", threshold_minutes)

    return recovered_ids
