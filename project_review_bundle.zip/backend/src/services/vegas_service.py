"""
Vegas Odds Service - Integrates live betting lines
Game totals are the #1 predictor of fantasy scoring!
"""

import os
import requests
from datetime import datetime
from typing import List, Dict
from dotenv import load_dotenv

# Load environment
load_dotenv()

ODDS_API_KEY = os.getenv('THE_ODDS_API_KEY', '')

class VegasOddsService:
    """
    Fetch and process Vegas betting lines
    """
    
    def __init__(self):
        self.base_url = "https://api.the-odds-api.com/v4"
        self.api_key = ODDS_API_KEY
        
    def get_nba_odds(self) -> List[Dict]:
        """
        Get current NBA game odds (totals, spreads, moneylines)
        
        Returns list of games with betting lines
        """
        
        if not self.api_key:
            print("⚠️  No Odds API key found - set THE_ODDS_API_KEY in .env")
            return []
        
        try:
            # The Odds API endpoint for NBA
            url = f"{self.base_url}/sports/basketball_nba/odds/"
            
            params = {
                'apiKey': self.api_key,
                'regions': 'us',  # US books
                'markets': 'totals,spreads,h2h',  # Get totals (O/U), spreads, moneylines
                'oddsFormat': 'american'
            }
            
            print(f"💰 Fetching Vegas odds from The Odds API...")
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            games = response.json()
            
            print(f"✅ Found odds for {len(games)} NBA games")
            
            # Process into usable format
            processed_games = []
            
            for game in games:
                game_data = self._process_game(game)
                if game_data:
                    processed_games.append(game_data)
            
            return processed_games
        
        except Exception as e:
            print(f"❌ Error fetching Vegas odds: {e}")
            return []
    
    def _process_game(self, game: Dict) -> Dict:
        """
        Process raw API game data into clean format
        """
        
        try:
            home_team = game.get('home_team', '')
            away_team = game.get('away_team', '')
            commence_time = game.get('commence_time', '')
            
            # Get bookmaker data (use first available, typically consensus)
            bookmakers = game.get('bookmakers', [])
            
            if not bookmakers:
                return None
            
            # Use first bookmaker (DraftKings, FanDuel, etc.)
            book = bookmakers[0]
            markets = book.get('markets', [])
            
            # Extract totals (over/under)
            total = None
            for market in markets:
                if market.get('key') == 'totals':
                    outcomes = market.get('outcomes', [])
                    if outcomes:
                        total = outcomes[0].get('point')  # The O/U line
                        break
            
            # Extract spread
            spread = None
            home_spread = None
            away_spread = None
            for market in markets:
                if market.get('key') == 'spreads':
                    outcomes = market.get('outcomes', [])
                    for outcome in outcomes:
                        if outcome.get('name') == home_team:
                            home_spread = outcome.get('point')
                        elif outcome.get('name') == away_team:
                            away_spread = outcome.get('point')
                    break
            
            # Calculate implied team totals
            home_implied = None
            away_implied = None
            
            if total and home_spread is not None:
                # Formula: Team Total = (Game Total / 2) - (Spread / 2)
                # If home is -5.5, they're expected to score more
                home_implied = (total / 2) - (home_spread / 2)
                away_implied = total - home_implied
            
            return {
                'home_team': self._normalize_team(home_team),
                'away_team': self._normalize_team(away_team),
                'game_time': commence_time,
                'total': total,
                'home_spread': home_spread,
                'away_spread': away_spread,
                'home_implied_points': round(home_implied, 1) if home_implied else None,
                'away_implied_points': round(away_implied, 1) if away_implied else None,
                'bookmaker': book.get('title', 'Unknown')
            }
        
        except Exception as e:
            print(f"⚠️  Error processing game: {e}")
            return None
    
    def _normalize_team(self, team_name: str) -> str:
        """
        Normalize team names to match slate format
        
        Examples:
        - "Los Angeles Lakers" → "LAL"
        - "Golden State Warriors" → "GSW"
        """
        
        team_map = {
            # Common variations
            'Atlanta Hawks': 'ATL',
            'Boston Celtics': 'BOS',
            'Brooklyn Nets': 'BKN',
            'Charlotte Hornets': 'CHA',
            'Chicago Bulls': 'CHI',
            'Cleveland Cavaliers': 'CLE',
            'Dallas Mavericks': 'DAL',
            'Denver Nuggets': 'DEN',
            'Detroit Pistons': 'DET',
            'Golden State Warriors': 'GSW',
            'Houston Rockets': 'HOU',
            'Indiana Pacers': 'IND',
            'LA Clippers': 'LAC',
            'Los Angeles Clippers': 'LAC',
            'Los Angeles Lakers': 'LAL',
            'LA Lakers': 'LAL',
            'Memphis Grizzlies': 'MEM',
            'Miami Heat': 'MIA',
            'Milwaukee Bucks': 'MIL',
            'Minnesota Timberwolves': 'MIN',
            'New Orleans Pelicans': 'NO',
            'New York Knicks': 'NY',
            'Oklahoma City Thunder': 'OKC',
            'Orlando Magic': 'ORL',
            'Philadelphia 76ers': 'PHI',
            'Phoenix Suns': 'PHX',
            'Portland Trail Blazers': 'POR',
            'Sacramento Kings': 'SAC',
            'San Antonio Spurs': 'SA',
            'Toronto Raptors': 'TOR',
            'Utah Jazz': 'UTA',
            'Washington Wizards': 'WAS'
        }
        
        return team_map.get(team_name, team_name)
    
    def get_team_total(self, team_abbr: str) -> float:
        """
        Get implied team total for a specific team
        
        Args:
            team_abbr: Team abbreviation (e.g., 'LAL', 'GSW')
        
        Returns:
            Implied team total or None
        """
        
        games = self.get_nba_odds()
        
        for game in games:
            if game['home_team'] == team_abbr:
                return game.get('home_implied_points')
            elif game['away_team'] == team_abbr:
                return game.get('away_implied_points')
        
        return None
    
    def get_vegas_report(self) -> str:
        """
        Generate human-readable Vegas report
        """
        
        games = self.get_nba_odds()
        
        if not games:
            return "📋 No Vegas odds available"
        
        report = f"\n💰 VEGAS ODDS REPORT ({len(games)} games)\n"
        report += "="*70 + "\n"
        
        # Sort by total (highest scoring games first)
        games_sorted = sorted(games, key=lambda g: g.get('total', 0) or 0, reverse=True)
        
        for game in games_sorted:
            away = game['away_team']
            home = game['home_team']
            total = game.get('total', 'N/A')
            spread = game.get('home_spread', 'N/A')
            away_total = game.get('away_implied_points', 'N/A')
            home_total = game.get('home_implied_points', 'N/A')
            
            report += f"\n{away} @ {home}\n"
            report += f"  Total: {total} | Spread: {home} {spread}\n"
            report += f"  Implied: {away} {away_total} | {home} {home_total}\n"
        
        return report


async def get_vegas_odds() -> Dict:
    """
    Async wrapper for Vegas odds
    """
    
    service = VegasOddsService()
    games = service.get_nba_odds()
    
    return {
        "success": True,
        "games": games,
        "total_games": len(games)
    }


def calculate_vegas_adjustment(team_abbr: str, base_projection: float) -> float:
    """
    Adjust player projection based on team's Vegas total
    
    Higher team total = higher projections
    Lower team total = lower projections
    
    Args:
        team_abbr: Team abbreviation
        base_projection: Player's base projection
    
    Returns:
        Adjusted projection
    """
    
    service = VegasOddsService()
    team_total = service.get_team_total(team_abbr)
    
    if not team_total:
        return base_projection  # No adjustment if no Vegas data
    
    # NBA average team total is ~112 points
    league_average = 112.0
    
    # Calculate adjustment factor
    # If team total is 120, factor = 120/112 = 1.071 (7.1% boost)
    # If team total is 105, factor = 105/112 = 0.938 (6.2% reduction)
    adjustment_factor = team_total / league_average
    
    # Apply adjustment
    adjusted_projection = base_projection * adjustment_factor
    
    return adjusted_projection