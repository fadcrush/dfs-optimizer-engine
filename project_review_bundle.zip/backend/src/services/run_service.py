"""
Run service — create, update, and persist optimizer results into the DB.

This is the database-first persistence layer for optimizer runs.

Workflow:
  1. ``create_run()`` — insert a Run row with status=queued
  2. The optimizer executes (sync or async)
  3. ``persist_lineups()`` — write Lineup + LineupEntry rows
  4. ``complete_run()`` / ``fail_run()`` — flip the status flag

Player matching strategy:
  - First try matching by external_id (platform player ID stored in slate_players).
  - Fall back to name-based match for platforms that don't expose a stable ID.
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from sqlalchemy.orm import Session

from models.lineup import Lineup
from models.lineup_entry import LineupEntry
from models.player import Player
from models.run import Run, STATUS_QUEUED, STATUS_RUNNING, STATUS_COMPLETED, STATUS_FAILED


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


def _find_player(
    db: Session,
    slate_id: str,
    external_id: Optional[str],
    name: Optional[str],
) -> Optional[Player]:
    """
    Resolve a player reference from optimizer output to a DB row.

    Tries external_id first (preferred), then falls back to name.
    """
    if external_id:
        player = (
            db.query(Player)
            .filter(Player.slate_id == slate_id, Player.external_id == external_id)
            .first()
        )
        if player:
            return player

    if name:
        player = (
            db.query(Player)
            .filter(Player.slate_id == slate_id, Player.name == name)
            .first()
        )
        if player:
            return player

        # Case-insensitive fallback
        player = (
            db.query(Player)
            .filter(Player.slate_id == slate_id, Player.name.ilike(name))
            .first()
        )
        return player

    return None


# ---------------------------------------------------------------------------
# Run lifecycle
# ---------------------------------------------------------------------------

def create_run(
    db: Session,
    slate_id: Optional[str] = None,
    num_lineups: int = 0,
    settings: Optional[Dict[str, Any]] = None,
) -> Run:
    """
    Insert a new Run row with status=queued and return it.

    Parameters
    ----------
    db:          SQLAlchemy session.
    slate_id:    UUID of the target slate (nullable).
    num_lineups: Requested lineup count.
    settings:    Optimizer parameter dict (serialised to JSON).
    """
    run = Run(
        id=str(uuid.uuid4()),
        slate_id=slate_id,
        status=STATUS_QUEUED,
        num_lineups=num_lineups,
        settings=json.dumps(settings or {}),
        created_at=_utcnow(),
    )
    db.add(run)
    db.commit()
    db.refresh(run)
    return run


def start_run(db: Session, run_id: str) -> Run:
    """Transition run to running status."""
    run = db.get(Run, run_id)
    if run is None:
        raise ValueError(f"Run not found: {run_id!r}")
    run.mark_running()
    db.commit()
    return run


def complete_run(db: Session, run_id: str) -> Run:
    """Transition run to completed status."""
    run = db.get(Run, run_id)
    if run is None:
        raise ValueError(f"Run not found: {run_id!r}")
    run.mark_completed()
    db.commit()
    return run


def fail_run(db: Session, run_id: str, reason: str) -> Run:
    """Transition run to failed status with error message."""
    run = db.get(Run, run_id)
    if run is None:
        raise ValueError(f"Run not found: {run_id!r}")
    run.mark_failed(reason)
    db.commit()
    return run


# ---------------------------------------------------------------------------
# Lineup persistence
# ---------------------------------------------------------------------------

def persist_lineups(
    db: Session,
    run_id: str,
    slate_id: str,
    lineups_data: List[List[Dict[str, Any]]],
) -> int:
    """
    Write Lineup + LineupEntry rows from optimizer output.

    Parameters
    ----------
    db:
        SQLAlchemy session.
    run_id:
        UUID of the parent Run.
    slate_id:
        Used to resolve player references and denormalise on LineupEntry.
    lineups_data:
        List of lineups.  Each lineup is a list of player dicts from the
        optimizer, expected to contain at minimum:
          - ``Name``      str    — player display name
          - ``ID``        str    — platform player ID  (optional)
          - ``Salary``    int
          - ``Projection`` float
          - ``Position``  str

    Returns
    -------
    int : number of lineups written.
    """
    run = db.get(Run, run_id)
    if run is None:
        raise ValueError(f"Run not found: {run_id!r}")

    # ── Idempotency guard — prevent duplicate lineup insertion ──────────────
    existing_count = db.query(Lineup).filter(Lineup.run_id == run_id).count()
    if existing_count > 0:
        import logging
        logging.getLogger(__name__).warning(
            "persist_lineups: run_id=%s already has %d lineup(s) — "
            "skipping duplicate write (idempotency guard)",
            run_id, existing_count,
        )
        return existing_count

    written = 0
    unmatched_players: List[str] = []

    for lineup_num, raw_players in enumerate(lineups_data, start=1):
        total_salary = sum(int(p.get("Salary", 0)) for p in raw_players)
        total_projection = sum(float(p.get("Projection", 0)) for p in raw_players)

        lineup = Lineup(
            id=str(uuid.uuid4()),
            run_id=run_id,
            lineup_number=lineup_num,
            total_salary=total_salary,
            total_projection=round(total_projection, 4),
            created_at=_utcnow(),
        )
        db.add(lineup)
        db.flush()  # need lineup.id before entries

        for raw_player in raw_players:
            external_id = str(raw_player.get("ID", raw_player.get("Id", ""))) or None
            name = str(raw_player.get("Name", "")) or None
            position = str(raw_player.get("Position", "") or "")

            player = _find_player(db, slate_id, external_id, name)
            if player is None:
                unmatched_players.append(name or external_id or "?")
                continue

            entry = LineupEntry(
                id=str(uuid.uuid4()),
                lineup_id=lineup.id,
                player_id=player.id,
                slate_id=slate_id,
                position=position,
                created_at=_utcnow(),
            )
            db.add(entry)

        written += 1

    # Update run counts
    run.num_lineups = written
    db.commit()

    if unmatched_players:
        import logging
        logging.getLogger(__name__).warning(
            "run_service.persist_lineups: %d player(s) could not be matched "
            "to DB rows (run_id=%s): %s",
            len(unmatched_players),
            run_id,
            unmatched_players[:10],
        )

    return written


# ---------------------------------------------------------------------------
# Convenience: run status query
# ---------------------------------------------------------------------------

def get_run(db: Session, run_id: str) -> Optional[Run]:
    """Return the Run row or None."""
    return db.get(Run, run_id)


def get_run_or_404(db: Session, run_id: str) -> Run:
    """Return the Run row; raises ValueError when not found."""
    run = get_run(db, run_id)
    if run is None:
        raise ValueError(f"Run not found: {run_id!r}")
    return run
