"""
Dynamic Opportunity Modeling Service
Analyzes game context, coaching tendencies, and dynamic factors affecting player minutes
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta
import logging
from pathlib import Path
import json

logger = logging.getLogger(__name__)


@dataclass
class GameContext:
    """Game-specific context factors"""
    game_id: str
    home_team: str
    away_team: str
    vegas_spread: float
    total_points: float
    game_importance: float  # Playoff implications, rivalry, etc.
    weather_impact: float  # NFL only
    rest_advantage: str  # 'home', 'away', 'neutral'


@dataclass
class CoachingTendencies:
    """Coaching rotation patterns and tendencies"""
    coach_name: str
    team: str
    avg_rotation_size: int
    blowout_threshold: float  # When coach starts resting players
    backup_minutes_factor: float  # How much backup minutes increase
    injury_reaction: float  # How quickly coach adjusts to injuries
    game_script_sensitivity: float  # How much game flow affects rotations


@dataclass
class PlayerOpportunity:
    """Dynamic opportunity assessment for a player"""
    player_id: str
    base_minutes: float
    adjusted_minutes: float
    opportunity_multiplier: float
    risk_factors: List[str]
    upside_factors: List[str]
    confidence_score: float


class OpportunityModelingService:
    """
    Professional dynamic opportunity modeling for DFS
    Adjusts player projections based on game context and coaching tendencies
    """

    def __init__(self):
        self.coaching_db = self._load_coaching_database()
        self.game_context_cache = {}

    def _load_coaching_database(self) -> Dict[str, CoachingTendencies]:
        """Load historical coaching tendencies database"""
        # In production, this would load from a database
        # For now, using hardcoded examples
        return {
            'example_coach': CoachingTendencies(
                coach_name='Example Coach',
                team='LAL',
                avg_rotation_size=9,
                blowout_threshold=15.0,
                backup_minutes_factor=1.3,
                injury_reaction=0.8,
                game_script_sensitivity=0.6
            )
        }

    def analyze_game_context(self, game_data: Dict) -> GameContext:
        """
        Analyze comprehensive game context factors
        """
        game_id = game_data.get('game_id', f"{game_data['home_team']}_vs_{game_data['away_team']}")

        # Calculate game importance (simplified)
        game_importance = 1.0
        if game_data.get('is_playoff', False):
            game_importance = 1.5
        elif game_data.get('is_rivalry', False):
            game_importance = 1.2

        # Rest advantage calculation
        home_rest = game_data.get('home_rest_days', 1)
        away_rest = game_data.get('away_rest_days', 1)

        if home_rest > away_rest:
            rest_advantage = 'home'
        elif away_rest > home_rest:
            rest_advantage = 'away'
        else:
            rest_advantage = 'neutral'

        # Weather impact (NFL only)
        weather_impact = game_data.get('weather_impact', 0.0)

        return GameContext(
            game_id=game_id,
            home_team=game_data['home_team'],
            away_team=game_data['away_team'],
            vegas_spread=game_data.get('vegas_spread', 0.0),
            total_points=game_data.get('total_points', 210.0),  # NBA default
            game_importance=game_importance,
            weather_impact=weather_impact,
            rest_advantage=rest_advantage
        )

    def get_coaching_tendencies(self, team: str) -> CoachingTendencies:
        """
        Retrieve coaching tendencies for a team
        """
        # In production, query database by team
        # For now, return default tendencies
        return CoachingTendencies(
            coach_name='Default Coach',
            team=team,
            avg_rotation_size=9,
            blowout_threshold=12.0,
            backup_minutes_factor=1.2,
            injury_reaction=0.7,
            game_script_sensitivity=0.5
        )

    def assess_blowout_risk(self, game_context: GameContext) -> Dict:
        """
        Assess likelihood and impact of blowouts in this game
        """
        # Calculate blowout probability based on vegas spread and total
        spread_magnitude = abs(game_context.vegas_spread)

        # Higher spread = more likely blowout
        blowout_prob = min(0.8, spread_magnitude / 20.0)

        # Expected margin of victory
        expected_mov = spread_magnitude * 0.7  # Regression to mean

        return {
            'blowout_probability': blowout_prob,
            'expected_margin': expected_mov,
            'early_gc_time': 120.0,  # Minutes when garbage time typically starts
            'rotation_compression_factor': 1.0 + (blowout_prob * 0.3)
        }

    def model_rotation_volatility(self, team: str, game_context: GameContext) -> Dict:
        """
        Model how volatile rotations might be in this game
        """
        coach_tendencies = self.get_coaching_tendencies(team)

        # Base volatility from coaching style
        base_volatility = coach_tendencies.game_script_sensitivity

        # Adjust for game context
        context_multiplier = 1.0

        # High importance games = more stable rotations
        context_multiplier *= (2.0 - game_context.game_importance)

        # Rest advantage affects volatility
        if game_context.rest_advantage == team:
            context_multiplier *= 0.9  # More stable with rest
        elif game_context.rest_advantage != 'neutral':
            context_multiplier *= 1.1  # Less stable without rest

        # Weather impact (NFL)
        context_multiplier *= (1.0 + game_context.weather_impact * 0.2)

        final_volatility = base_volatility * context_multiplier

        return {
            'rotation_volatility': min(1.0, final_volatility),
            'minutes_confidence': 1.0 - final_volatility,
            'backup_minutes_boost': coach_tendencies.backup_minutes_factor * (1.0 + final_volatility * 0.5)
        }

    def calculate_opportunity_adjustment(
        self,
        player_data: Dict,
        game_context: GameContext,
        team_rotation_model: Dict,
        blowout_assessment: Dict
    ) -> PlayerOpportunity:
        """
        Calculate dynamic opportunity adjustment for a player
        """
        player_id = player_data['player_id']
        base_minutes = player_data.get('base_minutes', player_data.get('minutes_proj', 25.0))

        # Start with base opportunity
        opportunity_multiplier = 1.0
        risk_factors = []
        upside_factors = []

        # Role-based adjustments
        role = player_data.get('role', 'rotation')
        if role == 'star':
            # Stars play consistent minutes regardless
            opportunity_multiplier *= 1.05
            upside_factors.append('Star power protection')
        elif role == 'backup':
            # Backups get more minutes in volatile games
            backup_boost = team_rotation_model['backup_minutes_boost']
            opportunity_multiplier *= backup_boost
            upside_factors.append(f'Backup boost ({backup_boost:.1f}x)')

        # Game script factors
        blowout_prob = blowout_assessment['blowout_probability']
        if blowout_prob > 0.6:
            if role == 'backup':
                opportunity_multiplier *= 1.3
                upside_factors.append('High blowout upside')
            else:
                opportunity_multiplier *= 0.9
                risk_factors.append('Potential rest in blowout')

        # Rest and matchup adjustments
        if game_context.rest_advantage == player_data.get('team'):
            opportunity_multiplier *= 1.05
            upside_factors.append('Rest advantage')
        elif game_context.rest_advantage != 'neutral':
            opportunity_multiplier *= 0.95
            risk_factors.append('Rest disadvantage')

        # Weather impact (NFL)
        if game_context.weather_impact > 0:
            if player_data.get('weather_sensitive', False):
                opportunity_multiplier *= (1.0 - game_context.weather_impact * 0.1)
                risk_factors.append('Weather affected')

        # Calculate adjusted minutes
        adjusted_minutes = base_minutes * opportunity_multiplier

        # Confidence score based on volatility
        confidence_score = team_rotation_model['minutes_confidence']
        if len(risk_factors) > len(upside_factors):
            confidence_score *= 0.9
        elif len(upside_factors) > len(risk_factors):
            confidence_score *= 1.05

        return PlayerOpportunity(
            player_id=player_id,
            base_minutes=base_minutes,
            adjusted_minutes=min(48.0, adjusted_minutes),  # NBA max
            opportunity_multiplier=opportunity_multiplier,
            risk_factors=risk_factors,
            upside_factors=upside_factors,
            confidence_score=min(1.0, confidence_score)
        )

    def apply_opportunity_modeling(
        self,
        projections_df: pd.DataFrame,
        games_data: List[Dict]
    ) -> pd.DataFrame:
        """
        Apply dynamic opportunity modeling to entire projection set
        """
        logger.info("Applying dynamic opportunity modeling...")

        # Create game context for each game
        game_contexts = {}
        for game_data in games_data:
            context = self.analyze_game_context(game_data)
            game_contexts[context.game_id] = context

        # Process each player
        opportunity_adjustments = []

        for _, player in projections_df.iterrows():
            team = player.get('team', '')
            game_id = player.get('game_id', f"{team}_game")

            if game_id not in game_contexts:
                # Create default context if missing
                game_contexts[game_id] = GameContext(
                    game_id=game_id,
                    home_team=team,
                    away_team='OPP',
                    vegas_spread=0.0,
                    total_points=210.0,
                    game_importance=1.0,
                    weather_impact=0.0,
                    rest_advantage='neutral'
                )

            game_context = game_contexts[game_id]

            # Get team-specific modeling
            team_rotation = self.model_rotation_volatility(team, game_context)
            blowout_risk = self.assess_blowout_risk(game_context)

            # Calculate opportunity adjustment
            player_dict = player.to_dict()
            opportunity = self.calculate_opportunity_adjustment(
                player_dict, game_context, team_rotation, blowout_risk
            )

            opportunity_adjustments.append({
                'player_id': player['player_id'],
                'base_minutes': opportunity.base_minutes,
                'adjusted_minutes': opportunity.adjusted_minutes,
                'opportunity_multiplier': opportunity.opportunity_multiplier,
                'risk_factors': '; '.join(opportunity.risk_factors),
                'upside_factors': '; '.join(opportunity.upside_factors),
                'confidence_score': opportunity.confidence_score,
                'blowout_probability': blowout_risk['blowout_probability'],
                'rotation_volatility': team_rotation['rotation_volatility']
            })

        # Merge adjustments back to projections
        adjustments_df = pd.DataFrame(opportunity_adjustments)
        projections_with_opportunity = projections_df.merge(
            adjustments_df, on='player_id', how='left'
        )

        # Update projections based on opportunity
        projections_with_opportunity['minutes_proj_adjusted'] = projections_with_opportunity['adjusted_minutes']
        projections_with_opportunity['projection_adjusted'] = (
            projections_with_opportunity['base_projection'] *
            projections_with_opportunity['opportunity_multiplier']
        )

        # Add uncertainty based on confidence
        projections_with_opportunity['opportunity_confidence'] = projections_with_opportunity['confidence_score']

        logger.info(f"Applied opportunity modeling to {len(projections_with_opportunity)} players")

        return projections_with_opportunity

    def export_opportunity_analysis(self, projections_df: pd.DataFrame, output_path: Path) -> None:
        """
        Export detailed opportunity analysis for review
        """
        analysis_columns = [
            'player_name', 'team', 'position', 'base_projection', 'projection_adjusted',
            'base_minutes', 'adjusted_minutes', 'opportunity_multiplier',
            'risk_factors', 'upside_factors', 'confidence_score',
            'blowout_probability', 'rotation_volatility'
        ]

        available_columns = [col for col in analysis_columns if col in projections_df.columns]
        analysis_df = projections_df[available_columns].copy()

        analysis_df.to_csv(output_path, index=False)
        logger.info(f"Exported opportunity analysis to {output_path}")


# Integration functions
async def apply_dynamic_opportunity_modeling(
    projections_df: pd.DataFrame,
    games_data: List[Dict]
) -> pd.DataFrame:
    """
    High-level function to apply dynamic opportunity modeling
    """
    service = OpportunityModelingService()

    try:
        adjusted_projections = service.apply_opportunity_modeling(projections_df, games_data)
        return adjusted_projections
    except Exception as e:
        logger.error(f"Opportunity modeling failed: {e}")
        return projections_df  # Return original if modeling fails


if __name__ == "__main__":
    print("Dynamic Opportunity Modeling Service")
    print("Ready for integration with DFS pipeline")
