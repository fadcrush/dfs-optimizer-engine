"""
WebSocket Service - Real-time DFS Updates
Provides live game updates, Vegas line changes, and injury alerts
"""

import asyncio
import json
import logging
from typing import Dict, List, Set, Optional
from datetime import datetime, timedelta
import websockets
from websockets.exceptions import ConnectionClosedError
import threading
import time
from concurrent.futures import ThreadPoolExecutor

from services.theodds_api_service import TheOddsAPIService
from services.weather_api_service import WeatherAPIService
from services.injury_service import InjuryService

logger = logging.getLogger(__name__)

class DFSWebSocketService:
    """WebSocket service for real-time DFS updates"""

    def __init__(self):
        self.connected_clients: Set[websockets.WebSocketServerProtocol] = set()
        self.client_subscriptions: Dict[websockets.WebSocketServerProtocol, Set[str]] = {}
        self.update_threads: Dict[str, threading.Thread] = {}
        self.executor = ThreadPoolExecutor(max_workers=4)

        # Initialize data services
        self.odds_service = TheOddsAPIService()
        self.weather_service = WeatherAPIService()
        self.injury_service = InjuryService()

        # Cache for last known data
        self.last_odds_data = {}
        self.last_weather_data = {}
        self.last_injury_data = {}

        # Update intervals (seconds)
        self.update_intervals = {
            'odds': 300,      # 5 minutes
            'weather': 1800,  # 30 minutes
            'injuries': 600,  # 10 minutes
            'games': 60       # 1 minute
        }

    async def register_client(self, websocket: websockets.WebSocketServerProtocol):
        """Register a new client connection"""
        self.connected_clients.add(websocket)
        self.client_subscriptions[websocket] = set()
        logger.info(f"Client connected. Total clients: {len(self.connected_clients)}")

        # Send welcome message
        welcome_msg = {
            'type': 'welcome',
            'timestamp': datetime.now().isoformat(),
            'message': 'Connected to DFS Edge Pro real-time service',
            'available_feeds': list(self.update_intervals.keys())
        }
        await self._send_to_client(websocket, welcome_msg)

    async def unregister_client(self, websocket: websockets.WebSocketServerProtocol):
        """Remove a client connection"""
        self.connected_clients.discard(websocket)
        self.client_subscriptions.pop(websocket, None)
        logger.info(f"Client disconnected. Total clients: {len(self.connected_clients)}")

    async def subscribe_client(self, websocket: websockets.WebSocketServerProtocol,
                             feeds: List[str]):
        """Subscribe client to specific data feeds"""
        if websocket not in self.client_subscriptions:
            return

        valid_feeds = set(self.update_intervals.keys())
        requested_feeds = set(feeds)

        # Only allow valid feeds
        subscribed_feeds = requested_feeds.intersection(valid_feeds)
        self.client_subscriptions[websocket] = subscribed_feeds

        # Send confirmation
        confirm_msg = {
            'type': 'subscription_confirmed',
            'timestamp': datetime.now().isoformat(),
            'subscribed_feeds': list(subscribed_feeds),
            'invalid_feeds': list(requested_feeds - valid_feeds)
        }
        await self._send_to_client(websocket, confirm_msg)

        # Send current data for subscribed feeds
        await self._send_current_data(websocket, subscribed_feeds)

        logger.info(f"Client subscribed to feeds: {subscribed_feeds}")

    async def handle_message(self, websocket: websockets.WebSocketServerProtocol,
                           message: str):
        """Handle incoming client messages"""
        try:
            data = json.loads(message)

            if data.get('type') == 'subscribe':
                feeds = data.get('feeds', [])
                await self.subscribe_client(websocket, feeds)

            elif data.get('type') == 'unsubscribe':
                feeds = data.get('feeds', [])
                if websocket in self.client_subscriptions:
                    self.client_subscriptions[websocket] -= set(feeds)

            elif data.get('type') == 'ping':
                # Respond to ping with pong
                pong_msg = {
                    'type': 'pong',
                    'timestamp': datetime.now().isoformat()
                }
                await self._send_to_client(websocket, pong_msg)

        except json.JSONDecodeError:
            logger.warning("Received invalid JSON message")
        except Exception as e:
            logger.error(f"Error handling message: {e}")

    async def _send_to_client(self, websocket: websockets.WebSocketServerProtocol,
                            message: Dict):
        """Send message to specific client"""
        try:
            await websocket.send(json.dumps(message))
        except ConnectionClosedError:
            await self.unregister_client(websocket)
        except Exception as e:
            logger.error(f"Error sending message to client: {e}")
            await self.unregister_client(websocket)

    async def broadcast_update(self, update_type: str, data: Dict):
        """Broadcast update to all subscribed clients"""
        message = {
            'type': 'update',
            'feed': update_type,
            'timestamp': datetime.now().isoformat(),
            'data': data
        }

        disconnected_clients = []

        for client in self.connected_clients:
            try:
                if update_type in self.client_subscriptions.get(client, set()):
                    await client.send(json.dumps(message))
            except ConnectionClosedError:
                disconnected_clients.append(client)
            except Exception as e:
                logger.error(f"Error broadcasting to client: {e}")
                disconnected_clients.append(client)

        # Clean up disconnected clients
        for client in disconnected_clients:
            await self.unregister_client(client)

    async def _send_current_data(self, websocket: websockets.WebSocketServerProtocol,
                               feeds: Set[str]):
        """Send current data for subscribed feeds"""
        for feed in feeds:
            current_data = None

            if feed == 'odds':
                current_data = self.last_odds_data
            elif feed == 'weather':
                current_data = self.last_weather_data
            elif feed == 'injuries':
                current_data = self.last_injury_data

            if current_data:
                message = {
                    'type': 'current_data',
                    'feed': feed,
                    'timestamp': datetime.now().isoformat(),
                    'data': current_data
                }
                await self._send_to_client(websocket, message)

    def start_background_updates(self):
        """Start background threads for data updates"""
        for feed, interval in self.update_intervals.items():
            thread = threading.Thread(
                target=self._background_update_loop,
                args=(feed, interval),
                daemon=True
            )
            self.update_threads[feed] = thread
            thread.start()
            logger.info(f"Started background updates for {feed} (every {interval}s)")

    def _background_update_loop(self, feed: str, interval: int):
        """Background update loop for a specific feed"""
        while True:
            try:
                # Get updated data
                updated_data = self._fetch_feed_data(feed)

                if updated_data and self._data_changed(feed, updated_data):
                    # Update cache
                    self._update_cache(feed, updated_data)

                    # Broadcast to clients (run in event loop)
                    asyncio.run(self.broadcast_update(feed, updated_data))

                    logger.info(f"Broadcasted {feed} update to {len(self.connected_clients)} clients")

            except Exception as e:
                logger.error(f"Error in {feed} update loop: {e}")

            time.sleep(interval)

    def _fetch_feed_data(self, feed: str) -> Optional[Dict]:
        """Fetch data for a specific feed"""
        try:
            if feed == 'odds':
                # Get NBA and NFL odds
                nba_odds = self.odds_service.get_nba_odds()
                nfl_odds = self.odds_service.get_nfl_odds()
                return {'nba': nba_odds, 'nfl': nfl_odds}

            elif feed == 'weather':
                # Get weather for active games
                # This would need game schedule integration
                return self.weather_service.get_forecasts_for_games()

            elif feed == 'injuries':
                # Get latest injury reports
                nba_injuries = self.injury_service.get_nba_injuries()
                nfl_injuries = self.injury_service.get_nfl_injuries()
                return {'nba': nba_injuries, 'nfl': nfl_injuries}

            elif feed == 'games':
                # Get live game updates (scores, etc.)
                return self._get_live_game_updates()

        except Exception as e:
            logger.error(f"Error fetching {feed} data: {e}")
            return None

    def _data_changed(self, feed: str, new_data: Dict) -> bool:
        """Check if data has changed since last update"""
        last_data = getattr(self, f'last_{feed}_data', {})

        # Simple comparison - in production, you'd want more sophisticated change detection
        return json.dumps(new_data, sort_keys=True) != json.dumps(last_data, sort_keys=True)

    def _update_cache(self, feed: str, data: Dict):
        """Update cached data"""
        setattr(self, f'last_{feed}_data', data)

    def _get_live_game_updates(self) -> Dict:
        """Get live game updates (placeholder - would integrate with sports APIs)"""
        # This would integrate with ESPN, NBA API, etc. for live scores
        return {
            'active_games': [],
            'recent_updates': [],
            'timestamp': datetime.now().isoformat()
        }

    def get_connection_stats(self) -> Dict:
        """Get connection statistics"""
        total_clients = len(self.connected_clients)
        subscriptions = {}

        for client_subs in self.client_subscriptions.values():
            for feed in client_subs:
                subscriptions[feed] = subscriptions.get(feed, 0) + 1

        return {
            'total_clients': total_clients,
            'subscriptions_by_feed': subscriptions,
            'active_feeds': list(self.update_intervals.keys()),
            'timestamp': datetime.now().isoformat()
        }

# WebSocket handler function
async def dfs_websocket_handler(websocket: websockets.WebSocketServerProtocol,
                               path: str):
    """Main WebSocket handler"""
    service = DFSWebSocketService()

    await service.register_client(websocket)

    try:
        async for message in websocket:
            await service.handle_message(websocket, message)
    except ConnectionClosedError:
        pass
    finally:
        await service.unregister_client(websocket)

# Global service instance
websocket_service = DFSWebSocketService()

def start_websocket_service(host: str = "0.0.0.0", port: int = 8765):
    """Start the WebSocket service"""
    websocket_service.start_background_updates()

    start_server = websockets.serve(
        dfs_websocket_handler,
        host,
        port
    )

    logger.info(f"Starting DFS WebSocket service on {host}:{port}")
    asyncio.get_event_loop().run_until_complete(start_server)
    asyncio.get_event_loop().run_forever()

if __name__ == "__main__":
    # Test the WebSocket service
    print("Starting DFS WebSocket Service...")
    start_websocket_service()
