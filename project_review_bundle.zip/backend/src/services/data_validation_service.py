"""
Data Validation Service - Complete Integration
Validates data quality, detects anomalies, and ensures data integrity
"""

import pandas as pd
import numpy as np
import logging
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta
import json
from pathlib import Path
import duckdb
from collections import defaultdict

logger = logging.getLogger(__name__)

class DataValidationService:
    """Comprehensive data validation and anomaly detection"""

    def __init__(self, db_path: str = "data/dfs_master.duckdb"):
        self.db_path = Path(db_path)
        self.validation_rules = self._load_validation_rules()
        self.anomaly_thresholds = self._load_anomaly_thresholds()

    def _load_validation_rules(self) -> Dict:
        """Load data validation rules"""
        return {
            'players': {
                'required_fields': ['player_name', 'position', 'team'],
                'position_valid': ['QB', 'RB', 'WR', 'TE', 'K', 'DEF'],
                'salary_range': (3000, 20000),
                'projection_range': (0, 50)
            },
            'games': {
                'required_fields': ['home_team', 'away_team', 'game_date'],
                'future_date_only': True,
                'valid_teams': self._get_valid_teams()
            },
            'contests': {
                'required_fields': ['contest_date', 'platform', 'total_entries'],
                'entries_range': (1, 1000000),
                'valid_platforms': ['FanDuel', 'DraftKings', 'Yahoo']
            }
        }

    def _load_anomaly_thresholds(self) -> Dict:
        """Load anomaly detection thresholds"""
        return {
            'projection_zscore': 3.0,  # Standard deviations
            'ownership_change': 0.15,  # 15% change threshold
            'salary_efficiency': 2.0,  # Max points per $1K
            'correlation_threshold': 0.95,  # High correlation warning
            'missing_data_percent': 0.05  # 5% missing data threshold
        }

    def _get_valid_teams(self) -> List[str]:
        """Get list of valid NFL/NBA team abbreviations"""
        return [
            # NFL Teams
            'ARI', 'ATL', 'BAL', 'BUF', 'CAR', 'CHI', 'CIN', 'CLE', 'DAL', 'DEN',
            'DET', 'GB', 'HOU', 'IND', 'JAX', 'KC', 'LAC', 'LAR', 'LV', 'MIA',
            'MIN', 'NE', 'NO', 'NYG', 'NYJ', 'PHI', 'PIT', 'SEA', 'SF', 'TB',
            'TEN', 'WAS',
            # NBA Teams
            'ATL', 'BOS', 'BKN', 'CHA', 'CHI', 'CLE', 'DAL', 'DEN', 'DET', 'GSW',
            'HOU', 'IND', 'LAC', 'LAL', 'MEM', 'MIA', 'MIL', 'MIN', 'NOP', 'NYK',
            'OKC', 'ORL', 'PHI', 'PHX', 'POR', 'SAC', 'SAS', 'TOR', 'UTA', 'WAS'
        ]

    def validate_player_data(self, df: pd.DataFrame) -> Dict[str, List]:
        """Validate player data quality"""
        issues = defaultdict(list)

        # Check required fields
        required_fields = self.validation_rules['players']['required_fields']
        for field in required_fields:
            if field not in df.columns:
                issues['missing_columns'].append(field)
            else:
                missing_count = df[field].isnull().sum()
                if missing_count > 0:
                    issues['missing_data'].append(f"{field}: {missing_count} missing")

        # Validate positions
        if 'position' in df.columns:
            invalid_positions = df[~df['position'].isin(self.validation_rules['players']['position_valid'])]['position'].unique()
            if len(invalid_positions) > 0:
                issues['invalid_positions'].append(list(invalid_positions))

        # Validate salary range
        if 'salary' in df.columns:
            salary_range = self.validation_rules['players']['salary_range']
            out_of_range = df[(df['salary'] < salary_range[0]) | (df['salary'] > salary_range[1])]
            if len(out_of_range) > 0:
                issues['salary_range'].append(f"{len(out_of_range)} players outside ${salary_range[0]}-${salary_range[1]}")

        # Validate projections
        if 'projection' in df.columns:
            proj_range = self.validation_rules['players']['projection_range']
            out_of_range = df[(df['projection'] < proj_range[0]) | (df['projection'] > proj_range[1])]
            if len(out_of_range) > 0:
                issues['projection_range'].append(f"{len(out_of_range)} projections outside {proj_range[0]}-{proj_range[1]}")

        return dict(issues)

    def detect_projection_anomalies(self, df: pd.DataFrame) -> Dict[str, List]:
        """Detect anomalous projections using statistical methods"""
        anomalies = defaultdict(list)

        if 'projection' not in df.columns or len(df) < 10:
            return dict(anomalies)

        # Z-score analysis
        mean_proj = df['projection'].mean()
        std_proj = df['projection'].std()

        if std_proj > 0:
            df['z_score'] = (df['projection'] - mean_proj) / std_proj
            threshold = self.anomaly_thresholds['projection_zscore']

            high_anomalies = df[df['z_score'] > threshold]
            low_anomalies = df[df['z_score'] < -threshold]

            if len(high_anomalies) > 0:
                anomalies['high_projections'].extend(
                    high_anomalies[['player_name', 'projection', 'z_score']].to_dict('records')
                )

            if len(low_anomalies) > 0:
                anomalies['low_projections'].extend(
                    low_anomalies[['player_name', 'projection', 'z_score']].to_dict('records')
                )

        # Position-based analysis
        for position in df['position'].unique():
            pos_data = df[df['position'] == position]
            if len(pos_data) >= 5:
                pos_mean = pos_data['projection'].mean()
                pos_std = pos_data['projection'].std()

                if pos_std > 0:
                    pos_anomalies = pos_data[
                        abs(pos_data['projection'] - pos_mean) > 2 * pos_std
                    ]
                    if len(pos_anomalies) > 0:
                        anomalies[f'{position}_anomalies'].extend(
                            pos_anomalies[['player_name', 'projection']].to_dict('records')
                        )

        return dict(anomalies)

    def validate_historical_consistency(self, player_name: str, days_back: int = 30) -> Dict:
        """Validate player performance consistency"""
        try:
            conn = duckdb.connect(str(self.db_path), read_only=True)

            query = """
                SELECT
                    game_date,
                    actual_fpts,
                    salary,
                    ownership
                FROM contest_results
                WHERE player_name = ?
                    AND game_date >= CURRENT_DATE - INTERVAL '{}' days
                ORDER BY game_date DESC
            """.format(days_back)

            df = conn.execute(query, [player_name]).df()
            conn.close()

            if len(df) < 3:
                return {'status': 'insufficient_data', 'games': len(df)}

            # Calculate consistency metrics
            points_std = df['actual_fpts'].std()
            points_mean = df['actual_fpts'].mean()
            cv = points_std / points_mean if points_mean > 0 else float('inf')

            # Ownership stability
            ownership_std = df['ownership'].std() if 'ownership' in df.columns else 0

            # Recent form (last 3 games vs overall)
            recent_avg = df.head(3)['actual_fpts'].mean()
            overall_avg = df['actual_fpts'].mean()
            form_trend = (recent_avg - overall_avg) / overall_avg if overall_avg > 0 else 0

            return {
                'status': 'analyzed',
                'games_analyzed': len(df),
                'coefficient_of_variation': round(cv, 3),
                'ownership_stability': round(ownership_std, 3),
                'form_trend': round(form_trend, 3),
                'consistency_rating': self._rate_consistency(cv),
                'recent_vs_overall': {
                    'recent_avg': round(recent_avg, 2),
                    'overall_avg': round(overall_avg, 2),
                    'difference': round(recent_avg - overall_avg, 2)
                }
            }

        except Exception as e:
            logger.error(f"Consistency validation failed for {player_name}: {e}")
            return {'status': 'error', 'error': str(e)}

    def _rate_consistency(self, cv: float) -> str:
        """Rate player consistency based on coefficient of variation"""
        if cv < 0.3:
            return 'very_consistent'
        elif cv < 0.5:
            return 'consistent'
        elif cv < 0.7:
            return 'variable'
        else:
            return 'very_variable'

    def detect_correlation_anomalies(self, df: pd.DataFrame) -> Dict[str, List]:
        """Detect highly correlated players that might indicate stacking issues"""
        correlations = defaultdict(list)

        if len(df) < 10 or 'projection' not in df.columns:
            return dict(correlations)

        # Calculate correlation matrix
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        if len(numeric_cols) >= 2:
            corr_matrix = df[numeric_cols].corr()

            # Find high correlations
            threshold = self.anomaly_thresholds['correlation_threshold']
            high_corr = corr_matrix.where(
                (corr_matrix > threshold) & (corr_matrix < 1.0)
            ).stack()

            for (col1, col2), corr_value in high_corr.items():
                if col1 != col2:  # Avoid self-correlations
                    correlations['high_correlations'].append({
                        'feature1': col1,
                        'feature2': col2,
                        'correlation': round(corr_value, 3)
                    })

        return dict(correlations)

    def validate_data_quality_report(self, df: pd.DataFrame) -> Dict:
        """Generate comprehensive data quality report"""
        report = {
            'timestamp': datetime.now().isoformat(),
            'total_records': len(df),
            'data_validation': self.validate_player_data(df),
            'anomaly_detection': self.detect_projection_anomalies(df),
            'correlation_analysis': self.detect_correlation_anomalies(df),
            'summary': {}
        }

        # Calculate summary statistics
        total_issues = sum(len(issues) for issues in report['data_validation'].values())
        total_anomalies = sum(len(anomalies) for anomalies in report['anomaly_detection'].values())

        report['summary'] = {
            'data_quality_score': max(0, 100 - (total_issues * 5) - (total_anomalies * 2)),
            'total_validation_issues': total_issues,
            'total_anomalies': total_anomalies,
            'recommendations': self._generate_recommendations(report)
        }

        return report

    def _generate_recommendations(self, report: Dict) -> List[str]:
        """Generate actionable recommendations based on validation results"""
        recommendations = []

        validation_issues = report.get('data_validation', {})
        anomalies = report.get('anomaly_detection', {})

        # Missing data recommendations
        if 'missing_data' in validation_issues:
            recommendations.append("Address missing data fields to improve model accuracy")

        # Anomaly recommendations
        if 'high_projections' in anomalies:
            recommendations.append("Review unusually high projections for data entry errors")

        if 'low_projections' in anomalies:
            recommendations.append("Investigate unusually low projections for injury concerns")

        # Correlation recommendations
        if 'high_correlations' in report.get('correlation_analysis', {}):
            recommendations.append("Consider correlation effects in lineup optimization")

        # General recommendations
        if report['summary']['data_quality_score'] < 80:
            recommendations.append("Improve data quality before using in production models")

        return recommendations

    def save_validation_report(self, report: Dict, filename: str = None) -> str:
        """Save validation report to file"""
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"data/validation_reports/data_quality_report_{timestamp}.json"

        Path(filename).parent.mkdir(parents=True, exist_ok=True)

        with open(filename, 'w') as f:
            json.dump(report, f, indent=2, default=str)

        logger.info(f"Validation report saved to {filename}")
        return filename

# Convenience functions
def validate_player_pool(df: pd.DataFrame) -> Dict:
    """Validate a player pool DataFrame"""
    validator = DataValidationService()
    return validator.validate_data_quality_report(df)

def check_player_consistency(player_name: str, days_back: int = 30) -> Dict:
    """Check individual player consistency"""
    validator = DataValidationService()
    return validator.validate_historical_consistency(player_name, days_back)

if __name__ == "__main__":
    # Test the validation service
    validator = DataValidationService()

    # Create sample data for testing
    sample_data = pd.DataFrame({
        'player_name': ['Patrick Mahomes', 'Christian McCaffrey', 'Cooper Kupp', 'Travis Kelce'],
        'position': ['QB', 'RB', 'WR', 'TE'],
        'team': ['KC', 'SF', 'LAR', 'KC'],
        'salary': [12000, 11000, 10000, 9000],
        'projection': [25.0, 22.0, 18.0, 15.0]
    })

    print("Testing Data Validation Service...")

    # Run validation
    report = validator.validate_data_quality_report(sample_data)

    print(f"Data Quality Score: {report['summary']['data_quality_score']}%")
    print(f"Validation Issues: {report['summary']['total_validation_issues']}")
    print(f"Anomalies Detected: {report['summary']['total_anomalies']}")

    if report['summary']['recommendations']:
        print("\nRecommendations:")
        for rec in report['summary']['recommendations']:
            print(f"  • {rec}")

    # Save report
    filename = validator.save_validation_report(report)
    print(f"\nReport saved to: {filename}")
