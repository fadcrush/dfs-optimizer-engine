"""
Real-Time Injury Service
Fetches injury data from SportsData.io and updates player status
"""
"""
Real-Time Injury Service
"""

import os
import requests
from datetime import datetime
from typing import List, Dict
import pandas as pd
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables FIRST
load_dotenv()

# Get API key from environment
SPORTSDATA_API_KEY = os.getenv('SPORTSDATA_API_KEY', '')

class InjuryService:
    """
    Manages real-time injury data from external APIs
    """
    
    def __init__(self):
        self.base_url = "https://api.sportsdata.io/v3/nba"
        self.api_key = SPORTSDATA_API_KEY
        
    def get_injury_updates(self) -> List[Dict]:
        """
        Fetch current injury reports from SportsData.io
        
        Returns list of injured players with status
        """
        
        if not self.api_key:
            print("⚠️  No API key found - set SPORTSDATA_API_KEY in .env")
            return []
        
        try:
            # SportsData.io injury endpoint
            url = f"{self.base_url}/scores/json/Players?key={self.api_key}"
            
            print(f"🏥 Fetching injury data from SportsData.io...")
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            
            players = response.json()
            
            # Filter for injured players
            injured_players = []
            
            for player in players:
                injury_status = player.get('InjuryStatus', '')
                
                if injury_status and injury_status != 'Healthy':
                    injured_players.append({
                        'player_id': player.get('PlayerID'),
                        'name': f"{player.get('FirstName', '')} {player.get('LastName', '')}".strip(),
                        'team': player.get('Team', ''),
                        'position': player.get('Position', ''),
                        'injury_status': injury_status,  # OUT, GTD, QUESTIONABLE, DOUBTFUL
                        'injury_body_part': player.get('InjuryBodyPart', ''),
                        'injury_start_date': player.get('InjuryStartDate', ''),
                        'injury_notes': player.get('InjuryNotes', ''),
                        'updated_at': datetime.now().isoformat()
                    })
            
            print(f"✅ Found {len(injured_players)} injured players")
            
            return injured_players
        
        except Exception as e:
            print(f"❌ Error fetching injuries: {e}")
            return []
    
    def get_todays_games(self) -> List[Dict]:
        """
        Get today's NBA games with lineups and status
        """
        
        if not self.api_key:
            return []
        
        try:
            # Get today's date
            today = datetime.now().strftime('%Y-%m-%d')
            
            url = f"{self.base_url}/scores/json/GamesByDate/{today}?key={self.api_key}"
            
            print(f"🏀 Fetching today's games...")
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            
            games = response.json()
            
            print(f"✅ Found {len(games)} games today")
            
            return games
        
        except Exception as e:
            print(f"❌ Error fetching games: {e}")
            return []
    
    def check_player_status(self, player_name: str) -> Dict:
        """
        Check specific player's injury status
        
        Args:
            player_name: Player's full name
        
        Returns:
            Dict with injury status or None
        """
        
        injuries = self.get_injury_updates()
        
        # Normalize name for matching
        player_name_lower = player_name.lower().strip()
        
        for injury in injuries:
            if player_name_lower in injury['name'].lower():
                return injury
        
        return {
            'name': player_name,
            'injury_status': 'HEALTHY',
            'injury_notes': 'No injury reported',
            'updated_at': datetime.now().isoformat()
        }
    
    def get_injury_report_text(self) -> str:
        """
        Generate human-readable injury report
        """
        
        injuries = self.get_injury_updates()
        
        if not injuries:
            return "📋 No injuries reported"
        
        # Group by status
        out = [p for p in injuries if p['injury_status'] == 'Out']
        gtd = [p for p in injuries if p['injury_status'] in ['GTD', 'Questionable']]
        doubtful = [p for p in injuries if p['injury_status'] == 'Doubtful']
        
        report = f"\n🏥 INJURY REPORT ({len(injuries)} players)\n"
        report += "="*60 + "\n"
        
        if out:
            report += f"\n❌ OUT ({len(out)} players):\n"
            for p in out[:10]:  # Top 10
                report += f"   • {p['name']} ({p['team']}) - {p['injury_body_part']}\n"
        
        if doubtful:
            report += f"\n⚠️  DOUBTFUL ({len(doubtful)} players):\n"
            for p in doubtful[:10]:
                report += f"   • {p['name']} ({p['team']}) - {p['injury_body_part']}\n"
        
        if gtd:
            report += f"\n❓ QUESTIONABLE/GTD ({len(gtd)} players):\n"
            for p in gtd[:10]:
                report += f"   • {p['name']} ({p['team']}) - {p['injury_body_part']}\n"
        
        return report
    
    def update_projections_with_injuries(self, projections_df: pd.DataFrame) -> pd.DataFrame:
        """
        Update projections DataFrame with current injury status
        
        Args:
            projections_df: DataFrame with player projections
        
        Returns:
            Updated DataFrame with injury_status column
        """
        
        injuries = self.get_injury_updates()
        
        # Create injury lookup dict
        injury_lookup = {
            injury['name'].lower().strip(): injury['injury_status']
            for injury in injuries
        }
        
        # Add injury status column
        if 'name' in projections_df.columns:
            projections_df['injury_status'] = projections_df['name'].apply(
                lambda name: injury_lookup.get(str(name).lower().strip(), '')
            )
        
        # Mark OUT players with 0 projection
        if 'injury_status' in projections_df.columns:
            out_mask = projections_df['injury_status'] == 'Out'
            projections_df.loc[out_mask, 'projection'] = 0.0
            
            print(f"⚠️  Marked {out_mask.sum()} OUT players with 0 projection")
        
        return projections_df


async def get_injury_updates() -> Dict:
    """
    Async wrapper for injury updates
    Returns formatted injury data for API
    """
    
    service = InjuryService()
    injuries = service.get_injury_updates()
    games = service.get_todays_games()
    
    return {
        "success": True,
        "injuries": injuries,
        "games": games,
        "total_injured": len(injuries),
        "updated_at": datetime.now().isoformat()
    }


async def check_player_status(player_name: str) -> Dict:
    """
    Check specific player injury status
    """
    
    service = InjuryService()
    status = service.check_player_status(player_name)
    
    return {
        "success": True,
        "player": status
    }