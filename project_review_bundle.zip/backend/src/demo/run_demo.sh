#!/bin/bash
# Demo script for DFS Platform backend
# Shows complete workflow: database setup → ingest → build projections → evaluate

set -e

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${BLUE}=== DFS Platform Backend Demo ===${NC}\n"

# Step 1: Setup database
echo -e "${YELLOW}Step 1: Setting up database...${NC}"
python backend/cli.py setup-database --dry-run
echo -e "${GREEN}✓ Database schema ready${NC}\n"

# Step 2: Ingest sample FanDuel slate
echo -e "${YELLOW}Step 2: Ingesting FanDuel slate...${NC}"
python backend/cli.py ingest-slate-csv \
    --file backend/demo/sample_fanduel_slate.csv \
    --site fanduel \
    --dry-run
echo -e "${GREEN}✓ FanDuel slate validated${NC}\n"

# Step 3: Ingest sample DraftKings slate
echo -e "${YELLOW}Step 3: Ingesting DraftKings slate...${NC}"
python backend/cli.py ingest-slate-csv \
    --file backend/demo/sample_draftkings_slate.csv \
    --site draftkings \
    --dry-run
echo -e "${GREEN}✓ DraftKings slate validated${NC}\n"

# Step 4: Build projections
echo -e "${YELLOW}Step 4: Building projections at point-in-time...${NC}"
python backend/cli.py build-projections \
    --slate-id fd_nba_20260122 \
    --as-of-time "2026-01-22T18:00:00Z" \
    --dry-run
echo -e "${GREEN}✓ Projections built${NC}\n"

# Step 5: Ingest results
echo -e "${YELLOW}Step 5: Ingesting contest results...${NC}"
python backend/cli.py ingest-results \
    --file backend/demo/sample_results.csv \
    --dry-run
echo -e "${GREEN}✓ Results ingested${NC}\n"

# Step 6: Evaluate accuracy
echo -e "${YELLOW}Step 6: Evaluating projection accuracy...${NC}"
python backend/cli.py evaluate \
    --slate-id fd_nba_20260122 \
    --dry-run
echo -e "${GREEN}✓ Evaluation complete${NC}\n"

# Step 7: Run backtest
echo -e "${YELLOW}Step 7: Running backtest...${NC}"
python backend/cli.py backtest \
    --from-date 2026-01-01 \
    --to-date 2026-01-31 \
    --league NBA \
    --dry-run
echo -e "${GREEN}✓ Backtest simulation complete${NC}\n"

# Step 8: Show system status
echo -e "${YELLOW}Step 8: System Status${NC}"
python backend/cli.py status
echo -e "${GREEN}✓ All systems operational${NC}\n"

echo -e "${BLUE}=== Demo Complete ===${NC}"
echo -e "\nTo run without --dry-run and actually process data:"
echo -e "  ${YELLOW}python backend/cli.py setup-database${NC}"
echo -e "  ${YELLOW}python backend/cli.py ingest-slate-csv --file <csv> --site fanduel${NC}"
echo -e "  ${YELLOW}python backend/cli.py build-projections --slate-id <id>${NC}"
echo -e "  ${YELLOW}python backend/cli.py evaluate --slate-id <id>${NC}"
