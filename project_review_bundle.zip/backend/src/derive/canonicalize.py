"""Canonicalization - normalize data to canonical dimensions."""

import logging
from typing import Dict, List, Optional, Any
from datetime import datetime

from core import get_utc_now

logger = logging.getLogger(__name__)


class CanonicalPlayer:
    """Canonical player dimension."""
    
    def __init__(
        self,
        player_id: str,
        league: str,
        canonical_name: str,
        position: str,
    ):
        self.player_id = player_id
        self.league = league
        self.canonical_name = canonical_name
        self.position = position
        self.birth_date: Optional[datetime] = None
        self.height: Optional[float] = None
        self.weight: Optional[float] = None
        self.active = True
        self.created_at = get_utc_now()
        self.updated_at = get_utc_now()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to database row."""
        return {
            "player_id": self.player_id,
            "league": self.league,
            "canonical_name": self.canonical_name,
            "position": self.position,
            "birth_date": self.birth_date,
            "height": self.height,
            "weight": self.weight,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "active": self.active,
        }


class CanonicalTeam:
    """Canonical team dimension."""
    
    def __init__(
        self,
        team_id: str,
        league: str,
        canonical_code: str,
        full_name: str,
        city: str,
    ):
        self.team_id = team_id
        self.league = league
        self.canonical_code = canonical_code
        self.full_name = full_name
        self.city = city
        self.created_at = get_utc_now()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to database row."""
        return {
            "team_id": self.team_id,
            "league": self.league,
            "canonical_code": self.canonical_code,
            "full_name": self.full_name,
            "city": self.city,
            "created_at": self.created_at,
        }


class CanonicalGame:
    """Canonical game dimension."""
    
    def __init__(
        self,
        game_id: str,
        league: str,
        season: int,
        game_date: datetime,
        game_datetime_utc: datetime,
        home_team_id: str,
        away_team_id: str,
    ):
        self.game_id = game_id
        self.league = league
        self.season = season
        self.game_date = game_date
        self.game_datetime_utc = game_datetime_utc
        self.home_team_id = home_team_id
        self.away_team_id = away_team_id
        self.venue: Optional[str] = None
        self.created_at = get_utc_now()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to database row."""
        return {
            "game_id": self.game_id,
            "league": self.league,
            "season": self.season,
            "game_date": self.game_date,
            "game_datetime_utc": self.game_datetime_utc,
            "home_team_id": self.home_team_id,
            "away_team_id": self.away_team_id,
            "venue": self.venue,
            "created_at": self.created_at,
        }


class CanonicalSlate:
    """Canonical slate dimension."""
    
    def __init__(
        self,
        slate_id: str,
        league: str,
        site: str,
        slate_date: datetime,
        lock_time: datetime,
        salary_cap: int,
    ):
        self.slate_id = slate_id
        self.league = league
        self.site = site
        self.slate_date = slate_date
        self.slate_type = "Main"
        self.lock_time = lock_time
        self.salary_cap = salary_cap
        self.roster_slots: List[str] = []
        self.created_at = get_utc_now()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to database row."""
        return {
            "slate_id": self.slate_id,
            "league": self.league,
            "site": self.site,
            "slate_date": self.slate_date,
            "slate_type": self.slate_type,
            "lock_time": self.lock_time,
            "salary_cap": self.salary_cap,
            "roster_slots": ",".join(self.roster_slots) if self.roster_slots else None,
            "created_at": self.created_at,
        }


class Canonicalizer:
    """Normalizes raw data to canonical dimensions."""
    
    def __init__(self, connection):
        """
        Initialize canonicalizer.
        
        Args:
            connection: SQLAlchemy database connection
        """
        self.connection = connection
        self.logger = logging.getLogger(__name__)
        
        # Cache for lookups
        self.player_cache: Dict[str, CanonicalPlayer] = {}
        self.team_cache: Dict[str, CanonicalTeam] = {}
        self.game_cache: Dict[str, CanonicalGame] = {}
        self.slate_cache: Dict[str, CanonicalSlate] = {}
    
    def get_or_create_player(
        self,
        player_id: str,
        league: str,
        canonical_name: str,
        position: str,
    ) -> CanonicalPlayer:
        """
        Get existing player or create new.
        
        Args:
            player_id: Player ID
            league: NBA or NFL
            canonical_name: Standardized player name
            position: Player position
            
        Returns:
            CanonicalPlayer instance
        """
        cache_key = f"{league}_{player_id}"
        
        if cache_key in self.player_cache:
            return self.player_cache[cache_key]
        
        # Try to load from database
        from sqlalchemy import text
        
        query = "SELECT * FROM dim_players WHERE player_id = :player_id AND league = :league"
        result = self.connection.execute(
            text(query),
            {"player_id": player_id, "league": league}
        )
        
        row = result.first()
        if row:
            data = dict(row._mapping)
            player = CanonicalPlayer(
                player_id=data["player_id"],
                league=data["league"],
                canonical_name=data["canonical_name"],
                position=data["position"],
            )
            player.birth_date = data.get("birth_date")
            player.height = data.get("height")
            player.weight = data.get("weight")
            player.active = data.get("active", True)
            player.created_at = data.get("created_at")
            player.updated_at = data.get("updated_at")
        else:
            # Create new
            player = CanonicalPlayer(
                player_id=player_id,
                league=league,
                canonical_name=canonical_name,
                position=position,
            )
            self.logger.debug(f"Created new canonical player: {player_id}")
        
        self.player_cache[cache_key] = player
        return player
    
    def get_or_create_team(
        self,
        team_id: str,
        league: str,
        canonical_code: str,
        full_name: str,
        city: str,
    ) -> CanonicalTeam:
        """Get or create canonical team."""
        cache_key = f"{league}_{team_id}"
        
        if cache_key in self.team_cache:
            return self.team_cache[cache_key]
        
        from sqlalchemy import text
        
        query = "SELECT * FROM dim_teams WHERE team_id = :team_id AND league = :league"
        result = self.connection.execute(
            text(query),
            {"team_id": team_id, "league": league}
        )
        
        row = result.first()
        if row:
            data = dict(row._mapping)
            team = CanonicalTeam(
                team_id=data["team_id"],
                league=data["league"],
                canonical_code=data["canonical_code"],
                full_name=data["full_name"],
                city=data["city"],
            )
            team.created_at = data.get("created_at")
        else:
            team = CanonicalTeam(
                team_id=team_id,
                league=league,
                canonical_code=canonical_code,
                full_name=full_name,
                city=city,
            )
            self.logger.debug(f"Created new canonical team: {team_id}")
        
        self.team_cache[cache_key] = team
        return team
    
    def get_or_create_game(
        self,
        game_id: str,
        league: str,
        season: int,
        game_date: datetime,
        game_datetime_utc: datetime,
        home_team_id: str,
        away_team_id: str,
    ) -> CanonicalGame:
        """Get or create canonical game."""
        cache_key = f"{league}_{game_id}"
        
        if cache_key in self.game_cache:
            return self.game_cache[cache_key]
        
        from sqlalchemy import text
        
        query = "SELECT * FROM dim_games WHERE game_id = :game_id AND league = :league"
        result = self.connection.execute(
            text(query),
            {"game_id": game_id, "league": league}
        )
        
        row = result.first()
        if row:
            data = dict(row._mapping)
            game = CanonicalGame(
                game_id=data["game_id"],
                league=data["league"],
                season=data["season"],
                game_date=data["game_date"],
                game_datetime_utc=data["game_datetime_utc"],
                home_team_id=data["home_team_id"],
                away_team_id=data["away_team_id"],
            )
            game.venue = data.get("venue")
        else:
            game = CanonicalGame(
                game_id=game_id,
                league=league,
                season=season,
                game_date=game_date,
                game_datetime_utc=game_datetime_utc,
                home_team_id=home_team_id,
                away_team_id=away_team_id,
            )
            self.logger.debug(f"Created new canonical game: {game_id}")
        
        self.game_cache[cache_key] = game
        return game
    
    def get_or_create_slate(
        self,
        slate_id: str,
        league: str,
        site: str,
        slate_date: datetime,
        lock_time: datetime,
        salary_cap: int,
    ) -> CanonicalSlate:
        """Get or create canonical slate."""
        if slate_id in self.slate_cache:
            return self.slate_cache[slate_id]
        
        from sqlalchemy import text
        
        query = "SELECT * FROM dim_slates WHERE slate_id = :slate_id"
        result = self.connection.execute(
            text(query),
            {"slate_id": slate_id}
        )
        
        row = result.first()
        if row:
            data = dict(row._mapping)
            slate = CanonicalSlate(
                slate_id=data["slate_id"],
                league=data["league"],
                site=data["site"],
                slate_date=data["slate_date"],
                lock_time=data["lock_time"],
                salary_cap=data["salary_cap"],
            )
            slate.slate_type = data.get("slate_type", "Main")
            if data.get("roster_slots"):
                slate.roster_slots = data["roster_slots"].split(",")
        else:
            slate = CanonicalSlate(
                slate_id=slate_id,
                league=league,
                site=site,
                slate_date=slate_date,
                lock_time=lock_time,
                salary_cap=salary_cap,
            )
            self.logger.debug(f"Created new canonical slate: {slate_id}")
        
        self.slate_cache[slate_id] = slate
        return slate
    
    def persist_player(self, player: CanonicalPlayer) -> bool:
        """Persist player to database."""
        from sqlalchemy import text
        
        try:
            # Try insert first
            query = """
                INSERT INTO dim_players 
                (player_id, league, canonical_name, position, birth_date, 
                 height, weight, created_at, updated_at, active)
                VALUES 
                (:player_id, :league, :canonical_name, :position, :birth_date,
                 :height, :weight, :created_at, :updated_at, :active)
                ON CONFLICT (player_id) DO UPDATE SET
                    updated_at = EXCLUDED.updated_at
            """
            
            data = player.to_dict()
            self.connection.execute(text(query), data)
            self.connection.commit()
            return True
        except Exception as e:
            self.logger.error(f"Error persisting player {player.player_id}: {str(e)}")
            self.connection.rollback()
            return False
    
    def persist_team(self, team: CanonicalTeam) -> bool:
        """Persist team to database."""
        from sqlalchemy import text
        
        try:
            query = """
                INSERT INTO dim_teams 
                (team_id, league, canonical_code, full_name, city, created_at)
                VALUES 
                (:team_id, :league, :canonical_code, :full_name, :city, :created_at)
                ON CONFLICT (team_id) DO NOTHING
            """
            
            data = team.to_dict()
            self.connection.execute(text(query), data)
            self.connection.commit()
            return True
        except Exception as e:
            self.logger.error(f"Error persisting team {team.team_id}: {str(e)}")
            self.connection.rollback()
            return False
    
    def persist_game(self, game: CanonicalGame) -> bool:
        """Persist game to database."""
        from sqlalchemy import text
        
        try:
            query = """
                INSERT INTO dim_games 
                (game_id, league, season, game_date, game_datetime_utc, 
                 home_team_id, away_team_id, venue, created_at)
                VALUES 
                (:game_id, :league, :season, :game_date, :game_datetime_utc,
                 :home_team_id, :away_team_id, :venue, :created_at)
                ON CONFLICT (game_id) DO NOTHING
            """
            
            data = game.to_dict()
            self.connection.execute(text(query), data)
            self.connection.commit()
            return True
        except Exception as e:
            self.logger.error(f"Error persisting game {game.game_id}: {str(e)}")
            self.connection.rollback()
            return False
    
    def persist_slate(self, slate: CanonicalSlate) -> bool:
        """Persist slate to database."""
        from sqlalchemy import text
        
        try:
            query = """
                INSERT INTO dim_slates 
                (slate_id, league, site, slate_date, slate_type, lock_time, 
                 salary_cap, roster_slots, created_at)
                VALUES 
                (:slate_id, :league, :site, :slate_date, :slate_type, :lock_time,
                 :salary_cap, :roster_slots, :created_at)
                ON CONFLICT (slate_id) DO NOTHING
            """
            
            data = slate.to_dict()
            self.connection.execute(text(query), data)
            self.connection.commit()
            return True
        except Exception as e:
            self.logger.error(f"Error persisting slate {slate.slate_id}: {str(e)}")
            self.connection.rollback()
            return False
