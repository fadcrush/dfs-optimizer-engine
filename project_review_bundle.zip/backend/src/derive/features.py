"""Feature builders - compute baseline statistics."""

import logging
from typing import Dict, List, Optional, Any
from datetime import datetime

logger = logging.getLogger(__name__)


class MinutesBaseline:
    """Baseline minutes distribution for a player."""
    
    def __init__(self, player_id: str, season: int):
        self.player_id = player_id
        self.season = season
        
        # Baseline statistics
        self.avg_minutes: float = 0.0
        self.min_minutes: float = 0.0
        self.max_minutes: float = 0.0
        self.floor_minutes: float = 0.0  # 25th percentile
        self.ceiling_minutes: float = 0.0  # 75th percentile
        
        # Confidence
        self.games_played: int = 0
        self.reliability_score: float = 0.5  # 0-1, higher = more confident
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to data dict."""
        return {
            "player_id": self.player_id,
            "season": self.season,
            "avg_minutes": self.avg_minutes,
            "min_minutes": self.min_minutes,
            "max_minutes": self.max_minutes,
            "floor_minutes": self.floor_minutes,
            "ceiling_minutes": self.ceiling_minutes,
            "games_played": self.games_played,
            "reliability_score": self.reliability_score,
        }


class UsageBaseline:
    """Baseline usage rate for a player."""
    
    def __init__(self, player_id: str, season: int):
        self.player_id = player_id
        self.season = season
        
        # Usage statistics (percentage of team possessions/attempts)
        self.avg_usage: float = 0.0
        self.floor_usage: float = 0.0
        self.ceiling_usage: float = 0.0
        
        # Splits by position
        self.vs_positional_avg: float = 0.0
        
        # Reliability
        self.games_played: int = 0
        self.reliability_score: float = 0.5
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to data dict."""
        return {
            "player_id": self.player_id,
            "season": self.season,
            "avg_usage": self.avg_usage,
            "floor_usage": self.floor_usage,
            "ceiling_usage": self.ceiling_usage,
            "vs_positional_avg": self.vs_positional_avg,
            "games_played": self.games_played,
            "reliability_score": self.reliability_score,
        }


class MatchupContext:
    """Matchup-specific context for projection."""
    
    def __init__(self, game_id: str, league: str):
        self.game_id = game_id
        self.league = league
        
        # Game-level factors
        self.pace: float = 100.0  # Possessions per game
        self.pace_vs_league_avg: float = 0.0
        
        # Defensive context
        self.defense_efficiency: float = 1.0  # Multiplier vs average
        self.position_defense_efficiency: Dict[str, float] = {}
        
        # Game environment
        self.expected_spread: float = 0.0  # Home team expected margin
        self.expected_pace: float = 100.0
        self.game_flow: str = "normal"  # tight, blowout, etc.
        
        # Confidence
        self.created_at = datetime.utcnow()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to data dict."""
        return {
            "game_id": self.game_id,
            "league": self.league,
            "pace": self.pace,
            "pace_vs_league_avg": self.pace_vs_league_avg,
            "defense_efficiency": self.defense_efficiency,
            "position_defense_efficiency": self.position_defense_efficiency,
            "expected_spread": self.expected_spread,
            "expected_pace": self.expected_pace,
            "game_flow": self.game_flow,
        }


class FeatureBuilder:
    """Builds baseline features from historical data."""
    
    def __init__(self, connection):
        """
        Initialize feature builder.
        
        Args:
            connection: SQLAlchemy database connection
        """
        self.connection = connection
        self.logger = logging.getLogger(__name__)
    
    def compute_minutes_baseline(
        self,
        player_id: str,
        season: int,
        league: str,
    ) -> Optional[MinutesBaseline]:
        """
        Compute baseline minutes for a player in a season.
        
        Uses historical actual results to compute:
        - Average minutes played
        - Floor (25th percentile) and ceiling (75th percentile)
        - Reliability score based on games played
        
        Args:
            player_id: Player ID
            season: Season year
            league: NBA or NFL
            
        Returns:
            MinutesBaseline with computed statistics
        """
        from sqlalchemy import text
        
        # Query actual results for this player in season
        query = """
            SELECT 
                COUNT(*) as games_played,
                AVG(minutes_played) as avg_minutes,
                MIN(minutes_played) as min_minutes,
                MAX(minutes_played) as max_minutes,
                PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY minutes_played) as floor_minutes,
                PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY minutes_played) as ceiling_minutes
            FROM fact_actual_player_results
            WHERE player_id = :player_id
              AND league = :league
              AND EXTRACT(YEAR FROM created_at) = :season
        """
        
        result = self.connection.execute(
            text(query),
            {"player_id": player_id, "season": season, "league": league}
        )
        
        row = result.first()
        if not row:
            self.logger.warning(f"No historical data for {player_id} in {season}")
            return None
        
        data = dict(row._mapping)
        
        baseline = MinutesBaseline(player_id, season)
        baseline.games_played = data.get("games_played", 0) or 0
        baseline.avg_minutes = float(data.get("avg_minutes") or 0.0)
        baseline.min_minutes = float(data.get("min_minutes") or 0.0)
        baseline.max_minutes = float(data.get("max_minutes") or 0.0)
        baseline.floor_minutes = float(data.get("floor_minutes") or 0.0)
        baseline.ceiling_minutes = float(data.get("ceiling_minutes") or 0.0)
        
        # Compute reliability: more games = higher confidence
        # Cap at 1.0, scale by games (assume ~82 games in NBA season)
        baseline.reliability_score = min(1.0, baseline.games_played / 82.0)
        
        self.logger.info(
            f"Computed minutes baseline for {player_id}: "
            f"avg={baseline.avg_minutes:.1f}, games={baseline.games_played}"
        )
        
        return baseline
    
    def compute_usage_baseline(
        self,
        player_id: str,
        season: int,
        league: str,
    ) -> Optional[UsageBaseline]:
        """
        Compute baseline usage rate for a player.
        
        Uses historical actual results to estimate:
        - Average usage (percentage of team possessions)
        - Floor and ceiling estimates
        - Position-relative usage
        
        Args:
            player_id: Player ID
            season: Season year
            league: NBA or NFL
            
        Returns:
            UsageBaseline with computed statistics
        """
        from sqlalchemy import text
        
        # For now, use a placeholder implementation
        # In production, would use more sophisticated usage calculation
        # from box score data
        
        baseline = UsageBaseline(player_id, season)
        
        # Query games played
        query = """
            SELECT COUNT(*) as games_played
            FROM fact_actual_player_results
            WHERE player_id = :player_id
              AND league = :league
              AND EXTRACT(YEAR FROM created_at) = :season
        """
        
        result = self.connection.execute(
            text(query),
            {"player_id": player_id, "season": season, "league": league}
        )
        
        row = result.first()
        if row:
            baseline.games_played = dict(row._mapping).get("games_played", 0) or 0
            baseline.reliability_score = min(1.0, baseline.games_played / 82.0)
        
        return baseline
    
    def compute_matchup_context(
        self,
        game_id: str,
        league: str,
    ) -> Optional[MatchupContext]:
        """
        Compute matchup context for a game.
        
        Uses season-level statistics to estimate:
        - Pace of play
        - Defensive efficiency by position
        - Expected game flow
        
        Args:
            game_id: Game ID
            league: NBA or NFL
            
        Returns:
            MatchupContext with computed statistics
        """
        # Get game details
        from sqlalchemy import text
        
        query = """
            SELECT home_team_id, away_team_id
            FROM dim_games
            WHERE game_id = :game_id AND league = :league
        """
        
        result = self.connection.execute(
            text(query),
            {"game_id": game_id, "league": league}
        )
        
        row = result.first()
        if not row:
            self.logger.warning(f"Game not found: {game_id}")
            return None
        
        context = MatchupContext(game_id, league)
        
        # Placeholder implementation
        # In production, would load team-level pace/defense from precomputed stats
        context.pace = 100.0  # Average NBA pace
        context.expected_pace = 100.0
        
        return context


class FeatureCache:
    """Cache for computed features."""
    
    def __init__(self):
        self.minutes_cache: Dict[str, MinutesBaseline] = {}
        self.usage_cache: Dict[str, UsageBaseline] = {}
        self.matchup_cache: Dict[str, MatchupContext] = {}
    
    def get_minutes_baseline(
        self,
        player_id: str,
        season: int,
        league: str,
        builder: Optional[FeatureBuilder] = None,
    ) -> Optional[MinutesBaseline]:
        """Get minutes baseline with caching."""
        key = f"{league}_{player_id}_{season}"
        
        if key in self.minutes_cache:
            return self.minutes_cache[key]
        
        if builder is None:
            return None
        
        baseline = builder.compute_minutes_baseline(player_id, season, league)
        if baseline:
            self.minutes_cache[key] = baseline
        
        return baseline
    
    def get_usage_baseline(
        self,
        player_id: str,
        season: int,
        league: str,
        builder: Optional[FeatureBuilder] = None,
    ) -> Optional[UsageBaseline]:
        """Get usage baseline with caching."""
        key = f"{league}_{player_id}_{season}"
        
        if key in self.usage_cache:
            return self.usage_cache[key]
        
        if builder is None:
            return None
        
        baseline = builder.compute_usage_baseline(player_id, season, league)
        if baseline:
            self.usage_cache[key] = baseline
        
        return baseline
    
    def get_matchup_context(
        self,
        game_id: str,
        league: str,
        builder: Optional[FeatureBuilder] = None,
    ) -> Optional[MatchupContext]:
        """Get matchup context with caching."""
        key = f"{league}_{game_id}"
        
        if key in self.matchup_cache:
            return self.matchup_cache[key]
        
        if builder is None:
            return None
        
        context = builder.compute_matchup_context(game_id, league)
        if context:
            self.matchup_cache[key] = context
        
        return context


# Singleton feature cache
_feature_cache = None


def get_feature_cache() -> FeatureCache:
    """Get or create feature cache singleton."""
    global _feature_cache
    if _feature_cache is None:
        _feature_cache = FeatureCache()
    return _feature_cache
