"""Opportunity modifiers - adjust baselines based on context."""

import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass

from signals import SignalSpec, ConfirmedStarterSignal, InjuryOutSignal

logger = logging.getLogger(__name__)


@dataclass
class OpportunityModifiers:
    """
    Computed opportunity modifiers for a player.
    
    Shows how minutes/usage ceilings change based on context signals.
    """
    
    player_id: str
    game_id: str
    
    # Baseline (before modifiers)
    minutes_floor_baseline: float = 0.0
    minutes_ceiling_baseline: float = 0.0
    usage_floor_baseline: float = 0.0
    usage_ceiling_baseline: float = 0.0
    
    # Applied modifiers
    injury_minutes_adjustment: float = 0.0  # -20 if out
    starter_minutes_adjustment: float = 0.0  # +4 if starter
    depth_chart_adjustment: float = 0.0  # Depth change
    minutes_multiplier: float = 1.0  # Composite multiplier
    
    # Final (after modifiers)
    minutes_floor_final: float = 0.0
    minutes_ceiling_final: float = 0.0
    usage_floor_final: float = 0.0
    usage_ceiling_final: float = 0.0
    
    # Status
    is_out: bool = False
    is_starter: bool = False
    starter_status: Optional[str] = None
    depth_change: Optional[str] = None
    confidence: float = 1.0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "player_id": self.player_id,
            "game_id": self.game_id,
            "minutes_floor_baseline": self.minutes_floor_baseline,
            "minutes_ceiling_baseline": self.minutes_ceiling_baseline,
            "usage_floor_baseline": self.usage_floor_baseline,
            "usage_ceiling_baseline": self.usage_ceiling_baseline,
            "injury_minutes_adjustment": self.injury_minutes_adjustment,
            "starter_minutes_adjustment": self.starter_minutes_adjustment,
            "depth_chart_adjustment": self.depth_chart_adjustment,
            "minutes_multiplier": self.minutes_multiplier,
            "minutes_floor_final": self.minutes_floor_final,
            "minutes_ceiling_final": self.minutes_ceiling_final,
            "usage_floor_final": self.usage_floor_final,
            "usage_ceiling_final": self.usage_ceiling_final,
            "is_out": self.is_out,
            "is_starter": self.is_starter,
            "starter_status": self.starter_status,
            "depth_change": self.depth_change,
            "confidence": self.confidence,
        }


class OpportunityModifier:
    """
    Applies opportunity modifiers to baselines.
    
    Combines signals (injuries, starters, depth changes) with baseline features
    to compute final opportunity distributions.
    """
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def apply_modifiers(
        self,
        player_id: str,
        game_id: str,
        baseline_minutes_floor: float,
        baseline_minutes_ceiling: float,
        baseline_usage_floor: float,
        baseline_usage_ceiling: float,
        signals: List[SignalSpec],
    ) -> OpportunityModifiers:
        """
        Apply opportunity modifiers to baseline.
        
        Args:
            player_id: Player ID
            game_id: Game ID
            baseline_minutes_floor: Floor from historical data
            baseline_minutes_ceiling: Ceiling from historical data
            baseline_usage_floor: Usage floor
            baseline_usage_ceiling: Usage ceiling
            signals: List of relevant signals (injuries, starters, etc.)
            
        Returns:
            OpportunityModifiers with applied adjustments
        """
        modifiers = OpportunityModifiers(
            player_id=player_id,
            game_id=game_id,
            minutes_floor_baseline=baseline_minutes_floor,
            minutes_ceiling_baseline=baseline_minutes_ceiling,
            usage_floor_baseline=baseline_usage_floor,
            usage_ceiling_baseline=baseline_usage_ceiling,
        )
        
        # Check for injury OUT - hard override
        for signal in signals:
            if signal.signal_type == "injury_out":
                modifiers.is_out = True
                modifiers.minutes_floor_final = 0
                modifiers.minutes_ceiling_final = 0
                modifiers.usage_floor_final = 0
                modifiers.usage_ceiling_final = 0
                modifiers.confidence = signal.source_confidence
                self.logger.debug(f"{player_id} is OUT (injury)")
                return modifiers

        
        # Check for confirmed starter
        for signal in signals:
            if signal.signal_type == "confirmed_starter":
                modifiers.is_starter = True
                modifiers.starter_status = "confirmed"
                modifiers.starter_minutes_adjustment = 4
                modifiers.confidence = signal.source_confidence
                self.logger.debug(f"{player_id} is confirmed starter")
                break

        
        # Compute final minutes with adjustments
        minutes_adjustment = (
            modifiers.injury_minutes_adjustment +
            modifiers.starter_minutes_adjustment +
            modifiers.depth_chart_adjustment
        )
        
        modifiers.minutes_floor_final = max(
            0,
            baseline_minutes_floor + minutes_adjustment * 0.3  # Smaller impact on floor
        )
        modifiers.minutes_ceiling_final = max(
            0,
            baseline_minutes_ceiling + minutes_adjustment * 0.7  # Larger impact on ceiling
        )
        
        # Apply multiplier if any
        modifiers.minutes_floor_final *= modifiers.minutes_multiplier
        modifiers.minutes_ceiling_final *= modifiers.minutes_multiplier
        
        # Usage floors/ceilings (scaled by opportunity)
        if baseline_minutes_ceiling > 0:
            ceiling_ratio = modifiers.minutes_ceiling_final / baseline_minutes_ceiling
        else:
            ceiling_ratio = 1.0
        
        modifiers.usage_floor_final = baseline_usage_floor * ceiling_ratio
        modifiers.usage_ceiling_final = baseline_usage_ceiling * ceiling_ratio
        
        return modifiers
    
    def apply_depth_change(
        self,
        modifiers: OpportunityModifiers,
        depth_change: str,
        severity: float = 0.5,
    ) -> OpportunityModifiers:
        """
        Apply depth chart change modifier.
        
        Args:
            modifiers: Existing modifiers
            depth_change: "promoted" or "demoted"
            severity: Adjustment severity (0-1)
            
        Returns:
            Updated modifiers
        """
        if depth_change == "promoted":
            adjustment = 5 * severity  # More minutes when promoted
            modifiers.depth_chart_adjustment = adjustment
            modifiers.minutes_ceiling_final += adjustment
        elif depth_change == "demoted":
            adjustment = -5 * severity  # Fewer minutes when demoted
            modifiers.depth_chart_adjustment = adjustment
            modifiers.minutes_ceiling_final = max(0, modifiers.minutes_ceiling_final + adjustment)
        
        modifiers.depth_change = depth_change
        return modifiers
    
    def apply_foul_trouble(
        self,
        modifiers: OpportunityModifiers,
        fouls: int,
    ) -> OpportunityModifiers:
        """
        Apply foul trouble modifier during game.
        
        Args:
            modifiers: Existing modifiers
            fouls: Number of fouls
            
        Returns:
            Updated modifiers
        """
        if fouls >= 4:  # 2 fouls away from foul out
            # Reduce ceiling by 20-30%
            modifiers.minutes_multiplier *= 0.75
            modifiers.minutes_ceiling_final *= 0.75
        elif fouls >= 3:
            # Slight reduction
            modifiers.minutes_multiplier *= 0.9
            modifiers.minutes_ceiling_final *= 0.9
        
        return modifiers


class DepthChartAnalyzer:
    """Analyzes depth chart changes."""
    
    def __init__(self, connection):
        """
        Initialize analyzer.
        
        Args:
            connection: SQLAlchemy database connection
        """
        self.connection = connection
        self.logger = logging.getLogger(__name__)
    
    def analyze_depth_change(
        self,
        player_id: str,
        team_id: str,
        position: str,
        season: int,
        game_date: str,
    ) -> Optional[Dict[str, Any]]:
        """
        Analyze depth chart change for a player.
        
        Compares historical depth position with current to detect:
        - Promotion up depth chart
        - Demotion down depth chart
        - Entry/exit from rotation
        
        Args:
            player_id: Player ID
            team_id: Team ID
            position: Position
            season: Season
            game_date: Current game date
            
        Returns:
            Depth change analysis or None
        """
        from sqlalchemy import text
        
        # For now, placeholder - in production would query box score data
        # to track depth chart position over time
        
        self.logger.debug(
            f"Depth chart analysis for {player_id} on {game_date}: "
            f"would require historical depth data"
        )
        
        return None
