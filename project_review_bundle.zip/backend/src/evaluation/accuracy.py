"""Accuracy metrics - compare projections vs actual results."""

from dataclasses import dataclass
from datetime import datetime
from typing import Optional
import math

from core import get_utc_now, get_logger


logger = get_logger(__name__)


@dataclass
class ProjectionAccuracy:
    """Accuracy metrics for a single projection."""
    
    projection_id: int
    player_id: str
    game_id: str
    slate_id: str
    league: str
    
    # Projection details
    projected_fppg: float  # Median from projection
    projected_floor: float
    projected_ceiling: float
    projected_confidence: float
    
    # Actual result
    actual_fppg: float
    
    # Computed metrics
    error: float = 0.0  # actual - projected (can be positive or negative)
    abs_error: float = 0.0  # |error|
    squared_error: float = 0.0  # error^2 for RMSE
    percentile_rank: float = 0.0  # Where actual falls in distribution (0-100)
    is_within_range: bool = False  # Is actual between floor and ceiling?
    
    # Metadata
    as_of_time: datetime = None
    contest_type: str = "Cash"  # Cash or Tournament
    evaluation_time: datetime = None
    notes: str = ""
    
    def __post_init__(self):
        """Compute metrics."""
        if self.as_of_time is None:
            self.as_of_time = get_utc_now()
        if self.evaluation_time is None:
            self.evaluation_time = get_utc_now()
        
        # Compute error
        self.error = self.actual_fppg - self.projected_fppg
        self.abs_error = abs(self.error)
        self.squared_error = self.error ** 2
        
        # Compute percentile rank
        self.percentile_rank = self._compute_percentile_rank()
        
        # Check if within range
        self.is_within_range = (
            self.projected_floor <= self.actual_fppg <= self.projected_ceiling
        )
    
    def _compute_percentile_rank(self) -> float:
        """
        Estimate where actual falls in projection distribution (0-100).
        Uses floor/ceiling as bounds.
        """
        range_size = self.projected_ceiling - self.projected_floor
        if range_size <= 0:
            return 50.0  # Can't compute if no range
        
        # Linear mapping
        if self.actual_fppg < self.projected_floor:
            # Below floor - extrapolate
            pct = (self.actual_fppg - self.projected_floor) / (range_size / 0.25)
            return max(0, pct)
        elif self.actual_fppg > self.projected_ceiling:
            # Above ceiling - extrapolate
            pct = 75 + ((self.actual_fppg - self.projected_ceiling) / (range_size / 0.25))
            return min(100, pct)
        else:
            # Within range
            offset = self.actual_fppg - self.projected_floor
            pct = 25 + (offset / range_size) * 50  # 25-75 range
            return pct
    
    def to_dict(self):
        """Convert to dictionary."""
        return {
            "projection_id": self.projection_id,
            "player_id": self.player_id,
            "game_id": self.game_id,
            "slate_id": self.slate_id,
            "league": self.league,
            "projected_fppg": self.projected_fppg,
            "projected_floor": self.projected_floor,
            "projected_ceiling": self.projected_ceiling,
            "projected_confidence": self.projected_confidence,
            "actual_fppg": self.actual_fppg,
            "error": self.error,
            "abs_error": self.abs_error,
            "squared_error": self.squared_error,
            "percentile_rank": self.percentile_rank,
            "is_within_range": self.is_within_range,
            "contest_type": self.contest_type,
            "as_of_time": self.as_of_time.isoformat(),
            "evaluation_time": self.evaluation_time.isoformat(),
            "notes": self.notes,
        }


class AccuracyMetricsComputer:
    """Compute aggregated accuracy metrics."""
    
    @staticmethod
    def compute_rmse(accuracies: list) -> float:
        """
        Root Mean Squared Error.
        
        Args:
            accuracies: List of ProjectionAccuracy objects
            
        Returns:
            RMSE across all projections
        """
        if not accuracies:
            return 0.0
        
        sum_squared = sum(a.squared_error for a in accuracies)
        return math.sqrt(sum_squared / len(accuracies))
    
    @staticmethod
    def compute_mae(accuracies: list) -> float:
        """
        Mean Absolute Error.
        
        Args:
            accuracies: List of ProjectionAccuracy objects
            
        Returns:
            MAE across all projections
        """
        if not accuracies:
            return 0.0
        
        sum_abs = sum(a.abs_error for a in accuracies)
        return sum_abs / len(accuracies)
    
    @staticmethod
    def compute_hit_rate(accuracies: list) -> float:
        """
        Percentage of projections within floor/ceiling range.
        
        Args:
            accuracies: List of ProjectionAccuracy objects
            
        Returns:
            Hit rate 0-1
        """
        if not accuracies:
            return 0.0
        
        within_range = sum(1 for a in accuracies if a.is_within_range)
        return within_range / len(accuracies)
    
    @staticmethod
    def compute_average_percentile(accuracies: list) -> float:
        """
        Average percentile rank across projections.
        
        Args:
            accuracies: List of ProjectionAccuracy objects
            
        Returns:
            Average percentile (should be close to 50 for well-calibrated)
        """
        if not accuracies:
            return 50.0
        
        avg_pct = sum(a.percentile_rank for a in accuracies) / len(accuracies)
        return avg_pct
    
    @staticmethod
    def compute_bias(accuracies: list) -> float:
        """
        Mean error (positive = over-projecting, negative = under-projecting).
        
        Args:
            accuracies: List of ProjectionAccuracy objects
            
        Returns:
            Mean error (can be positive or negative)
        """
        if not accuracies:
            return 0.0
        
        sum_error = sum(a.error for a in accuracies)
        return sum_error / len(accuracies)
    
    @staticmethod
    def compute_correlation(accuracies: list) -> float:
        """
        Pearson correlation between projected and actual.
        
        Args:
            accuracies: List of ProjectionAccuracy objects
            
        Returns:
            Correlation coefficient (-1 to 1)
        """
        if len(accuracies) < 2:
            return 0.0
        
        projected = [a.projected_fppg for a in accuracies]
        actual = [a.actual_fppg for a in accuracies]
        
        mean_proj = sum(projected) / len(projected)
        mean_actual = sum(actual) / len(actual)
        
        covariance = sum(
            (projected[i] - mean_proj) * (actual[i] - mean_actual)
            for i in range(len(projected))
        ) / len(projected)
        
        std_proj = math.sqrt(
            sum((p - mean_proj) ** 2 for p in projected) / len(projected)
        )
        std_actual = math.sqrt(
            sum((a - mean_actual) ** 2 for a in actual) / len(actual)
        )
        
        if std_proj == 0 or std_actual == 0:
            return 0.0
        
        return covariance / (std_proj * std_actual)


@dataclass
class AccuracySummary:
    """Summary of accuracy metrics for a group."""
    
    group_key: str  # e.g., "NBA", "position_PG", "team_LAL"
    num_projections: int
    rmse: float
    mae: float
    hit_rate: float  # 0-1
    average_percentile: float
    bias: float
    correlation: float
    min_error: float
    max_error: float
    
    def to_dict(self):
        """Convert to dictionary."""
        return {
            "group_key": self.group_key,
            "num_projections": self.num_projections,
            "rmse": self.rmse,
            "mae": self.mae,
            "hit_rate": self.hit_rate,
            "average_percentile": self.average_percentile,
            "bias": self.bias,
            "correlation": self.correlation,
            "min_error": self.min_error,
            "max_error": self.max_error,
        }
