"""Bias tracking and dashboarding."""

from dataclasses import dataclass, field
from typing import Dict, List
from datetime import datetime

from core import get_utc_now, get_logger
from evaluation.accuracy import ProjectionAccuracy


logger = get_logger(__name__)


@dataclass
class BiasMetrics:
    """Bias metrics for a group."""
    
    group_key: str  # e.g., "team_LAL", "position_PG", "league_NBA"
    category: str  # "team", "position", "league", "contest_type"
    
    total_projections: int = 0
    sum_error: float = 0.0
    sum_abs_error: float = 0.0
    
    # Derived metrics
    mean_bias: float = 0.0  # Sum error / count
    mean_abs_error: float = 0.0
    over_projection_pct: float = 0.0  # % where projected > actual
    under_projection_pct: float = 0.0  # % where projected < actual
    
    updated_at: datetime = field(default_factory=get_utc_now)
    
    def add_projection(self, accuracy: ProjectionAccuracy):
        """
        Add projection result to bias metrics.
        
        Args:
            accuracy: ProjectionAccuracy object
        """
        self.total_projections += 1
        self.sum_error += accuracy.error
        self.sum_abs_error += accuracy.abs_error
        
        # Recompute
        self.mean_bias = self.sum_error / self.total_projections
        self.mean_abs_error = self.sum_abs_error / self.total_projections
        
        # Count over/under
        over_count = sum(1 for p in [accuracy] if p.error > 0)
        under_count = sum(1 for p in [accuracy] if p.error < 0)
        
        if self.total_projections > 0:
            self.over_projection_pct = over_count / 1  # 1 new projection
            self.under_projection_pct = under_count / 1
        
        self.updated_at = get_utc_now()
    
    def to_dict(self):
        """Convert to dictionary."""
        return {
            "group_key": self.group_key,
            "category": self.category,
            "total_projections": self.total_projections,
            "mean_bias": self.mean_bias,
            "mean_abs_error": self.mean_abs_error,
            "over_projection_pct": self.over_projection_pct,
            "under_projection_pct": self.under_projection_pct,
            "updated_at": self.updated_at.isoformat(),
        }


class BiasAnalyzer:
    """Analyze and track bias by dimension."""
    
    def __init__(self):
        """Initialize analyzer."""
        self.bias_by_team: Dict[str, BiasMetrics] = {}
        self.bias_by_position: Dict[str, BiasMetrics] = {}
        self.bias_by_league: Dict[str, BiasMetrics] = {}
        self.bias_by_contest_type: Dict[str, BiasMetrics] = {}
    
    def process_accuracies(self, accuracies: List[ProjectionAccuracy]):
        """
        Process batch of accuracy records and update bias metrics.
        
        Args:
            accuracies: List of ProjectionAccuracy objects
        """
        for accuracy in accuracies:
            # Track by league (requires team from somewhere - placeholder)
            league_key = f"league_{accuracy.league}"
            if league_key not in self.bias_by_league:
                self.bias_by_league[league_key] = BiasMetrics(
                    group_key=league_key,
                    category="league",
                )
            self.bias_by_league[league_key].add_projection(accuracy)
            
            # Track by contest type
            contest_key = f"contest_{accuracy.contest_type}"
            if contest_key not in self.bias_by_contest_type:
                self.bias_by_contest_type[contest_key] = BiasMetrics(
                    group_key=contest_key,
                    category="contest_type",
                )
            self.bias_by_contest_type[contest_key].add_projection(accuracy)
    
    def get_bias_by_league(self, league: str) -> BiasMetrics:
        """Get bias metrics for league."""
        key = f"league_{league}"
        return self.bias_by_league.get(key)
    
    def get_bias_by_contest_type(self, contest_type: str) -> BiasMetrics:
        """Get bias metrics for contest type."""
        key = f"contest_{contest_type}"
        return self.bias_by_contest_type.get(key)
    
    def get_overbiased_groups(self, threshold: float = 5.0) -> Dict[str, BiasMetrics]:
        """
        Identify groups that consistently over-project.
        
        Args:
            threshold: Absolute bias threshold
            
        Returns:
            Dict of group_key → BiasMetrics for over-biased groups
        """
        overbiased = {}
        
        for key, metrics in {
            **self.bias_by_league,
            **self.bias_by_contest_type,
        }.items():
            if metrics.mean_bias > threshold:
                overbiased[key] = metrics
        
        return overbiased
    
    def get_underbiased_groups(self, threshold: float = -5.0) -> Dict[str, BiasMetrics]:
        """
        Identify groups that consistently under-project.
        
        Args:
            threshold: Absolute bias threshold (negative)
            
        Returns:
            Dict of group_key → BiasMetrics for under-biased groups
        """
        underbiased = {}
        
        for key, metrics in {
            **self.bias_by_league,
            **self.bias_by_contest_type,
        }.items():
            if metrics.mean_bias < threshold:
                underbiased[key] = metrics
        
        return underbiased
    
    def generate_bias_report(self) -> Dict:
        """
        Generate comprehensive bias report.
        
        Returns:
            Report dict with bias by dimension
        """
        return {
            "by_league": {
                key: metrics.to_dict()
                for key, metrics in self.bias_by_league.items()
            },
            "by_contest_type": {
                key: metrics.to_dict()
                for key, metrics in self.bias_by_contest_type.items()
            },
            "overbiased_groups": {
                key: metrics.to_dict()
                for key, metrics in self.get_overbiased_groups().items()
            },
            "underbiased_groups": {
                key: metrics.to_dict()
                for key, metrics in self.get_underbiased_groups().items()
            },
        }


class BiasStore:
    """Store and retrieve bias metrics."""
    
    def __init__(self, connection):
        """Initialize store.
        
        Args:
            connection: Database connection
        """
        self.connection = connection
    
    def store_bias_metrics(self, metrics: BiasMetrics):
        """
        Store bias metrics to database.
        
        Args:
            metrics: BiasMetrics object
        """
        try:
            query = """
            INSERT INTO evaluation_bias (
                group_key, category, total_projections,
                mean_bias, mean_abs_error, over_projection_pct,
                under_projection_pct, updated_at
            ) VALUES (
                :group_key, :category, :total_projections,
                :mean_bias, :mean_abs_error, :over_projection_pct,
                :under_projection_pct, :updated_at
            )
            ON CONFLICT (group_key) DO UPDATE SET
                total_projections = EXCLUDED.total_projections,
                mean_bias = EXCLUDED.mean_bias,
                mean_abs_error = EXCLUDED.mean_abs_error,
                over_projection_pct = EXCLUDED.over_projection_pct,
                under_projection_pct = EXCLUDED.under_projection_pct,
                updated_at = EXCLUDED.updated_at
            """
            
            self.connection.execute(
                query,
                {
                    "group_key": metrics.group_key,
                    "category": metrics.category,
                    "total_projections": metrics.total_projections,
                    "mean_bias": metrics.mean_bias,
                    "mean_abs_error": metrics.mean_abs_error,
                    "over_projection_pct": metrics.over_projection_pct,
                    "under_projection_pct": metrics.under_projection_pct,
                    "updated_at": metrics.updated_at,
                },
            )
            
            logger.debug(f"Stored bias metrics for {metrics.group_key}")
        
        except Exception as e:
            logger.error(f"Error storing bias metrics: {e}")
            raise
    
    def get_bias_metrics(self, group_key: str) -> BiasMetrics:
        """
        Retrieve bias metrics for group.
        
        Args:
            group_key: Group identifier
            
        Returns:
            BiasMetrics or None
        """
        try:
            query = """
            SELECT
                group_key, category, total_projections, mean_bias,
                mean_abs_error, over_projection_pct, under_projection_pct,
                updated_at
            FROM evaluation_bias
            WHERE group_key = :group_key
            """
            
            result = self.connection.execute(
                query,
                {"group_key": group_key},
            ).first()
            
            if not result:
                return None
            
            return BiasMetrics(
                group_key=result[0],
                category=result[1],
                total_projections=result[2],
                sum_error=result[3] * result[2],  # Reverse-compute from mean
                sum_abs_error=result[4] * result[2],
                mean_bias=result[3],
                mean_abs_error=result[4],
                over_projection_pct=result[5],
                under_projection_pct=result[6],
                updated_at=result[7],
            )
        
        except Exception as e:
            logger.error(f"Error retrieving bias metrics: {e}")
            raise
