"""Self-correction feedback loop - automatic reliability adjustment."""

from datetime import datetime, timedelta
from typing import List, Dict

from core import get_utc_now, get_logger
from evaluation.accuracy import ProjectionAccuracy, AccuracyMetricsComputer
from evaluation.source_reliability import SourceReliabilityTracker


logger = get_logger(__name__)


class FeedbackLoop:
    """
    Self-correcting feedback loop.
    
    After each slate:
    1. Load all projections vs actuals
    2. Compute accuracy metrics
    3. Update source reliability scores
    4. Identify underperforming sources
    5. Adjust future projections accordingly
    """
    
    def __init__(self, connection, reliability_tracker: SourceReliabilityTracker):
        """
        Initialize feedback loop.
        
        Args:
            connection: Database connection
            reliability_tracker: SourceReliabilityTracker instance
        """
        self.connection = connection
        self.tracker = reliability_tracker
    
    def process_slate_results(
        self,
        slate_id: str,
        accuracies: List[ProjectionAccuracy],
    ) -> Dict:
        """
        Process accuracy results for a slate and update sources.
        
        Args:
            slate_id: Slate identifier
            accuracies: List of ProjectionAccuracy objects
            
        Returns:
            Feedback report with:
            - overall metrics (RMSE, MAE, hit rate)
            - source updates (which sources improved/declined)
            - recommended actions (sources to deprioritize)
        """
        if not accuracies:
            logger.warning(f"No accuracies to process for slate {slate_id}")
            return {}
        
        logger.info(f"Processing {len(accuracies)} accuracy results for slate {slate_id}")
        
        # Step 1: Compute overall metrics
        overall_rmse = AccuracyMetricsComputer.compute_rmse(accuracies)
        overall_mae = AccuracyMetricsComputer.compute_mae(accuracies)
        overall_hit_rate = AccuracyMetricsComputer.compute_hit_rate(accuracies)
        overall_bias = AccuracyMetricsComputer.compute_bias(accuracies)
        
        logger.info(
            f"Slate {slate_id} metrics: "
            f"RMSE={overall_rmse:.2f}, MAE={overall_mae:.2f}, "
            f"hit_rate={overall_hit_rate:.1%}, bias={overall_bias:.2f}"
        )
        
        # Step 2: Update source reliability for each accuracy
        source_updates = {}
        for accuracy in accuracies:
            # Extract source from signals (placeholder - would need to load signals)
            # For now, track by league as proxy
            source = f"projection_v1_{accuracy.league}"
            signal_type = "PROJECTION"
            
            self.tracker.update_from_accuracy(
                source=source,
                signal_type=signal_type,
                league=accuracy.league,
                accuracy_data=accuracy,
            )
            
            if source not in source_updates:
                source_updates[source] = {
                    "updates": 0,
                    "confidence": 0.0,
                }
            source_updates[source]["updates"] += 1
            source_updates[source]["confidence"] = self.tracker.get_source_weight(
                source, signal_type, accuracy.league
            )
        
        # Step 3: Apply self-correction
        self.tracker.apply_self_correction()
        
        # Step 4: Identify issues
        unreliable_sources = self.tracker.identify_unreliable_sources(threshold=0.4)
        
        # Step 5: Generate report
        report = {
            "slate_id": slate_id,
            "processed_at": get_utc_now().isoformat(),
            "num_accuracies": len(accuracies),
            "metrics": {
                "rmse": overall_rmse,
                "mae": overall_mae,
                "hit_rate": overall_hit_rate,
                "bias": overall_bias,
            },
            "source_updates": source_updates,
            "unreliable_sources": [
                {
                    "source": s.source,
                    "signal_type": s.signal_type,
                    "confidence": s.confidence_score,
                    "hit_rate": s.hit_rate,
                }
                for s in unreliable_sources
            ],
            "recommendations": self._generate_recommendations(
                overall_hit_rate,
                unreliable_sources,
            ),
        }
        
        logger.info(f"Feedback report: {len(report['recommendations'])} recommendations")
        return report
    
    def _generate_recommendations(
        self,
        hit_rate: float,
        unreliable_sources: List,
    ) -> List[str]:
        """
        Generate recommendations based on performance.
        
        Args:
            hit_rate: Overall hit rate (0-1)
            unreliable_sources: List of unreliable sources
            
        Returns:
            List of recommendation strings
        """
        recommendations = []
        
        # Check overall hit rate
        if hit_rate < 0.50:
            recommendations.append(
                f"Overall hit rate {hit_rate:.1%} is LOW - "
                "Consider widening floor/ceiling ranges or reducing confidence"
            )
        elif hit_rate > 0.85:
            recommendations.append(
                f"Overall hit rate {hit_rate:.1%} is HIGH - "
                "Can tighten ranges to improve calibration"
            )
        
        # Check unreliable sources
        if unreliable_sources:
            for source in unreliable_sources:
                recommendations.append(
                    f"Source {source.source} ({source.signal_type}) has "
                    f"confidence {source.confidence_score:.2f} - deprioritize or remove"
                )
        
        # Generic recommendation if all good
        if not recommendations:
            recommendations.append("System performance is optimal - maintain current configuration")
        
        return recommendations
    
    def store_feedback_results(self, report: Dict):
        """
        Store feedback loop results to database.
        
        Args:
            report: Feedback report dict
        """
        try:
            # Store in evaluation_feedback_log table
            query = """
            INSERT INTO evaluation_feedback_log (
                slate_id, processed_at, num_accuracies,
                overall_rmse, overall_mae, overall_hit_rate, overall_bias,
                unreliable_sources_count, recommendations, report_json
            ) VALUES (
                :slate_id, :processed_at, :num_accuracies,
                :overall_rmse, :overall_mae, :overall_hit_rate, :overall_bias,
                :unreliable_sources_count, :recommendations, :report_json
            )
            """
            
            import json
            
            self.connection.execute(
                query,
                {
                    "slate_id": report["slate_id"],
                    "processed_at": report["processed_at"],
                    "num_accuracies": report["num_accuracies"],
                    "overall_rmse": report["metrics"]["rmse"],
                    "overall_mae": report["metrics"]["mae"],
                    "overall_hit_rate": report["metrics"]["hit_rate"],
                    "overall_bias": report["metrics"]["bias"],
                    "unreliable_sources_count": len(report["unreliable_sources"]),
                    "recommendations": "; ".join(report["recommendations"]),
                    "report_json": json.dumps(report),
                },
            )
            
            logger.info(f"Stored feedback results for slate {report['slate_id']}")
        
        except Exception as e:
            logger.error(f"Error storing feedback results: {e}")
            raise


class EvaluationScheduler:
    """Schedule and manage evaluation/feedback jobs."""
    
    def __init__(self, connection):
        """Initialize scheduler.
        
        Args:
            connection: Database connection
        """
        self.connection = connection
    
    def get_slates_needing_evaluation(self, lookback_hours: int = 24) -> List[str]:
        """
        Find slates with results but no evaluation yet.
        
        Args:
            lookback_hours: Only consider slates from last N hours
            
        Returns:
            List of slate_ids to evaluate
        """
        try:
            cutoff_time = get_utc_now() - timedelta(hours=lookback_hours)
            
            query = """
            SELECT DISTINCT slate_id
            FROM evaluation_projection_accuracy
            WHERE created_at >= :cutoff_time
              AND NOT EXISTS (
                SELECT 1 FROM evaluation_feedback_log
                WHERE evaluation_feedback_log.slate_id = evaluation_projection_accuracy.slate_id
              )
            ORDER BY slate_id
            """
            
            results = self.connection.execute(
                query,
                {"cutoff_time": cutoff_time},
            ).fetchall()
            
            slate_ids = [row[0] for row in results]
            logger.info(f"Found {len(slate_ids)} slates needing evaluation")
            return slate_ids
        
        except Exception as e:
            logger.error(f"Error finding slates for evaluation: {e}")
            return []
    
    def load_slate_accuracies(self, slate_id: str) -> List[ProjectionAccuracy]:
        """
        Load all accuracy records for a slate.
        
        Args:
            slate_id: Slate identifier
            
        Returns:
            List of ProjectionAccuracy objects
        """
        try:
            query = """
            SELECT
                projection_id, player_id, game_id, slate_id, league,
                projected_fppg, projected_floor, projected_ceiling,
                projected_confidence, actual_fppg, contest_type, created_at
            FROM evaluation_projection_accuracy
            WHERE slate_id = :slate_id
            ORDER BY player_id
            """
            
            results = self.connection.execute(
                query,
                {"slate_id": slate_id},
            ).fetchall()
            
            accuracies = []
            for row in results:
                accuracy = ProjectionAccuracy(
                    projection_id=row[0],
                    player_id=row[1],
                    game_id=row[2],
                    slate_id=row[3],
                    league=row[4],
                    projected_fppg=row[5],
                    projected_floor=row[6],
                    projected_ceiling=row[7],
                    projected_confidence=row[8],
                    actual_fppg=row[9],
                    contest_type=row[10],
                    as_of_time=row[11],
                )
                accuracies.append(accuracy)
            
            logger.info(f"Loaded {len(accuracies)} accuracy records for slate {slate_id}")
            return accuracies
        
        except Exception as e:
            logger.error(f"Error loading slate accuracies: {e}")
            return []
