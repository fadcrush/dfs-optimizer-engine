"""Source reliability tracking - identify trustworthy signals."""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict
import math

from core import get_utc_now, get_logger


logger = get_logger(__name__)


@dataclass
class SourceReliability:
    """Reliability metrics for a signal source."""
    
    source: str  # e.g., "official", "twitter", "nba_api"
    signal_type: str  # e.g., "INJURY_OUT", "CONFIRMED_STARTER"
    league: str  # NBA or NFL
    
    # Tracking metrics
    total_signals_issued: int = 0
    accurate_signals: int = 0  # Signals that led to actual being within range
    false_positives: int = 0  # Signal issued but low impact
    false_negatives: int = 0  # Signal not issued but high variance
    
    # Performance tracking
    hit_rate: float = 0.0  # accurate / total
    false_positive_rate: float = 0.0  # false_positives / total
    confidence_score: float = 0.5  # 0-1, weighted by accuracy
    
    # Temporal tracking
    lead_time_hours: Dict[str, float] = field(default_factory=dict)  # signal_source → avg hours before game
    update_count: int = 0  # Number of times this metric was updated
    last_updated: datetime = None
    created_at: datetime = None
    
    def __post_init__(self):
        """Initialize timestamps."""
        if self.last_updated is None:
            self.last_updated = get_utc_now()
        if self.created_at is None:
            self.created_at = get_utc_now()
    
    def update_from_accuracy(self, accuracy_data):
        """
        Update reliability from accuracy result.
        
        Args:
            accuracy_data: ProjectionAccuracy object
        """
        self.total_signals_issued += 1
        
        # Track if within range
        if accuracy_data.is_within_range:
            self.accurate_signals += 1
        
        # Recompute hit rate
        self.hit_rate = self.accurate_signals / self.total_signals_issued if self.total_signals_issued > 0 else 0
        
        # Compute confidence score (increases with hit rate, penalized by variance)
        # Confidence = hit_rate * (1 - false_positive_rate)
        self.confidence_score = self.hit_rate * (1 - self.false_positive_rate)
        self.confidence_score = max(0.0, min(1.0, self.confidence_score))
        
        self.last_updated = get_utc_now()
        self.update_count += 1
        
        logger.debug(
            f"Updated {self.source} {self.signal_type}: "
            f"hit_rate={self.hit_rate:.1%}, confidence={self.confidence_score:.2f}"
        )
    
    def downweight(self, penalty: float = 0.1):
        """
        Downweight reliability score due to poor performance.
        
        Args:
            penalty: Amount to reduce confidence (0-1)
        """
        self.confidence_score = max(0.0, self.confidence_score - penalty)
        self.last_updated = get_utc_now()
        logger.warning(
            f"Downweighted {self.source} {self.signal_type} "
            f"by {penalty:.1%} to {self.confidence_score:.2f}"
        )
    
    def upweight(self, bonus: float = 0.05):
        """
        Upweight reliability score due to good performance.
        
        Args:
            bonus: Amount to increase confidence (0-1)
        """
        self.confidence_score = min(1.0, self.confidence_score + bonus)
        self.last_updated = get_utc_now()
        logger.info(
            f"Upweighted {self.source} {self.signal_type} "
            f"by {bonus:.1%} to {self.confidence_score:.2f}"
        )
    
    def to_dict(self):
        """Convert to dictionary."""
        return {
            "source": self.source,
            "signal_type": self.signal_type,
            "league": self.league,
            "total_signals_issued": self.total_signals_issued,
            "accurate_signals": self.accurate_signals,
            "false_positives": self.false_positives,
            "false_negatives": self.false_negatives,
            "hit_rate": self.hit_rate,
            "false_positive_rate": self.false_positive_rate,
            "confidence_score": self.confidence_score,
            "update_count": self.update_count,
            "last_updated": self.last_updated.isoformat(),
            "created_at": self.created_at.isoformat(),
        }


class SourceReliabilityTracker:
    """Track and manage source reliability scores."""
    
    def __init__(self, connection=None):
        """Initialize tracker.

        Args:
            connection: Database connection for persistence
        """
        self.connection = connection
        self.sources: Dict[str, SourceReliability] = {}  # key: "source_signal_type_league"

        # Load existing reliability data if connection provided
        if connection:
            self.load_from_database()
    
    def register_source(
        self,
        source: str,
        signal_type: str,
        league: str,
    ) -> SourceReliability:
        """
        Register or retrieve source reliability tracker.
        
        Args:
            source: Source identifier
            signal_type: Signal type
            league: NBA or NFL
            
        Returns:
            SourceReliability instance
        """
        key = f"{source}_{signal_type}_{league}"
        
        if key not in self.sources:
            self.sources[key] = SourceReliability(
                source=source,
                signal_type=signal_type,
                league=league,
            )
        
        return self.sources[key]
    
    def update_from_accuracy(
        self,
        source: str,
        signal_type: str,
        league: str,
        accuracy_data,
    ):
        """
        Update source reliability from accuracy result.
        
        Args:
            source: Source identifier
            signal_type: Signal type
            league: NBA or NFL
            accuracy_data: ProjectionAccuracy object
        """
        reliability = self.register_source(source, signal_type, league)
        reliability.update_from_accuracy(accuracy_data)
    
    def get_source_weight(
        self,
        source: str,
        signal_type: str,
        league: str,
    ) -> float:
        """
        Get weighting factor for source (for projection building).
        
        Args:
            source: Source identifier
            signal_type: Signal type
            league: NBA or NFL
            
        Returns:
            Weight 0-1 based on confidence score
        """
        key = f"{source}_{signal_type}_{league}"
        
        if key not in self.sources:
            # Unknown source - default to 0.5
            return 0.5
        
        return self.sources[key].confidence_score
    
    def identify_unreliable_sources(self, threshold: float = 0.4) -> list:
        """
        Identify sources below reliability threshold.
        
        Args:
            threshold: Confidence score threshold (0-1)
            
        Returns:
            List of unreliable SourceReliability objects
        """
        unreliable = [
            source for source in self.sources.values()
            if source.confidence_score < threshold
        ]
        return unreliable
    
    def apply_self_correction(self):
        """
        Apply self-correction: downweight poor sources, upweight good ones.
        """
        for source in self.sources.values():
            if source.total_signals_issued >= 10:  # Minimum sample
                if source.hit_rate < 0.4:
                    # Poor performance
                    source.downweight(penalty=0.15)
                elif source.hit_rate > 0.75:
                    # Excellent performance
                    source.upweight(bonus=0.05)
            
            logger.info(
                f"Self-correction: {source.source} {source.signal_type} → "
                f"confidence {source.confidence_score:.2f}"
            )
    
    def to_dict(self):
        """Convert all sources to dictionary."""
        return {
            key: source.to_dict()
            for key, source in self.sources.items()
        }

    def load_from_database(self):
        """
        Load source reliability data from database.

        Loads all existing source reliability records and populates the tracker.
        """
        if not self.connection:
            logger.warning("No database connection provided for loading reliability data")
            return

        try:
            query = """
            SELECT
                source, signal_type, league,
                total_signals_issued, accurate_signals, false_positives, false_negatives,
                hit_rate, false_positive_rate, confidence_score,
                update_count, last_updated, created_at
            FROM evaluation_source_reliability
            """

            result = self.connection.execute(query)
            rows = result.fetchall()

            for row in rows:
                source_reliability = SourceReliability(
                    source=row[0],
                    signal_type=row[1],
                    league=row[2],
                    total_signals_issued=row[3],
                    accurate_signals=row[4],
                    false_positives=row[5],
                    false_negatives=row[6],
                    hit_rate=row[7],
                    false_positive_rate=row[8],
                    confidence_score=row[9],
                    update_count=row[10],
                    last_updated=row[11],
                    created_at=row[12],
                )

                key = f"{row[0]}_{row[1]}_{row[2]}"
                self.sources[key] = source_reliability

            logger.info(f"Loaded {len(self.sources)} source reliability records from database")

        except Exception as e:
            logger.error(f"Error loading source reliability from database: {e}")
            raise

    def save_to_database(self):
        """
        Save all source reliability data to database.

        Updates existing records and inserts new ones.
        """
        if not self.connection:
            logger.warning("No database connection provided for saving reliability data")
            return

        try:
            for key, source_reliability in self.sources.items():
                # Upsert query - update if exists, insert if not
                query = """
                INSERT INTO evaluation_source_reliability (
                    source, signal_type, league,
                    total_signals_issued, accurate_signals, false_positives, false_negatives,
                    hit_rate, false_positive_rate, confidence_score,
                    update_count, last_updated, created_at
                ) VALUES (
                    :source, :signal_type, :league,
                    :total_signals_issued, :accurate_signals, :false_positives, :false_negatives,
                    :hit_rate, :false_positive_rate, :confidence_score,
                    :update_count, :last_updated, :created_at
                )
                ON CONFLICT (source, signal_type, league)
                DO UPDATE SET
                    total_signals_issued = EXCLUDED.total_signals_issued,
                    accurate_signals = EXCLUDED.accurate_signals,
                    false_positives = EXCLUDED.false_positives,
                    false_negatives = EXCLUDED.false_negatives,
                    hit_rate = EXCLUDED.hit_rate,
                    false_positive_rate = EXCLUDED.false_positive_rate,
                    confidence_score = EXCLUDED.confidence_score,
                    update_count = EXCLUDED.update_count,
                    last_updated = EXCLUDED.last_updated
                """

                self.connection.execute(
                    query,
                    {
                        "source": source_reliability.source,
                        "signal_type": source_reliability.signal_type,
                        "league": source_reliability.league,
                        "total_signals_issued": source_reliability.total_signals_issued,
                        "accurate_signals": source_reliability.accurate_signals,
                        "false_positives": source_reliability.false_positives,
                        "false_negatives": source_reliability.false_negatives,
                        "hit_rate": source_reliability.hit_rate,
                        "false_positive_rate": source_reliability.false_positive_rate,
                        "confidence_score": source_reliability.confidence_score,
                        "update_count": source_reliability.update_count,
                        "last_updated": source_reliability.last_updated,
                        "created_at": source_reliability.created_at,
                    }
                )

            self.connection.commit()
            logger.info(f"Saved {len(self.sources)} source reliability records to database")

        except Exception as e:
            logger.error(f"Error saving source reliability to database: {e}")
            self.connection.rollback()
            raise


# Singleton instance
_tracker_instance = None


def get_source_reliability_tracker(connection=None) -> SourceReliabilityTracker:
    """Get singleton tracker instance.

    Args:
        connection: Database connection for persistence

    Returns:
        SourceReliabilityTracker instance
    """
    global _tracker_instance
    if _tracker_instance is None:
        _tracker_instance = SourceReliabilityTracker(connection)
    return _tracker_instance
