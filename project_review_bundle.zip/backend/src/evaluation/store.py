"""Store and retrieve evaluation results."""

import json
from datetime import datetime
from typing import List, Optional

from core import get_utc_now, get_logger
from evaluation.accuracy import ProjectionAccuracy


logger = get_logger(__name__)


class EvaluationStore:
    """CRUD operations for evaluation results."""
    
    def __init__(self, connection):
        """Initialize store.
        
        Args:
            connection: Database connection
        """
        self.connection = connection
    
    def insert_accuracy(self, accuracy: ProjectionAccuracy) -> int:
        """
        Insert accuracy record.
        
        Args:
            accuracy: ProjectionAccuracy object
            
        Returns:
            Accuracy record ID
        """
        try:
            query = """
            INSERT INTO evaluation_projection_accuracy (
                projection_id, player_id, game_id, slate_id, league,
                projected_fppg, projected_floor, projected_ceiling,
                projected_confidence, actual_fppg, error, abs_error,
                squared_error, percentile_rank, is_within_range,
                contest_type, as_of_time, evaluation_time, notes
            ) VALUES (
                :projection_id, :player_id, :game_id, :slate_id, :league,
                :projected_fppg, :projected_floor, :projected_ceiling,
                :projected_confidence, :actual_fppg, :error, :abs_error,
                :squared_error, :percentile_rank, :is_within_range,
                :contest_type, :as_of_time, :evaluation_time, :notes
            )
            RETURNING accuracy_id
            """
            
            result = self.connection.execute(
                query,
                {
                    "projection_id": accuracy.projection_id,
                    "player_id": accuracy.player_id,
                    "game_id": accuracy.game_id,
                    "slate_id": accuracy.slate_id,
                    "league": accuracy.league,
                    "projected_fppg": accuracy.projected_fppg,
                    "projected_floor": accuracy.projected_floor,
                    "projected_ceiling": accuracy.projected_ceiling,
                    "projected_confidence": accuracy.projected_confidence,
                    "actual_fppg": accuracy.actual_fppg,
                    "error": accuracy.error,
                    "abs_error": accuracy.abs_error,
                    "squared_error": accuracy.squared_error,
                    "percentile_rank": accuracy.percentile_rank,
                    "is_within_range": accuracy.is_within_range,
                    "contest_type": accuracy.contest_type,
                    "as_of_time": accuracy.as_of_time,
                    "evaluation_time": accuracy.evaluation_time,
                    "notes": accuracy.notes,
                },
            )
            
            accuracy_id = result.first()[0]
            logger.debug(f"Inserted accuracy record {accuracy_id}")
            return accuracy_id
        
        except Exception as e:
            logger.error(f"Error inserting accuracy: {e}")
            raise
    
    def get_accuracy_by_id(self, accuracy_id: int) -> Optional[ProjectionAccuracy]:
        """
        Get accuracy record by ID.
        
        Args:
            accuracy_id: Accuracy record ID
            
        Returns:
            ProjectionAccuracy or None
        """
        try:
            query = """
            SELECT
                projection_id, player_id, game_id, slate_id, league,
                projected_fppg, projected_floor, projected_ceiling,
                projected_confidence, actual_fppg, contest_type, as_of_time
            FROM evaluation_projection_accuracy
            WHERE accuracy_id = :accuracy_id
            """
            
            result = self.connection.execute(
                query,
                {"accuracy_id": accuracy_id},
            ).first()
            
            if not result:
                return None
            
            return self._row_to_accuracy(result)
        
        except Exception as e:
            logger.error(f"Error retrieving accuracy {accuracy_id}: {e}")
            raise
    
    def get_accuracies_for_slate(self, slate_id: str) -> List[ProjectionAccuracy]:
        """
        Get all accuracy records for a slate.
        
        Args:
            slate_id: Slate identifier
            
        Returns:
            List of ProjectionAccuracy objects
        """
        try:
            query = """
            SELECT
                projection_id, player_id, game_id, slate_id, league,
                projected_fppg, projected_floor, projected_ceiling,
                projected_confidence, actual_fppg, contest_type, as_of_time
            FROM evaluation_projection_accuracy
            WHERE slate_id = :slate_id
            ORDER BY player_id
            """
            
            results = self.connection.execute(
                query,
                {"slate_id": slate_id},
            ).fetchall()
            
            accuracies = [self._row_to_accuracy(row) for row in results]
            logger.debug(f"Retrieved {len(accuracies)} accuracy records for slate {slate_id}")
            return accuracies
        
        except Exception as e:
            logger.error(f"Error retrieving slate accuracies: {e}")
            raise
    
    def get_accuracies_for_player(
        self,
        player_id: str,
        lookback_days: int = 30,
    ) -> List[ProjectionAccuracy]:
        """
        Get accuracy records for player (last N days).
        
        Args:
            player_id: Player identifier
            lookback_days: Days to look back
            
        Returns:
            List of ProjectionAccuracy objects
        """
        try:
            from datetime import timedelta
            cutoff = get_utc_now() - timedelta(days=lookback_days)
            
            query = """
            SELECT
                projection_id, player_id, game_id, slate_id, league,
                projected_fppg, projected_floor, projected_ceiling,
                projected_confidence, actual_fppg, contest_type, as_of_time
            FROM evaluation_projection_accuracy
            WHERE player_id = :player_id
              AND as_of_time >= :cutoff
            ORDER BY as_of_time DESC
            """
            
            results = self.connection.execute(
                query,
                {
                    "player_id": player_id,
                    "cutoff": cutoff,
                },
            ).fetchall()
            
            accuracies = [self._row_to_accuracy(row) for row in results]
            logger.debug(f"Retrieved {len(accuracies)} accuracy records for {player_id}")
            return accuracies
        
        except Exception as e:
            logger.error(f"Error retrieving player accuracies: {e}")
            raise
    
    def store_source_reliability(
        self,
        source: str,
        signal_type: str,
        league: str,
        reliability_dict: dict,
    ):
        """
        Store source reliability metrics.
        
        Args:
            source: Source identifier
            signal_type: Signal type
            league: NBA or NFL
            reliability_dict: Reliability data dict
        """
        try:
            query = """
            INSERT INTO evaluation_source_reliability (
                source, signal_type, league, hit_rate, false_positive_rate,
                confidence_score, total_signals, update_count, last_updated
            ) VALUES (
                :source, :signal_type, :league, :hit_rate,
                :false_positive_rate, :confidence_score, :total_signals,
                :update_count, :last_updated
            )
            ON CONFLICT (source, signal_type, league) DO UPDATE SET
                hit_rate = EXCLUDED.hit_rate,
                false_positive_rate = EXCLUDED.false_positive_rate,
                confidence_score = EXCLUDED.confidence_score,
                total_signals = EXCLUDED.total_signals,
                update_count = EXCLUDED.update_count,
                last_updated = EXCLUDED.last_updated
            """
            
            self.connection.execute(
                query,
                {
                    "source": source,
                    "signal_type": signal_type,
                    "league": league,
                    "hit_rate": reliability_dict.get("hit_rate", 0.0),
                    "false_positive_rate": reliability_dict.get("false_positive_rate", 0.0),
                    "confidence_score": reliability_dict.get("confidence_score", 0.5),
                    "total_signals": reliability_dict.get("total_signals_issued", 0),
                    "update_count": reliability_dict.get("update_count", 0),
                    "last_updated": reliability_dict.get("last_updated"),
                },
            )
            
            logger.debug(f"Stored reliability for {source} {signal_type}")
        
        except Exception as e:
            logger.error(f"Error storing source reliability: {e}")
            raise
    
    def get_source_reliability(
        self,
        source: str,
        signal_type: str,
        league: str,
    ) -> Optional[dict]:
        """
        Retrieve source reliability metrics.
        
        Args:
            source: Source identifier
            signal_type: Signal type
            league: NBA or NFL
            
        Returns:
            Reliability dict or None
        """
        try:
            query = """
            SELECT
                hit_rate, false_positive_rate, confidence_score,
                total_signals, update_count, last_updated
            FROM evaluation_source_reliability
            WHERE source = :source
              AND signal_type = :signal_type
              AND league = :league
            """
            
            result = self.connection.execute(
                query,
                {
                    "source": source,
                    "signal_type": signal_type,
                    "league": league,
                },
            ).first()
            
            if not result:
                return None
            
            return {
                "hit_rate": result[0],
                "false_positive_rate": result[1],
                "confidence_score": result[2],
                "total_signals": result[3],
                "update_count": result[4],
                "last_updated": result[5],
            }
        
        except Exception as e:
            logger.error(f"Error retrieving source reliability: {e}")
            raise
    
    def _row_to_accuracy(self, row) -> ProjectionAccuracy:
        """Convert database row to ProjectionAccuracy."""
        return ProjectionAccuracy(
            projection_id=row[0],
            player_id=row[1],
            game_id=row[2],
            slate_id=row[3],
            league=row[4],
            projected_fppg=row[5],
            projected_floor=row[6],
            projected_ceiling=row[7],
            projected_confidence=row[8],
            actual_fppg=row[9],
            contest_type=row[10],
            as_of_time=row[11],
        )


def get_evaluation_store(connection) -> EvaluationStore:
    """Get evaluation store singleton.
    
    Args:
        connection: Database connection
        
    Returns:
        EvaluationStore instance
    """
    return EvaluationStore(connection)
