"""Decision snapshot storage for audit trails."""

import json
import logging
from datetime import datetime
from typing import List, Optional

from sqlalchemy import text

try:
    from core import get_utc_now
except ImportError:
    from datetime import datetime, timezone
    def get_utc_now():
        return datetime.now(timezone.utc)

logger = logging.getLogger(__name__)


class DecisionSnapshot:
    """Record of a projection decision."""
    
    def __init__(self, 
                player_id: str,
                game_id: str,
                slate_id: str,
                override_level: int = 0,
                decision: str = 'STANDARD',
                applied_at: Optional[datetime] = None,
                inputs_hash: str = '',
                signals_used: Optional[List[str]] = None,
                features_used: Optional[dict] = None,
                baseline_version: str = ''):
        """
        Initialize decision snapshot.
        
        Args:
            player_id: Player ID
            game_id: Game ID
            slate_id: Slate ID
            override_level: Signal priority level applied (0-5)
            decision: Decision made (STANDARD, ZERO_MINUTES, REDUCE_USAGE, etc.)
            applied_at: When decision was made
            inputs_hash: Hash of all inputs (for reproducibility check)
            signals_used: List of signal IDs that influenced decision
            features_used: Dict of features used in projection
            baseline_version: Version of baseline used
        """
        self.player_id = player_id
        self.game_id = game_id
        self.slate_id = slate_id
        self.override_level = override_level
        self.decision = decision
        self.applied_at = applied_at or get_utc_now()
        self.inputs_hash = inputs_hash
        self.signals_used = signals_used or []
        self.features_used = features_used or {}
        self.baseline_version = baseline_version
    
    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            'player_id': self.player_id,
            'game_id': self.game_id,
            'slate_id': self.slate_id,
            'override_level': self.override_level,
            'decision': self.decision,
            'applied_at': self.applied_at.isoformat() if self.applied_at else None,
            'inputs_hash': self.inputs_hash,
            'signals_used': self.signals_used,
            'features_used': self.features_used,
            'baseline_version': self.baseline_version,
        }


class DecisionSnapshotStore:
    """Store for decision snapshots with CRUD operations."""
    
    def __init__(self, connection):
        """
        Initialize decision snapshot store.
        
        Args:
            connection: SQLAlchemy database connection
        """
        self.connection = connection
    
    def insert(self, snapshot: DecisionSnapshot) -> int:
        """
        Insert a decision snapshot.
        
        Args:
            snapshot: DecisionSnapshot to store
            
        Returns:
            snapshot_id of inserted record
            
        Raises:
            Exception: If insert fails
            
        Example:
            >>> store = DecisionSnapshotStore(connection)
            >>> snapshot = DecisionSnapshot(
            ...     player_id='player_123',
            ...     game_id='game_456',
            ...     slate_id='slate_789',
            ...     override_level=0,
            ...     decision='STANDARD',
            ...     inputs_hash='abc123...',
            ...     signals_used=['sig_1', 'sig_2'],
            ... )
            >>> snapshot_id = store.insert(snapshot)
            >>> print(f"Inserted snapshot {snapshot_id}")
        """
        query = """
            INSERT INTO operational_decision_snapshots
            (player_id, game_id, slate_id, override_level, decision,
             applied_at, inputs_hash, signals_used, features_used,
             baseline_version, created_at)
            VALUES
            (:player_id, :game_id, :slate_id, :override_level, :decision,
             :applied_at, :inputs_hash, :signals_used, :features_used,
             :baseline_version, NOW())
        """
        
        try:
            result = self.connection.execute(
                text(query),
                {
                    'player_id': snapshot.player_id,
                    'game_id': snapshot.game_id,
                    'slate_id': snapshot.slate_id,
                    'override_level': snapshot.override_level,
                    'decision': snapshot.decision,
                    'applied_at': snapshot.applied_at,
                    'inputs_hash': snapshot.inputs_hash,
                    'signals_used': json.dumps(snapshot.signals_used),
                    'features_used': json.dumps(snapshot.features_used),
                    'baseline_version': snapshot.baseline_version,
                }
            )
            
            self.connection.commit()
            logger.info(f"Inserted decision snapshot for {snapshot.player_id} in {snapshot.slate_id}")
            return result.lastrowid
        except Exception as e:
            logger.error(f"Failed to insert decision snapshot: {e}")
            self.connection.rollback()
            raise
    
    def get_by_slate(self, slate_id: str) -> List[DecisionSnapshot]:
        """
        Get all decision snapshots for a slate.
        
        Args:
            slate_id: Slate ID
            
        Returns:
            List of DecisionSnapshot ordered by applied_at DESC
            
        Example:
            >>> store = DecisionSnapshotStore(connection)
            >>> snapshots = store.get_by_slate('slate_789')
            >>> print(f"Found {len(snapshots)} decisions")
        """
        query = """
            SELECT snapshot_id, player_id, game_id, slate_id, override_level, decision,
                   applied_at, inputs_hash, signals_used, features_used,
                   baseline_version, created_at
            FROM operational_decision_snapshots
            WHERE slate_id = :slate_id
            ORDER BY applied_at DESC
        """
        
        try:
            result = self.connection.execute(
                text(query),
                {'slate_id': slate_id}
            )
            
            snapshots = []
            for row in result:
                snapshots.append(DecisionSnapshot(
                    player_id=row[1],
                    game_id=row[2],
                    slate_id=row[3],
                    override_level=row[4],
                    decision=row[5],
                    applied_at=row[6],
                    inputs_hash=row[7],
                    signals_used=json.loads(row[8]) if row[8] else [],
                    features_used=json.loads(row[9]) if row[9] else {},
                    baseline_version=row[10]
                ))
            
            return snapshots
        except Exception as e:
            logger.error(f"Failed to fetch snapshots for slate {slate_id}: {e}")
            return []
    
    def get_by_player_game(self, player_id: str, game_id: str) -> Optional[DecisionSnapshot]:
        """
        Get decision snapshot for specific player/game.
        
        Args:
            player_id: Player ID
            game_id: Game ID
            
        Returns:
            DecisionSnapshot or None if not found
            
        Example:
            >>> store = DecisionSnapshotStore(connection)
            >>> snapshot = store.get_by_player_game('player_123', 'game_456')
            >>> if snapshot:
            ...     print(f"Decision: {snapshot.decision}")
        """
        query = """
            SELECT snapshot_id, player_id, game_id, slate_id, override_level, decision,
                   applied_at, inputs_hash, signals_used, features_used,
                   baseline_version, created_at
            FROM operational_decision_snapshots
            WHERE player_id = :player_id AND game_id = :game_id
            ORDER BY applied_at DESC
            LIMIT 1
        """
        
        try:
            result = self.connection.execute(
                text(query),
                {'player_id': player_id, 'game_id': game_id}
            )
            
            row = result.first()
            if not row:
                return None
            
            return DecisionSnapshot(
                player_id=row[1],
                game_id=row[2],
                slate_id=row[3],
                override_level=row[4],
                decision=row[5],
                applied_at=row[6],
                inputs_hash=row[7],
                signals_used=json.loads(row[8]) if row[8] else [],
                features_used=json.loads(row[9]) if row[9] else {},
                baseline_version=row[10]
            )
        except Exception as e:
            logger.error(f"Failed to fetch snapshot for {player_id}/{game_id}: {e}")
            return None
    
    def verify_reproducibility(self, snapshot: DecisionSnapshot) -> bool:
        """
        Verify that a decision snapshot's hash is valid.
        
        Used to confirm that projection inputs haven't changed.
        
        Args:
            snapshot: DecisionSnapshot to verify
            
        Returns:
            True if hash matches inputs (reproducible), False otherwise
            
        Example:
            >>> snapshot = store.get_by_player_game('player_123', 'game_456')
            >>> if store.verify_reproducibility(snapshot):
            ...     print("Projection is reproducible")
            ... else:
            ...     print("Projection inputs have changed")
        """
        from .hash_builder import InputsHashBuilder
        
        # Reconstruct the hash from stored inputs
        is_reproducible = InputsHashBuilder.validate_reproducibility(
            original_hash=snapshot.inputs_hash,
            player_id=snapshot.player_id,
            game_id=snapshot.game_id,
            signal_ids=snapshot.signals_used,
            feature_versions=snapshot.features_used,
            baseline_version=snapshot.baseline_version,
            as_of_time=snapshot.applied_at
        )
        
        return is_reproducible
    
    def delete_by_slate(self, slate_id: str) -> int:
        """
        Delete all decision snapshots for a slate.
        
        Args:
            slate_id: Slate ID
            
        Returns:
            Number of rows deleted
        """
        query = """
            DELETE FROM operational_decision_snapshots
            WHERE slate_id = :slate_id
        """
        
        try:
            result = self.connection.execute(
                text(query),
                {'slate_id': slate_id}
            )
            
            self.connection.commit()
            rows_deleted = result.rowcount
            logger.info(f"Deleted {rows_deleted} decision snapshots for slate {slate_id}")
            return rows_deleted
        except Exception as e:
            logger.error(f"Failed to delete snapshots for slate {slate_id}: {e}")
            self.connection.rollback()
            return 0
