"""Deterministic input hashing for projection reproducibility."""

import hashlib
import json
from typing import List, Dict, Optional
from datetime import datetime


class InputsHashBuilder:
    """Build deterministic hash from projection inputs."""
    
    @staticmethod
    def compute_hash(player_id: str, 
                    game_id: str,
                    signal_ids: List[str],
                    feature_versions: Dict[str, str],
                    baseline_version: str,
                    as_of_time: datetime) -> str:
        """
        Create deterministic SHA256 hash of all projection inputs.
        Same inputs → same hash (verifies reproducibility).
        
        Args:
            player_id: Player ID
            game_id: Game ID
            signal_ids: List of active signal IDs (sorted)
            feature_versions: Dict of feature_type → version_hash
            baseline_version: Version hash of baseline being used
            as_of_time: Decision time
            
        Returns:
            SHA256 hex digest
            
        Example:
            >>> hash1 = InputsHashBuilder.compute_hash(
            ...     player_id='player_123',
            ...     game_id='game_456',
            ...     signal_ids=['sig_1', 'sig_2'],
            ...     feature_versions={'minutes': 'v1_hash', 'usage': 'v1_hash'},
            ...     baseline_version='baseline_v1_hash',
            ...     as_of_time=datetime.utcnow()
            ... )
            >>> hash2 = InputsHashBuilder.compute_hash(
            ...     player_id='player_123',
            ...     game_id='game_456',
            ...     signal_ids=['sig_1', 'sig_2'],
            ...     feature_versions={'minutes': 'v1_hash', 'usage': 'v1_hash'},
            ...     baseline_version='baseline_v1_hash',
            ...     as_of_time=datetime.utcnow()  # Same time (approximately)
            ... )
            >>> hash1 == hash2
            True
        """
        # Create canonical input representation
        input_parts = [
            player_id,
            game_id,
            "|".join(sorted(signal_ids)) if signal_ids else "",  # Consistent ordering
            json.dumps(feature_versions, sort_keys=True),  # Deterministic JSON
            baseline_version,
            as_of_time.isoformat(),
        ]
        
        input_string = "|".join(input_parts)
        
        # Return hash
        return hashlib.sha256(input_string.encode()).hexdigest()
    
    @staticmethod
    def validate_reproducibility(original_hash: str,
                                player_id: str,
                                game_id: str,
                                signal_ids: List[str],
                                feature_versions: Dict[str, str],
                                baseline_version: str,
                                as_of_time: datetime) -> bool:
        """
        Verify that a projection is reproducible.
        Recompute hash and compare to stored hash.
        
        Args:
            original_hash: Hash stored with projection
            player_id: Player ID
            game_id: Game ID
            signal_ids: List of active signal IDs
            feature_versions: Dict of feature versions
            baseline_version: Baseline version hash
            as_of_time: Decision time
            
        Returns:
            True if hashes match (reproducible), False otherwise
            
        Example:
            >>> original_hash = 'abc123def456...'
            >>> is_reproducible = InputsHashBuilder.validate_reproducibility(
            ...     original_hash=original_hash,
            ...     player_id='player_123',
            ...     game_id='game_456',
            ...     signal_ids=['sig_1', 'sig_2'],
            ...     feature_versions={'minutes': 'v1_hash', 'usage': 'v1_hash'},
            ...     baseline_version='baseline_v1_hash',
            ...     as_of_time=datetime.utcnow()
            ... )
            >>> print(f"Reproducible: {is_reproducible}")
            Reproducible: True
        """
        recomputed_hash = InputsHashBuilder.compute_hash(
            player_id, game_id, signal_ids, feature_versions,
            baseline_version, as_of_time
        )
        
        return recomputed_hash == original_hash
    
    @staticmethod
    def explain_hash(original_hash: str,
                    player_id: str,
                    game_id: str,
                    signal_ids: List[str],
                    feature_versions: Dict[str, str],
                    baseline_version: str,
                    as_of_time: datetime) -> Dict:
        """
        Debug hash computation.
        Return all inputs and hash for verification.
        
        Args:
            original_hash: Hash stored with projection
            (remaining args same as validate_reproducibility)
            
        Returns:
            Dict with all inputs and hash comparison
            
        Example:
            >>> explanation = InputsHashBuilder.explain_hash(
            ...     original_hash='stored_hash',
            ...     player_id='player_123',
            ...     game_id='game_456',
            ...     signal_ids=['sig_1', 'sig_2'],
            ...     feature_versions={'minutes': 'v1_hash', 'usage': 'v1_hash'},
            ...     baseline_version='baseline_v1_hash',
            ...     as_of_time=datetime.utcnow()
            ... )
            >>> print(explanation['inputs'])
        """
        recomputed_hash = InputsHashBuilder.compute_hash(
            player_id, game_id, signal_ids, feature_versions,
            baseline_version, as_of_time
        )
        
        return {
            'original_hash': original_hash,
            'recomputed_hash': recomputed_hash,
            'hashes_match': original_hash == recomputed_hash,
            'inputs': {
                'player_id': player_id,
                'game_id': game_id,
                'signal_ids': sorted(signal_ids) if signal_ids else [],
                'feature_versions': feature_versions,
                'baseline_version': baseline_version,
                'as_of_time': as_of_time.isoformat(),
            }
        }
