"""Store and retrieve projections."""

import json
from datetime import datetime
from typing import List, Dict, Optional

from core import get_utc_now, get_logger
from projection.models import ProjectionDistribution


logger = get_logger(__name__)


class ProjectionStore:
    """CRUD operations for projections."""
    
    def __init__(self, connection):
        """Initialize store.
        
        Args:
            connection: Database connection
        """
        self.connection = connection
    
    def insert(self, projection: ProjectionDistribution) -> str:
        """
        Insert projection.
        
        Args:
            projection: ProjectionDistribution to insert
            
        Returns:
            Projection ID
        """
        try:
            query = """
            INSERT INTO operational_projections (
                player_id, game_id, slate_id, league, as_of_time,
                median_fppg, floor_fppg, ceiling_fppg, volatility, confidence,
                source_signals, contributing_factors, version, inputs_hash, created_at
            ) VALUES (
                :player_id, :game_id, :slate_id, :league, :as_of_time,
                :median_fppg, :floor_fppg, :ceiling_fppg, :volatility, :confidence,
                :source_signals, :contributing_factors, :version, :inputs_hash, :created_at
            )
            RETURNING projection_id
            """
            
            result = self.connection.execute(
                query,
                {
                    "player_id": projection.player_id,
                    "game_id": projection.game_id,
                    "slate_id": projection.slate_id,
                    "league": projection.league,
                    "as_of_time": projection.as_of_time,
                    "median_fppg": projection.median_fppg,
                    "floor_fppg": projection.floor_fppg,
                    "ceiling_fppg": projection.ceiling_fppg,
                    "volatility": projection.volatility,
                    "confidence": projection.confidence,
                    "source_signals": json.dumps(projection.source_signals),
                    "contributing_factors": json.dumps(projection.contributing_factors),
                    "version": projection.version,
                    "inputs_hash": projection.inputs_hash,
                    "created_at": projection.created_at,
                },
            )
            
            projection_id = result.first()[0]
            logger.debug(f"Inserted projection {projection_id} for {projection.player_id}")
            return projection_id
        
        except Exception as e:
            logger.error(f"Error inserting projection: {e}")
            raise
    
    def get_by_id(self, projection_id: int) -> Optional[ProjectionDistribution]:
        """
        Get projection by ID.
        
        Args:
            projection_id: Projection ID
            
        Returns:
            ProjectionDistribution or None
        """
        try:
            query = """
            SELECT
                player_id, game_id, slate_id, league, as_of_time,
                median_fppg, floor_fppg, ceiling_fppg, volatility, confidence,
                source_signals, contributing_factors, version, inputs_hash, created_at
            FROM operational_projections
            WHERE projection_id = :projection_id
            """
            
            result = self.connection.execute(
                query,
                {"projection_id": projection_id},
            ).first()
            
            if not result:
                return None
            
            return self._row_to_projection(result)
        
        except Exception as e:
            logger.error(f"Error retrieving projection {projection_id}: {e}")
            raise
    
    def get_for_slate(
        self,
        slate_id: str,
        version: str,
        as_of_time: Optional[datetime] = None,
    ) -> Dict[str, ProjectionDistribution]:
        """
        Get projections for slate at specific version.
        
        Args:
            slate_id: Slate identifier
            version: Projection version (e.g., "v1")
            as_of_time: Optional - if provided, get most recent before this time
            
        Returns:
            Dict of {player_id → ProjectionDistribution}
        """
        try:
            if as_of_time is None:
                as_of_time = get_utc_now()
            
            query = """
            SELECT DISTINCT ON (player_id)
                player_id, game_id, slate_id, league, as_of_time,
                median_fppg, floor_fppg, ceiling_fppg, volatility, confidence,
                source_signals, contributing_factors, version, inputs_hash, created_at
            FROM operational_projections
            WHERE slate_id = :slate_id
              AND version = :version
              AND as_of_time <= :as_of_time
            ORDER BY player_id, created_at DESC
            """
            
            results = self.connection.execute(
                query,
                {
                    "slate_id": slate_id,
                    "version": version,
                    "as_of_time": as_of_time,
                },
            ).fetchall()
            
            projections = {}
            for row in results:
                projection = self._row_to_projection(row)
                projections[projection.player_id] = projection
            
            logger.debug(f"Retrieved {len(projections)} projections for slate {slate_id} v{version}")
            return projections
        
        except Exception as e:
            logger.error(f"Error retrieving slate projections: {e}")
            raise
    
    def get_for_player_game(
        self,
        player_id: str,
        game_id: str,
        version: str,
    ) -> Optional[ProjectionDistribution]:
        """
        Get projection for specific player game.
        
        Args:
            player_id: Player identifier
            game_id: Game identifier
            version: Projection version
            
        Returns:
            ProjectionDistribution or None
        """
        try:
            query = """
            SELECT
                player_id, game_id, slate_id, league, as_of_time,
                median_fppg, floor_fppg, ceiling_fppg, volatility, confidence,
                source_signals, contributing_factors, version, inputs_hash, created_at
            FROM operational_projections
            WHERE player_id = :player_id
              AND game_id = :game_id
              AND version = :version
            ORDER BY created_at DESC
            LIMIT 1
            """
            
            result = self.connection.execute(
                query,
                {
                    "player_id": player_id,
                    "game_id": game_id,
                    "version": version,
                },
            ).first()
            
            if not result:
                return None
            
            return self._row_to_projection(result)
        
        except Exception as e:
            logger.error(f"Error retrieving projection for {player_id}/{game_id}: {e}")
            raise
    
    def get_by_inputs_hash(self, inputs_hash: str) -> Optional[ProjectionDistribution]:
        """
        Get projection by inputs hash (check for reproducibility).
        
        Args:
            inputs_hash: SHA256 hash of inputs
            
        Returns:
            ProjectionDistribution or None if not found
        """
        try:
            query = """
            SELECT
                player_id, game_id, slate_id, league, as_of_time,
                median_fppg, floor_fppg, ceiling_fppg, volatility, confidence,
                source_signals, contributing_factors, version, inputs_hash, created_at
            FROM operational_projections
            WHERE inputs_hash = :inputs_hash
            LIMIT 1
            """
            
            result = self.connection.execute(
                query,
                {"inputs_hash": inputs_hash},
            ).first()
            
            if not result:
                return None
            
            return self._row_to_projection(result)
        
        except Exception as e:
            logger.error(f"Error retrieving projection by hash: {e}")
            raise
    
    def get_versions_for_slate(self, slate_id: str) -> List[str]:
        """
        Get all projection versions for a slate.
        
        Args:
            slate_id: Slate identifier
            
        Returns:
            List of version strings
        """
        try:
            query = """
            SELECT DISTINCT version
            FROM operational_projections
            WHERE slate_id = :slate_id
            ORDER BY version DESC
            """
            
            results = self.connection.execute(
                query,
                {"slate_id": slate_id},
            ).fetchall()
            
            versions = [row[0] for row in results]
            return versions
        
        except Exception as e:
            logger.error(f"Error retrieving versions for slate {slate_id}: {e}")
            raise
    
    def update_projection(self, projection: ProjectionDistribution) -> None:
        """
        Update existing projection.
        
        Args:
            projection: Updated ProjectionDistribution
        """
        try:
            query = """
            UPDATE operational_projections
            SET
                median_fppg = :median_fppg,
                floor_fppg = :floor_fppg,
                ceiling_fppg = :ceiling_fppg,
                volatility = :volatility,
                confidence = :confidence,
                source_signals = :source_signals,
                contributing_factors = :contributing_factors,
                inputs_hash = :inputs_hash,
                updated_at = CURRENT_TIMESTAMP
            WHERE player_id = :player_id
              AND game_id = :game_id
              AND slate_id = :slate_id
              AND version = :version
            """
            
            self.connection.execute(
                query,
                {
                    "player_id": projection.player_id,
                    "game_id": projection.game_id,
                    "slate_id": projection.slate_id,
                    "version": projection.version,
                    "median_fppg": projection.median_fppg,
                    "floor_fppg": projection.floor_fppg,
                    "ceiling_fppg": projection.ceiling_fppg,
                    "volatility": projection.volatility,
                    "confidence": projection.confidence,
                    "source_signals": json.dumps(projection.source_signals),
                    "contributing_factors": json.dumps(projection.contributing_factors),
                    "inputs_hash": projection.inputs_hash,
                },
            )
            
            logger.debug(f"Updated projection for {projection.player_id}")
        
        except Exception as e:
            logger.error(f"Error updating projection: {e}")
            raise
    
    def _row_to_projection(self, row) -> ProjectionDistribution:
        """Convert database row to ProjectionDistribution."""
        return ProjectionDistribution(
            player_id=row[0],
            game_id=row[1],
            slate_id=row[2],
            league=row[3],
            as_of_time=row[4],
            median_fppg=row[5],
            floor_fppg=row[6],
            ceiling_fppg=row[7],
            volatility=row[8],
            confidence=row[9],
            source_signals=json.loads(row[10]) if row[10] else [],
            contributing_factors=json.loads(row[11]) if row[11] else {},
            version=row[12],
            inputs_hash=row[13],
            created_at=row[14],
        )


def get_projection_store(connection) -> ProjectionStore:
    """Get projection store singleton.
    
    Args:
        connection: Database connection
        
    Returns:
        ProjectionStore instance
    """
    return ProjectionStore(connection)
