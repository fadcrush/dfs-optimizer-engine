"""Projection models for building distribution-based player projections."""

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Dict, Optional
import json
import hashlib

from core import get_utc_now, get_logger, SIGNAL_TYPE
from projection.decision_snapshots import DecisionSnapshotStore, DecisionSnapshot
from signals.store import SignalStore


logger = get_logger(__name__)


@dataclass
class ProjectionDistribution:
    """Distribution-based projection, not single point estimate."""
    
    player_id: str
    game_id: str
    slate_id: str
    league: str
    as_of_time: datetime
    
    # Core distribution (required)
    median_fppg: float
    floor_fppg: float  # 25th percentile
    ceiling_fppg: float  # 75th percentile
    
    # Volatility and confidence (required)
    volatility: float  # Standard deviation estimate
    confidence: float  # 0-1, decreases over time from signals
    
    # Additional distribution shape
    mean_fppg: Optional[float] = None  # Average, may differ from median
    std_dev: Optional[float] = None  # Standard deviation for normal approximation
    skewness: Optional[float] = None  # Distribution skew (left/right tail)
    kurtosis: Optional[float] = None  # Distribution tail thickness
    
    # Metadata
    source_signals: List[str] = field(default_factory=list)  # signal_ids that contributed
    contributing_factors: Dict[str, float] = field(default_factory=dict)  # signal→weight mapping
    version: str = ""  # Projection set version for auditability
    inputs_hash: str = ""  # Hash of all inputs (determinism check)
    created_at: datetime = field(default_factory=get_utc_now)
    
    def to_dict(self) -> Dict:
        """Convert to dictionary."""
        return {
            "player_id": self.player_id,
            "game_id": self.game_id,
            "slate_id": self.slate_id,
            "league": self.league,
            "as_of_time": self.as_of_time.isoformat(),
            "median_fppg": self.median_fppg,
            "floor_fppg": self.floor_fppg,
            "ceiling_fppg": self.ceiling_fppg,
            "volatility": self.volatility,
            "confidence": self.confidence,
            "mean_fppg": self.mean_fppg,
            "std_dev": self.std_dev,
            "skewness": self.skewness,
            "kurtosis": self.kurtosis,
            "source_signals": self.source_signals,
            "contributing_factors": self.contributing_factors,
            "version": self.version,
            "inputs_hash": self.inputs_hash,
            "created_at": self.created_at.isoformat(),
        }
    
    def compute_percentile(self, percentile: float) -> float:
        """
        Estimate percentile value from distribution.
        Uses median/floor/ceiling to approximate percentile range.
        
        Args:
            percentile: 0-100
            
        Returns:
            Estimated FPPG at percentile
        """
        if percentile < 0 or percentile > 100:
            raise ValueError(f"Percentile must be 0-100, got {percentile}")
        
        # Simple linear approximation
        if percentile <= 25:
            # Between floor and lower median
            t = percentile / 25.0
            return self.floor_fppg + t * (self.median_fppg - self.floor_fppg)
        elif percentile <= 50:
            # Between lower median and median
            t = (percentile - 25) / 25.0
            return self.median_fppg + t * 0  # median is reference
        elif percentile <= 75:
            # Between median and ceiling
            t = (percentile - 50) / 25.0
            return self.median_fppg + t * (self.ceiling_fppg - self.median_fppg)
        else:
            # Above ceiling (extrapolate)
            t = (percentile - 75) / 25.0
            range_above = self.ceiling_fppg - self.median_fppg
            return self.ceiling_fppg + t * range_above
    
    def get_volatility_range(self) -> tuple:
        """Return (low, high) volatility range for this player."""
        return (self.floor_fppg, self.ceiling_fppg)


@dataclass
class ProjectionRuleApplication:
    """Track how priority rules affected projection."""
    
    rule_name: str
    applied: bool
    effect_on_floor: float = 0.0  # Additive change
    effect_on_ceiling: float = 0.0
    effect_on_volatility: float = 0.0
    reason: str = ""
    signal_id: Optional[str] = None


@dataclass
class PlayerDecisionExplanation:
    """Human-readable explanation for player include/exclude decision."""

    player_name: str
    decision: str  # INCLUDED or EXCLUDED
    projection: float
    salary: float
    value_target: float
    signal_impact: str
    minutes_expected: float
    final_reason: str

    def to_dict(self) -> Dict:
        return {
            "player_name": self.player_name,
            "decision": self.decision,
            "projection": self.projection,
            "salary": self.salary,
            "value_target": self.value_target,
            "signal_impact": self.signal_impact,
            "minutes_expected": self.minutes_expected,
            "final_reason": self.final_reason,
        }


class ProjectionBuilderRules:
    """Priority hierarchy rules for projections.
    
    Priority order:
    1. Injury OUT → Floor and ceiling = 0
    2. Injury IN → Restore baseline (recovery signal)
    3. Confirmed Starter → Ceiling +4, Confidence 0.95
    4. Expected Starter → Ceiling +2, Confidence 0.70
    5. Fatigue → Reduce ceiling by severity
    """
    
    def __init__(self):
        """Initialize rules engine."""
        self.rules_applied: List[ProjectionRuleApplication] = []
    
    def apply_rules(
        self,
        floor: float,
        ceiling: float,
        volatility: float,
        signals: List,  # List of Signal objects
        confidence_base: float = 0.75,
    ) -> tuple:
        """
        Apply priority hierarchy rules.
        
        Returns:
            (floor_final, ceiling_final, volatility_final, confidence_final)
        """
        self.rules_applied = []
        
        floor_result = floor
        ceiling_result = ceiling
        volatility_result = volatility
        confidence_result = confidence_base
        
        # Rule 1: Injury OUT (hard override, short-circuit)
        injury_out_signal = self._get_signal_by_type(signals, SIGNAL_TYPE.INJURY_OUT)
        if injury_out_signal:
            self.rules_applied.append(ProjectionRuleApplication(
                rule_name="Injury OUT",
                applied=True,
                effect_on_floor=-floor_result,
                effect_on_ceiling=-ceiling_result,
                reason="Player officially OUT",
                signal_id=getattr(injury_out_signal, 'signal_id', None),
            ))
            return 0, 0, 0, 0  # Hard override
        
        # Rule 2: Injury IN (recovery, restore baseline)
        injury_in_signal = self._get_signal_by_type(signals, SIGNAL_TYPE.INJURY_IN)
        if injury_in_signal:
            confidence_increase = 0.10
            self.rules_applied.append(ProjectionRuleApplication(
                rule_name="Injury IN",
                applied=True,
                reason="Recovery signal received",
                signal_id=getattr(injury_in_signal, 'signal_id', None),
            ))
            confidence_result = min(1.0, confidence_result + confidence_increase)
        
        # Rule 3: Confirmed Starter (highest opportunity)
        confirmed_starter = self._get_signal_by_type(signals, SIGNAL_TYPE.CONFIRMED_STARTER)
        if confirmed_starter:
            ceiling_increase = 4.0
            self.rules_applied.append(ProjectionRuleApplication(
                rule_name="Confirmed Starter",
                applied=True,
                effect_on_ceiling=ceiling_increase,
                reason="Confirmed starting assignment",
                signal_id=getattr(confirmed_starter, 'signal_id', None),
            ))
            ceiling_result += ceiling_increase
            confidence_result = 0.95  # Very high confidence
            return floor_result, ceiling_result, volatility_result, confidence_result
        
        # Rule 4: Expected Starter (medium opportunity)
        expected_starter = self._get_signal_by_type(signals, SIGNAL_TYPE.EXPECTED_STARTER)
        if expected_starter:
            ceiling_increase = 2.0
            self.rules_applied.append(ProjectionRuleApplication(
                rule_name="Expected Starter",
                applied=True,
                effect_on_ceiling=ceiling_increase,
                reason="Expected starting assignment",
                signal_id=getattr(expected_starter, 'signal_id', None),
            ))
            ceiling_result += ceiling_increase
            confidence_result = 0.70
            return floor_result, ceiling_result, volatility_result, confidence_result
        
        # Rule 5: Fatigue (reduce ceiling by severity)
        fatigue_signal = self._get_signal_by_type(signals, SIGNAL_TYPE.FATIGUE_SIGNAL)
        if fatigue_signal:
            severity = getattr(fatigue_signal, 'severity', 0.5)  # 0-1
            ceiling_reduction = ceiling_result * severity * 0.15  # 0-15% reduction
            
            self.rules_applied.append(ProjectionRuleApplication(
                rule_name="Fatigue",
                applied=True,
                effect_on_ceiling=-ceiling_reduction,
                reason=f"Fatigue severity {severity:.1%}",
                signal_id=getattr(fatigue_signal, 'signal_id', None),
            ))
            ceiling_result -= ceiling_reduction
            confidence_result *= (1.0 - severity * 0.1)  # Slight confidence penalty
        
        return floor_result, ceiling_result, volatility_result, confidence_result
    
    def _get_signal_by_type(self, signals: List, signal_type: str):
        """Get first signal matching type."""
        for signal in signals:
            if getattr(signal, 'signal_type', None) == signal_type:
                return signal
        return None


class ProjectionBuilder:
    """Build distributions from baselines, features, and signals."""
    
    def __init__(self, connection):
        """Initialize builder.

        Args:
            connection: Database connection
        """
        self.connection = connection
        self.rules = ProjectionBuilderRules()
        self.projection_cache: Dict[str, ProjectionDistribution] = {}
        self.decision_store = DecisionSnapshotStore(connection)
        self.signal_store = SignalStore(connection)
    
    def build_projection(
        self,
        player_id: str,
        game_id: str,
        slate_id: str,
        league: str,
        as_of_time: datetime,
        minutes_baseline_floor: float,
        minutes_baseline_ceiling: float,
        usage_baseline_floor: float,
        usage_baseline_ceiling: float,
        fppg_baseline: float,
        position: str,
        salary: int,
        version: str = "v1",
    ) -> ProjectionDistribution:
        """
        Build full projection distribution.
        
        Args:
            player_id: Player identifier
            game_id: Game identifier
            slate_id: Slate identifier
            league: NBA or NFL
            as_of_time: Decision point timestamp
            minutes_baseline_floor: Baseline minutes 25th %ile
            minutes_baseline_ceiling: Baseline minutes 75th %ile
            usage_baseline_floor: Baseline usage floor
            usage_baseline_ceiling: Baseline usage ceiling
            fppg_baseline: Baseline FPPG (median)
            position: Player position
            salary: DFS salary
            version: Projection version
            
        Returns:
            ProjectionDistribution with floor/median/ceiling/confidence/volatility
        """
        try:
            # Step 0: Fetch active signals for this player at decision time
            signals = self.signal_store.get_for_entity(
                entity_type="player",
                entity_id=player_id,
                league=league,
                as_of_time=as_of_time,
            )

            # Step 1: Compute distribution parameters from baselines
            minutes_floor, minutes_ceiling = minutes_baseline_floor, minutes_baseline_ceiling
            
            # Step 2: Apply priority rules (rules may short-circuit on Injury OUT)
            minutes_floor, minutes_ceiling, _, confidence = self.rules.apply_rules(
                minutes_floor,
                minutes_ceiling,
                0,  # Volatility computed separately
                signals,
                confidence_base=0.75,
            )
            
            # Step 3: Compute FPPG distribution from minutes distribution
            # Assume FPPG = (minutes / baseline_minutes) * fppg_baseline
            # with some noise from variance
            min_usage_ratio = (minutes_floor / minutes_baseline_ceiling) if minutes_baseline_ceiling > 0 else 0
            max_usage_ratio = (minutes_ceiling / minutes_baseline_floor) if minutes_baseline_floor > 0 else 1
            
            floor_fppg = min_usage_ratio * fppg_baseline * 0.85  # Conservative floor
            ceiling_fppg = max_usage_ratio * fppg_baseline * 1.15  # Optimistic ceiling
            median_fppg = (floor_fppg + ceiling_fppg) / 2
            
            # Step 4: Compute volatility from range
            volatility = (ceiling_fppg - floor_fppg) / 4  # Heuristic
            
            # Step 5: Gather contributing factors from signals
            contributing_factors = {}
            source_signals = []
            for signal in signals:
                signal_id = getattr(signal, 'signal_id', 'unknown')
                signal_type = getattr(signal, 'signal_type', 'unknown')
                source = getattr(signal, 'source', 'unknown')
                
                source_signals.append(signal_id)
                contributing_factors[f"{signal_type}_{source}"] = getattr(signal, 'source_confidence', 0.75)
            
            # Step 6: Compute deterministic inputs hash
            inputs_json = json.dumps({
                "player_id": player_id,
                "game_id": game_id,
                "slate_id": slate_id,
                "minutes_baseline_floor": minutes_baseline_floor,
                "minutes_baseline_ceiling": minutes_baseline_ceiling,
                "usage_baseline_floor": usage_baseline_floor,
                "usage_baseline_ceiling": usage_baseline_ceiling,
                "fppg_baseline": fppg_baseline,
                "signal_ids": sorted(source_signals),
                "version": version,
            }, sort_keys=True)
            inputs_hash = hashlib.sha256(inputs_json.encode()).hexdigest()
            
            # Step 7: Create projection
            projection = ProjectionDistribution(
                player_id=player_id,
                game_id=game_id,
                slate_id=slate_id,
                league=league,
                as_of_time=as_of_time,
                median_fppg=median_fppg,
                floor_fppg=floor_fppg,
                ceiling_fppg=ceiling_fppg,
                volatility=volatility,
                confidence=confidence,
                mean_fppg=median_fppg,  # Use median as mean for simplicity
                std_dev=volatility,
                source_signals=source_signals,
                contributing_factors=contributing_factors,
                version=version,
                inputs_hash=inputs_hash,
            )
            
            # Step 8: Create decision snapshot (audit trail for post-game evaluation)
            try:
                # Determine override level and decision based on signals
                override_level = 0
                decision = 'STANDARD'
                
                if signals:
                    for signal in signals:
                        signal_type = getattr(signal, 'signal_type', '')
                        
                        # Check for priority signals in decreasing order of impact
                        if signal_type == 'InjuryOutSignal':
                            override_level = 1
                            decision = 'ZERO_MINUTES'
                            break  # Highest priority
                        elif signal_type == 'InjuryInSignal':
                            if override_level < 2:
                                override_level = 2
                                decision = 'REDUCE_USAGE'
                        elif signal_type == 'ConfirmedStarterSignal':
                            if override_level < 3:
                                override_level = 3
                                decision = 'EXPAND_OPPORTUNITY'
                
                # Create snapshot for audit trail
                snapshot = DecisionSnapshot(
                    player_id=player_id,
                    game_id=game_id,
                    slate_id=slate_id,
                    override_level=override_level,
                    decision=decision,
                    applied_at=as_of_time,
                    inputs_hash=inputs_hash,
                    signals_used=source_signals,
                    features_used={'minutes': version, 'usage': version},
                    baseline_version=version
                )
                
                # Store snapshot in database
                self.decision_store.insert(snapshot)
                
            except Exception as snapshot_error:
                # Log error but don't fail projection creation
                logger.warning(
                    f"Failed to create decision snapshot for {player_id}: {snapshot_error}"
                )
            
            logger.info(
                f"Built projection for {player_id}: "
                f"FPPG {floor_fppg:.1f}-{ceiling_fppg:.1f} (median {median_fppg:.1f}), "
                f"confidence {confidence:.1%}, signals={len(source_signals)}"
            )
            
            return projection
        
        except Exception as e:
            logger.error(f"Error building projection for {player_id}: {e}")
            raise
    
    def build_slate_projections(
        self,
        slate_id: str,
        game_ids: List[str],
        player_game_data: Dict,  # {player_id → {game_id → data}}
        as_of_time: datetime,
        version: str = "v1",
    ) -> Dict[str, ProjectionDistribution]:
        """
        Build projections for entire slate.
        
        Args:
            slate_id: Slate identifier
            game_ids: Games in slate
            player_game_data: Player game data by (player_id, game_id)
            as_of_time: Decision point
            version: Projection version
            
        Returns:
            Dict of {player_id → ProjectionDistribution}
        """
        projections = {}
        
        for player_id, game_data_dict in player_game_data.items():
            for game_id, data in game_data_dict.items():
                projection = self.build_projection(
                    player_id=player_id,
                    game_id=game_id,
                    slate_id=slate_id,
                    league=data.get("league", "NBA"),
                    as_of_time=as_of_time,
                    minutes_baseline_floor=data.get("minutes_baseline_floor", 0),
                    minutes_baseline_ceiling=data.get("minutes_baseline_ceiling", 35),
                    usage_baseline_floor=data.get("usage_baseline_floor", 0.10),
                    usage_baseline_ceiling=data.get("usage_baseline_ceiling", 0.30),
                    fppg_baseline=data.get("fppg_baseline", 30),
                    position=data.get("position", "PG"),
                    salary=data.get("salary", 5000),
                    version=version,
                )
                
                projections[player_id] = projection
        
        logger.info(f"Built {len(projections)} projections for slate {slate_id}")
        return projections
    
    def store_projection(self, projection: ProjectionDistribution):
        """
        Store projection to database.
        
        Args:
            projection: ProjectionDistribution to store
        """
        try:
            projection_dict = projection.to_dict()
            
            # Query to insert projection with version + as_of_time
            query = """
            INSERT INTO operational_projections (
                player_id, game_id, slate_id, league, as_of_time,
                median_fppg, floor_fppg, ceiling_fppg, volatility, confidence,
                source_signals, contributing_factors, version, inputs_hash, created_at
            ) VALUES (
                :player_id, :game_id, :slate_id, :league, :as_of_time,
                :median_fppg, :floor_fppg, :ceiling_fppg, :volatility, :confidence,
                :source_signals, :contributing_factors, :version, :inputs_hash, :created_at
            )
            ON CONFLICT (player_id, game_id, slate_id, version) 
            DO UPDATE SET
                median_fppg = EXCLUDED.median_fppg,
                floor_fppg = EXCLUDED.floor_fppg,
                ceiling_fppg = EXCLUDED.ceiling_fppg,
                confidence = EXCLUDED.confidence,
                volatility = EXCLUDED.volatility,
                inputs_hash = EXCLUDED.inputs_hash,
                updated_at = CURRENT_TIMESTAMP
            """
            
            self.connection.execute(
                query,
                {
                    "player_id": projection.player_id,
                    "game_id": projection.game_id,
                    "slate_id": projection.slate_id,
                    "league": projection.league,
                    "as_of_time": projection.as_of_time,
                    "median_fppg": projection.median_fppg,
                    "floor_fppg": projection.floor_fppg,
                    "ceiling_fppg": projection.ceiling_fppg,
                    "volatility": projection.volatility,
                    "confidence": projection.confidence,
                    "source_signals": json.dumps(projection.source_signals),
                    "contributing_factors": json.dumps(projection.contributing_factors),
                    "version": projection.version,
                    "inputs_hash": projection.inputs_hash,
                    "created_at": projection.created_at,
                },
            )
            
            logger.debug(
                f"Stored projection for {projection.player_id} "
                f"in slate {projection.slate_id} v{projection.version}"
            )
        
        except Exception as e:
            logger.error(f"Error storing projection: {e}")
            raise
