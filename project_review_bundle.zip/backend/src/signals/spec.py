"""Signal specification and data models."""

from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from enum import Enum

from core import (
    SIGNAL_TYPE,
    DECAY_PROFILE,
    ENTITY_TYPE,
    get_utc_now,
    calculate_decay_factor,
)


@dataclass
class SignalSpec:
    """
    Core signal specification - every signal MUST conform to this.
    
    Represents a piece of intelligence about a player/game/slate with:
    - Temporal validity (when it starts/ends)
    - Confidence that decays over time
    - Scope (what it applies/doesn't apply to)
    - Payload with signal-specific data
    """
    
    # ENTITY IDENTIFICATION
    signal_type: str  # From SIGNAL_TYPE enum
    entity_type: str  # From ENTITY_TYPE enum (player, game, slate)
    entity_id: str    # player_id, game_id, slate_id
    league: str       # NBA or NFL
    
    # TEMPORAL
    timestamp_utc: datetime  # When signal was created/issued
    decay_profile: str       # From DECAY_PROFILE enum
    validity_start: datetime
    
    # CONFIDENCE & SOURCE
    source: str              # e.g., "official", "beatwriter", "nba_api", "model"
    source_confidence: float # 0.0 - 1.0
    
    # SCOPE
    applies_to: List[str]      # Domains it affects (minutes, usage, projection, ownership)
    
    # TEMPORAL (continued)
    validity_end: Optional[datetime] = None  # None = no end date
    
    # SCOPE (continued)
    cannot_apply_to: List[str] = field(default_factory=list)  # Explicit deny list
    
    # PAYLOAD
    payload: Dict[str, Any] = field(default_factory=dict)
    
    # SLATE CONTEXT (optional)
    slate_id: Optional[str] = None
    
    # METADATA (populated by system)
    signal_id: Optional[int] = None
    created_at: Optional[datetime] = None
    ingested_at: Optional[datetime] = None
    
    def __post_init__(self):
        """Validate signal spec."""
        if not isinstance(self.timestamp_utc, datetime):
            raise ValueError("timestamp_utc must be datetime")
        if not 0 <= self.source_confidence <= 1.0:
            raise ValueError("source_confidence must be between 0.0 and 1.0")
        if self.validity_end and self.validity_start > self.validity_end:
            raise ValueError("validity_start cannot be after validity_end")
    
    def get_effective_confidence(self, as_of: Optional[datetime] = None) -> float:
        """
        Get effective confidence after decay.
        
        Args:
            as_of: Evaluation time (default: now)
            
        Returns:
            Effective confidence (0.0 - 1.0) after decay applied
        """
        if as_of is None:
            as_of = get_utc_now()
        
        # Check validity window
        if not self.is_valid_at(as_of):
            return 0.0
        
        # Apply decay based on age
        decay_factor = calculate_decay_factor(
            self.timestamp_utc,
            self.decay_profile,
            as_of
        )
        
        return self.source_confidence * decay_factor
    
    def is_valid_at(self, at_time: Optional[datetime] = None) -> bool:
        """
        Check if signal is valid at a specific time.
        
        Args:
            at_time: Evaluation time (default: now)
            
        Returns:
            True if signal is within validity window and not expired
        """
        if at_time is None:
            at_time = get_utc_now()
        
        # Check validity window
        if at_time < self.validity_start:
            return False
        
        if self.validity_end and at_time >= self.validity_end:
            return False
        
        return True
    
    def applies_to_domain(self, domain: str) -> bool:
        """Check if signal applies to a specific domain."""
        if domain in self.cannot_apply_to:
            return False
        
        return domain in self.applies_to
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for storage."""
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SignalSpec":
        """Create from dictionary."""
        return cls(**data)


# Common signal specifications (templates)

class InjuryOutSignal(SignalSpec):
    """
    Injury OUT signal - player is OUT of game.
    
    Hard override: minutes=0 no matter what.
    Applies to: minutes, usage
    Cannot apply to: efficiency
    """
    
    def __init__(
        self,
        entity_id: str,
        league: str,
        source: str,
        announced_at: datetime,
        expected_return: Optional[datetime] = None,
        reason: str = "Injury",
        slate_id: Optional[str] = None,
    ):
        super().__init__(
            signal_type=SIGNAL_TYPE.INJURY_OUT,
            entity_type=ENTITY_TYPE.PLAYER,
            entity_id=entity_id,
            league=league,
            timestamp_utc=announced_at,
            decay_profile=DECAY_PROFILE.NONE,  # No decay for injury status
            validity_start=announced_at,
            validity_end=expected_return,  # Until return
            source=source,
            source_confidence=1.0,  # Official sources are high confidence
            applies_to=["minutes", "usage"],
            cannot_apply_to=["efficiency"],
            payload={
                "reason": reason,
                "expected_return": expected_return.isoformat() if expected_return else None,
            },
            slate_id=slate_id,
        )


class ConfirmedStarterSignal(SignalSpec):
    """
    Confirmed starter signal - player confirmed to start.
    
    Affects: minutes ceiling/floor expansion, opportunity access, ownership
    Does NOT change: efficiency (fppm)
    
    Starter is an opportunity modifier, not a boost.
    """
    
    def __init__(
        self,
        entity_id: str,
        league: str,
        game_id: str,
        announced_at: datetime,
        source: str = "official",
        source_confidence: float = 1.0,
        slate_id: Optional[str] = None,
    ):
        super().__init__(
            signal_type=SIGNAL_TYPE.CONFIRMED_STARTER,
            entity_type=ENTITY_TYPE.PLAYER,
            entity_id=entity_id,
            league=league,
            timestamp_utc=announced_at,
            decay_profile=DECAY_PROFILE.NONE,  # No decay for lineup status
            validity_start=announced_at,
            validity_end=None,  # Valid until game starts
            source=source,
            source_confidence=source_confidence,
            applies_to=["minutes", "usage", "ownership"],
            cannot_apply_to=["efficiency"],
            payload={
                "game_id": game_id,
                "status": "confirmed_starter",
            },
            slate_id=slate_id,
        )


class OwnershipProjectionSignal(SignalSpec):
    """
    Ownership projection from model or service.
    
    Decays quickly (fast profile) as contest approaches.
    """
    
    def __init__(
        self,
        entity_id: str,
        league: str,
        projected_pct: float,
        source: str,
        issued_at: datetime,
        slate_id: Optional[str] = None,
    ):
        # Valid for 15 minutes (fast decay profile)
        super().__init__(
            signal_type=SIGNAL_TYPE.OWNERSHIP_PROJECTION,
            entity_type=ENTITY_TYPE.PLAYER,
            entity_id=entity_id,
            league=league,
            timestamp_utc=issued_at,
            decay_profile=DECAY_PROFILE.FAST,  # 15-minute half-life
            validity_start=issued_at,
            validity_end=issued_at + timedelta(minutes=30),  # Valid for 30 min
            source=source,
            source_confidence=0.7,  # Projections are less certain
            applies_to=["ownership"],
            payload={
                "projected_pct": projected_pct,
                "percentile": None,  # Will be computed
            },
            slate_id=slate_id,
        )


class MatchupContextSignal(SignalSpec):
    """
    Matchup context - pace, defense strength, game environment.
    
    Decays slowly (24h) unless game context changes.
    """
    
    def __init__(
        self,
        entity_id: str,  # game_id
        league: str,
        source: str,
        issued_at: datetime,
        context_data: Dict[str, Any],
        slate_id: Optional[str] = None,
    ):
        super().__init__(
            signal_type=SIGNAL_TYPE.MATCHUP_CONTEXT,
            entity_type=ENTITY_TYPE.GAME,
            entity_id=entity_id,
            league=league,
            timestamp_utc=issued_at,
            decay_profile=DECAY_PROFILE.SLOW,  # 24-hour half-life
            validity_start=issued_at,
            validity_end=None,
            source=source,
            source_confidence=0.85,
            applies_to=["projection"],
            payload=context_data,
            slate_id=slate_id,
        )


class FatigueSignal(SignalSpec):
    """
    Fatigue signal - player fatigue/load management.
    
    Moderate decay (1h) as games progress.
    """
    
    def __init__(
        self,
        entity_id: str,
        league: str,
        fatigue_level: str,  # low, medium, high
        source: str,
        issued_at: datetime,
        slate_id: Optional[str] = None,
    ):
        super().__init__(
            signal_type=SIGNAL_TYPE.FATIGUE_SIGNAL,
            entity_type=ENTITY_TYPE.PLAYER,
            entity_id=entity_id,
            league=league,
            timestamp_utc=issued_at,
            decay_profile=DECAY_PROFILE.MEDIUM,  # 1-hour half-life
            validity_start=issued_at,
            validity_end=issued_at + timedelta(hours=6),
            source=source,
            source_confidence=0.6,  # Fatigue is subjective
            applies_to=["minutes", "efficiency"],
            payload={
                "fatigue_level": fatigue_level,  # low, medium, high
                "severity": {"low": 0.1, "medium": 0.3, "high": 0.5}.get(fatigue_level, 0.0),
            },
            slate_id=slate_id,
        )
