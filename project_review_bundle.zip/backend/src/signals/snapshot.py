"""Decision snapshot builder - builds state as-of a time."""

import json
import hashlib
import logging
from datetime import datetime
from typing import Dict, List, Optional, Any

from core import get_utc_now, to_utc, ENTITY_TYPE
from .spec import SignalSpec
from .store import SignalStore
from .overrides import get_override_engine

logger = logging.getLogger(__name__)


class DecisionSnapshot:
    """
    Complete decision state for a slate/player at a point in time.
    
    This is the primary output of the signals layer. It contains:
    - All applicable signals as-of the time
    - Computed effective confidences (after decay)
    - Applied overrides for each domain
    - Input hash for reproducibility
    - Auditable decision path
    """
    
    def __init__(
        self,
        entity_type: str,
        entity_id: str,
        league: str,
        as_of_time: datetime,
    ):
        self.entity_type = entity_type
        self.entity_id = entity_id
        self.league = league
        self.as_of_time = to_utc(as_of_time)
        
        self.signals: List[SignalSpec] = []
        self.signal_contributions: Dict[str, Any] = {}
        self.overrides: Dict[str, Dict[str, Any]] = {}
        self.final_state: Dict[str, Any] = {}
        self.inputs_hash: Optional[str] = None
    
    def add_signals(self, signals: List[SignalSpec]):
        """Add signals to the snapshot."""
        self.signals.extend(signals)
    
    def compute_signal_contributions(self) -> Dict[str, Any]:
        """
        Compute how each signal contributes to the decision.
        
        Returns dict like:
        {
            "injury_out_confirmed": {
                "signal_id": 123,
                "source": "official",
                "effective_confidence": 1.0,
                "applied_to": ["minutes", "usage"],
            },
            ...
        }
        """
        contributions = {}
        
        for signal in self.signals:
            if not signal.is_valid_at(self.as_of_time):
                continue
            
            effective_conf = signal.get_effective_confidence(self.as_of_time)
            
            contributions[f"{signal.signal_type}_{signal.source}"] = {
                "signal_id": signal.signal_id,
                "signal_type": signal.signal_type,
                "source": signal.source,
                "source_confidence": signal.source_confidence,
                "effective_confidence": effective_conf,
                "applied_to": signal.applies_to,
                "timestamp_utc": signal.timestamp_utc.isoformat(),
            }
        
        self.signal_contributions = contributions
        return contributions
    
    def apply_overrides(
        self,
        domain: str,
        baseline: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Apply override rules for a domain.
        
        Args:
            domain: Domain name (minutes, usage, projection, etc.)
            baseline: Baseline values to override
            
        Returns:
            Final values after overrides
        """
        engine = get_override_engine()
        final = engine.apply_overrides(
            self.signals,
            domain,
            baseline,
            self.as_of_time,
        )
        
        self.overrides[domain] = final
        return final
    
    def compute_inputs_hash(self) -> str:
        """
        Compute hash of all inputs for reproducibility.
        
        Hash includes:
        - All signal IDs
        - as_of_time
        - entity identification
        
        This enables verifying that same inputs produce same outputs.
        """
        inputs = {
            "entity_type": self.entity_type,
            "entity_id": self.entity_id,
            "league": self.league,
            "as_of_time": self.as_of_time.isoformat(),
            "signal_ids": sorted([s.signal_id for s in self.signals if s.signal_id]),
            "signal_types": sorted(list(set(s.signal_type for s in self.signals))),
        }
        
        inputs_json = json.dumps(inputs, sort_keys=True)
        self.inputs_hash = hashlib.sha256(inputs_json.encode()).hexdigest()
        return self.inputs_hash
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert snapshot to dictionary for storage."""
        return {
            "entity_type": self.entity_type,
            "entity_id": self.entity_id,
            "league": self.league,
            "as_of_time": self.as_of_time.isoformat(),
            "signals_count": len(self.signals),
            "signal_contributions": self.signal_contributions,
            "overrides": self.overrides,
            "final_state": self.final_state,
            "inputs_hash": self.inputs_hash,
        }
    
    def __repr__(self) -> str:
        return (
            f"DecisionSnapshot({self.entity_type}/{self.entity_id} @ {self.as_of_time}, "
            f"signals={len(self.signals)}, hash={self.inputs_hash[:8]}...)"
        )


class SnapshotBuilder:
    """Builder for decision snapshots."""
    
    def __init__(self, signal_store: SignalStore):
        """
        Initialize snapshot builder.
        
        Args:
            signal_store: SignalStore instance for querying signals
        """
        self.signal_store = signal_store
    
    def build_for_player(
        self,
        player_id: str,
        league: str,
        as_of_time: Optional[datetime] = None,
        slate_id: Optional[str] = None,
    ) -> DecisionSnapshot:
        """
        Build decision snapshot for a player.
        
        Args:
            player_id: Player ID
            league: NBA or NFL
            as_of_time: Snapshot time (default: now)
            slate_id: Optional slate context
            
        Returns:
            DecisionSnapshot with all applicable signals
        """
        if as_of_time is None:
            as_of_time = get_utc_now()
        
        snapshot = DecisionSnapshot(
            entity_type=ENTITY_TYPE.PLAYER,
            entity_id=player_id,
            league=league,
            as_of_time=as_of_time,
        )
        
        # Get all valid signals for this player
        signals = self.signal_store.get_for_entity(
            entity_type=ENTITY_TYPE.PLAYER,
            entity_id=player_id,
            league=league,
            as_of_time=as_of_time,
        )
        
        snapshot.add_signals(signals)
        snapshot.compute_signal_contributions()
        snapshot.compute_inputs_hash()
        
        return snapshot
    
    def build_for_game(
        self,
        game_id: str,
        league: str,
        as_of_time: Optional[datetime] = None,
    ) -> DecisionSnapshot:
        """Build decision snapshot for a game."""
        if as_of_time is None:
            as_of_time = get_utc_now()
        
        snapshot = DecisionSnapshot(
            entity_type=ENTITY_TYPE.GAME,
            entity_id=game_id,
            league=league,
            as_of_time=as_of_time,
        )
        
        signals = self.signal_store.get_for_entity(
            entity_type=ENTITY_TYPE.GAME,
            entity_id=game_id,
            league=league,
            as_of_time=as_of_time,
        )
        
        snapshot.add_signals(signals)
        snapshot.compute_signal_contributions()
        snapshot.compute_inputs_hash()
        
        return snapshot
    
    def build_for_slate(
        self,
        slate_id: str,
        as_of_time: Optional[datetime] = None,
    ) -> Dict[str, DecisionSnapshot]:
        """
        Build decision snapshot for all players in a slate.
        
        Returns:
            Dict mapping player_id -> DecisionSnapshot
        """
        if as_of_time is None:
            as_of_time = get_utc_now()
        
        snapshots = {}
        
        # Get signals for entire slate
        all_signals = self.signal_store.get_for_slate(
            slate_id=slate_id,
            as_of_time=as_of_time,
        )
        
        # Group by entity
        signals_by_entity: Dict[str, List[SignalSpec]] = {}
        for signal in all_signals:
            key = signal.entity_id
            if key not in signals_by_entity:
                signals_by_entity[key] = []
            signals_by_entity[key].append(signal)
        
        # Build snapshot for each entity
        for entity_id, signals in signals_by_entity.items():
            snapshot = DecisionSnapshot(
                entity_type=ENTITY_TYPE.PLAYER,
                entity_id=entity_id,
                league=all_signals[0].league if all_signals else "NBA",
                as_of_time=as_of_time,
            )
            snapshot.add_signals(signals)
            snapshot.compute_signal_contributions()
            snapshot.compute_inputs_hash()
            
            snapshots[entity_id] = snapshot
        
        logger.info(f"Built snapshots for {len(snapshots)} entities in slate {slate_id}")
        return snapshots
    
    def audit_trail(self, snapshot: DecisionSnapshot) -> str:
        """
        Generate human-readable audit trail for a snapshot.
        
        Shows which signals were considered and how they influenced the decision.
        """
        lines = [
            f"\n{'='*80}",
            f"DECISION SNAPSHOT AUDIT TRAIL",
            f"Entity: {snapshot.entity_type}/{snapshot.entity_id}",
            f"As Of: {snapshot.as_of_time.isoformat()}",
            f"Hash: {snapshot.inputs_hash}",
            f"{'='*80}",
        ]
        
        lines.append(f"\nSIGNALS ({len(snapshot.signals)}):")
        lines.append("-" * 80)
        
        for signal in sorted(snapshot.signals, key=lambda s: s.timestamp_utc, reverse=True):
            if not signal.is_valid_at(snapshot.as_of_time):
                continue
            
            effective_conf = signal.get_effective_confidence(snapshot.as_of_time)
            lines.append(
                f"  {signal.signal_type:30} | "
                f"Source: {signal.source:15} | "
                f"Conf: {effective_conf:0.2f} | "
                f"Applies: {', '.join(signal.applies_to)}"
            )
        
        lines.append(f"\nOVERRIDES (by domain):")
        lines.append("-" * 80)
        for domain, overrides in snapshot.overrides.items():
            lines.append(f"  {domain}:")
            for key, value in overrides.items():
                lines.append(f"    {key}: {value}")
        
        lines.append(f"\n{'='*80}\n")
        return "\n".join(lines)
