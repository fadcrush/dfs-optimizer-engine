"""Override rules engine - applies signal priorities and rules."""

import logging
from datetime import datetime
from typing import Dict, List, Optional, Any

from core import SIGNAL_TYPE, ENTITY_TYPE, get_utc_now
from .spec import SignalSpec

logger = logging.getLogger(__name__)


class OverrideRule:
    """Single override rule with priority."""
    
    def __init__(
        self,
        priority: int,
        signal_type: str,
        applies_to: List[str],
        rule_fn,
    ):
        """
        Initialize override rule.
        
        Args:
            priority: Lower number = higher priority (1 is highest)
            signal_type: Type of signal this rule handles
            applies_to: Domains this rule affects
            rule_fn: Function(signal: SignalSpec, context) -> Dict[str, Any] modifications
        """
        self.priority = priority
        self.signal_type = signal_type
        self.applies_to = applies_to
        self.rule_fn = rule_fn
    
    def __lt__(self, other):
        return self.priority < other.priority


class OverrideEngine:
    """
    Rules engine for signal priority and application.
    
    Priority hierarchy (NBA example):
    1. injury_out (confirmed) -> minutes=0, hard override
    2. injury_in (confirmed)
    3. confirmed_starter -> expand opportunities
    4. expected_starter -> slight adjustment
    5. rotation_history -> baseline
    6. season_usage -> baseline
    7. final model -> projection
    """
    
    def __init__(self):
        self.rules: List[OverrideRule] = []
        self._initialize_default_rules()
    
    def _initialize_default_rules(self):
        """Initialize default NBA/NFL override rules."""
        
        # Priority 1: Injury OUT - hard override, minutes = 0
        self.add_rule(OverrideRule(
            priority=1,
            signal_type=SIGNAL_TYPE.INJURY_OUT,
            applies_to=["minutes", "usage"],
            rule_fn=self._apply_injury_out,
        ))
        
        # Priority 2: Injury IN - restore to baseline
        self.add_rule(OverrideRule(
            priority=2,
            signal_type=SIGNAL_TYPE.INJURY_IN,
            applies_to=["minutes", "usage"],
            rule_fn=self._apply_injury_in,
        ))
        
        # Priority 3: Confirmed Starter - expand opportunity ceiling
        self.add_rule(OverrideRule(
            priority=3,
            signal_type=SIGNAL_TYPE.CONFIRMED_STARTER,
            applies_to=["minutes", "usage", "ownership"],
            rule_fn=self._apply_confirmed_starter,
        ))
        
        # Priority 4: Expected Starter - slight expansion with confidence
        self.add_rule(OverrideRule(
            priority=4,
            signal_type=SIGNAL_TYPE.EXPECTED_STARTER,
            applies_to=["minutes", "usage"],
            rule_fn=self._apply_expected_starter,
        ))
        
        # Priority 5: Fatigue - reduce usage ceiling
        self.add_rule(OverrideRule(
            priority=5,
            signal_type=SIGNAL_TYPE.FATIGUE_SIGNAL,
            applies_to=["minutes", "efficiency"],
            rule_fn=self._apply_fatigue,
        ))
    
    def add_rule(self, rule: OverrideRule):
        """Add a rule to the engine."""
        self.rules.append(rule)
        self.rules.sort()
    
    def apply_overrides(
        self,
        signals: List[SignalSpec],
        domain: str,
        baseline: Dict[str, Any],
        as_of: Optional[datetime] = None,
    ) -> Dict[str, Any]:
        """
        Apply override rules to baseline values.
        
        Priority hierarchy ensures only the highest-priority applicable signal
        modifies the baseline for each domain.
        
        Args:
            signals: List of applicable signals
            domain: Which domain to apply (minutes, usage, projection, etc.)
            baseline: Baseline values (e.g., {minutes_floor: 10, minutes_ceiling: 35})
            as_of: Evaluation time
            
        Returns:
            Modified baseline after overrides
        """
        if as_of is None:
            as_of = get_utc_now()
        
        result = baseline.copy()
        applied_signal = None
        
        # Apply highest-priority rule
        for rule in self.rules:
            # Check if rule applies to this domain
            if domain not in rule.applies_to:
                continue
            
            # Find matching signal
            for signal in signals:
                if signal.signal_type != rule.signal_type:
                    continue
                
                # Check if signal is valid and applies to this domain
                if not signal.is_valid_at(as_of):
                    continue
                
                if not signal.applies_to_domain(domain):
                    continue
                
                # Apply rule
                try:
                    modifications = rule.rule_fn(signal, baseline)
                    result.update(modifications)
                    applied_signal = signal
                    logger.debug(
                        f"Applied {rule.signal_type} override for {domain}: {modifications}"
                    )
                    # Stop after first (highest priority) applicable rule
                    return result
                except Exception as e:
                    logger.error(f"Error applying {rule.signal_type}: {str(e)}")
                    continue
        
        return result
    
    @staticmethod
    def _apply_injury_out(signal: SignalSpec, baseline: Dict[str, Any]) -> Dict[str, Any]:
        """
        INJURY OUT hard override: minutes = 0.
        """
        return {
            "minutes_floor": 0,
            "minutes_ceiling": 0,
            "is_out": True,
            "override_reason": "Injury OUT (confirmed)",
            "override_source": signal.source,
            "override_confidence": signal.source_confidence,
        }
    
    @staticmethod
    def _apply_injury_in(signal: SignalSpec, baseline: Dict[str, Any]) -> Dict[str, Any]:
        """
        INJURY IN: player is back, use normal processing.
        """
        return {
            "is_out": False,
            "override_reason": "Injury IN (confirmed)",
            "override_source": signal.source,
            "override_confidence": signal.source_confidence,
        }
    
    @staticmethod
    def _apply_confirmed_starter(signal: SignalSpec, baseline: Dict[str, Any]) -> Dict[str, Any]:
        """
        CONFIRMED STARTER: expand opportunity ceiling.
        
        Starter increases opportunity access (minutes, touches), not efficiency.
        Typical adjustments:
        - minutes_ceiling: +3 to +5
        - usage_ceiling: +5 to +10%
        """
        return {
            "minutes_ceiling_adjustment": 4,  # Add 4 minutes to ceiling
            "is_starter": True,
            "starter_status": "confirmed",
            "override_reason": "Confirmed Starter",
            "override_source": signal.source,
            "override_confidence": signal.source_confidence,
        }
    
    @staticmethod
    def _apply_expected_starter(signal: SignalSpec, baseline: Dict[str, Any]) -> Dict[str, Any]:
        """
        EXPECTED STARTER: slight adjustment with confidence.
        
        Adjustment is proportional to source_confidence:
        - confirmed beatwriter: 80-90% confidence
        - rumor: 50-70% confidence
        """
        confidence = signal.get_effective_confidence()
        adjustment = 2 * confidence  # Scale adjustment by confidence
        
        return {
            "minutes_ceiling_adjustment": adjustment,
            "is_starter": True,
            "starter_status": "expected",
            "override_reason": "Expected Starter",
            "override_source": signal.source,
            "override_confidence": confidence,
        }
    
    @staticmethod
    def _apply_fatigue(signal: SignalSpec, baseline: Dict[str, Any]) -> Dict[str, Any]:
        """
        FATIGUE: reduce usage/efficiency ceiling.
        
        Fatigue level (low/medium/high) maps to:
        - low: -5% usage
        - medium: -10% usage
        - high: -20% usage
        """
        fatigue_level = signal.payload.get("fatigue_level", "low")
        adjustment = {
            "low": 0.95,      # 95% of baseline
            "medium": 0.90,   # 90% of baseline
            "high": 0.80,     # 80% of baseline
        }.get(fatigue_level, 1.0)
        
        return {
            "minutes_ceiling_multiplier": adjustment,
            "fatigue_level": fatigue_level,
            "override_reason": f"Fatigue ({fatigue_level})",
            "override_source": signal.source,
            "override_confidence": signal.get_effective_confidence(),
        }


# Singleton instance
_override_engine = None


def get_override_engine() -> OverrideEngine:
    """Get or create the override engine singleton."""
    global _override_engine
    if _override_engine is None:
        _override_engine = OverrideEngine()
    return _override_engine
