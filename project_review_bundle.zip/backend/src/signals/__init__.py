"""
Signals layer - temporal intelligence and decision snapshots.

Phase 14A additions:
- Signal ingestion from external sources
- Normalization and scoring
- Feature store for adjustments
- Integration with projection/ownership services
"""

from .spec import (
    SignalSpec,
    InjuryOutSignal,
    ConfirmedStarterSignal,
    OwnershipProjectionSignal,
    MatchupContextSignal,
    FatigueSignal,
)
from .store import SignalStore
from .overrides import OverrideEngine, OverrideRule, get_override_engine
from .snapshot import DecisionSnapshot, SnapshotBuilder

# Phase 14A: Intelligence layer
from .models import SignalEvent, PlayerSignalAggregate, SignalType
from .ingest import SignalIngestor, is_signals_enabled, get_default_ingestor
from .normalize import SignalNormalizer, normalize_events
from .scoring import SignalScorer, score_player_signals
from .feature_store import SignalFeatureStore, get_feature_store, reset_feature_store
from .service import SignalService, get_signal_service, reset_signal_service

__all__ = [
    # Signal specifications
    "SignalSpec",
    "InjuryOutSignal",
    "ConfirmedStarterSignal",
    "OwnershipProjectionSignal",
    "MatchupContextSignal",
    "FatigueSignal",
    # Storage
    "SignalStore",
    # Overrides
    "OverrideEngine",
    "OverrideRule",
    "get_override_engine",
    # Snapshots
    "DecisionSnapshot",
    "SnapshotBuilder",
    # Phase 14A: Intelligence layer
    "SignalEvent",
    "PlayerSignalAggregate",
    "SignalType",
    "SignalIngestor",
    "is_signals_enabled",
    "get_default_ingestor",
    "SignalNormalizer",
    "normalize_events",
    "SignalScorer",
    "score_player_signals",
    "SignalFeatureStore",
    "get_feature_store",
    "reset_feature_store",
    "SignalService",
    "get_signal_service",
    "reset_signal_service",
]
