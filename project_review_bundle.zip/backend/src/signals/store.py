"""Signal storage and retrieval."""

import json
import logging
from datetime import datetime
from typing import Dict, List, Optional, Any

from sqlalchemy import text

from core import get_utc_now, to_utc
from .spec import SignalSpec

logger = logging.getLogger(__name__)


class SignalStore:
    """Store for signals with CRUD operations and time-range queries."""
    
    def __init__(self, connection):
        """
        Initialize signal store.
        
        Args:
            connection: SQLAlchemy database connection
        """
        self.connection = connection
    
    def insert(self, signal: SignalSpec) -> int:
        """
        Insert a signal into the store.
        
        Args:
            signal: SignalSpec to store
            
        Returns:
            signal_id of inserted signal
        """
        query = """
            INSERT INTO operational_signals
            (signal_type, entity_type, entity_id, league, slate_id,
             timestamp_utc, source, source_confidence, decay_profile,
             validity_start, validity_end, applies_to, cannot_apply_to,
             signal_payload, ingested_at)
            VALUES
            (:signal_type, :entity_type, :entity_id, :league, :slate_id,
             :timestamp_utc, :source, :source_confidence, :decay_profile,
             :validity_start, :validity_end, :applies_to, :cannot_apply_to,
             :signal_payload, :ingested_at)
        """
        
        result = self.connection.execute(
            text(query),
            {
                "signal_type": signal.signal_type,
                "entity_type": signal.entity_type,
                "entity_id": signal.entity_id,
                "league": signal.league,
                "slate_id": signal.slate_id,
                "timestamp_utc": signal.timestamp_utc,
                "source": signal.source,
                "source_confidence": signal.source_confidence,
                "decay_profile": signal.decay_profile,
                "validity_start": signal.validity_start,
                "validity_end": signal.validity_end,
                "applies_to": json.dumps(signal.applies_to),
                "cannot_apply_to": json.dumps(signal.cannot_apply_to),
                "signal_payload": json.dumps(signal.payload),
                "ingested_at": get_utc_now(),
            }
        )
        
        self.connection.commit()
        logger.info(f"Inserted signal: {signal.signal_type} for {signal.entity_id}")
        return result.lastrowid
    
    def get_by_id(self, signal_id: int) -> Optional[SignalSpec]:
        """Get signal by ID."""
        query = """
            SELECT * FROM operational_signals
            WHERE signal_id = :signal_id
        """
        
        result = self.connection.execute(
            text(query),
            {"signal_id": signal_id}
        )
        
        row = result.first()
        if not row:
            return None
        
        return self._row_to_signal(row)
    
    def get_for_entity(
        self,
        entity_type: str,
        entity_id: str,
        league: str,
        as_of_time: Optional[datetime] = None,
    ) -> List[SignalSpec]:
        """
        Get all valid signals for an entity at a point in time.
        
        Filters by:
        - entity_type and entity_id
        - validity window
        - not expired
        
        Args:
            entity_type: Type of entity (player, game, slate)
            entity_id: ID of entity
            league: League (NBA, NFL)
            as_of_time: Evaluation time (default: now)
            
        Returns:
            List of SignalSpec, ordered newest first
        """
        if as_of_time is None:
            as_of_time = get_utc_now()
        
        query = """
            SELECT * FROM operational_signals
            WHERE entity_type = :entity_type
              AND entity_id = :entity_id
              AND league = :league
              AND validity_start <= :as_of_time
              AND (validity_end IS NULL OR validity_end > :as_of_time)
            ORDER BY timestamp_utc DESC
        """
        
        result = self.connection.execute(
            text(query),
            {
                "entity_type": entity_type,
                "entity_id": entity_id,
                "league": league,
                "as_of_time": as_of_time,
            }
        )
        
        return [self._row_to_signal(row) for row in result]
    
    def get_for_slate(
        self,
        slate_id: str,
        as_of_time: Optional[datetime] = None,
    ) -> List[SignalSpec]:
        """Get all valid signals for a slate."""
        if as_of_time is None:
            as_of_time = get_utc_now()
        
        query = """
            SELECT * FROM operational_signals
            WHERE slate_id = :slate_id
              AND validity_start <= :as_of_time
              AND (validity_end IS NULL OR validity_end > :as_of_time)
            ORDER BY timestamp_utc DESC
        """
        
        result = self.connection.execute(
            text(query),
            {
                "slate_id": slate_id,
                "as_of_time": as_of_time,
            }
        )
        
        return [self._row_to_signal(row) for row in result]
    
    def get_by_type(
        self,
        signal_type: str,
        league: str,
        as_of_time: Optional[datetime] = None,
    ) -> List[SignalSpec]:
        """Get all signals of a specific type."""
        if as_of_time is None:
            as_of_time = get_utc_now()
        
        query = """
            SELECT * FROM operational_signals
            WHERE signal_type = :signal_type
              AND league = :league
              AND validity_start <= :as_of_time
              AND (validity_end IS NULL OR validity_end > :as_of_time)
            ORDER BY timestamp_utc DESC
        """
        
        result = self.connection.execute(
            text(query),
            {
                "signal_type": signal_type,
                "league": league,
                "as_of_time": as_of_time,
            }
        )
        
        return [self._row_to_signal(row) for row in result]
    
    def get_by_source(
        self,
        source: str,
        league: str,
        as_of_time: Optional[datetime] = None,
    ) -> List[SignalSpec]:
        """Get all signals from a specific source."""
        if as_of_time is None:
            as_of_time = get_utc_now()
        
        query = """
            SELECT * FROM operational_signals
            WHERE source = :source
              AND league = :league
              AND validity_start <= :as_of_time
              AND (validity_end IS NULL OR validity_end > :as_of_time)
            ORDER BY timestamp_utc DESC
        """
        
        result = self.connection.execute(
            text(query),
            {
                "source": source,
                "league": league,
                "as_of_time": as_of_time,
            }
        )
        
        return [self._row_to_signal(row) for row in result]
    
    def get_recent(
        self,
        league: str,
        hours: int = 24,
    ) -> List[SignalSpec]:
        """Get signals from the last N hours."""
        query = """
            SELECT * FROM operational_signals
            WHERE league = :league
              AND timestamp_utc >= CURRENT_TIMESTAMP - INTERVAL :hours HOUR
            ORDER BY timestamp_utc DESC
        """
        
        result = self.connection.execute(
            text(query),
            {
                "league": league,
                "hours": hours,
            }
        )
        
        return [self._row_to_signal(row) for row in result]
    
    def delete(self, signal_id: int) -> int:
        """Delete a signal by ID."""
        query = """
            DELETE FROM operational_signals
            WHERE signal_id = :signal_id
        """
        
        result = self.connection.execute(
            text(query),
            {"signal_id": signal_id}
        )
        
        self.connection.commit()
        return result.rowcount
    
@staticmethod
def _row_to_signal(row) -> SignalSpec:
    """Convert database row to SignalSpec."""
    data = dict(row._mapping)

    # Parse JSON fields
    if isinstance(data.get("applies_to"), str):
        data["applies_to"] = json.loads(data["applies_to"])

    if isinstance(data.get("cannot_apply_to"), str):
        data["cannot_apply_to"] = json.loads(data["cannot_apply_to"])

    # IMPORTANT: map signal_payload -> payload
    if isinstance(data.get("signal_payload"), str):
        data["payload"] = json.loads(data["signal_payload"])
    else:
        data["payload"] = data.get("signal_payload")

    # Remove DB-only field
    data.pop("signal_payload", None)

    return SignalSpec(**data)
    
