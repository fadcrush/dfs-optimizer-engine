"""Database module - schema, migrations, and queries."""

from .engine import create_engine_with_retry, get_canonical_db_path
from .migrations import run_migrations, get_migration_sql, MIGRATIONS
from .schema_registry import (
    SCHEMA_REGISTRY,
    get_table_schema,
    get_all_table_names,
    validate_table_exists,
    validate_row,
)
from .query_lib import SafeQueries, QueryBuilder, get_query_template

__all__ = [
    "create_engine_with_retry",
    "get_canonical_db_path",
    "run_migrations",
    "get_migration_sql",
    "MIGRATIONS",
    "SCHEMA_REGISTRY",
    "get_table_schema",
    "get_all_table_names",
    "validate_table_exists",
    "validate_row",
    "SafeQueries",
    "QueryBuilder",
    "get_query_template",
]
