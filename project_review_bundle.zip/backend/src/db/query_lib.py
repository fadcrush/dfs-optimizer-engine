"""Safe parameterized query library."""

import logging
from typing import Any, Dict, List, Optional, Tuple
from datetime import datetime
from sqlalchemy import text
from sqlalchemy.sql import ClauseElement

logger = logging.getLogger(__name__)


class QueryBuilder:
    """Safe SQL query builder with parameterization."""
    
    def __init__(self):
        self.query = ""
        self.params: Dict[str, Any] = {}
        self.param_count = 0
    
    def add_param(self, value: Any) -> str:
        """Add a parameter and return its placeholder."""
        param_name = f"param_{self.param_count}"
        self.params[param_name] = value
        self.param_count += 1
        return f":{param_name}"
    
    def select(self, columns: List[str], table: str) -> "QueryBuilder":
        """Start a SELECT query."""
        cols = ", ".join(columns)
        self.query = f"SELECT {cols} FROM {table}"
        return self
    
    def where(self, condition: str) -> "QueryBuilder":
        """Add WHERE clause."""
        self.query += f" WHERE {condition}"
        return self
    
    def and_where(self, condition: str) -> "QueryBuilder":
        """Add AND WHERE clause."""
        self.query += f" AND {condition}"
        return self
    
    def or_where(self, condition: str) -> "QueryBuilder":
        """Add OR WHERE clause."""
        self.query += f" OR {condition}"
        return self
    
    def order_by(self, column: str, desc: bool = False) -> "QueryBuilder":
        """Add ORDER BY clause."""
        direction = "DESC" if desc else "ASC"
        self.query += f" ORDER BY {column} {direction}"
        return self
    
    def limit(self, limit: int) -> "QueryBuilder":
        """Add LIMIT clause."""
        self.query += f" LIMIT {limit}"
        return self
    
    def offset(self, offset: int) -> "QueryBuilder":
        """Add OFFSET clause."""
        self.query += f" OFFSET {offset}"
        return self
    
    def build(self) -> Tuple[str, Dict[str, Any]]:
        """Build final query."""
        return self.query, self.params
    
    def build_text(self) -> ClauseElement:
        """Build SQLAlchemy text object."""
        return text(self.query).bindparams(**self.params)


class SafeQueries:
    """Library of safe, pre-built queries."""
    
    @staticmethod
    def insert_raw_fd_slate(
        connection,
        slate_id: str,
        contest_id: str,
        slate_date: datetime,
        file_hash: str,
        payload: Dict[str, Any],
    ) -> int:
        """Insert FanDuel slate CSV row."""
        query = """
            INSERT INTO raw_fd_slate_csv 
            (slate_id, contest_id, slate_date, file_hash, payload)
            VALUES (:slate_id, :contest_id, :slate_date, :file_hash, :payload)
            ON CONFLICT (slate_id, contest_id, file_hash) DO NOTHING
        """
        
        result = connection.execute(
            text(query),
            {
                "slate_id": slate_id,
                "contest_id": contest_id,
                "slate_date": slate_date.date() if isinstance(slate_date, datetime) else slate_date,
                "file_hash": file_hash,
                "payload": payload,
            }
        )
        
        return result.rowcount
    
    @staticmethod
    def get_signals_for_entity(
        connection,
        entity_type: str,
        entity_id: str,
        league: str,
        as_of_time: datetime,
    ) -> List[Dict[str, Any]]:
        """
        Get all valid signals for an entity at a point in time.
        
        Filters by:
        - entity_type and entity_id
        - validity window (valid_start <= as_of <= valid_end or valid_end is NULL)
        - not expired (valid_end > as_of or valid_end is NULL)
        """
        query = """
            SELECT 
                signal_id, signal_type, source, source_confidence, 
                decay_profile, timestamp_utc, validity_start, validity_end,
                applies_to, cannot_apply_to, signal_payload
            FROM operational_signals
            WHERE entity_type = :entity_type
              AND entity_id = :entity_id
              AND league = :league
              AND validity_start <= :as_of_time
              AND (validity_end IS NULL OR validity_end > :as_of_time)
            ORDER BY timestamp_utc DESC
        """
        
        result = connection.execute(
            text(query),
            {
                "entity_type": entity_type,
                "entity_id": entity_id,
                "league": league,
                "as_of_time": as_of_time,
            }
        )
        
        return [dict(row._mapping) for row in result]
    
    @staticmethod
    def get_slate_players(
        connection,
        slate_id: str,
    ) -> List[Dict[str, Any]]:
        """Get all players in a slate with their metadata."""
        query = """
            SELECT 
                fsp.site_player_id,
                fsp.player_id,
                dp.canonical_name,
                fsp.position,
                fsp.salary,
                fsp.team,
                fsp.game_id,
                fsp.injury_status,
                fsp.game_start_time
            FROM fact_site_players fsp
            JOIN dim_players dp ON fsp.player_id = dp.player_id
            WHERE fsp.slate_id = :slate_id
            ORDER BY fsp.position, fsp.salary DESC
        """
        
        result = connection.execute(
            text(query),
            {"slate_id": slate_id}
        )
        
        return [dict(row._mapping) for row in result]
    
    @staticmethod
    def get_latest_lineup_status(
        connection,
        game_id: str,
        player_id: str,
    ) -> Optional[Dict[str, Any]]:
        """Get latest starting lineup status for a player in a game."""
        query = """
            SELECT 
                lineup_id, status, source_type, source_confidence,
                announced_at, valid_until, minutes_ceiling_adjustment
            FROM operational_lineups
            WHERE game_id = :game_id AND player_id = :player_id
            ORDER BY announced_at DESC
            LIMIT 1
        """
        
        result = connection.execute(
            text(query),
            {"game_id": game_id, "player_id": player_id}
        )
        
        row = result.first()
        return dict(row._mapping) if row else None
    
    @staticmethod
    def insert_projection(
        connection,
        slate_id: str,
        site_player_id: str,
        player_id: str,
        build_time: datetime,
        as_of_time: datetime,
        version: int,
        inputs_hash: str,
        median_fpts: float,
        floor_fpts: float,
        ceiling_fpts: float,
        volatility: float,
        confidence: float,
        projection_distribution: Dict[str, Any],
        signal_contribution: Dict[str, Any],
    ) -> int:
        """Insert projection snapshot."""
        query = """
            INSERT INTO operational_projections
            (slate_id, site_player_id, player_id, build_time, as_of_time,
             version, inputs_hash, median_fpts, floor_fpts, ceiling_fpts,
             volatility, confidence, projection_distribution, signal_contribution)
            VALUES 
            (:slate_id, :site_player_id, :player_id, :build_time, :as_of_time,
             :version, :inputs_hash, :median_fpts, :floor_fpts, :ceiling_fpts,
             :volatility, :confidence, :projection_distribution, :signal_contribution)
        """
        
        result = connection.execute(
            text(query),
            {
                "slate_id": slate_id,
                "site_player_id": site_player_id,
                "player_id": player_id,
                "build_time": build_time,
                "as_of_time": as_of_time,
                "version": version,
                "inputs_hash": inputs_hash,
                "median_fpts": median_fpts,
                "floor_fpts": floor_fpts,
                "ceiling_fpts": ceiling_fpts,
                "volatility": volatility,
                "confidence": confidence,
                "projection_distribution": projection_distribution,
                "signal_contribution": signal_contribution,
            }
        )
        
        return result.rowcount
    
    @staticmethod
    def get_projections_for_slate(
        connection,
        slate_id: str,
        build_time: Optional[datetime] = None,
    ) -> List[Dict[str, Any]]:
        """
        Get projections for a slate.
        
        Args:
            slate_id: Slate ID
            build_time: Optional specific build time (latest if not provided)
        """
        if build_time:
            query = """
                SELECT * FROM operational_projections
                WHERE slate_id = :slate_id AND build_time = :build_time
                ORDER BY build_time DESC
            """
            params = {"slate_id": slate_id, "build_time": build_time}
        else:
            query = """
                SELECT * FROM operational_projections
                WHERE slate_id = :slate_id
                ORDER BY build_time DESC
            """
            params = {"slate_id": slate_id}
        
        result = connection.execute(text(query), params)
        return [dict(row._mapping) for row in result]
    
    @staticmethod
    def record_accuracy(
        connection,
        slate_id: str,
        player_id: str,
        site_player_id: str,
        projection_id: int,
        projected_median: float,
        actual_fpts: float,
    ) -> int:
        """Record projection accuracy after slate completes."""
        error = actual_fpts - projected_median
        
        query = """
            INSERT INTO evaluation_projection_accuracy
            (slate_id, player_id, site_player_id, projection_id,
             projected_median, actual_fpts, error_fpts, error_abs)
            VALUES
            (:slate_id, :player_id, :site_player_id, :projection_id,
             :projected_median, :actual_fpts, :error, :error_abs)
        """
        
        result = connection.execute(
            text(query),
            {
                "slate_id": slate_id,
                "player_id": player_id,
                "site_player_id": site_player_id,
                "projection_id": projection_id,
                "projected_median": projected_median,
                "actual_fpts": actual_fpts,
                "error": error,
                "error_abs": abs(error),
            }
        )
        
        return result.rowcount
    
    @staticmethod
    def get_source_reliability(
        connection,
        source: str,
        signal_type: str,
        league: str,
    ) -> Optional[Dict[str, Any]]:
        """Get source reliability metrics."""
        query = """
            SELECT *
            FROM evaluation_source_reliability
            WHERE source = :source
              AND signal_type = :signal_type
              AND league = :league
            ORDER BY updated_at DESC
            LIMIT 1
        """
        
        result = connection.execute(
            text(query),
            {
                "source": source,
                "signal_type": signal_type,
                "league": league,
            }
        )
        
        row = result.first()
        return dict(row._mapping) if row else None
    
    @staticmethod
    def update_source_reliability(
        connection,
        source: str,
        signal_type: str,
        league: str,
        metric_date: datetime,
        hit_rate: float,
        false_positive_rate: float,
        reliability_score: float,
    ) -> int:
        """Update source reliability metrics."""
        query = """
            INSERT INTO evaluation_source_reliability
            (source, signal_type, league, metric_date, hit_rate, 
             false_positive_rate, reliability_score)
            VALUES
            (:source, :signal_type, :league, :metric_date, :hit_rate,
             :false_positive_rate, :reliability_score)
        """
        
        result = connection.execute(
            text(query),
            {
                "source": source,
                "signal_type": signal_type,
                "league": league,
                "metric_date": metric_date.date() if isinstance(metric_date, datetime) else metric_date,
                "hit_rate": hit_rate,
                "false_positive_rate": false_positive_rate,
                "reliability_score": reliability_score,
            }
        )
        
        return result.rowcount


# Query templates for common operations
QUERY_TEMPLATES = {
    "get_active_slates": """
        SELECT * FROM dim_slates
        WHERE slate_date >= CURRENT_DATE - INTERVAL '7 days'
        ORDER BY slate_date DESC, lock_time ASC
    """,
    
    "get_slate_by_id": """
        SELECT * FROM dim_slates WHERE slate_id = :slate_id
    """,
    
    "get_player_by_id": """
        SELECT * FROM dim_players WHERE player_id = :player_id AND active = true
    """,
    
    "get_game_by_id": """
        SELECT * FROM dim_games WHERE game_id = :game_id
    """,
    
    "get_recent_accuracy": """
        SELECT 
            position,
            COUNT(*) as total_players,
            AVG(error_fpts) as avg_error,
            AVG(error_abs) as avg_error_abs,
            SQRT(AVG(error_fpts * error_fpts)) as rmse
        FROM evaluation_projection_accuracy
        WHERE slate_id = :slate_id
        GROUP BY position
    """,
}


def get_query_template(name: str) -> Optional[str]:
    """Get a query template by name."""
    return QUERY_TEMPLATES.get(name)
