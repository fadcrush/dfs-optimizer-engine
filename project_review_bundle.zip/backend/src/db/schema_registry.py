"""Database schema registry - Table definitions and contracts."""

from dataclasses import dataclass
from typing import Dict, List, Optional, Any
from enum import Enum


class ColumnType(str, Enum):
    """Supported column types."""
    BIGINT = "BIGINT"
    INT = "INT"
    VARCHAR = "VARCHAR"
    TEXT = "TEXT"
    DATE = "DATE"
    TIMESTAMP = "TIMESTAMP"
    TIMESTAMP_TZ = "TIMESTAMP WITH TIME ZONE"
    DECIMAL = "DECIMAL"
    BOOLEAN = "BOOLEAN"
    JSON = "JSON"
    ARRAY = "ARRAY"


@dataclass
class Column:
    """Column definition."""
    name: str
    col_type: ColumnType
    primary_key: bool = False
    unique: bool = False
    nullable: bool = True
    default: Optional[str] = None
    references: Optional[str] = None  # "table_name(column_name)"
    
    def __str__(self) -> str:
        parts = [self.name, self.col_type.value]
        
        if self.primary_key:
            parts.append("PRIMARY KEY")
        if not self.nullable and not self.primary_key:
            parts.append("NOT NULL")
        if self.unique:
            parts.append("UNIQUE")
        if self.default:
            parts.append(f"DEFAULT {self.default}")
        if self.references:
            parts.append(f"REFERENCES {self.references}")
        
        return " ".join(parts)


@dataclass
class Table:
    """Table schema definition."""
    name: str
    columns: List[Column]
    indexes: Optional[List[str]] = None
    
    def get_column(self, name: str) -> Optional[Column]:
        """Get column by name."""
        return next((c for c in self.columns if c.name == name), None)
    
    def validate_row(self, row: Dict[str, Any]) -> List[str]:
        """
        Validate a row against schema.
        
        Returns:
            List of validation errors (empty if valid)
        """
        errors = []
        
        for col in self.columns:
            if col.name not in row:
                if not col.nullable:
                    errors.append(f"Missing required column: {col.name}")
            else:
                value = row[col.name]
                if value is not None and not self._validate_type(value, col.col_type):
                    errors.append(f"Column {col.name}: invalid type {type(value).__name__}")
        
        return errors
    
    @staticmethod
    def _validate_type(value: Any, col_type: ColumnType) -> bool:
        """Check if value matches column type."""
        if value is None:
            return True
        
        if col_type in (ColumnType.BIGINT, ColumnType.INT):
            return isinstance(value, int)
        elif col_type in (ColumnType.VARCHAR, ColumnType.TEXT):
            return isinstance(value, str)
        elif col_type == ColumnType.DECIMAL:
            return isinstance(value, (int, float))
        elif col_type == ColumnType.BOOLEAN:
            return isinstance(value, bool)
        elif col_type in (ColumnType.DATE, ColumnType.TIMESTAMP, ColumnType.TIMESTAMP_TZ):
            return isinstance(value, str)  # Accept ISO format strings
        elif col_type == ColumnType.JSON:
            return isinstance(value, (dict, list, str))
        elif col_type == ColumnType.ARRAY:
            return isinstance(value, list)
        
        return True


# Schema Registry - All tables and their contracts

SCHEMA_REGISTRY: Dict[str, Table] = {
    # =========================================================================
    # RAW TABLES
    # =========================================================================
    "raw_fd_slate_csv": Table(
        name="raw_fd_slate_csv",
        columns=[
            Column("raw_id", ColumnType.BIGINT, primary_key=True),
            Column("ingested_at", ColumnType.TIMESTAMP_TZ, nullable=False, default="CURRENT_TIMESTAMP"),
            Column("slate_date", ColumnType.DATE),
            Column("slate_id", ColumnType.VARCHAR),
            Column("contest_id", ColumnType.VARCHAR),
            Column("site_name", ColumnType.VARCHAR, default="'FanDuel'"),
            Column("file_hash", ColumnType.VARCHAR),
            Column("payload", ColumnType.JSON),
        ]
    ),
    
    "raw_dk_slate_csv": Table(
        name="raw_dk_slate_csv",
        columns=[
            Column("raw_id", ColumnType.BIGINT, primary_key=True),
            Column("ingested_at", ColumnType.TIMESTAMP_TZ, nullable=False, default="CURRENT_TIMESTAMP"),
            Column("slate_date", ColumnType.DATE),
            Column("slate_id", ColumnType.VARCHAR),
            Column("contest_id", ColumnType.VARCHAR),
            Column("site_name", ColumnType.VARCHAR, default="'DraftKings'"),
            Column("file_hash", ColumnType.VARCHAR),
            Column("payload", ColumnType.JSON),
        ]
    ),
    
    "raw_nba_api_responses": Table(
        name="raw_nba_api_responses",
        columns=[
            Column("raw_id", ColumnType.BIGINT, primary_key=True),
            Column("ingested_at", ColumnType.TIMESTAMP_TZ, nullable=False, default="CURRENT_TIMESTAMP"),
            Column("endpoint", ColumnType.VARCHAR),
            Column("game_date", ColumnType.DATE),
            Column("query_params", ColumnType.JSON),
            Column("response_payload", ColumnType.JSON),
            Column("response_hash", ColumnType.VARCHAR),
        ]
    ),
    
    "raw_actual_results": Table(
        name="raw_actual_results",
        columns=[
            Column("raw_id", ColumnType.BIGINT, primary_key=True),
            Column("ingested_at", ColumnType.TIMESTAMP_TZ, nullable=False, default="CURRENT_TIMESTAMP"),
            Column("league", ColumnType.VARCHAR),
            Column("season", ColumnType.INT),
            Column("game_date", ColumnType.DATE),
            Column("game_id", ColumnType.VARCHAR),
            Column("player_id", ColumnType.VARCHAR),
            Column("site_player_id", ColumnType.VARCHAR),
            Column("position", ColumnType.VARCHAR),
            Column("team", ColumnType.VARCHAR),
            Column("opponent", ColumnType.VARCHAR),
            Column("minutes_played", ColumnType.DECIMAL),
            Column("actual_fpts", ColumnType.DECIMAL),
            Column("is_starter", ColumnType.BOOLEAN),
            Column("payload", ColumnType.JSON),
        ]
    ),
    
    # =========================================================================
    # DERIVED TABLES
    # =========================================================================
    "dim_players": Table(
        name="dim_players",
        columns=[
            Column("player_id", ColumnType.VARCHAR, primary_key=True),
            Column("league", ColumnType.VARCHAR),
            Column("canonical_name", ColumnType.VARCHAR),
            Column("position", ColumnType.VARCHAR),
            Column("birth_date", ColumnType.DATE),
            Column("height", ColumnType.DECIMAL),
            Column("weight", ColumnType.DECIMAL),
            Column("created_at", ColumnType.TIMESTAMP, default="CURRENT_TIMESTAMP"),
            Column("updated_at", ColumnType.TIMESTAMP, default="CURRENT_TIMESTAMP"),
            Column("active", ColumnType.BOOLEAN, default="TRUE"),
        ]
    ),
    
    "dim_teams": Table(
        name="dim_teams",
        columns=[
            Column("team_id", ColumnType.VARCHAR, primary_key=True),
            Column("league", ColumnType.VARCHAR),
            Column("canonical_code", ColumnType.VARCHAR),
            Column("full_name", ColumnType.VARCHAR),
            Column("city", ColumnType.VARCHAR),
            Column("created_at", ColumnType.TIMESTAMP, default="CURRENT_TIMESTAMP"),
        ]
    ),
    
    "dim_games": Table(
        name="dim_games",
        columns=[
            Column("game_id", ColumnType.VARCHAR, primary_key=True),
            Column("league", ColumnType.VARCHAR),
            Column("season", ColumnType.INT),
            Column("game_date", ColumnType.DATE),
            Column("game_datetime_utc", ColumnType.TIMESTAMP_TZ),
            Column("home_team_id", ColumnType.VARCHAR, references="dim_teams(team_id)"),
            Column("away_team_id", ColumnType.VARCHAR, references="dim_teams(team_id)"),
            Column("venue", ColumnType.VARCHAR),
            Column("created_at", ColumnType.TIMESTAMP, default="CURRENT_TIMESTAMP"),
        ]
    ),
    
    "dim_slates": Table(
        name="dim_slates",
        columns=[
            Column("slate_id", ColumnType.VARCHAR, primary_key=True),
            Column("league", ColumnType.VARCHAR),
            Column("site", ColumnType.VARCHAR),
            Column("slate_date", ColumnType.DATE),
            Column("slate_type", ColumnType.VARCHAR),
            Column("lock_time", ColumnType.TIMESTAMP_TZ),
            Column("salary_cap", ColumnType.INT),
            Column("roster_slots", ColumnType.VARCHAR),
            Column("created_at", ColumnType.TIMESTAMP, default="CURRENT_TIMESTAMP"),
        ]
    ),
    
    "fact_site_players": Table(
        name="fact_site_players",
        columns=[
            Column("site_player_id", ColumnType.VARCHAR, primary_key=True),
            Column("slate_id", ColumnType.VARCHAR, references="dim_slates(slate_id)"),
            Column("player_id", ColumnType.VARCHAR, references="dim_players(player_id)"),
            Column("site", ColumnType.VARCHAR),
            Column("salary", ColumnType.INT),
            Column("position", ColumnType.VARCHAR),
            Column("team", ColumnType.VARCHAR),
            Column("game_id", ColumnType.VARCHAR, references="dim_games(game_id)"),
            Column("injury_status", ColumnType.VARCHAR),
            Column("game_start_time", ColumnType.TIMESTAMP_TZ),
            Column("created_at", ColumnType.TIMESTAMP, default="CURRENT_TIMESTAMP"),
        ]
    ),
    
    "fact_actual_player_results": Table(
        name="fact_actual_player_results",
        columns=[
            Column("result_id", ColumnType.BIGINT, primary_key=True),
            Column("game_id", ColumnType.VARCHAR, references="dim_games(game_id)"),
            Column("player_id", ColumnType.VARCHAR, references="dim_players(player_id)"),
            Column("league", ColumnType.VARCHAR),
            Column("position", ColumnType.VARCHAR),
            Column("minutes_played", ColumnType.DECIMAL),
            Column("is_starter", ColumnType.BOOLEAN),
            Column("fpts", ColumnType.DECIMAL),
            Column("actual_stats", ColumnType.JSON),
            Column("created_at", ColumnType.TIMESTAMP, default="CURRENT_TIMESTAMP"),
        ]
    ),
    
    # =========================================================================
    # OPERATIONAL TABLES
    # =========================================================================
    "operational_signals": Table(
        name="operational_signals",
        columns=[
            Column("signal_id", ColumnType.BIGINT, primary_key=True),
            Column("signal_type", ColumnType.VARCHAR),
            Column("entity_type", ColumnType.VARCHAR),
            Column("entity_id", ColumnType.VARCHAR),
            Column("league", ColumnType.VARCHAR),
            Column("slate_id", ColumnType.VARCHAR, references="dim_slates(slate_id)"),
            Column("timestamp_utc", ColumnType.TIMESTAMP_TZ),
            Column("source", ColumnType.VARCHAR),
            Column("source_confidence", ColumnType.DECIMAL),
            Column("decay_profile", ColumnType.VARCHAR),
            Column("validity_start", ColumnType.TIMESTAMP_TZ),
            Column("validity_end", ColumnType.TIMESTAMP_TZ),
            Column("applies_to", ColumnType.JSON),
            Column("cannot_apply_to", ColumnType.JSON),
            Column("signal_payload", ColumnType.JSON),
            Column("created_at", ColumnType.TIMESTAMP, default="CURRENT_TIMESTAMP"),
            Column("ingested_at", ColumnType.TIMESTAMP_TZ, default="CURRENT_TIMESTAMP"),
        ]
    ),
    
    "operational_lineups": Table(
        name="operational_lineups",
        columns=[
            Column("lineup_id", ColumnType.BIGINT, primary_key=True),
            Column("game_id", ColumnType.VARCHAR, references="dim_games(game_id)"),
            Column("player_id", ColumnType.VARCHAR, references="dim_players(player_id)"),
            Column("league", ColumnType.VARCHAR),
            Column("status", ColumnType.VARCHAR),
            Column("source_type", ColumnType.VARCHAR),
            Column("source_confidence", ColumnType.DECIMAL),
            Column("announced_at", ColumnType.TIMESTAMP_TZ),
            Column("valid_until", ColumnType.TIMESTAMP_TZ),
            Column("minutes_ceiling_adjustment", ColumnType.DECIMAL),
            Column("created_at", ColumnType.TIMESTAMP, default="CURRENT_TIMESTAMP"),
        ]
    ),
    
    "operational_projections": Table(
        name="operational_projections",
        columns=[
            Column("projection_id", ColumnType.BIGINT, primary_key=True),
            Column("slate_id", ColumnType.VARCHAR, references="dim_slates(slate_id)"),
            Column("site_player_id", ColumnType.VARCHAR),
            Column("player_id", ColumnType.VARCHAR, references="dim_players(player_id)"),
            Column("build_time", ColumnType.TIMESTAMP_TZ),
            Column("as_of_time", ColumnType.TIMESTAMP_TZ),
            Column("version", ColumnType.INT),
            Column("inputs_hash", ColumnType.VARCHAR),
            Column("median_fpts", ColumnType.DECIMAL),
            Column("floor_fpts", ColumnType.DECIMAL),
            Column("ceiling_fpts", ColumnType.DECIMAL),
            Column("volatility", ColumnType.DECIMAL),
            Column("confidence", ColumnType.DECIMAL),
            Column("projection_distribution", ColumnType.JSON),
            Column("signal_contribution", ColumnType.JSON),
            Column("created_at", ColumnType.TIMESTAMP, default="CURRENT_TIMESTAMP"),
        ]
    ),
    
    # =========================================================================
    # EVALUATION TABLES
    # =========================================================================
    "evaluation_projection_accuracy": Table(
        name="evaluation_projection_accuracy",
        columns=[
            Column("accuracy_id", ColumnType.BIGINT, primary_key=True),
            Column("slate_id", ColumnType.VARCHAR, references="dim_slates(slate_id)"),
            Column("player_id", ColumnType.VARCHAR, references="dim_players(player_id)"),
            Column("site_player_id", ColumnType.VARCHAR),
            Column("league", ColumnType.VARCHAR),
            Column("position", ColumnType.VARCHAR),
            Column("game_id", ColumnType.VARCHAR, references="dim_games(game_id)"),
            Column("team", ColumnType.VARCHAR),
            Column("projection_id", ColumnType.BIGINT, references="operational_projections(projection_id)"),
            Column("projected_median", ColumnType.DECIMAL),
            Column("projected_floor", ColumnType.DECIMAL),
            Column("projected_ceiling", ColumnType.DECIMAL),
            Column("projected_confidence", ColumnType.DECIMAL),
            Column("actual_fpts", ColumnType.DECIMAL),
            Column("is_starter", ColumnType.BOOLEAN),
            Column("error_fpts", ColumnType.DECIMAL),
            Column("error_abs", ColumnType.DECIMAL),
            Column("percentile_rank", ColumnType.INT),
            Column("contest_finish", ColumnType.JSON),
            Column("created_at", ColumnType.TIMESTAMP, default="CURRENT_TIMESTAMP"),
        ]
    ),
    
    "evaluation_source_reliability": Table(
        name="evaluation_source_reliability",
        columns=[
            Column("reliability_id", ColumnType.BIGINT, primary_key=True),
            Column("source", ColumnType.VARCHAR),
            Column("signal_type", ColumnType.VARCHAR),
            Column("league", ColumnType.VARCHAR),
            Column("metric_date", ColumnType.DATE),
            Column("total_signals", ColumnType.INT),
            Column("hit_count", ColumnType.INT),
            Column("false_positive_count", ColumnType.INT),
            Column("avg_lead_time_minutes", ColumnType.INT),
            Column("confidence_avg", ColumnType.DECIMAL),
            Column("hit_rate", ColumnType.DECIMAL),
            Column("false_positive_rate", ColumnType.DECIMAL),
            Column("reliability_score", ColumnType.DECIMAL),
            Column("updated_at", ColumnType.TIMESTAMP, default="CURRENT_TIMESTAMP"),
        ]
    ),
    
    "evaluation_bias": Table(
        name="evaluation_bias",
        columns=[
            Column("bias_id", ColumnType.BIGINT, primary_key=True),
            Column("slate_id", ColumnType.VARCHAR, references="dim_slates(slate_id)"),
            Column("league", ColumnType.VARCHAR),
            Column("bias_dimension", ColumnType.VARCHAR),
            Column("dimension_value", ColumnType.VARCHAR),
            Column("total_players", ColumnType.INT),
            Column("avg_error", ColumnType.DECIMAL),
            Column("avg_error_abs", ColumnType.DECIMAL),
            Column("rmse", ColumnType.DECIMAL),
            Column("created_at", ColumnType.TIMESTAMP, default="CURRENT_TIMESTAMP"),
        ]
    ),
}


def get_table_schema(table_name: str) -> Optional[Table]:
    """Get table schema by name."""
    return SCHEMA_REGISTRY.get(table_name)


def get_all_table_names() -> List[str]:
    """Get all registered table names."""
    return list(SCHEMA_REGISTRY.keys())


def validate_table_exists(table_name: str) -> bool:
    """Check if table is registered in schema."""
    return table_name in SCHEMA_REGISTRY


def validate_row(table_name: str, row: Dict[str, Any]) -> List[str]:
    """
    Validate a row against a table schema.
    
    Args:
        table_name: Name of the table
        row: Row data to validate
        
    Returns:
        List of validation errors (empty if valid)
    """
    table = get_table_schema(table_name)
    if not table:
        return [f"Table not found: {table_name}"]
    
    return table.validate_row(row)
