"""
DuckDB / SQLAlchemy engine helpers.

Provides:
  - get_canonical_db_path()       → deterministic local DuckDB file path
  - create_engine_with_retry()    → SQLAlchemy engine with retry / fallback
"""

from __future__ import annotations

import logging
import os
import time
from pathlib import Path
from typing import Any

from sqlalchemy import create_engine, text

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# DuckDB path resolution
# ---------------------------------------------------------------------------

def get_canonical_db_path() -> Path:
    """
    Return the canonical path for the local DuckDB database file.

    Resolution order:
    1. ``DUCKDB_PATH`` environment variable (explicit override)
    2. ``<repo-root>/data/dfs_edge.duckdb``   (conventional location)

    The parent directory is created if it does not yet exist.
    """
    if env_path := os.getenv("DUCKDB_PATH"):
        p = Path(env_path)
    else:
        # Walk up from this file's location to find the repo root.
        # This file lives at  backend/src/db/engine.py
        # repo root is         /
        repo_root = Path(__file__).resolve().parents[3]
        p = repo_root / "data" / "dfs_edge.duckdb"

    p.parent.mkdir(parents=True, exist_ok=True)
    return p


# ---------------------------------------------------------------------------
# SQLAlchemy engine factory
# ---------------------------------------------------------------------------

def _make_engine(database_url: str) -> Any:
    """Create a raw SQLAlchemy engine from a URL string."""
    if "duckdb" in database_url.lower():
        return create_engine(database_url, echo=False)

    from sqlalchemy.pool import QueuePool

    return create_engine(
        database_url,
        poolclass=QueuePool,
        pool_size=int(os.getenv("DB_POOL_SIZE", "10")),
        max_overflow=int(os.getenv("DB_MAX_OVERFLOW", "20")),
        pool_timeout=int(os.getenv("DB_POOL_TIMEOUT", "30")),
        pool_recycle=int(os.getenv("DB_POOL_RECYCLE", "3600")),
        echo=False,
        pool_pre_ping=True,
    )


def create_engine_with_retry(
    database_url: str | None = None,
    max_retries: int = 3,
    retry_delay: float = 0.5,
) -> Any:
    """
    Create a SQLAlchemy engine, retrying on transient failures.

    Falls back to DuckDB local file when *database_url* is ``None`` and no
    ``DATABASE_URL`` environment variable is set.
    """
    if database_url is None:
        database_url = os.getenv("DATABASE_URL") or f"duckdb:///{get_canonical_db_path()}"

    last_exc: Exception | None = None
    for attempt in range(max_retries + 1):
        try:
            engine = _make_engine(database_url)
            with engine.connect() as conn:
                conn.execute(text("SELECT 1"))
            logger.info("Database connection established (attempt %d)", attempt + 1)
            return engine
        except Exception as exc:  # noqa: BLE001
            last_exc = exc
            if attempt < max_retries:
                wait = retry_delay * (2 ** attempt)
                logger.warning(
                    "DB connection attempt %d/%d failed: %s — retrying in %.1fs",
                    attempt + 1,
                    max_retries,
                    exc,
                    wait,
                )
                time.sleep(wait)

    raise RuntimeError(
        f"Could not connect to database after {max_retries + 1} attempts"
    ) from last_exc


# ---------------------------------------------------------------------------
# DuckDB concurrency guardrails
# ---------------------------------------------------------------------------

def is_duckdb_url(url: str) -> bool:
    """
    Return True if *url* points to a **file-based** DuckDB database.

    In-memory DuckDB (``duckdb:///:memory:``) is per-process and carries no
    shared file-lock risk, so it is intentionally excluded.
    """
    lower = url.lower()
    if "duckdb" not in lower:
        return False
    # :memory: databases are safe — each process gets its own isolated store
    if ":memory:" in lower:
        return False
    return True


def assert_single_worker_for_duckdb(database_url: str | None = None) -> None:
    """
    Raise ``RuntimeError`` at application startup if a **file-based DuckDB**
    URL is detected together with more than one Uvicorn / Gunicorn worker.

    DuckDB uses an **exclusive write-lock** on the database file.  Running
    multiple OS-level worker processes against the same file causes the
    second (and subsequent) workers to crash or, worse, silently corrupt
    data as they race for the lock.

    This function is a no-op when:
    * The resolved URL is not DuckDB (e.g. PostgreSQL).
    * The URL is ``duckdb:///:memory:`` (per-process, no shared file).
    * Worker count is 1 (safe default).

    Worker count is read from (first match wins):
    * ``WEB_CONCURRENCY``   — set automatically by Heroku / Railway / Render
    * ``UVICORN_WORKERS``   — explicit override for local deployments

    Remediation choices printed in the error message:
    1. Keep ``WEB_CONCURRENCY=1`` (default, safe for DuckDB).
    2. Switch ``DATABASE_URL`` to PostgreSQL for multi-worker production.
    3. Use ``DATABASE_URL=duckdb:///:memory:`` for ephemeral test workloads.
    """
    if database_url is None:
        database_url = os.getenv("DATABASE_URL") or f"duckdb:///{get_canonical_db_path()}"

    if not is_duckdb_url(database_url):
        return  # PostgreSQL / other backends handle multi-worker natively

    workers_raw = os.getenv("WEB_CONCURRENCY") or os.getenv("UVICORN_WORKERS") or "1"
    try:
        workers = int(workers_raw)
    except ValueError:
        workers = 1  # unparseable → assume safe

    if workers <= 1:
        return  # single worker: safe

    _SEP = "=" * 70
    raise RuntimeError(
        f"\n{_SEP}\n"
        f"STARTUP ABORTED — DuckDB + multiple workers is UNSAFE\n"
        f"{_SEP}\n"
        f"  DATABASE_URL             : {database_url}\n"
        f"  WEB_CONCURRENCY detected : {workers}\n"
        f"\n"
        f"DuckDB acquires an exclusive file-lock on startup.  Running\n"
        f"{workers} worker processes against the same DuckDB file will cause\n"
        f"workers 2..N to crash on startup, or race for the lock and\n"
        f"silently corrupt the database.\n"
        f"\n"
        f"Remediation — choose one:\n"
        f"  1. Reduce to a single worker (safe for DuckDB):\n"
        f"       unset WEB_CONCURRENCY          # or\n"
        f"       WEB_CONCURRENCY=1\n"
        f"  2. Switch to PostgreSQL for multi-worker production:\n"
        f"       DATABASE_URL=postgresql://user:pass@host/dbname\n"
        f"  3. Use an in-memory DuckDB for ephemeral / test deployments:\n"
        f"       DATABASE_URL=duckdb:///:memory:\n"
        f"{_SEP}\n"
    )
