"""Database migrations - Initialize schema from architecture plan."""

import logging
from typing import List, Tuple
from sqlalchemy import text

logger = logging.getLogger(__name__)


# All migrations in order
MIGRATIONS: List[Tuple[str, str]] = [
    (
        "001_init_schema",
        """
-- RAW INGESTION TABLES (append-only, JSON payloads preserved)

CREATE TABLE IF NOT EXISTS raw_fd_slate_csv (
    raw_id BIGINT PRIMARY KEY DEFAULT CAST(random() * 9223372036854775807 AS BIGINT),
    ingested_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    slate_date DATE,
    slate_id VARCHAR,
    contest_id VARCHAR,
    site_name VARCHAR DEFAULT 'FanDuel',
    file_hash VARCHAR,
    payload JSON,
    UNIQUE(slate_id, contest_id, file_hash)
);

CREATE TABLE IF NOT EXISTS raw_dk_slate_csv (
    raw_id BIGINT PRIMARY KEY DEFAULT CAST(random() * 9223372036854775807 AS BIGINT),
    ingested_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    slate_date DATE,
    slate_id VARCHAR,
    contest_id VARCHAR,
    site_name VARCHAR DEFAULT 'DraftKings',
    file_hash VARCHAR,
    payload JSON,
    UNIQUE(slate_id, contest_id, file_hash)
);

CREATE TABLE IF NOT EXISTS raw_nba_api_responses (
    raw_id BIGINT PRIMARY KEY DEFAULT CAST(random() * 9223372036854775807 AS BIGINT),
    ingested_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    endpoint VARCHAR,
    game_date DATE,
    query_params JSON,
    response_payload JSON,
    response_hash VARCHAR,
    UNIQUE(endpoint, response_hash)
);

CREATE TABLE IF NOT EXISTS raw_nfl_pbp (
    raw_id BIGINT PRIMARY KEY DEFAULT CAST(random() * 9223372036854775807 AS BIGINT),
    ingested_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    season INT,
    week INT,
    game_id VARCHAR,
    payload JSON,
    source_hash VARCHAR,
    UNIQUE(season, week, game_id, source_hash)
);

CREATE TABLE IF NOT EXISTS raw_contest_results (
    raw_id BIGINT PRIMARY KEY DEFAULT CAST(random() * 9223372036854775807 AS BIGINT),
    ingested_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    slate_id VARCHAR,
    contest_id VARCHAR,
    contest_name VARCHAR,
    entry_id VARCHAR,
    entry_lineup JSON,
    entry_score DECIMAL(10, 2),
    entry_rank INT,
    entry_winnings DECIMAL(12, 2),
    source_file VARCHAR,
    payload JSON,
    UNIQUE(contest_id, entry_id)
);

CREATE TABLE IF NOT EXISTS raw_actual_results (
    raw_id BIGINT PRIMARY KEY DEFAULT CAST(random() * 9223372036854775807 AS BIGINT),
    ingested_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    league VARCHAR,
    season INT,
    game_date DATE,
    game_id VARCHAR,
    player_id VARCHAR,
    site_player_id VARCHAR,
    position VARCHAR,
    team VARCHAR,
    opponent VARCHAR,
    minutes_played DECIMAL(5, 2),
    actual_fpts DECIMAL(8, 2),
    is_starter BOOLEAN,
    payload JSON,
    UNIQUE(game_id, player_id, league)
);
"""
    ),
    (
        "002_derived_tables",
        """
-- CANONICAL ENTITIES

CREATE TABLE IF NOT EXISTS dim_players (
    player_id VARCHAR PRIMARY KEY,
    league VARCHAR,
    canonical_name VARCHAR,
    position VARCHAR,
    birth_date DATE,
    height DECIMAL(5, 2),
    weight DECIMAL(5, 1),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    active BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS dim_teams (
    team_id VARCHAR PRIMARY KEY,
    league VARCHAR,
    canonical_code VARCHAR,
    full_name VARCHAR,
    city VARCHAR,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS dim_games (
    game_id VARCHAR PRIMARY KEY,
    league VARCHAR,
    season INT,
    game_date DATE,
    game_datetime_utc TIMESTAMP WITH TIME ZONE,
    home_team_id VARCHAR REFERENCES dim_teams(team_id),
    away_team_id VARCHAR REFERENCES dim_teams(team_id),
    venue VARCHAR,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS dim_slates (
    slate_id VARCHAR PRIMARY KEY,
    league VARCHAR,
    site VARCHAR,
    slate_date DATE,
    slate_type VARCHAR,
    lock_time TIMESTAMP WITH TIME ZONE,
    salary_cap INT,
    roster_slots VARCHAR,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- SITE PLAYER MAPPINGS
CREATE TABLE IF NOT EXISTS fact_site_players (
    site_player_id VARCHAR PRIMARY KEY,
    slate_id VARCHAR REFERENCES dim_slates(slate_id),
    player_id VARCHAR REFERENCES dim_players(player_id),
    site VARCHAR,
    salary INT,
    position VARCHAR,
    team VARCHAR,
    game_id VARCHAR REFERENCES dim_games(game_id),
    injury_status VARCHAR,
    game_start_time TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(slate_id, site_player_id)
);

-- ACTUAL GAME RESULTS (Immutable truth)
CREATE TABLE IF NOT EXISTS fact_actual_player_results (
    result_id BIGINT PRIMARY KEY DEFAULT CAST(random() * 9223372036854775807 AS BIGINT),
    game_id VARCHAR REFERENCES dim_games(game_id),
    player_id VARCHAR REFERENCES dim_players(player_id),
    league VARCHAR,
    position VARCHAR,
    minutes_played DECIMAL(5, 2),
    is_starter BOOLEAN,
    fpts DECIMAL(8, 2),
    actual_stats JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(game_id, player_id)
);
"""
    ),
    (
        "003_operational_tables",
        """
-- SIGNALS TABLE (core intelligence layer)
CREATE TABLE IF NOT EXISTS operational_signals (
    signal_id BIGINT PRIMARY KEY DEFAULT CAST(random() * 9223372036854775807 AS BIGINT),
    signal_type VARCHAR,
    entity_type VARCHAR,
    entity_id VARCHAR,
    league VARCHAR,
    slate_id VARCHAR REFERENCES dim_slates(slate_id),
    timestamp_utc TIMESTAMP WITH TIME ZONE,
    source VARCHAR,
    source_confidence DECIMAL(3, 2),
    decay_profile VARCHAR,
    validity_start TIMESTAMP WITH TIME ZONE,
    validity_end TIMESTAMP WITH TIME ZONE,
    applies_to JSON,
    cannot_apply_to JSON,
    signal_payload JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ingested_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_signals_entity_time ON operational_signals(
    league, entity_type, entity_id, timestamp_utc DESC
);

-- STARTING LINEUP OPERATIONAL SIGNAL
CREATE TABLE IF NOT EXISTS operational_lineups (
    lineup_id BIGINT PRIMARY KEY DEFAULT CAST(random() * 9223372036854775807 AS BIGINT),
    game_id VARCHAR REFERENCES dim_games(game_id),
    player_id VARCHAR REFERENCES dim_players(player_id),
    league VARCHAR,
    status VARCHAR,
    source_type VARCHAR,
    source_confidence DECIMAL(3, 2),
    announced_at TIMESTAMP WITH TIME ZONE,
    valid_until TIMESTAMP WITH TIME ZONE,
    minutes_ceiling_adjustment DECIMAL(3, 1),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_lineups_game_time ON operational_lineups(
    game_id, announced_at DESC
);

-- PROJECTION SNAPSHOTS (predictions with input hash)
CREATE TABLE IF NOT EXISTS operational_projections (
    projection_id BIGINT PRIMARY KEY DEFAULT CAST(random() * 9223372036854775807 AS BIGINT),
    slate_id VARCHAR REFERENCES dim_slates(slate_id),
    site_player_id VARCHAR,
    player_id VARCHAR REFERENCES dim_players(player_id),
    build_time TIMESTAMP WITH TIME ZONE,
    as_of_time TIMESTAMP WITH TIME ZONE,
    version INT,
    inputs_hash VARCHAR,
    median_fpts DECIMAL(8, 2),
    floor_fpts DECIMAL(8, 2),
    ceiling_fpts DECIMAL(8, 2),
    volatility DECIMAL(5, 3),
    confidence DECIMAL(3, 2),
    projection_distribution JSON,
    signal_contribution JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_projections_slate_build ON operational_projections(
    slate_id, build_time DESC
);
"""
    ),
    (
        "004_evaluation_tables",
        """
-- PROJECTION vs ACTUAL ACCURACY
CREATE TABLE IF NOT EXISTS evaluation_projection_accuracy (
    accuracy_id BIGINT PRIMARY KEY DEFAULT CAST(random() * 9223372036854775807 AS BIGINT),
    slate_id VARCHAR REFERENCES dim_slates(slate_id),
    player_id VARCHAR REFERENCES dim_players(player_id),
    site_player_id VARCHAR,
    league VARCHAR,
    position VARCHAR,
    game_id VARCHAR REFERENCES dim_games(game_id),
    team VARCHAR,
    projection_id BIGINT REFERENCES operational_projections(projection_id),
    projected_median DECIMAL(8, 2),
    projected_floor DECIMAL(8, 2),
    projected_ceiling DECIMAL(8, 2),
    projected_confidence DECIMAL(3, 2),
    actual_fpts DECIMAL(8, 2),
    is_starter BOOLEAN,
    error_fpts DECIMAL(8, 2),
    error_abs DECIMAL(8, 2),
    percentile_rank INT,
    contest_finish JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_accuracy_slate_position ON evaluation_projection_accuracy(
    slate_id, position, created_at DESC
);

-- SOURCE RELIABILITY TRACKING
CREATE TABLE IF NOT EXISTS evaluation_source_reliability (
    reliability_id BIGINT PRIMARY KEY DEFAULT CAST(random() * 9223372036854775807 AS BIGINT),
    source VARCHAR,
    signal_type VARCHAR,
    league VARCHAR,
    metric_date DATE,
    total_signals INT,
    hit_count INT,
    false_positive_count INT,
    avg_lead_time_minutes INT,
    confidence_avg DECIMAL(3, 2),
    hit_rate DECIMAL(3, 2),
    false_positive_rate DECIMAL(3, 2),
    reliability_score DECIMAL(3, 2),
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- BIAS TRACKING (by team, position, context)
CREATE TABLE IF NOT EXISTS evaluation_bias (
    bias_id BIGINT PRIMARY KEY DEFAULT CAST(random() * 9223372036854775807 AS BIGINT),
    slate_id VARCHAR REFERENCES dim_slates(slate_id),
    league VARCHAR,
    bias_dimension VARCHAR,
    dimension_value VARCHAR,
    total_players INT,
    avg_error DECIMAL(8, 3),
    avg_error_abs DECIMAL(8, 3),
    rmse DECIMAL(8, 3),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
"""
    ),
]


def get_migration_sql(migration_name: str) -> str:
    """Get SQL for a specific migration."""
    for name, sql in MIGRATIONS:
        if name == migration_name:
            return sql
    raise ValueError(f"Migration not found: {migration_name}")


def run_migrations(connection) -> None:
    """
    Run all pending migrations.
    
    Args:
        connection: SQLAlchemy connection object
    """
    for migration_name, migration_sql in MIGRATIONS:
        try:
            logger.info(f"Running migration: {migration_name}")
            connection.execute(text(migration_sql))
            connection.commit()
            logger.info(f"✓ Migration completed: {migration_name}")
        except Exception as e:
            logger.error(f"✗ Migration failed: {migration_name}")
            logger.error(f"Error: {str(e)}")
            raise
