"""Health check endpoint."""

from fastapi import APIRouter
from datetime import datetime
from core import get_utc_now, get_logger


logger = get_logger(__name__)

router = APIRouter(prefix="/health", tags=["health"])


@router.get("")
async def health_check():
    """
    Health check endpoint.
    
    Returns:
        Health status with timestamp
    """
    return {
        "status": "healthy",
        "timestamp": get_utc_now().isoformat(),
        "version": "1.0.0",
        "service": "DFS Optimizer API",
    }


@router.get("/ready")
async def readiness_check():
    """
    Readiness check (dependencies available).
    
    Returns:
        Readiness status
    """
    try:
        # Could add database connectivity check here
        return {
            "ready": True,
            "timestamp": get_utc_now().isoformat(),
        }
    except Exception as e:
        logger.error(f"Readiness check failed: {e}")
        return {
            "ready": False,
            "error": str(e),
            "timestamp": get_utc_now().isoformat(),
        }
