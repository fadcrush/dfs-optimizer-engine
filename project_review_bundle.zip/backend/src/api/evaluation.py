"""Evaluation and accuracy endpoints."""

from fastapi import APIRouter, Depends, HTTPException, Query
from typing import Optional
from core import get_logger
from evaluation import AccuracyMetricsComputer, EvaluationStore, BiasAnalyzer
from api.dependencies import get_db_connection


logger = get_logger(__name__)

router = APIRouter(prefix="/evaluation", tags=["evaluation"])


@router.get("/accuracy")
async def get_accuracy_metrics(
    slate_id: Optional[str] = Query(None, description="Filter by slate"),
    league: Optional[str] = Query(None, description="Filter by league"),
    lookback_days: int = Query(30, description="Days to look back"),
    connection=Depends(get_db_connection),
):
    """
    Get aggregated accuracy metrics.
    
    Args:
        slate_id: Filter by specific slate
        league: Filter by NBA/NFL
        lookback_days: Historical lookback window
        
    Returns:
        RMSE, MAE, hit_rate, bias metrics
    """
    try:
        store = EvaluationStore(connection)
        
        # Get accuracies
        if slate_id:
            accuracies = store.get_accuracies_for_slate(slate_id)
        else:
            # Get recent accuracies (would need method in store)
            query = """
            SELECT
                projection_id, player_id, game_id, slate_id, league,
                projected_fppg, projected_floor, projected_ceiling,
                projected_confidence, actual_fppg, contest_type, as_of_time
            FROM evaluation_projection_accuracy
            WHERE as_of_time >= CURRENT_TIMESTAMP - INTERVAL '1 day' * :days
            ORDER BY as_of_time DESC
            LIMIT 5000
            """
            
            results = connection.execute(
                query,
                {"days": lookback_days},
            ).fetchall()
            
            # Convert to accuracy objects (simplified)
            from evaluation import ProjectionAccuracy
            accuracies = [
                ProjectionAccuracy(
                    projection_id=row[0],
                    player_id=row[1],
                    game_id=row[2],
                    slate_id=row[3],
                    league=row[4],
                    projected_fppg=row[5],
                    projected_floor=row[6],
                    projected_ceiling=row[7],
                    projected_confidence=row[8],
                    actual_fppg=row[9],
                    contest_type=row[10],
                    as_of_time=row[11],
                )
                for row in results
            ]
        
        if not accuracies:
            return {
                "message": "No accuracy data available",
                "slate_id": slate_id,
                "league": league,
            }
        
        # Compute metrics
        rmse = AccuracyMetricsComputer.compute_rmse(accuracies)
        mae = AccuracyMetricsComputer.compute_mae(accuracies)
        hit_rate = AccuracyMetricsComputer.compute_hit_rate(accuracies)
        bias = AccuracyMetricsComputer.compute_bias(accuracies)
        avg_percentile = AccuracyMetricsComputer.compute_average_percentile(accuracies)
        correlation = AccuracyMetricsComputer.compute_correlation(accuracies)
        
        logger.info(f"Accuracy metrics: RMSE={rmse:.2f}, hit_rate={hit_rate:.1%}")
        
        return {
            "metrics": {
                "rmse": round(rmse, 2),
                "mae": round(mae, 2),
                "hit_rate": round(hit_rate, 3),
                "bias": round(bias, 2),
                "average_percentile": round(avg_percentile, 1),
                "correlation": round(correlation, 3),
            },
            "sample_size": len(accuracies),
            "slate_id": slate_id,
            "league": league,
            "lookback_days": lookback_days,
        }
    
    except Exception as e:
        logger.error(f"Error computing accuracy: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/bias")
async def get_bias_metrics(
    league: Optional[str] = Query("NBA", description="NBA or NFL"),
    connection=Depends(get_db_connection),
):
    """
    Get bias metrics by dimension.
    
    Args:
        league: Filter by league
        
    Returns:
        Bias analysis (over/under-projection by team, position, etc.)
    """
    try:
        # Load recent accuracies
        query = """
        SELECT
            projection_id, player_id, game_id, slate_id, league,
            projected_fppg, projected_floor, projected_ceiling,
            projected_confidence, actual_fppg, contest_type, as_of_time
        FROM evaluation_projection_accuracy
        WHERE league = :league
          AND as_of_time >= CURRENT_TIMESTAMP - INTERVAL '7 days'
        ORDER BY as_of_time DESC
        LIMIT 10000
        """
        
        results = connection.execute(
            query,
            {"league": league},
        ).fetchall()
        
        from evaluation import ProjectionAccuracy
        accuracies = [
            ProjectionAccuracy(
                projection_id=row[0],
                player_id=row[1],
                game_id=row[2],
                slate_id=row[3],
                league=row[4],
                projected_fppg=row[5],
                projected_floor=row[6],
                projected_ceiling=row[7],
                projected_confidence=row[8],
                actual_fppg=row[9],
                contest_type=row[10],
                as_of_time=row[11],
            )
            for row in results
        ]
        
        # Analyze bias
        analyzer = BiasAnalyzer()
        analyzer.process_accuracies(accuracies)
        bias_report = analyzer.generate_bias_report()
        
        logger.info(f"Bias report for {league}: {len(accuracies)} projections analyzed")
        
        return {
            "league": league,
            "sample_size": len(accuracies),
            "bias_report": bias_report,
        }
    
    except Exception as e:
        logger.error(f"Error computing bias: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/source-reliability")
async def get_source_reliability(
    league: Optional[str] = Query("NBA", description="NBA or NFL"),
    connection=Depends(get_db_connection),
):
    """
    Get source reliability scores.
    
    Args:
        league: Filter by league
        
    Returns:
        Hit rates and confidence scores by source
    """
    try:
        query = """
        SELECT
            source, signal_type, hit_rate, false_positive_rate,
            confidence_score, total_signals, last_updated
        FROM evaluation_source_reliability
        WHERE league = :league
        ORDER BY confidence_score DESC
        """
        
        results = connection.execute(
            query,
            {"league": league},
        ).fetchall()
        
        sources = [
            {
                "source": row[0],
                "signal_type": row[1],
                "hit_rate": round(row[2], 3),
                "false_positive_rate": round(row[3], 3),
                "confidence_score": round(row[4], 3),
                "total_signals": row[5],
                "last_updated": row[6].isoformat() if row[6] else None,
            }
            for row in results
        ]
        
        logger.info(f"Retrieved {len(sources)} source reliability scores for {league}")
        
        return {
            "sources": sources,
            "count": len(sources),
            "league": league,
        }
    
    except Exception as e:
        logger.error(f"Error retrieving source reliability: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/post-game/{slate_id}")
async def run_post_game_evaluation(
    slate_id: str,
    connection=Depends(get_db_connection),
):
    """
    Run post-game evaluation pipeline for a slate.
    
    This endpoint orchestrates:
    1. Computing accuracy metrics for the slate
    2. Grouping results by source
    3. Updating source reliability scores
    4. Recording changes for feedback loop
    
    Args:
        slate_id: Slate ID to evaluate
        
    Returns:
        Report with accuracy metrics and reliability updates
        
    Example:
        POST /evaluation/post-game/fd_nba_20260122
        Returns:
        {
            "slate_id": "fd_nba_20260122",
            "evaluated_at": "2026-01-22T15:30:00",
            "projections_count": 150,
            "accuracy": {
                "rmse": 4.23,
                "mae": 3.1,
                "hit_rate": 0.52,
                "correlation": 0.78
            },
            "by_source": {...},
            "reliability_updates": [...]
        }
    """
    try:
        from orchestration.feedback_loop import FeedbackLoopOrchestrator
        
        # Initialize orchestrator with dependencies
        accuracy_computer = AccuracyMetricsComputer(connection)
        evaluation_store = EvaluationStore(connection)
        
        # For now, create a simple version without full reliability tracking
        # Full version would instantiate SourceReliabilityTracker
        orchestrator = FeedbackLoopOrchestrator(
            connection=connection,
            accuracy_computer=accuracy_computer,
            reliability_tracker=None,  # Would need to instantiate properly
            projection_store=None,  # Would need to instantiate properly
            result_store=None,  # Would need to instantiate properly
        )
        
        # Run post-game pipeline
        report = orchestrator.run_post_game_pipeline(slate_id)
        
        if 'error' in report:
            raise HTTPException(status_code=400, detail=report['error'])
        
        logger.info(f"Post-game evaluation complete for slate {slate_id}")
        return report
        
    except Exception as e:
        logger.error(f"Error running post-game evaluation for {slate_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/reliability-summary")
async def get_reliability_summary(
    league: Optional[str] = Query("NBA", description="NBA or NFL"),
    connection=Depends(get_db_connection),
):
    """
    Get current source reliability scores for the feedback loop.
    
    Returns reliability adjustments that have been made based on
    post-game evaluation results.
    
    Args:
        league: Filter by NBA or NFL
        
    Returns:
        Dict of source_name → current_reliability_score (0-1)
        
    Example:
        GET /evaluation/reliability-summary
        Returns:
        {
            "minutes_baseline_v1": 0.72,
            "usage_baseline_v1": 0.68,
            "minutes_baseline_v2": 0.81
        }
    """
    try:
        query = """
        SELECT source, reliability_score, hit_rate, sample_count, last_updated
        FROM evaluation_source_reliability
        WHERE league = :league
        ORDER BY reliability_score DESC
        """
        
        results = connection.execute(
            query,
            {"league": league},
        ).fetchall()
        
        if not results:
            return {
                "message": "No reliability scores available",
                "league": league,
            }
        
        reliability_dict = {
            row[0]: {
                "reliability": round(row[1], 3),
                "hit_rate": round(row[2], 3) if row[2] is not None else None,
                "samples": row[3],
                "last_updated": row[4].isoformat() if row[4] else None,
            }
            for row in results
        }
        
        logger.info(f"Retrieved {len(reliability_dict)} reliability scores for {league}")
        
        return {
            "league": league,
            "count": len(reliability_dict),
            "scores": reliability_dict,
        }
        
    except Exception as e:
        logger.error(f"Error retrieving reliability summary: {e}")
        raise HTTPException(status_code=500, detail=str(e))
