"""CSV ingestion endpoints."""

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
import io
import csv
from core import get_logger
from ingest import FanDuelConnector, DraftKingsConnector
from api.dependencies import get_db_connection


logger = get_logger(__name__)

router = APIRouter(prefix="/ingest", tags=["ingest"])


@router.post("/fd-csv")
async def ingest_fanduel_csv(
    file: UploadFile = File(..., description="FanDuel CSV file"),
    connection=Depends(get_db_connection),
):
    """
    Ingest FanDuel slate CSV.
    
    Args:
        file: CSV file upload
        
    Returns:
        Ingestion results with record counts
    """
    try:
        if not file.filename.endswith(".csv"):
            raise HTTPException(status_code=400, detail="File must be CSV")
        
        # Read file content
        contents = await file.read()
        csv_text = contents.decode("utf-8")
        
        # Parse CSV
        reader = csv.DictReader(io.StringIO(csv_text))
        records = list(reader)
        
        if not records:
            raise HTTPException(status_code=400, detail="CSV is empty")
        
        # Ingest via FanDuel connector
        connector = FanDuelConnector()
        valid_records, invalid_records = connector.ingest_and_validate(records)
        
        logger.info(
            f"FanDuel ingestion: {len(valid_records)} valid, {len(invalid_records)} invalid"
        )
        
        return {
            "status": "success",
            "filename": file.filename,
            "valid_records": len(valid_records),
            "invalid_records": len(invalid_records),
            "total": len(records),
            "errors": [
                {"record_index": i, "error": error}
                for i, error in enumerate(invalid_records)
            ][:10],  # Return first 10 errors
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error ingesting FanDuel CSV: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/dk-csv")
async def ingest_draftkings_csv(
    file: UploadFile = File(..., description="DraftKings CSV file"),
    connection=Depends(get_db_connection),
):
    """
    Ingest DraftKings slate CSV.
    
    Args:
        file: CSV file upload
        
    Returns:
        Ingestion results with record counts
    """
    try:
        if not file.filename.endswith(".csv"):
            raise HTTPException(status_code=400, detail="File must be CSV")
        
        # Read file content
        contents = await file.read()
        csv_text = contents.decode("utf-8")
        
        # Parse CSV
        reader = csv.DictReader(io.StringIO(csv_text))
        records = list(reader)
        
        if not records:
            raise HTTPException(status_code=400, detail="CSV is empty")
        
        # Ingest via DraftKings connector
        connector = DraftKingsConnector()
        valid_records, invalid_records = connector.ingest_and_validate(records)
        
        logger.info(
            f"DraftKings ingestion: {len(valid_records)} valid, {len(invalid_records)} invalid"
        )
        
        return {
            "status": "success",
            "filename": file.filename,
            "valid_records": len(valid_records),
            "invalid_records": len(invalid_records),
            "total": len(records),
            "errors": [
                {"record_index": i, "error": error}
                for i, error in enumerate(invalid_records)
            ][:10],  # Return first 10 errors
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error ingesting DraftKings CSV: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/results")
async def ingest_contest_results(
    file: UploadFile = File(..., description="Results CSV (player_id, actual_fppg)"),
    slate_id: str = None,
    connection=Depends(get_db_connection),
):
    """
    Ingest contest results (actual FPPG by player).
    
    CSV format:
        player_id,actual_fppg
        nba_12345,45.5
        nba_67890,32.0
        ...
    
    Args:
        file: CSV file upload
        slate_id: Slate identifier for results
        
    Returns:
        Ingestion results
    """
    try:
        if not file.filename.endswith(".csv"):
            raise HTTPException(status_code=400, detail="File must be CSV")
        
        # Read file content
        contents = await file.read()
        csv_text = contents.decode("utf-8")
        
        # Parse CSV
        reader = csv.DictReader(io.StringIO(csv_text))
        records = list(reader)
        
        if not records:
            raise HTTPException(status_code=400, detail="CSV is empty")
        
        # Validate records have required columns
        if not all("player_id" in r and "actual_fppg" in r for r in records):
            raise HTTPException(
                status_code=400,
                detail="CSV must have player_id and actual_fppg columns"
            )
        
        # Store results
        stored_count = 0
        for record in records:
            try:
                query = """
                INSERT INTO raw_contest_results (
                    slate_id, player_id, actual_fppg, recorded_at
                ) VALUES (
                    :slate_id, :player_id, :actual_fppg, CURRENT_TIMESTAMP
                )
                """
                
                connection.execute(
                    query,
                    {
                        "slate_id": slate_id or "unknown",
                        "player_id": record["player_id"],
                        "actual_fppg": float(record["actual_fppg"]),
                    },
                )
                stored_count += 1
            except Exception as e:
                logger.warning(f"Error storing result for {record.get('player_id')}: {e}")
        
        logger.info(f"Results ingestion: {stored_count}/{len(records)} stored")
        
        return {
            "status": "success",
            "filename": file.filename,
            "stored": stored_count,
            "total": len(records),
            "slate_id": slate_id,
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error ingesting results: {e}")
        raise HTTPException(status_code=500, detail=str(e))
