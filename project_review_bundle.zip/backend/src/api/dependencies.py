"""Dependency injection for FastAPI."""

from typing import Generator
from core import get_logger
from db import create_engine_with_retry


logger = get_logger(__name__)

# Global connection (in production, use connection pool)
_connection = None


def get_db_connection():
    """
    Get database connection dependency.
    
    Yields:
        Database connection
    """
    global _connection
    
    if _connection is None:
        logger.info("Initializing database connection")
        _connection = create_engine_with_retry()
    
    yield _connection


def shutdown_db_connection():
    """Shutdown database connection."""
    global _connection
    
    if _connection is not None:
        try:
            _connection.close()
            logger.info("Database connection closed")
        except Exception as e:
            logger.error(f"Error closing database connection: {e}")
        finally:
            _connection = None
