"""Projection endpoints."""

from fastapi import APIRouter, Depends, HTTPException, Query
from typing import Optional
from core import get_utc_now, get_logger
from projection import ProjectionStore, ProjectionBuilder
from api.dependencies import get_db_connection


logger = get_logger(__name__)

router = APIRouter(prefix="/projections", tags=["projections"])


@router.get("/slate/{slate_id}")
async def get_slate_projections(
    slate_id: str,
    version: str = Query("v1", description="Projection version"),
    position: Optional[str] = Query(None, description="Filter by position"),
    min_confidence: Optional[float] = Query(None, description="Minimum confidence (0-1)"),
    connection=Depends(get_db_connection),
):
    """
    Get all projections for a slate at specific version.
    
    Args:
        slate_id: Slate identifier
        version: Projection version (e.g., "v1")
        position: Filter by position
        min_confidence: Filter by minimum confidence
        
    Returns:
        List of projections with distributions
    """
    try:
        store = ProjectionStore(connection)
        
        # Get projections at version
        projections = store.get_for_slate(slate_id, version)
        
        if not projections:
            logger.warning(f"No projections found for slate {slate_id} v{version}")
            return {
                "projections": [],
                "count": 0,
                "slate_id": slate_id,
                "version": version,
            }
        
        # Filter if requested
        filtered = {}
        for player_id, proj in projections.items():
            if position and proj.player_id != position:  # Would need to join player table
                continue
            if min_confidence and proj.confidence < min_confidence:
                continue
            filtered[player_id] = proj
        
        projection_list = [
            {
                "player_id": proj.player_id,
                "game_id": proj.game_id,
                "median_fppg": round(proj.median_fppg, 2),
                "floor_fppg": round(proj.floor_fppg, 2),
                "ceiling_fppg": round(proj.ceiling_fppg, 2),
                "volatility": round(proj.volatility, 2),
                "confidence": round(proj.confidence, 3),
                "source_signals": proj.source_signals,
                "version": proj.version,
            }
            for proj in filtered.values()
        ]
        
        logger.info(f"Retrieved {len(projection_list)} projections for slate {slate_id} v{version}")
        return {
            "projections": projection_list,
            "count": len(projection_list),
            "slate_id": slate_id,
            "version": version,
        }
    
    except Exception as e:
        logger.error(f"Error retrieving projections: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/player/{player_id}/game/{game_id}")
async def get_player_game_projection(
    player_id: str,
    game_id: str,
    version: str = Query("v1", description="Projection version"),
    connection=Depends(get_db_connection),
):
    """
    Get projection for specific player in game.
    
    Args:
        player_id: Player identifier
        game_id: Game identifier
        version: Projection version
        
    Returns:
        Single projection with full distribution details
    """
    try:
        store = ProjectionStore(connection)
        
        projection = store.get_for_player_game(player_id, game_id, version)
        
        if not projection:
            raise HTTPException(
                status_code=404,
                detail=f"No projection found for {player_id} in {game_id} v{version}"
            )
        
        return {
            "player_id": projection.player_id,
            "game_id": projection.game_id,
            "slate_id": projection.slate_id,
            "league": projection.league,
            "as_of_time": projection.as_of_time.isoformat(),
            "median_fppg": round(projection.median_fppg, 2),
            "floor_fppg": round(projection.floor_fppg, 2),
            "ceiling_fppg": round(projection.ceiling_fppg, 2),
            "volatility": round(projection.volatility, 2),
            "confidence": round(projection.confidence, 3),
            "mean_fppg": round(projection.mean_fppg, 2) if projection.mean_fppg else None,
            "std_dev": round(projection.std_dev, 2) if projection.std_dev else None,
            "source_signals": projection.source_signals,
            "contributing_factors": projection.contributing_factors,
            "version": projection.version,
            "inputs_hash": projection.inputs_hash,
            "created_at": projection.created_at.isoformat(),
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving projection: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/build-slate/{slate_id}")
async def build_slate_projections(
    slate_id: str,
    as_of_time: Optional[str] = Query(None, description="Decision time (ISO format)"),
    version: str = Query("v1", description="Projection version to create"),
    connection=Depends(get_db_connection),
):
    """
    Trigger building projections for entire slate at point-in-time.

    This builds decision snapshots and projections considering all signals
    valid at the specified time.

    Args:
        slate_id: Slate identifier
        as_of_time: ISO format timestamp (default: now)
        version: Projection version label

    Returns:
        Build job status and projection count
    """
    try:
        if as_of_time is None:
            decision_time = get_utc_now()
        else:
            # TODO: Parse as_of_time from ISO string
            decision_time = get_utc_now()

        logger.info(f"Building projections for slate {slate_id} v{version} as_of {decision_time}")

        # Initialize projection builder
        builder = ProjectionBuilder(connection)

        # TODO: Fetch player_game_data from database
        # This would query for players in the slate with their baseline data
        # For now, return placeholder indicating build structure is in place

        # Example structure (would be populated from database):
        # player_game_data = {
        #     "player_123": {
        #         "game_456": {
        #             "league": "NBA",
        #             "position": "PG",
        #             "salary": 8000,
        #             "minutes_baseline_floor": 25.0,
        #             "minutes_baseline_ceiling": 35.0,
        #             "usage_baseline_floor": 0.15,
        #             "usage_baseline_ceiling": 0.25,
        #             "fppg_baseline": 35.0
        #         }
        #     }
        # }

        # game_ids = ["game_456"]  # Would be fetched from slate

        # projections = builder.build_slate_projections(
        #     slate_id=slate_id,
        #     game_ids=game_ids,
        #     player_game_data=player_game_data,
        #     as_of_time=decision_time,
        #     version=version
        # )

        # # Store projections
        # store = ProjectionStore(connection)
        # for projection in projections.values():
        #     store.insert(projection)

        return {
            "slate_id": slate_id,
            "version": version,
            "as_of_time": decision_time.isoformat(),
            "status": "structure_ready",
            "message": "Projection build structure implemented - signals now fetched automatically during build",
            "note": "Player baseline data fetching needs to be implemented to complete the build"
        }

    except Exception as e:
        logger.error(f"Error building projections: {e}")
        raise HTTPException(status_code=500, detail=str(e))
