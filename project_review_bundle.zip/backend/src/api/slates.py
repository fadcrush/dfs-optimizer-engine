"""Slate management endpoints."""

from fastapi import APIRouter, Depends, HTTPException, Query
from typing import List, Optional
from datetime import datetime
from core import get_utc_now, get_logger
from db import SafeQueries
from api.dependencies import get_db_connection


logger = get_logger(__name__)

router = APIRouter(prefix="/slates", tags=["slates"])


@router.get("")
async def list_slates(
    league: Optional[str] = Query(None, description="Filter by league (NBA/NFL)"),
    site: Optional[str] = Query(None, description="Filter by site (FanDuel/DraftKings)"),
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    connection=Depends(get_db_connection),
):
    """
    List all slates with optional filtering.
    
    Args:
        league: Filter by NBA or NFL
        site: Filter by FanDuel or DraftKings
        limit: Max results
        offset: Pagination offset
        
    Returns:
        List of slate summaries
    """
    try:
        query = SafeQueries.get_slates(connection)
        
        # Apply filters
        if league:
            query = query.and_where("league = :league")
        if site:
            query = query.and_where("site = :site")
        
        query = query.order_by("slate_date DESC").limit(limit).offset(offset)
        
        params = {
            "league": league,
            "site": site,
        }
        
        results = connection.execute(query.build_text(), params).fetchall()
        
        slates = [
            {
                "slate_id": row[0],
                "league": row[1],
                "site": row[2],
                "slate_date": row[3].isoformat() if row[3] else None,
                "slate_type": row[4],
                "salary_cap": row[5],
            }
            for row in results
        ]
        
        logger.info(f"Listed {len(slates)} slates (league={league}, site={site})")
        return {
            "slates": slates,
            "count": len(slates),
            "limit": limit,
            "offset": offset,
        }
    
    except Exception as e:
        logger.error(f"Error listing slates: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{slate_id}")
async def get_slate(
    slate_id: str,
    connection=Depends(get_db_connection),
):
    """
    Get detailed slate information.
    
    Args:
        slate_id: Slate identifier
        
    Returns:
        Slate details with player count
    """
    try:
        query = """
        SELECT slate_id, league, site, slate_date, slate_type, salary_cap, roster_slots
        FROM dim_slates
        WHERE slate_id = :slate_id
        """
        
        result = connection.execute(query, {"slate_id": slate_id}).first()
        
        if not result:
            raise HTTPException(status_code=404, detail=f"Slate {slate_id} not found")
        
        # Get player count
        player_query = """
        SELECT COUNT(*) FROM fact_site_players
        WHERE slate_id = :slate_id
        """
        
        player_count = connection.execute(
            player_query,
            {"slate_id": slate_id},
        ).first()[0]
        
        slate_info = {
            "slate_id": result[0],
            "league": result[1],
            "site": result[2],
            "slate_date": result[3].isoformat() if result[3] else None,
            "slate_type": result[4],
            "salary_cap": result[5],
            "roster_slots": result[6],
            "player_count": player_count,
        }
        
        logger.info(f"Retrieved slate {slate_id}")
        return slate_info
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving slate {slate_id}: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{slate_id}/players")
async def get_slate_players(
    slate_id: str,
    position: Optional[str] = Query(None, description="Filter by position"),
    min_salary: Optional[int] = Query(None, description="Minimum salary"),
    max_salary: Optional[int] = Query(None, description="Maximum salary"),
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    connection=Depends(get_db_connection),
):
    """
    Get players in slate with optional filtering.
    
    Args:
        slate_id: Slate identifier
        position: Filter by position
        min_salary: Minimum salary filter
        max_salary: Maximum salary filter
        limit: Max results
        offset: Pagination offset
        
    Returns:
        List of players with salaries
    """
    try:
        query = """
        SELECT
            p.player_id, p.canonical_name, p.position, p.league,
            f.site_player_id, f.salary, f.site
        FROM fact_site_players f
        JOIN dim_players p ON f.player_id = p.player_id
        WHERE f.slate_id = :slate_id
        """
        
        params = {"slate_id": slate_id}
        
        if position:
            query += " AND p.position = :position"
            params["position"] = position
        
        if min_salary is not None:
            query += " AND f.salary >= :min_salary"
            params["min_salary"] = min_salary
        
        if max_salary is not None:
            query += " AND f.salary <= :max_salary"
            params["max_salary"] = max_salary
        
        query += " ORDER BY f.salary DESC LIMIT :limit OFFSET :offset"
        params["limit"] = limit
        params["offset"] = offset
        
        results = connection.execute(query, params).fetchall()
        
        players = [
            {
                "player_id": row[0],
                "name": row[1],
                "position": row[2],
                "league": row[3],
                "site_player_id": row[4],
                "salary": row[5],
                "site": row[6],
            }
            for row in results
        ]
        
        logger.info(f"Retrieved {len(players)} players for slate {slate_id}")
        return {
            "players": players,
            "count": len(players),
            "limit": limit,
            "offset": offset,
        }
    
    except Exception as e:
        logger.error(f"Error retrieving slate players: {e}")
        raise HTTPException(status_code=500, detail=str(e))
