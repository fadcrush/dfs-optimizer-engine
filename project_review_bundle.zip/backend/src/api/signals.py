"""Signal and decision snapshot endpoints."""

from fastapi import APIRouter, Depends, HTTPException, Query
from typing import Optional
from datetime import datetime
from core import get_utc_now, get_logger
from signals import SignalStore
from api.dependencies import get_db_connection


logger = get_logger(__name__)

router = APIRouter(prefix="/signals", tags=["signals"])


@router.get("/slate/{slate_id}")
async def get_slate_signals(
    slate_id: str,
    as_of_time: Optional[str] = Query(None, description="Timestamp (ISO format)"),
    signal_type: Optional[str] = Query(None, description="Filter by signal type"),
    league: Optional[str] = Query(None, description="Filter by league"),
    connection=Depends(get_db_connection),
):
    """
    Get all signals active for slate at point-in-time.
    
    Args:
        slate_id: Slate identifier
        as_of_time: ISO timestamp (default: now)
        signal_type: Filter by type (INJURY_OUT, CONFIRMED_STARTER, etc.)
        league: Filter by league (NBA/NFL)
        
    Returns:
        List of active signals with details
    """
    try:
        if as_of_time is None:
            decision_time = get_utc_now()
        else:
            decision_time = datetime.fromisoformat(as_of_time)
        
        query = """
        SELECT
            signal_id, signal_type, entity_type, entity_id, league,
            timestamp_utc, source, source_confidence, decay_profile,
            validity_start, validity_end, payload
        FROM operational_signals
        WHERE league = :league
          AND validity_start <= :as_of_time
          AND (validity_end IS NULL OR validity_end > :as_of_time)
        """
        
        params = {
            "league": league or "NBA",
            "as_of_time": decision_time,
        }
        
        if signal_type:
            query += " AND signal_type = :signal_type"
            params["signal_type"] = signal_type
        
        query += " ORDER BY timestamp_utc DESC"
        
        results = connection.execute(query, params).fetchall()
        
        signals = [
            {
                "signal_id": row[0],
                "signal_type": row[1],
                "entity_type": row[2],
                "entity_id": row[3],
                "league": row[4],
                "timestamp_utc": row[5].isoformat(),
                "source": row[6],
                "source_confidence": round(row[7], 3),
                "decay_profile": row[8],
                "validity_start": row[9].isoformat() if row[9] else None,
                "validity_end": row[10].isoformat() if row[10] else None,
                "payload": row[11],
            }
            for row in results
        ]
        
        logger.info(f"Retrieved {len(signals)} signals for league {league or 'NBA'} as_of {decision_time}")
        return {
            "signals": signals,
            "count": len(signals),
            "as_of_time": decision_time.isoformat(),
            "league": league or "NBA",
        }
    
    except Exception as e:
        logger.error(f"Error retrieving signals: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/player/{player_id}")
async def get_player_signals(
    player_id: str,
    league: str = Query("NBA", description="NBA or NFL"),
    as_of_time: Optional[str] = Query(None, description="Timestamp (ISO format)"),
    include_expired: bool = Query(False, description="Include expired signals"),
    connection=Depends(get_db_connection),
):
    """
    Get all signals for a player.
    
    Args:
        player_id: Player identifier
        league: NBA or NFL
        as_of_time: Decision timestamp (default: now)
        include_expired: Include signals outside validity window
        
    Returns:
        List of signals affecting player
    """
    try:
        if as_of_time is None:
            decision_time = get_utc_now()
        else:
            decision_time = datetime.fromisoformat(as_of_time)
        
        query = """
        SELECT
            signal_id, signal_type, entity_id, source, source_confidence,
            decay_profile, validity_start, validity_end, timestamp_utc, payload
        FROM operational_signals
        WHERE entity_id = :player_id
          AND league = :league
        """
        
        params = {
            "player_id": player_id,
            "league": league,
        }
        
        if not include_expired:
            query += """
            AND validity_start <= :as_of_time
            AND (validity_end IS NULL OR validity_end > :as_of_time)
            """
            params["as_of_time"] = decision_time
        
        query += " ORDER BY timestamp_utc DESC"
        
        results = connection.execute(query, params).fetchall()
        
        signals = [
            {
                "signal_id": row[0],
                "signal_type": row[1],
                "entity_id": row[2],
                "source": row[3],
                "source_confidence": round(row[4], 3),
                "decay_profile": row[5],
                "validity_start": row[6].isoformat() if row[6] else None,
                "validity_end": row[7].isoformat() if row[7] else None,
                "timestamp_utc": row[8].isoformat(),
                "payload": row[9],
            }
            for row in results
        ]
        
        logger.info(f"Retrieved {len(signals)} signals for {player_id}")
        return {
            "player_id": player_id,
            "signals": signals,
            "count": len(signals),
            "as_of_time": decision_time.isoformat(),
        }
    
    except Exception as e:
        logger.error(f"Error retrieving player signals: {e}")
        raise HTTPException(status_code=500, detail=str(e))
