"""
Legacy v1 data API (slates, projections, signals, ingest, evaluation).

NOT the canonical entry point.  The production app is src/main.py.
This module is kept as a factory so existing tests that target /api/v1/
routes can continue to work.  Do NOT launch this with uvicorn directly.
"""

from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from core import get_logger
from api.dependencies import get_db_connection, shutdown_db_connection
from api import health, slates, projections, signals, ingest, evaluation

logger = get_logger(__name__)

# Same origins as the canonical app (src/main.py)
_ALLOWED_ORIGINS = [
    "http://localhost:3000",
    "http://127.0.0.1:3000",
]


@asynccontextmanager
async def _lifespan(app: FastAPI):
    """Startup / shutdown for the legacy v1 data API."""
    logger.info("Starting legacy v1 data API")
    try:
        connection = None
        for conn in get_db_connection():
            connection = conn
            break
        if connection:
            logger.info("Running database migrations...")
            from db import run_migrations
            run_migrations(connection)
            logger.info("Database migrations completed")
    except Exception as e:
        logger.error(f"Startup error: {e}")
        raise

    yield

    logger.info("Shutting down legacy v1 data API")
    shutdown_db_connection()


def create_app() -> FastAPI:
    """Create the legacy v1 data API (for tests only)."""
    app = FastAPI(
        title="DFS Optimizer API (legacy v1)",
        description="NFL + NBA DFS projection and optimization engine",
        version="1.0.0",
        lifespan=_lifespan,
    )

    # CORS — restricted to known origins (no wildcard)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=_ALLOWED_ORIGINS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Include routers
    app.include_router(health.router, prefix="/api/v1")
    app.include_router(slates.router, prefix="/api/v1")
    app.include_router(projections.router, prefix="/api/v1")
    app.include_router(signals.router, prefix="/api/v1")
    app.include_router(ingest.router, prefix="/api/v1")
    app.include_router(evaluation.router, prefix="/api/v1")

    # Root endpoint
    @app.get("/")
    async def root():
        """API root."""
        return {
            "service": "DFS Optimizer API",
            "version": "1.0.0",
            "status": "running",
            "docs": "/docs",
            "openapi": "/openapi.json",
        }

    logger.info("Legacy v1 data API created (test-only)")
    return app
