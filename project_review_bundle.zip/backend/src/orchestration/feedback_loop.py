"""Post-game evaluation and feedback loop orchestration."""

import logging
from typing import Dict, Optional, List
from datetime import datetime

try:
    from core import get_utc_now
except ImportError:
    from datetime import datetime, timezone
    def get_utc_now():
        return datetime.now(timezone.utc)

logger = logging.getLogger(__name__)


class SourceReliabilityUpdate:
    """Record of a source reliability change."""
    
    def __init__(self, 
                source: str,
                old_reliability: float,
                new_reliability: float,
                change_reason: str,
                hit_rate: float,
                sample_count: int):
        """
        Initialize reliability update record.
        
        Args:
            source: Source name (e.g., 'minutes_baseline_v1')
            old_reliability: Previous reliability score (0-1)
            new_reliability: Updated reliability score (0-1)
            change_reason: Why reliability changed (e.g., 'high_hit_rate')
            hit_rate: Hit rate that triggered change
            sample_count: Number of samples evaluated
        """
        self.source = source
        self.old_reliability = old_reliability
        self.new_reliability = new_reliability
        self.change_reason = change_reason
        self.hit_rate = hit_rate
        self.sample_count = sample_count


class FeedbackLoopOrchestrator:
    """
    Post-game evaluation pipeline:
    1. Compute accuracy metrics for slate
    2. Group results by source
    3. Update source reliability based on performance
    4. Prepare for next projection build with improved weights
    """
    
    def __init__(self, 
                 connection,
                 accuracy_computer,
                 reliability_tracker,
                 projection_store,
                 result_store,
                 signal_store=None):
        """
        Initialize orchestrator.
        
        Args:
            connection: Database connection
            accuracy_computer: AccuracyMetricsComputer instance
            reliability_tracker: SourceReliabilityTracker instance
            projection_store: ProjectionStore instance
            result_store: ResultStore instance
            signal_store: SignalStore instance (optional)
        """
        self.connection = connection
        self.accuracy_computer = accuracy_computer
        self.reliability_tracker = reliability_tracker
        self.projection_store = projection_store
        self.result_store = result_store
        self.signal_store = signal_store
    
    def run_post_game_pipeline(self, slate_id: str) -> Dict:
        """
        Execute post-game evaluation pipeline.
        
        Steps:
        1. Fetch projections & actuals for slate
        2. Compute accuracy metrics
        3. Group by source
        4. Update source reliability
        5. Return report
        
        Args:
            slate_id: Slate ID to evaluate
            
        Returns:
            Report dict with:
            - slate_id
            - evaluated_at (datetime)
            - projections_count
            - accuracy (global metrics)
            - by_source (per-source metrics)
            - reliability_updates (changes made)
            
        Example:
            >>> orchestrator = FeedbackLoopOrchestrator(
            ...     connection=db_connection,
            ...     accuracy_computer=accuracy_comp,
            ...     reliability_tracker=rel_tracker,
            ...     projection_store=proj_store,
            ...     result_store=result_store
            ... )
            >>> report = orchestrator.run_post_game_pipeline('slate_123')
            >>> print(f"RMSE: {report['accuracy']['rmse']:.2f}")
            >>> print(f"Updated {len(report['reliability_updates'])} sources")
        """
        logger.info(f"Starting post-game pipeline for slate {slate_id}")
        
        try:
            # Step 1: Fetch projections & actuals
            logger.info(f"Fetching projections for slate {slate_id}")
            projections = self.projection_store.get_for_slate(slate_id)
            
            logger.info(f"Fetching results for slate {slate_id}")
            actuals = self.result_store.get_for_slate(slate_id)
            
            if not projections or not actuals:
                logger.warning(f"No projections or actuals for slate {slate_id}")
                return {
                    'error': 'Insufficient data',
                    'slate_id': slate_id,
                    'projections_count': len(projections) if projections else 0,
                    'actuals_count': len(actuals) if actuals else 0,
                }
            
            logger.info(f"Evaluating {len(projections)} projections against {len(actuals)} actuals")
            
            # Step 2: Compute accuracy
            logger.info("Computing accuracy metrics...")
            accuracy_report = self.accuracy_computer.compute_accuracy(
                projections=projections,
                actuals=actuals
            )
            
            # Step 3: Update source reliability
            logger.info(f"Updating reliability for {len(accuracy_report.by_source)} sources")
            reliability_updates = []
            
            for source, metrics in accuracy_report.by_source.items():
                hit_rate = metrics.hit_rate
                # Parse source to get components (source_signalType_league format)
                source_parts = source.split('_', 2)
                if len(source_parts) >= 3:
                    source_name, signal_type, league = source_parts[0], source_parts[1], source_parts[2]
                    old_reliability = self.reliability_tracker.get_source_weight(source_name, signal_type, league)

                    change_reason = ''

                    if hit_rate > 0.65:  # Above threshold: upweight
                        bonus = min((hit_rate - 0.65) * 0.1, 0.1)  # Max +0.1
                        self.reliability_tracker.update_from_accuracy(source_name, signal_type, league, None)  # This will trigger upweight logic
                        change_reason = f'high_hit_rate ({hit_rate:.2%})'
                        logger.info(f"  ✓ Upweight {source}: {hit_rate:.2%} hit_rate")

                    elif hit_rate < 0.45:  # Below threshold: downweight
                        penalty = min((0.45 - hit_rate) * 0.1, 0.1)  # Max -0.1
                        # For downweight, we need to call the method on the specific source reliability object
                        reliability_obj = self.reliability_tracker.register_source(source_name, signal_type, league)
                        reliability_obj.downweight(penalty)
                        change_reason = f'low_hit_rate ({hit_rate:.2%})'
                        logger.info(f"  ✗ Downweight {source}: {hit_rate:.2%} hit_rate")

                    else:  # Neutral
                        logger.info(f"  - Neutral {source}: {hit_rate:.2%} hit_rate")
                        continue

                    # Record update
                    new_reliability = self.reliability_tracker.get_source_weight(source_name, signal_type, league)
                else:
                    logger.warning(f"Could not parse source format: {source}")
                    continue
                update = SourceReliabilityUpdate(
                    source=source,
                    old_reliability=old_reliability,
                    new_reliability=new_reliability,
                    change_reason=change_reason,
                    hit_rate=hit_rate,
                    sample_count=metrics.count
                )
                reliability_updates.append(update)
            
            # Step 4: Prepare report
            evaluated_at = get_utc_now()
            report = {
                'slate_id': slate_id,
                'evaluated_at': evaluated_at.isoformat(),
                'projections_count': len(projections),
                'actuals_count': len(actuals),
                'accuracy': {
                    'rmse': accuracy_report.rmse,
                    'mae': accuracy_report.mae,
                    'hit_rate': accuracy_report.hit_rate,
                    'correlation': accuracy_report.correlation if hasattr(accuracy_report, 'correlation') else None,
                },
                'by_source': {
                    source: {
                        'hit_rate': metrics.hit_rate,
                        'count': metrics.count,
                        'rmse': metrics.rmse if hasattr(metrics, 'rmse') else None,
                        'mae': metrics.mae if hasattr(metrics, 'mae') else None,
                        'reliability_after': self.reliability_tracker.get_source_weight(source_name, signal_type, league) if len(source_parts) >= 3 else 0.5
                    }
                    for source, metrics in accuracy_report.by_source.items()
                },
                'reliability_updates': [
                    {
                        'source': u.source,
                        'old_reliability': u.old_reliability,
                        'new_reliability': u.new_reliability,
                        'change': u.new_reliability - u.old_reliability,
                        'reason': u.change_reason,
                        'hit_rate': u.hit_rate,
                        'samples': u.sample_count
                    }
                    for u in reliability_updates
                ]
            }
            
            logger.info(f"Post-game pipeline complete for {slate_id}")
            logger.info(f"  Updated {len(reliability_updates)} sources")
            logger.info(f"  Global RMSE: {accuracy_report.rmse:.3f}")
            logger.info(f"  Global hit_rate: {accuracy_report.hit_rate:.2%}")
            
            return report
        
        except Exception as e:
            logger.error(f"Post-game pipeline failed for slate {slate_id}: {e}", exc_info=True)
            return {
                'error': str(e),
                'slate_id': slate_id,
            }
    
    def get_source_reliability_summary(self) -> Dict[str, float]:
        """
        Get current reliability scores for all sources.

        Returns:
            Dict of source → reliability_score

        Example:
            >>> summary = orchestrator.get_source_reliability_summary()
            >>> for source, reliability in summary.items():
            ...     print(f"{source}: {reliability:.2f}")
        """
        # Return a summary of all tracked sources with their reliability scores
        summary = {}
        for key, source_reliability in self.reliability_tracker.sources.items():
            summary[key] = source_reliability.confidence_score
        return summary
    
    def run_multiple_slates(self, slate_ids: List[str]) -> List[Dict]:
        """
        Run post-game pipeline for multiple slates.
        
        Args:
            slate_ids: List of slate IDs to evaluate
            
        Returns:
            List of reports (one per slate)
            
        Example:
            >>> slates = ['slate_1', 'slate_2', 'slate_3']
            >>> reports = orchestrator.run_multiple_slates(slates)
            >>> total_rmse = sum(r['accuracy']['rmse'] for r in reports) / len(reports)
            >>> print(f"Average RMSE: {total_rmse:.3f}")
        """
        reports = []
        
        for slate_id in slate_ids:
            logger.info(f"Processing slate {slate_id} ({slate_ids.index(slate_id)+1}/{len(slate_ids)})")
            report = self.run_post_game_pipeline(slate_id)
            reports.append(report)
        
        # Log summary
        successful = sum(1 for r in reports if 'error' not in r)
        failed = len(reports) - successful
        
        logger.info(f"Batch processing complete: {successful} successful, {failed} failed")
        
        return reports
