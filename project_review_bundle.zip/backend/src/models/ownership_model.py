"""
OwnershipData model — projected / actual ownership percentages per slate.

Named OwnershipData (table: ownership_data) to avoid a namespace clash
with the routers/ownership.py module.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import Column, DateTime, Float, ForeignKey, Index, String
from sqlalchemy.orm import relationship

from models.base import DFSBase


def _utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


class OwnershipData(DFSBase):
    """Projected / actual DFS ownership for one player on one slate."""

    __tablename__ = "ownership_data"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))

    slate_id = Column(
        String, ForeignKey("slates.id", ondelete="CASCADE"), nullable=False
    )
    player_id = Column(
        String,
        ForeignKey("slate_players.id", ondelete="CASCADE"),
        nullable=False,
    )

    ownership_pct = Column(Float, nullable=False)
    source = Column(String, default="upload")   # upload | model | dk_ownership

    created_at = Column(DateTime, default=_utcnow)

    # Relationships
    player = relationship("Player", back_populates="ownership")

    __table_args__ = (
        Index("ix_ownership_data_slate_id", "slate_id"),
        Index("ix_ownership_data_player_id", "player_id"),
    )

    def __repr__(self) -> str:
        return (
            f"<OwnershipData player_id={self.player_id!r} "
            f"pct={self.ownership_pct} source={self.source!r}>"
        )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "slate_id": self.slate_id,
            "player_id": self.player_id,
            "ownership_pct": self.ownership_pct,
            "source": self.source,
        }
