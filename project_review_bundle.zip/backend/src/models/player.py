"""
SlatePlayer model — salary and positional data for one player on one slate.

Because salary and position differ between platforms and contest types,
players are slate-scoped rather than stored in a global players table.
external_id is the platform's own player identifier (DK or FD ID).
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import (
    Column, DateTime, ForeignKey, Index, Integer, String, UniqueConstraint
)
from sqlalchemy.orm import relationship

from models.base import DFSBase


def _utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


class Player(DFSBase):
    """Salary-and-position record for a player within a single slate."""

    __tablename__ = "slate_players"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))

    # FK to the parent slate — CASCADE so orphan rows can't accumulate
    slate_id = Column(
        String, ForeignKey("slates.id", ondelete="CASCADE"), nullable=False
    )

    # Platform-assigned player ID
    external_id = Column(String, nullable=False)

    # Player details (snapshot from the CSV upload)
    name = Column(String, nullable=False)
    position = Column(String, nullable=True)   # PG, SG, SF, PF, C, FLEX, etc.
    team = Column(String, nullable=True)
    opponent = Column(String, nullable=True)
    salary = Column(Integer, default=0)
    game = Column(String, nullable=True)       # e.g. "BOS@MIA 07:30PM ET"

    created_at = Column(DateTime, default=_utcnow)

    # Relationships
    slate = relationship("Slate", back_populates="players")
    projection = relationship(
        "Projection", back_populates="player", uselist=False,
        cascade="all, delete-orphan"
    )
    ownership = relationship(
        "OwnershipData", back_populates="player", cascade="all, delete-orphan"
    )
    lineup_entries = relationship("LineupEntry", back_populates="player")

    __table_args__ = (
        UniqueConstraint("slate_id", "external_id", name="uq_slate_player_external"),
        Index("ix_slate_players_slate_id", "slate_id"),
    )

    def __repr__(self) -> str:
        return (
            f"<Player id={self.id!r} name={self.name!r} "
            f"pos={self.position!r} salary={self.salary}>"
        )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "slate_id": self.slate_id,
            "external_id": self.external_id,
            "name": self.name,
            "position": self.position,
            "team": self.team,
            "opponent": self.opponent,
            "salary": self.salary,
            "game": self.game,
        }
