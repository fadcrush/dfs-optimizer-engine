"""
Slate model — one row per uploaded DFS contest slate.

A slate is identified by its platform, sport, date, and the uploaded
source file name.  Every player and projection is scoped to a slate.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import TYPE_CHECKING

from sqlalchemy import Column, DateTime, Date, Integer, String
from sqlalchemy.orm import relationship

from models.base import DFSBase

if TYPE_CHECKING:
    from models.player import Player
    from models.run import Run


def _utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


class Slate(DFSBase):
    """
    One uploaded FanDuel / DraftKings contest slate.

    All downstream objects (players, projections, ownership rows, runs)
    reference slates.id so they can be deleted atomically when a slate is
    retired.
    """

    __tablename__ = "slates"

    # Primary key
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))

    # Contest metadata
    sport = Column(String, nullable=False, default="nba")      # nba | nfl
    platform = Column(String, nullable=False, default="fanduel")  # fanduel | draftkings
    slate_date = Column(Date, nullable=True)
    source_filename = Column(String, nullable=True)
    player_count = Column(Integer, default=0)

    # Audit
    created_at = Column(DateTime, default=_utcnow)

    # Relationships (lazy-loaded; import-cycle-safe via strings)
    players = relationship(
        "Player", back_populates="slate", cascade="all, delete-orphan", lazy="dynamic"
    )
    runs = relationship(
        "Run", back_populates="slate", cascade="all, delete-orphan", lazy="dynamic"
    )

    def __repr__(self) -> str:
        return f"<Slate id={self.id!r} platform={self.platform!r} sport={self.sport!r}>"

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "sport": self.sport,
            "platform": self.platform,
            "slate_date": str(self.slate_date) if self.slate_date else None,
            "source_filename": self.source_filename,
            "player_count": self.player_count,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
