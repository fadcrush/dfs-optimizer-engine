"""
Run model — one optimizer run that generates N lineups.

Status lifecycle:  queued → running → completed | failed
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone

from sqlalchemy import Column, DateTime, ForeignKey, Index, Integer, String, Text
from sqlalchemy.orm import relationship

from models.base import DFSBase


def _utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


# Valid status values
STATUS_QUEUED = "queued"
STATUS_RUNNING = "running"
STATUS_COMPLETED = "completed"
STATUS_FAILED = "failed"
VALID_STATUSES = {STATUS_QUEUED, STATUS_RUNNING, STATUS_COMPLETED, STATUS_FAILED}


class Run(DFSBase):
    """Single optimizer run record stored in the database."""

    __tablename__ = "runs"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))

    # Optional slate association (nullable so runs can be created before a slate)
    slate_id = Column(
        String, ForeignKey("slates.id", ondelete="CASCADE"), nullable=True
    )

    # Lifecycle
    status = Column(String, nullable=False, default=STATUS_QUEUED)
    num_lineups = Column(Integer, default=0)

    # JSON-serialized optimizer settings blob
    settings = Column(Text, nullable=True)
    error_message = Column(Text, nullable=True)

    # Audit timestamps
    created_at = Column(DateTime, default=_utcnow)
    started_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)

    # Relationships
    slate = relationship("Slate", back_populates="runs")
    lineups = relationship(
        "Lineup", back_populates="run", cascade="all, delete-orphan", lazy="dynamic"
    )

    __table_args__ = (
        Index("ix_runs_slate_id", "slate_id"),
        Index("ix_runs_status", "status"),
    )

    # -----------------------------------------------------------------
    # Helpers
    # -----------------------------------------------------------------

    def get_settings(self) -> dict:
        """Deserialise the settings JSON blob; returns {} when empty."""
        if not self.settings:
            return {}
        try:
            return json.loads(self.settings)
        except (json.JSONDecodeError, TypeError):
            return {}

    def set_settings(self, value: dict) -> None:
        """Serialise *value* into the settings column."""
        self.settings = json.dumps(value) if value else None

    def mark_running(self) -> None:
        self.status = STATUS_RUNNING
        self.started_at = _utcnow()

    def mark_completed(self) -> None:
        self.status = STATUS_COMPLETED
        self.completed_at = _utcnow()

    def mark_failed(self, reason: str) -> None:
        self.status = STATUS_FAILED
        self.error_message = reason
        self.completed_at = _utcnow()

    def __repr__(self) -> str:
        return f"<Run id={self.id!r} status={self.status!r} lineups={self.num_lineups}>"

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "slate_id": self.slate_id,
            "status": self.status,
            "num_lineups": self.num_lineups,
            "settings": self.get_settings(),
            "error_message": self.error_message,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
        }
