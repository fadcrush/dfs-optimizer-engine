"""
Lineup model — one optimizer-generated lineup within a Run.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import Column, DateTime, Float, ForeignKey, Index, Integer, String
from sqlalchemy.orm import relationship

from models.base import DFSBase


def _utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


class Lineup(DFSBase):
    """One DFS lineup produced by a single optimizer run."""

    __tablename__ = "lineups"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))

    run_id = Column(
        String, ForeignKey("runs.id", ondelete="CASCADE"), nullable=False
    )

    lineup_number = Column(Integer, nullable=False)   # 1-based index within the run
    total_salary = Column(Integer, default=0)
    total_projection = Column(Float, default=0.0)

    created_at = Column(DateTime, default=_utcnow)

    # Relationships
    run = relationship("Run", back_populates="lineups")
    entries = relationship(
        "LineupEntry",
        back_populates="lineup",
        cascade="all, delete-orphan",
        lazy="selectin",
    )

    __table_args__ = (
        Index("ix_lineups_run_id", "run_id"),
    )

    def __repr__(self) -> str:
        return (
            f"<Lineup #{self.lineup_number} run={self.run_id!r} "
            f"proj={self.total_projection:.2f} salary={self.total_salary}>"
        )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "run_id": self.run_id,
            "lineup_number": self.lineup_number,
            "total_salary": self.total_salary,
            "total_projection": self.total_projection,
        }
