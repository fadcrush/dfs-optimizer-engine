"""
LineupEntry model — one player slot within a Lineup.

slate_id is denormalised here (it can be derived from lineup→run→slate)
to allow fast single-table exposure queries across an entire slate without
multiple joins.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import Column, DateTime, ForeignKey, Index, String
from sqlalchemy.orm import relationship

from models.base import DFSBase


def _utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


class LineupEntry(DFSBase):
    """Association between a Lineup and a Player (one slot)."""

    __tablename__ = "lineup_entries"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))

    lineup_id = Column(
        String, ForeignKey("lineups.id", ondelete="CASCADE"), nullable=False
    )
    player_id = Column(
        String, ForeignKey("slate_players.id"), nullable=False
    )

    # Denormalised for fast exposure queries — avoids join through lineups→runs
    slate_id = Column(String, nullable=True)

    # Roster slot (PG, SG, SF, PF, C, FLEX, G, F, UTIL, etc.)
    position = Column(String, nullable=True)

    created_at = Column(DateTime, default=_utcnow)

    # Relationships
    lineup = relationship("Lineup", back_populates="entries")
    player = relationship("Player", back_populates="lineup_entries")

    __table_args__ = (
        Index("ix_lineup_entries_lineup_id", "lineup_id"),
        Index("ix_lineup_entries_player_id", "player_id"),
        Index("ix_lineup_entries_slate_id", "slate_id"),
    )

    def __repr__(self) -> str:
        return (
            f"<LineupEntry lineup={self.lineup_id!r} "
            f"player={self.player_id!r} pos={self.position!r}>"
        )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "lineup_id": self.lineup_id,
            "player_id": self.player_id,
            "slate_id": self.slate_id,
            "position": self.position,
        }
