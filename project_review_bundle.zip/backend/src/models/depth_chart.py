"""
Depth chart models (stub).

TeamDepthChart and NBAPosition were referenced in the signals propagation
module.  This stub file satisfies imports while the full depth-chart pipeline
is implemented in a later phase.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional


class NBAPosition(str, Enum):
    """NBA roster positions."""
    PG = "PG"
    SG = "SG"
    SF = "SF"
    PF = "PF"
    C = "C"
    UTIL = "UTIL"


@dataclass
class DepthSlot:
    """A single depth-chart slot for a player at a position."""
    player_id: str
    name: str
    depth: int  # 1 = starter, 2 = first backup, …
    position: NBAPosition


@dataclass
class TeamDepthChart:
    """Depth chart for one team."""
    team_abbr: str
    slots: Dict[NBAPosition, List[DepthSlot]] = field(default_factory=dict)

    def get_starter(self, position: NBAPosition) -> Optional[DepthSlot]:
        """Return the starter at *position*, or None if unknown."""
        slots = self.slots.get(position, [])
        starters = [s for s in slots if s.depth == 1]
        return starters[0] if starters else None

    def get_backups(self, position: NBAPosition, depth_limit: int = 3) -> List[DepthSlot]:
        """Return backup players at *position* up to *depth_limit*."""
        slots = self.slots.get(position, [])
        return [s for s in slots if s.depth > 1 and s.depth <= depth_limit]
