"""
Projection model — per-player fantasy point projections within a slate.

One row per (slate_id, player_id) pair.  Updated in-place when the user
re-uploads projections for the same slate.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import (
    Column, DateTime, Float, ForeignKey, Index, String, UniqueConstraint
)
from sqlalchemy.orm import relationship

from models.base import DFSBase


def _utcnow() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


class Projection(DFSBase):
    """Fantasy-point projection + metadata for (slate, player)."""

    __tablename__ = "projections"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))

    slate_id = Column(
        String, ForeignKey("slates.id", ondelete="CASCADE"), nullable=False
    )
    player_id = Column(
        String,
        ForeignKey("slate_players.id", ondelete="CASCADE"),
        nullable=False,
    )

    # Projection figures
    projection = Column(Float, default=0.0)
    floor = Column(Float, default=0.0)
    ceiling = Column(Float, default=0.0)
    value = Column(Float, default=0.0)   # pts / $1000 salary

    # Optional enrichment
    injury_status = Column(String, nullable=True)   # OUT, Q, PROBABLE, etc.
    ownership_pct = Column(Float, nullable=True)     # from ownership upload

    created_at = Column(DateTime, default=_utcnow)

    # Relationships
    player = relationship("Player", back_populates="projection")

    __table_args__ = (
        UniqueConstraint("slate_id", "player_id", name="uq_projection_slate_player"),
        Index("ix_projections_slate_id", "slate_id"),
        Index("ix_projections_player_id", "player_id"),
    )

    def __repr__(self) -> str:
        return (
            f"<Projection id={self.id!r} projection={self.projection} "
            f"ownership={self.ownership_pct}>"
        )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "slate_id": self.slate_id,
            "player_id": self.player_id,
            "projection": self.projection,
            "floor": self.floor,
            "ceiling": self.ceiling,
            "value": self.value,
            "injury_status": self.injury_status,
            "ownership_pct": self.ownership_pct,
        }
