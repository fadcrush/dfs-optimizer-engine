"""
Shared declarative base for all DFS core models.

The existing User model keeps its own separate Base for backwards
compatibility.  All new DFS schema models (slates, players, projections,
ownership, runs, lineups, lineup_entries) use DFSBase so their metadata
is managed together by Alembic.
"""

from sqlalchemy import MetaData
from sqlalchemy.orm import declarative_base

# Deterministic constraint / index names.
# Alembic autogenerate uses these templates so that generated migrations are
# identical regardless of the developer's local SQLAlchemy version.
NAMING_CONVENTION: dict = {
    "ix": "ix_%(table_name)s_%(column_0_name)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}

DFSBase = declarative_base(metadata=MetaData(naming_convention=NAMING_CONVENTION))
