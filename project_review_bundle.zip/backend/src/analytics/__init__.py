"""
Analytics module — exposure tracking and post-run reporting.

Provides three public functions consumed by optimizer_service.py and the
results router:

  build_lineup_analytics(lineups, players, run_id, ...)
      Compute per-player exposure from a completed optimizer run.

  save_analytics_report(analytics, run_id=None, output_dir=None)
      Persist the analytics dict as JSON under outputs/.

  get_analytics_report(run_id)
      Load and return a previously saved analytics dict, or None.
"""

from __future__ import annotations

import json
import logging
from collections import Counter
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# Canonical outputs directory: backend/src/outputs/
# Using __file__ makes this path independent of the working directory.
_OUTPUTS_DIR: Path = Path(__file__).resolve().parent.parent / "outputs"

# Structured run-file directory: backend/src/outputs/runs/
# Each completed optimizer run writes {run_id}.json here with the
# full player-stats schema consumed by GET /api/results/{run_id}/exposure.
_RUNS_DIR: Path = _OUTPUTS_DIR / "runs"


# ---------------------------------------------------------------------------
# Public helpers
# ---------------------------------------------------------------------------

def build_lineup_analytics(
    lineups: List[Dict[str, Any]],
    players: Optional[Dict[str, Dict[str, Any]]] = None,
    run_id: Optional[str] = None,
    slate_id: Optional[str] = None,
    **_kwargs: Any,
) -> Dict[str, Any]:
    """
    Compute per-player exposure for *lineups*.

    Parameters
    ----------
    lineups:
        List of lineup dicts.  Two formats are accepted:

        *Compact format* (from optimizer_service):
            ``{"player_ids": ["id1", "id2", ...], "total_salary": 60000}``

        *Flat format* (legacy / direct calls):
            ``{"PG": "name1", "SG": "name2", ...}``  — any string values are
            treated as player identifiers.

    players:
        Optional metadata dict keyed by player_id → dict with any of:
        ``name``, ``team``, ``position``, ``salary``, ``projection``.
        Used to enrich the per-player exposure rows.

    run_id:
        Unique identifier for this optimizer run.

    Returns
    -------
    dict with keys ``run_id``, ``total_lineups``, ``exposure``.
    Each exposure row contains: ``player``, ``player_id``, ``count``,
    ``pct``, ``avg_projection``, ``salary``, ``team``, ``position``.
    """
    players = players or {}
    total = max(len(lineups), 1)

    # Accumulate player IDs across all lineups
    all_player_ids: List[str] = []
    for lu in lineups:
        if "player_ids" in lu:
            # Compact format: explicit list
            all_player_ids.extend(lu["player_ids"])
        else:
            # Flat format: grab any non-empty string values
            for v in lu.values():
                if isinstance(v, str) and v.strip():
                    all_player_ids.append(v.strip())

    counts: Counter[str] = Counter(all_player_ids)

    exposure: List[Dict[str, Any]] = []
    for player_id, count in counts.most_common():
        meta = players.get(player_id, {})
        exposure.append({
            "player": meta.get("name") or player_id,
            "player_id": player_id,
            "count": count,
            "pct": round(count / total, 4),
            "avg_projection": round(float(meta.get("projection", 0.0)), 2),
            "salary": int(meta.get("salary", 0)),
            "team": meta.get("team", ""),
            "position": meta.get("position", ""),
        })

    return {
        "run_id": run_id or "",
        "slate_id": slate_id or "",
        "total_lineups": len(lineups),
        "exposure": exposure,
    }


def save_analytics_report(
    analytics: Dict[str, Any],
    run_id: Optional[str] = None,
    output_dir: Optional[Path] = None,
) -> Optional[Path]:
    """
    Persist *analytics* as ``outputs/analytics_{run_id}.json``.

    *run_id* may be omitted when the ``run_id`` key is already present in the
    analytics dict (the common case when called from optimizer_service.py).

    Returns the written ``Path``, or ``None`` on failure.
    """
    effective_run_id = run_id or analytics.get("run_id") or "unknown"
    effective_dir = output_dir if output_dir is not None else _OUTPUTS_DIR

    try:
        effective_dir.mkdir(parents=True, exist_ok=True)
        out_path = effective_dir / f"analytics_{effective_run_id}.json"
        out_path.write_text(json.dumps(analytics, indent=2), encoding="utf-8")
        logger.info("Analytics saved → %s", out_path)
        return out_path
    except Exception as exc:  # noqa: BLE001
        logger.warning("Could not save analytics report: %s", exc)
        return None


def get_analytics_report(
    run_id: str,
    output_dir: Optional[Path] = None,
) -> Optional[Dict[str, Any]]:
    """
    Load a previously saved analytics report by *run_id*.

    Returns the parsed dict, or ``None`` if the file does not exist.
    """
    effective_dir = output_dir if output_dir is not None else _OUTPUTS_DIR
    candidate = effective_dir / f"analytics_{run_id}.json"

    if not candidate.exists():
        return None

    try:
        return json.loads(candidate.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        logger.warning("Could not load analytics report %s: %s", candidate, exc)
        return None


# ---------------------------------------------------------------------------
# Structured run-file persistence  (new schema — outputs/runs/{run_id}.json)
# ---------------------------------------------------------------------------

def save_run_file(
    run_id: str,
    lineups: List[Dict[str, Any]],
    players: Optional[Dict[str, Dict[str, Any]]] = None,
    output_dir: Optional[Path] = None,
) -> Optional[Path]:
    """
    Build per-player exposure stats and persist to ``outputs/runs/{run_id}.json``.

    This mirrors ``save_analytics_report`` but writes the **new** schema that
    the ``GET /api/results/{run_id}/exposure`` endpoint consumes:

    .. code-block:: json

        {
          "run_id": "run_20260219_...",
          "total_lineups": 150,
          "players": [
            {
              "player_id": "LeBron James",
              "name": "LeBron James",
              "team": "LAL",
              "position": "SF",
              "salary": 10500,
              "count": 45,
              "exposure_pct": 0.3,
              "avg_projection": 52.4,
              "leverage": null
            }
          ]
        }

    ``leverage`` is left as ``null`` here; it can be patched in by a separate
    ownership-comparison step once DraftKings ownership data is available.

    Returns the written :class:`~pathlib.Path`, or ``None`` on failure.
    """
    analytics = build_lineup_analytics(lineups, players=players, run_id=run_id)

    run_data: Dict[str, Any] = {
        "run_id": run_id,
        "total_lineups": analytics["total_lineups"],
        "players": [
            {
                "player_id": row["player_id"],
                "name": row["player"],
                "team": row.get("team", ""),
                "position": row.get("position", ""),
                "salary": int(row.get("salary", 0)),
                "count": int(row["count"]),
                "exposure_pct": float(row["pct"]),
                "avg_projection": float(row.get("avg_projection", 0.0)),
                "leverage": None,  # populated externally when ownership data is available
            }
            for row in analytics.get("exposure", [])
        ],
    }

    effective_dir = output_dir if output_dir is not None else _RUNS_DIR
    try:
        effective_dir.mkdir(parents=True, exist_ok=True)
        out_path = effective_dir / f"{run_id}.json"
        out_path.write_text(json.dumps(run_data, indent=2), encoding="utf-8")
        logger.info("Run file saved \u2192 %s", out_path)
        return out_path
    except Exception as exc:  # noqa: BLE001
        logger.warning("Could not save run file: %s", exc)
        return None


def get_run_file(
    run_id: str,
    output_dir: Optional[Path] = None,
) -> Optional[Dict[str, Any]]:
    """
    Load a run file from ``outputs/runs/{run_id}.json``.

    Returns the parsed dict, or ``None`` if the file does not exist.
    """
    effective_dir = output_dir if output_dir is not None else _RUNS_DIR
    candidate = effective_dir / f"{run_id}.json"

    if not candidate.exists():
        return None

    try:
        return json.loads(candidate.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        logger.warning("Could not load run file %s: %s", candidate, exc)
        return None
