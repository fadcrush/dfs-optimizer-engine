"""Schema drift handling - detect and handle missing/extra columns."""

import logging
from typing import Dict, List, Any, Optional

logger = logging.getLogger(__name__)


class SchemaDrift:
    """
    Detects and handles schema drift (columns appearing/disappearing).
    
    Stores schema history for debugging and auditing.
    """
    
    def __init__(self):
        self.seen_schemas: Dict[str, set] = {}  # table -> set of columns
        self.drift_events: List[Dict[str, Any]] = []
    
    def register_schema(self, table: str, columns: set) -> bool:
        """
        Register a schema and detect drift.
        
        Args:
            table: Table name
            columns: Set of column names from record/batch
            
        Returns:
            True if schema is new or matches existing, False if drift detected
        """
        if table not in self.seen_schemas:
            # First time seeing this table
            self.seen_schemas[table] = columns
            logger.info(f"Registered schema for {table}: {columns}")
            return True
        
        existing = self.seen_schemas[table]
        
        if columns == existing:
            # Schema matches
            return True
        
        # Schema drift detected
        extra_cols = columns - existing
        missing_cols = existing - columns
        
        drift_event = {
            "table": table,
            "extra_columns": list(extra_cols),
            "missing_columns": list(missing_cols),
        }
        self.drift_events.append(drift_event)
        
        logger.warning(f"Schema drift detected for {table}: +{extra_cols} -{missing_cols}")
        
        # Update seen schema to be union
        self.seen_schemas[table] = existing | columns
        
        return False
    
    def detect_drift_in_batch(
        self,
        table: str,
        records: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """
        Detect schema drift in a batch of records.
        
        Args:
            table: Table name
            records: Records to check
            
        Returns:
            Drift report dict
        """
        if not records:
            return {"drift_detected": False, "drift_events": []}
        
        report = {
            "drift_detected": False,
            "drift_events": [],
            "columns_by_record": {},
            "union_columns": set(),
            "intersection_columns": set(),
        }
        
        if not records:
            return report
        
        # Get columns from each record
        all_columns_sets = [set(r.keys()) for r in records]
        
        # Union and intersection
        union_cols = set()
        for cols in all_columns_sets:
            union_cols |= cols
        
        if all_columns_sets:
            intersection_cols = all_columns_sets[0]
            for cols in all_columns_sets[1:]:
                intersection_cols &= cols
        else:
            intersection_cols = set()
        
        report["union_columns"] = list(union_cols)
        report["intersection_columns"] = list(intersection_cols)
        
        # Check if all records have same columns
        if len(set(frozenset(s) for s in all_columns_sets)) > 1:
            report["drift_detected"] = True
            report["columns_by_record"] = {
                i: list(cols) for i, cols in enumerate(all_columns_sets)
            }
        
        # Register with main schema tracker
        if all_columns_sets:
            self.register_schema(table, all_columns_sets[0])
        
        return report
    
    def handle_missing_column(
        self,
        record: Dict[str, Any],
        column: str,
        default_value: Any = None,
    ) -> Dict[str, Any]:
        """
        Handle missing column in record.
        
        Args:
            record: Record with missing column
            column: Column name
            default_value: Default value to use
            
        Returns:
            Updated record
        """
        if column not in record:
            logger.debug(f"Missing column {column} in record, using default: {default_value}")
            record[column] = default_value
        
        return record
    
    def handle_extra_column(
        self,
        record: Dict[str, Any],
        column: str,
        action: str = "preserve",
    ) -> Dict[str, Any]:
        """
        Handle extra column in record.
        
        Args:
            record: Record with extra column
            column: Column name
            action: 'preserve' (keep), 'drop' (remove), 'store' (move to JSON)
            
        Returns:
            Updated record
        """
        if action == "drop":
            if column in record:
                del record[column]
                logger.debug(f"Dropped extra column {column}")
        
        elif action == "store":
            # Move to _extra_columns JSON if present
            if column in record and "_extra_columns" not in record:
                record["_extra_columns"] = {}
            if column in record:
                record["_extra_columns"][column] = record[column]
                del record[column]
                logger.debug(f"Stored extra column {column} to _extra_columns")
        
        # 'preserve' does nothing
        
        return record
    
    def get_drift_report(self) -> Dict[str, Any]:
        """Get summary of all detected schema drift."""
        return {
            "tables_seen": len(self.seen_schemas),
            "drift_events_count": len(self.drift_events),
            "schemas": {
                table: sorted(list(cols))
                for table, cols in self.seen_schemas.items()
            },
            "drift_events": self.drift_events,
        }


# Singleton instance
_drift_tracker = None


def get_drift_tracker() -> SchemaDrift:
    """Get or create the drift tracker singleton."""
    global _drift_tracker
    if _drift_tracker is None:
        _drift_tracker = SchemaDrift()
    return _drift_tracker
