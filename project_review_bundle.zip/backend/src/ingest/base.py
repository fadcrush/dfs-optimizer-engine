"""Base connector interface for all data sources."""

import logging
from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional
from datetime import datetime

from core import get_utc_now

logger = logging.getLogger(__name__)


class BaseConnector(ABC):
    """
    Abstract base class for all data connectors.
    
    Ensures consistent interface for ingesting from various sources:
    - DFS site CSVs (FD, DK)
    - API endpoints (NBA, NFL)
    - Contest results
    - Injury reports
    """
    
    def __init__(self, name: str, league: str):
        """
        Initialize connector.
        
        Args:
            name: Connector name (e.g., "FanDuelCSV", "DraftKingsCSV")
            league: League (NBA, NFL)
        """
        self.name = name
        self.league = league
        self.logger = logging.getLogger(f"ingest.{name}")
    
    @abstractmethod
    def ingest(self, source: Any) -> List[Dict[str, Any]]:
        """
        Ingest data from source and return list of records.
        
        Args:
            source: Source data (file path, API endpoint, etc.)
            
        Returns:
            List of record dictionaries
            
        Raises:
            IngestionError if ingestion fails
        """
        pass
    
    @abstractmethod
    def validate(self, record: Dict[str, Any]) -> List[str]:
        """
        Validate a record against expected schema.
        
        Args:
            record: Record to validate
            
        Returns:
            List of validation errors (empty if valid)
        """
        pass
    
    @abstractmethod
    def transform(self, record: Dict[str, Any]) -> Dict[str, Any]:
        """
        Transform raw record to canonical format.
        
        Args:
            record: Raw record from source
            
        Returns:
            Transformed record
        """
        pass
    
    def ingest_and_validate(self, source: Any) -> tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
        """
        Ingest data and validate records.
        
        Args:
            source: Source data
            
        Returns:
            Tuple of (valid_records, invalid_records)
        """
        self.logger.info(f"Starting ingestion from {source}")
        
        try:
            raw_records = self.ingest(source)
            self.logger.info(f"Ingested {len(raw_records)} raw records")
        except Exception as e:
            self.logger.error(f"Ingestion failed: {str(e)}")
            raise
        
        valid = []
        invalid = []
        
        for i, record in enumerate(raw_records):
            errors = self.validate(record)
            
            if errors:
                invalid.append({
                    "record_index": i,
                    "record": record,
                    "errors": errors,
                })
                self.logger.warning(f"Record {i} invalid: {errors}")
            else:
                try:
                    transformed = self.transform(record)
                    valid.append(transformed)
                except Exception as e:
                    invalid.append({
                        "record_index": i,
                        "record": record,
                        "errors": [f"Transform error: {str(e)}"],
                    })
                    self.logger.warning(f"Record {i} transform failed: {str(e)}")
        
        self.logger.info(
            f"Validation complete: {len(valid)} valid, {len(invalid)} invalid"
        )
        
        return valid, invalid


class CSVConnector(BaseConnector):
    """Base connector for CSV sources."""
    
    def __init__(self, name: str, league: str):
        super().__init__(name, league)
        self.required_columns: List[str] = []
        self.optional_columns: List[str] = []
    
    def ingest(self, csv_file: str) -> List[Dict[str, Any]]:
        """
        Ingest CSV file.
        
        Args:
            csv_file: Path to CSV file
            
        Returns:
            List of row dictionaries
        """
        import csv
        from pathlib import Path
        
        file_path = Path(csv_file)
        if not file_path.exists():
            raise FileNotFoundError(f"CSV file not found: {csv_file}")
        
        records = []
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    # Remove None values and empty strings
                    cleaned = {k: v for k, v in row.items() if v is not None and v != ""}
                    records.append(cleaned)
        except Exception as e:
            self.logger.error(f"CSV parsing failed: {str(e)}")
            raise
        
        return records
    
    def validate(self, record: Dict[str, Any]) -> List[str]:
        """
        Validate record has required columns.
        
        Args:
            record: Record to validate
            
        Returns:
            List of validation errors
        """
        errors = []
        
        # Check required columns
        for col in self.required_columns:
            if col not in record:
                errors.append(f"Missing required column: {col}")
        
        # Check for unexpected columns (schema drift)
        expected = set(self.required_columns) | set(self.optional_columns)
        unexpected = set(record.keys()) - expected
        if unexpected:
            self.logger.debug(f"Unexpected columns (schema drift): {unexpected}")
        
        return errors


class APIConnector(BaseConnector):
    """Base connector for API sources."""
    
    def __init__(self, name: str, league: str):
        super().__init__(name, league)
        self.session = None
    
    def close(self):
        """Close HTTP session."""
        if self.session:
            self.session.close()
