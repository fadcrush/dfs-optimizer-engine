"""DraftKings DFS CSV connector."""

import logging
from typing import Dict, List, Any
from datetime import datetime

from core import DFS_SITE, get_utc_now
from .base import CSVConnector

logger = logging.getLogger(__name__)


class DraftKingsConnector(CSVConnector):
    """
    Connector for DraftKings DFS slate CSVs.
    
    Parses DraftKings player export files and normalizes to canonical format.
    """
    
    def __init__(self, league: str = "NBA"):
        super().__init__("DraftKingsCSV", league)
        
        # DraftKings CSV columns (may vary)
        self.required_columns = [
            "ID",
            "First Name",
            "Last Name",
            "Salary",
            "Game",
            "Position",
        ]
        
        self.optional_columns = [
            "Injury Indicator",
            "Injury Details",
            "Tier",
            "Played",
            "Salary Change",
            "Avg Points",
            "Injury",
        ]
    
    def ingest(self, csv_file: str) -> List[Dict[str, Any]]:
        """Ingest DraftKings CSV file."""
        return super().ingest(csv_file)
    
    def validate(self, record: Dict[str, Any]) -> List[str]:
        """Validate DraftKings record."""
        errors = super().validate(record)
        
        # DraftKings-specific validation
        try:
            salary = int(record.get("Salary", 0))
            if salary < 3000 or salary > 15000:
                errors.append(f"Salary {salary} out of reasonable range")
        except (ValueError, TypeError):
            errors.append(f"Invalid salary: {record.get('Salary')}")
        
        # Validate position
        valid_positions = ["PG", "SG", "SF", "PF", "C", "G", "F", "UTIL", "MVP", "CPT"]
        if record.get("Position") not in valid_positions:
            errors.append(f"Invalid position: {record.get('Position')}")
        
        return errors
    
    def transform(self, record: Dict[str, Any]) -> Dict[str, Any]:
        """
        Transform DraftKings record to canonical format.
        
        Maps DraftKings column names to internal canonical names.
        """
        site_player_id = f"DK_{record.get('ID', '')}"
        
        # Parse game code (format may vary)
        game_info = record.get("Game", "")
        game_code = game_info.split()[0] if game_info else ""
        
        # Handle injury indicators
        injury_status = None
        injury_details = record.get("Injury Details", "").strip()
        
        if "Injury Indicator" in record:
            injury_status = record.get("Injury Indicator", "").strip() or None
        elif "Injury" in record:
            # Some exports use "Injury" column
            injury_text = record.get("Injury", "").strip()
            if injury_text:
                injury_status = injury_text.split()[0] if injury_text else None
        
        return {
            "site_player_id": site_player_id,
            "site": DFS_SITE.DRAFTKINGS,
            "player_id": record.get("ID"),
            "first_name": record.get("First Name", "").strip(),
            "last_name": record.get("Last Name", "").strip(),
            "position": record.get("Position", "").strip(),
            "salary": int(record.get("Salary", 0)),
            "game": game_code,
            "team": self._extract_team_from_game(game_code),
            "opponent": self._extract_opponent_from_game(game_code),
            "injury_status": injury_status,
            "injury_details": injury_details or None,
            "played": record.get("Played", "").lower() == "true",
            "salary_change": int(record.get("Salary Change", 0)) or 0,
            "avg_points": float(record.get("Avg Points", 0)) or 0.0,
            "tier": record.get("Tier", "").strip() or None,
            "ingested_at": get_utc_now().isoformat(),
        }
    
    @staticmethod
    def _extract_team_from_game(game_code: str) -> str:
        """Extract team code from game code (e.g., 'LAL' from 'BOS-LAL')."""
        if "-" in game_code:
            parts = game_code.split("-")
            if len(parts) >= 2:
                return parts[1].strip()
        return ""
    
    @staticmethod
    def _extract_opponent_from_game(game_code: str) -> str:
        """Extract opponent code from game code."""
        if "-" in game_code:
            parts = game_code.split("-")
            if len(parts) >= 1:
                return parts[0].strip()
        return ""
    
    def parse_slate_info_from_filename(self, filename: str) -> Dict[str, Any]:
        """
        Parse slate info from DraftKings filename.
        
        Example: "DraftKings-NBA-2026-01-05-Main-players-list.csv"
        Returns: {
            'league': 'NBA',
            'slate_date': '2026-01-05',
            'slate_type': 'Main',
        }
        """
        import re
        
        # Common patterns for DraftKings filenames
        # Pattern 1: DraftKings-LEAGUE-YYYY-MM-DD-TYPE
        pattern1 = r"DraftKings-(\w+)-(\d{4})-(\d{2})-(\d{2})-(\w+)"
        match = re.search(pattern1, filename)
        
        if match:
            league, year, month, day, slate_type = match.groups()
            try:
                slate_date = f"{year}-{month}-{day}"
                return {
                    "league": league,
                    "slate_date": slate_date,
                    "slate_type": slate_type,
                    "site": "DraftKings",
                }
            except Exception as e:
                logger.error(f"Error parsing date: {str(e)}")
        
        # Pattern 2: DraftKings_LEAGUE_YYYYMMDD
        pattern2 = r"DraftKings[_-](\w+)[_-](\d{4})(\d{2})(\d{2})"
        match = re.search(pattern2, filename)
        
        if match:
            league, year, month, day = match.groups()
            try:
                slate_date = f"{year}-{month}-{day}"
                return {
                    "league": league,
                    "slate_date": slate_date,
                    "slate_type": "Main",
                    "site": "DraftKings",
                }
            except Exception as e:
                logger.error(f"Error parsing date: {str(e)}")
        
        logger.warning(f"Could not parse DraftKings filename: {filename}")
        return {}
