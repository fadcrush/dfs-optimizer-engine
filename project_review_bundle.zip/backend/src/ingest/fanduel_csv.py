"""FanDuel DFS CSV connector."""

import logging
from typing import Dict, List, Any
from datetime import datetime

from core import DFS_SITE, get_utc_now
from .base import CSVConnector
from .idempotency import IdempotencyKey

logger = logging.getLogger(__name__)


class FanDuelConnector(CSVConnector):
    """
    Connector for FanDuel DFS slate CSVs.
    
    Parses FanDuel player export files and normalizes to canonical format.
    """
    
    def __init__(self, league: str = "NBA"):
        super().__init__("FanDuelCSV", league)
        
        # FanDuel CSV columns
        self.required_columns = [
            "Id",
            "First Name",
            "Last Name",
            "Position",
            "Salary",
            "Game",
            "Injury Indicator",
            "Injury Details",
            "Played",
            "Salary Change",
            "Game Info",
            "Link",
        ]
        
        self.optional_columns = [
            "Times Played",
            "Avg Points",
        ]
    
    def ingest(self, csv_file: str) -> List[Dict[str, Any]]:
        """Ingest FanDuel CSV file."""
        return super().ingest(csv_file)
    
    def validate(self, record: Dict[str, Any]) -> List[str]:
        """Validate FanDuel record."""
        errors = super().validate(record)
        
        # Additional FanDuel-specific validation
        try:
            salary = int(record.get("Salary", 0))
            if salary < 3000 or salary > 12000:
                errors.append(f"Salary {salary} out of reasonable range")
        except (ValueError, TypeError):
            errors.append(f"Invalid salary: {record.get('Salary')}")
        
        # Validate position
        valid_positions = ["PG", "SG", "SF", "PF", "C", "G", "F", "UTIL"]
        if record.get("Position") not in valid_positions:
            errors.append(f"Invalid position: {record.get('Position')}")
        
        return errors
    
    def transform(self, record: Dict[str, Any]) -> Dict[str, Any]:
        """
        Transform FanDuel record to canonical format.
        
        Maps FanDuel column names to internal canonical names.
        """
        site_player_id = f"FD_{record.get('Id', '')}"
        
        # Parse game code (e.g., "BOS@LAL 10:30PM ET")
        game_info = record.get("Game Info", "")
        game_code = game_info.split()[0] if game_info else ""
        
        return {
            "site_player_id": site_player_id,
            "site": DFS_SITE.FANDUEL,
            "player_id": record.get("Id"),
            "first_name": record.get("First Name", "").strip(),
            "last_name": record.get("Last Name", "").strip(),
            "position": record.get("Position", "").strip(),
            "salary": int(record.get("Salary", 0)),
            "game": game_code,
            "team": self._extract_team_from_game(game_code),
            "opponent": self._extract_opponent_from_game(game_code),
            "injury_status": record.get("Injury Indicator", "").strip() or None,
            "injury_details": record.get("Injury Details", "").strip() or None,
            "played": record.get("Played", "").lower() == "true",
            "salary_change": int(record.get("Salary Change", 0)) or 0,
            "avg_points": float(record.get("Avg Points", 0)) or 0.0,
            "ingested_at": get_utc_now().isoformat(),
        }
    
    @staticmethod
    def _extract_team_from_game(game_code: str) -> str:
        """Extract team code from game code (e.g., 'LAL' from 'BOS@LAL')."""
        if "@" in game_code:
            return game_code.split("@")[1].strip()
        return ""
    
    @staticmethod
    def _extract_opponent_from_game(game_code: str) -> str:
        """Extract opponent code from game code."""
        if "@" in game_code:
            return game_code.split("@")[0].strip()
        return ""
    
    def parse_slate_info_from_filename(self, filename: str) -> Dict[str, Any]:
        """
        Parse slate info from FanDuel filename.
        
        Example: "FanDuel-NBA-2026 EST-01 EST-05 EST-125225-players-list.csv"
        Returns: {
            'league': 'NBA',
            'slate_date': '2026-01-05',
            'slate_type': 'Main',
            'contest_id': '125225',
        }
        """
        import re
        from datetime import datetime
        
        # Pattern: FanDuel-LEAGUE-DATE TIME TIME CONTEST_ID-players-list.csv
        pattern = r"FanDuel-(\w+)-(\d{4})\s+(\w+)-(\d{2})\s+(\w+)-(\d{2})\s+(\w+)-(\d+)-players"
        match = re.search(pattern, filename)
        
        if not match:
            logger.warning(f"Could not parse FanDuel filename: {filename}")
            return {}
        
        league, year, tz1, month, tz2, day, tz3, contest_id = match.groups()
        
        try:
            slate_date = datetime(int(year), int(month), int(day)).date()
            return {
                "league": league,
                "slate_date": str(slate_date),
                "slate_type": "Main",
                "contest_id": contest_id,
                "site": "FanDuel",
            }
        except Exception as e:
            logger.error(f"Error parsing date from filename: {str(e)}")
            return {}
