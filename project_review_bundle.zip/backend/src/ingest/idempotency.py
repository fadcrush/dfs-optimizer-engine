"""Idempotency and deduplication utilities."""

import hashlib
import json
import logging
from typing import Any, Dict

logger = logging.getLogger(__name__)


class IdempotencyKey:
    """Generates and validates idempotency keys."""
    
    @staticmethod
    def generate_from_dict(data: Dict[str, Any]) -> str:
        """
        Generate idempotency key from dictionary.
        
        Uses SHA256 hash of JSON representation for deterministic hashing.
        
        Args:
            data: Dictionary to hash
            
        Returns:
            SHA256 hex digest
        """
        # Use sorted JSON for deterministic hashing
        json_str = json.dumps(data, sort_keys=True, default=str)
        return hashlib.sha256(json_str.encode()).hexdigest()
    
    @staticmethod
    def generate_from_file(file_path: str, chunk_size: int = 8192) -> str:
        """
        Generate idempotency key from file content.
        
        Uses SHA256 hash of file contents.
        
        Args:
            file_path: Path to file
            chunk_size: Bytes to read per chunk
            
        Returns:
            SHA256 hex digest
        """
        sha256 = hashlib.sha256()
        
        try:
            with open(file_path, 'rb') as f:
                while chunk := f.read(chunk_size):
                    sha256.update(chunk)
            return sha256.hexdigest()
        except Exception as e:
            logger.error(f"Error generating file hash: {str(e)}")
            raise
    
    @staticmethod
    def generate_from_csv_row(row: Dict[str, Any]) -> str:
        """
        Generate idempotency key from CSV row.
        
        Args:
            row: Row dictionary
            
        Returns:
            SHA256 hex digest
        """
        return IdempotencyKey.generate_from_dict(row)


class DeduplicateCheck:
    """Check for duplicate records in database."""
    
    def __init__(self, connection):
        """
        Initialize deduplication checker.
        
        Args:
            connection: SQLAlchemy database connection
        """
        self.connection = connection
    
    def is_duplicate(
        self,
        table: str,
        hash_column: str,
        hash_value: str,
    ) -> bool:
        """
        Check if record with hash already exists.
        
        Args:
            table: Table name
            hash_column: Hash column name (e.g., 'file_hash')
            hash_value: Hash value to check
            
        Returns:
            True if duplicate exists
        """
        from sqlalchemy import text
        
        query = f"SELECT COUNT(*) as cnt FROM {table} WHERE {hash_column} = :hash"
        
        result = self.connection.execute(
            text(query),
            {"hash": hash_value}
        )
        
        row = result.first()
        return row.cnt > 0 if row else False
    
    def get_duplicate_details(
        self,
        table: str,
        hash_column: str,
        hash_value: str,
    ) -> Dict[str, Any]:
        """
        Get details of existing duplicate record.
        
        Args:
            table: Table name
            hash_column: Hash column name
            hash_value: Hash value
            
        Returns:
            Duplicate record details
        """
        from sqlalchemy import text
        
        query = f"SELECT * FROM {table} WHERE {hash_column} = :hash LIMIT 1"
        
        result = self.connection.execute(
            text(query),
            {"hash": hash_value}
        )
        
        row = result.first()
        return dict(row._mapping) if row else None


class IdempotentWriter:
    """
    Writes records idempotently using hash-based deduplication.
    
    Ensures that re-running ingestion doesn't create duplicates.
    """
    
    def __init__(self, connection):
        """
        Initialize writer.
        
        Args:
            connection: SQLAlchemy database connection
        """
        self.connection = connection
        self.dedup = DeduplicateCheck(connection)
        self.logger = logging.getLogger(__name__)
    
    def write_record(
        self,
        table: str,
        record: Dict[str, Any],
        hash_column: str,
        hash_value: str,
    ) -> tuple[bool, str]:
        """
        Write record idempotently.
        
        Args:
            table: Target table
            record: Record to insert
            hash_column: Hash column name
            hash_value: Hash value for deduplication
            
        Returns:
            Tuple of (success, message)
        """
        from sqlalchemy import text
        
        # Check for duplicate
        if self.dedup.is_duplicate(table, hash_column, hash_value):
            self.logger.debug(f"Skipping duplicate in {table} with hash {hash_value[:8]}...")
            return False, "Duplicate skipped (idempotent)"
        
        # Insert record
        try:
            # Build INSERT statement
            record[hash_column] = hash_value
            columns = ", ".join(record.keys())
            placeholders = ", ".join([f":{k}" for k in record.keys()])
            
            query = f"INSERT INTO {table} ({columns}) VALUES ({placeholders})"
            
            self.connection.execute(
                text(query),
                record
            )
            self.connection.commit()
            
            self.logger.debug(f"Inserted record into {table} with hash {hash_value[:8]}...")
            return True, "Record inserted"
        
        except Exception as e:
            self.connection.rollback()
            self.logger.error(f"Insert failed: {str(e)}")
            return False, f"Insert error: {str(e)}"
    
    def write_records(
        self,
        table: str,
        records: list[Dict[str, Any]],
        hash_column: str,
        hash_generator,
    ) -> Dict[str, Any]:
        """
        Write multiple records idempotently.
        
        Args:
            table: Target table
            records: Records to insert
            hash_column: Hash column name
            hash_generator: Function to generate hash from record
            
        Returns:
            Statistics dict with inserted, skipped, failed counts
        """
        stats = {
            "total": len(records),
            "inserted": 0,
            "skipped": 0,
            "failed": 0,
            "errors": [],
        }
        
        for i, record in enumerate(records):
            try:
                hash_value = hash_generator(record)
                success, msg = self.write_record(
                    table,
                    record.copy(),
                    hash_column,
                    hash_value,
                )
                
                if success:
                    stats["inserted"] += 1
                else:
                    if "Duplicate" in msg:
                        stats["skipped"] += 1
                    else:
                        stats["failed"] += 1
                        stats["errors"].append({"record_index": i, "error": msg})
            
            except Exception as e:
                stats["failed"] += 1
                stats["errors"].append({"record_index": i, "error": str(e)})
        
        self.logger.info(
            f"Write complete: {stats['inserted']} inserted, "
            f"{stats['skipped']} skipped, {stats['failed']} failed"
        )
        
        return stats
