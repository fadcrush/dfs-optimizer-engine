"""Enums and constants for DFS platform."""

from enum import Enum


class LEAGUE(str, Enum):
    """Supported leagues."""
    NBA = "NBA"
    NFL = "NFL"


class POSITION(str, Enum):
    """Supported positions."""
    # NBA
    PG = "PG"  # Point Guard
    SG = "SG"  # Shooting Guard
    SF = "SF"  # Small Forward
    PF = "PF"  # Power Forward
    C = "C"    # Center
    G = "G"    # Guard (either PG or SG)
    F = "F"    # Forward (either SF or PF)
    UTIL = "UTIL"  # Utility (any position)
    
    # NFL
    QB = "QB"    # Quarterback
    RB = "RB"    # Running Back
    WR = "WR"    # Wide Receiver
    TE = "TE"    # Tight End
    K = "K"      # Kicker
    DEF = "DEF"  # Defense


class SIGNAL_TYPE(str, Enum):
    """Types of signals in the system."""
    INJURY_OUT = "injury_out"
    INJURY_IN = "injury_in"
    CONFIRMED_STARTER = "confirmed_starter"
    EXPECTED_STARTER = "expected_starter"
    ROSTER_CHANGE = "roster_change"
    OWNERSHIP_PROJECTION = "ownership_projection"
    MATCHUP_CONTEXT = "matchup_context"
    FATIGUE_SIGNAL = "fatigue_signal"
    DEPTH_CHANGE = "depth_change"
    WEATHER = "weather"
    ODDS_MOVEMENT = "odds_movement"


class DECAY_PROFILE(str, Enum):
    """Signal decay profiles."""
    NONE = "none"           # No decay
    FAST = "fast"           # 15-minute half-life
    MEDIUM = "medium"       # 1-hour half-life
    SLOW = "slow"           # 24-hour half-life


class ENTITY_TYPE(str, Enum):
    """Types of entities in the system."""
    PLAYER = "player"
    GAME = "game"
    SLATE = "slate"
    TEAM = "team"


class SLOT_TYPE(str, Enum):
    """DFS contest slot types."""
    CLASSIC = "classic"           # Standard cash/tournament
    SHOWDOWN = "showdown"         # Single-game contest
    CAPTAIN_MODE = "captain_mode" # 5x salary cap player (FD)
    SUPERSWAP = "superswap"       # Swaptional slots (DK)


class STARTER_STATUS(str, Enum):
    """Starting lineup status."""
    CONFIRMED_STARTER = "confirmed_starter"
    EXPECTED_STARTER = "expected_starter"
    BENCHED = "benched"
    UNKNOWN = "unknown"


class INJURY_STATUS(str, Enum):
    """Injury status codes."""
    OUT = "O"        # Out
    DAY_TO_DAY = "D" # Day-to-day
    PROBABLE = "P"   # Probable (not in use)
    QUESTIONABLE = "Q"  # Questionable
    DOUBTFUL = "D"   # Doubtful
    LIKELY_OUT = "LO"   # Likely out


class DFS_SITE(str, Enum):
    """Supported DFS sites."""
    FANDUEL = "FanDuel"
    DRAFTKINGS = "DraftKings"
    DRAFTKINGS_PLAYBOOK = "DraftKings Playbook"


# Signal application domains
APPLIES_TO_DOMAINS = {
    "minutes",      # Player playing time ceiling/floor
    "usage",        # Opportunity for touches/shot attempts
    "projection",   # Expected fantasy points
    "ownership",    # Contest ownership percentage
    "constraints",  # Lineup building constraints
    "efficiency",   # Points per minute efficiency
}
