"""Custom exceptions for DFS platform."""


class DFSError(Exception):
    """Base exception for all DFS platform errors."""
    pass


class IngestionError(DFSError):
    """Raised when data ingestion fails."""
    pass


class ValidationError(DFSError):
    """Raised when data validation fails."""
    pass


class SignalError(DFSError):
    """Raised when signal processing fails."""
    pass


class ProjectionError(DFSError):
    """Raised when projection building fails."""
    pass


class EvaluationError(DFSError):
    """Raised when evaluation fails."""
    pass


class ConfigError(DFSError):
    """Raised when configuration is invalid."""
    pass


class DatabaseError(DFSError):
    """Raised when database operations fail."""
    pass


class NotFoundError(DFSError):
    """Raised when requested resource is not found."""
    pass


class IdempotencyError(DFSError):
    """Raised when idempotency check fails."""
    pass


class InjuryEnrichmentError(DFSError):
    """
    Raised when external injury-data fetch fails and fail_mode='closed'.

    Attributes
    ----------
    reason : str
        Machine-readable failure code: 'missing_key', 'invalid_key',
        'rate_limited', 'network_failure', or 'unknown'.
    run_id : str | None
        The optimizer run identifier (for traceability in logs / 503 body).
    detail : str
        Human-readable, actionable error message.
    """

    def __init__(self, reason: str, run_id: str | None = None, detail: str = "") -> None:
        self.reason = reason
        self.run_id = run_id
        self.detail = detail
        super().__init__(detail)
