"""
DFS Edge Pro - Core Module

Contains configuration, security, and shared utilities.
"""

from .config import get_settings, Settings, validate_config
from .exceptions import (
    DFSError,
    IngestionError,
    ValidationError,
    SignalError,
    ProjectionError,
    EvaluationError,
    ConfigError,
    DatabaseError,
    NotFoundError,
    IdempotencyError,
)
from .logging import setup_logging, get_logger
from .time_utils import (
    get_utc_now,
    to_utc,
    from_utc,
    duration_to_minutes,
    minutes_to_duration,
    timestamp_seconds_since,
    is_expired,
    calculate_decay_factor,
)
from .constants import (
    LEAGUE,
    POSITION,
    SIGNAL_TYPE,
    DECAY_PROFILE,
    ENTITY_TYPE,
    SLOT_TYPE,
    STARTER_STATUS,
    INJURY_STATUS,
    DFS_SITE,
    APPLIES_TO_DOMAINS,
)

__all__ = [
    # Config
    'get_settings', 'Settings', 'validate_config',
    # Exceptions
    'DFSError', 'IngestionError', 'ValidationError',
    'SignalError', 'ProjectionError', 'EvaluationError',
    'ConfigError', 'DatabaseError', 'NotFoundError', 'IdempotencyError',
    # Logging
    'setup_logging', 'get_logger',
    # Time utils
    'get_utc_now', 'to_utc', 'from_utc', 'duration_to_minutes',
    'minutes_to_duration', 'timestamp_seconds_since', 'is_expired',
    'calculate_decay_factor',
    # Constants
    'LEAGUE', 'POSITION', 'SIGNAL_TYPE', 'DECAY_PROFILE',
    'ENTITY_TYPE', 'SLOT_TYPE', 'STARTER_STATUS', 'INJURY_STATUS',
    'DFS_SITE', 'APPLIES_TO_DOMAINS',
]
