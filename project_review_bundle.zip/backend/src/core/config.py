"""
DFS Edge Pro - Secure Configuration Management

This module provides secure, centralized configuration management using Pydantic.
API keys and secrets should ONLY be loaded from environment variables, never hardcoded.

Usage:
    from core.config import get_settings
    settings = get_settings()
    api_key = settings.odds_api_key
"""

from functools import lru_cache
from typing import Optional
from pathlib import Path
import os

from pydantic_settings import BaseSettings
from pydantic import Field


class Settings(BaseSettings):
    """
    Application settings loaded from environment variables.

    All sensitive values (API keys, secrets) are loaded from .env file
    and should NEVER be hardcoded or committed to source control.
    """

    # =========================================================================
    # Application
    # =========================================================================
    app_name: str = "DFS Edge Pro"
    app_version: str = "1.0.0"
    debug: bool = Field(default=False, description="Enable debug mode")
    log_level: str = Field(default="INFO", description="Logging level")

    # =========================================================================
    # Database
    # =========================================================================
    database_path: str = Field(
        default="data/dfs_master.duckdb",
        description="Path to DuckDB database"
    )
    backup_path: str = Field(
        default="data/backups/",
        description="Path to database backups"
    )
    use_duckdb_fallback: bool = Field(
        default=True,
        description="Use DuckDB as primary database"
    )

    # =========================================================================
    # API Keys (LOADED FROM ENVIRONMENT - NEVER HARDCODE)
    # =========================================================================
    odds_api_key: str = Field(
        default="",
        description="The Odds API key (https://the-odds-api.com/)"
    )
    sportsdata_api_key: str = Field(
        default="",
        description="SportsData.io API key"
    )
    openweather_api_key: str = Field(
        default="",
        description="OpenWeather API key"
    )

    # =========================================================================
    # Security
    # =========================================================================
    secret_key: str = Field(
        default="",
        description="Application secret key for encryption"
    )
    jwt_secret_key: str = Field(
        default="",
        description="JWT token signing key"
    )
    jwt_algorithm: str = "HS256"
    jwt_expire_minutes: int = 60 * 24 * 7  # 1 week

    # =========================================================================
    # API Rate Limits (requests per minute)
    # =========================================================================
    rate_limit_nba_stats: int = Field(default=20, description="NBA Stats API rate limit")
    rate_limit_odds_api: int = Field(default=10, description="The Odds API rate limit")
    rate_limit_openweather: int = Field(default=60, description="OpenWeather rate limit")
    rate_limit_sportsdata: int = Field(default=10, description="SportsData.io rate limit")

    # =========================================================================
    # Paths
    # =========================================================================
    uploads_path: str = Field(default="backend/uploads/", description="Upload directory")
    outputs_path: str = Field(default="outputs/", description="Output directory")
    cache_path: str = Field(default="data/cache/", description="Cache directory")

    # =========================================================================
    # DFS Settings
    # =========================================================================
    default_salary_cap: int = Field(default=60000, description="Default salary cap")
    default_min_salary: int = Field(default=49000, description="Default minimum salary")
    default_max_exposure: float = Field(default=0.35, description="Default max exposure")
    default_num_lineups: int = Field(default=150, description="Default lineup count")

    # =========================================================================
    # Feature Flags
    # =========================================================================
    enable_auto_update: bool = Field(default=True, description="Enable auto data updates")
    enable_pattern_discovery: bool = Field(default=True, description="Enable pattern discovery")
    enable_lineup_optimization: bool = Field(default=True, description="Enable optimizer")

    # =========================================================================
    # Injury Enrichment
    # =========================================================================
    injury_data_required: bool = Field(
        default=False,
        description=(
            "When True, injury-enrichment failures are logged at ERROR level and "
            "a prominent warning about incomplete OUT filtering is emitted. "
            "Should be True in production."
        ),
    )
    injury_data_fail_mode: str = Field(
        default="open",
        description=(
            "How to respond when external injury data cannot be fetched. "
            "'open' = log WARNING and continue (Injury Status set to empty). "
            "'closed' = return HTTP 503 with an actionable error message."
        ),
    )

    # =========================================================================
    # Production safety / infrastructure
    # =========================================================================
    db_required: bool = Field(
        default=False,
        description=(
            "When True, DuckDB/SQLite fallback is disabled and a PostgreSQL "
            "DATABASE_URL is strictly required on startup. "
            "Set to True in production. Disables create_all() auto-migration "
            "so Alembic is the sole schema authority."
        ),
    )
    redis_url: str = Field(
        default="redis://localhost:6379/0",
        description="Redis URL used by Dramatiq async task queue.",
    )
    allowed_origins: str = Field(
        default="http://localhost:3000,http://127.0.0.1:3000",
        description=(
            "Comma-separated list of CORS-allowed origins. "
            "Set to specific domains in production."
        ),
    )

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        extra = "ignore"  # Ignore extra fields in .env

    def validate_api_keys(self) -> dict:
        """
        Validate that required API keys are configured.

        Returns:
            Dict with validation status for each key
        """
        validations = {}

        if self.odds_api_key and len(self.odds_api_key) > 10:
            validations['odds_api'] = True
        else:
            validations['odds_api'] = False

        if self.sportsdata_api_key and len(self.sportsdata_api_key) > 10:
            validations['sportsdata'] = True
        else:
            validations['sportsdata'] = False

        if self.openweather_api_key and len(self.openweather_api_key) > 10:
            validations['openweather'] = True
        else:
            validations['openweather'] = False

        return validations

    def ensure_directories(self) -> None:
        """Create required directories if they don't exist."""
        directories = [
            self.uploads_path,
            self.outputs_path,
            self.cache_path,
            self.backup_path,
            Path(self.database_path).parent,
        ]

        for directory in directories:
            Path(directory).mkdir(parents=True, exist_ok=True)


@lru_cache
def get_settings() -> Settings:
    """
    Get cached application settings.

    Settings are loaded once and cached for the lifetime of the application.
    This ensures consistent configuration and avoids repeated file reads.

    Returns:
        Settings instance
    """
    return Settings()


def validate_config() -> bool:
    """
    Validate the configuration and print status.

    Returns:
        True if all critical settings are valid
    """
    settings = get_settings()
    validations = settings.validate_api_keys()

    print("\n" + "=" * 60)
    print("DFS EDGE PRO - CONFIGURATION STATUS")
    print("=" * 60)

    issues = []

    # Check API keys
    print("\n📡 API Keys:")
    for api_name, is_valid in validations.items():
        status = "✅" if is_valid else "❌"
        print(f"   {status} {api_name}")
        if not is_valid:
            issues.append(f"Missing API key: {api_name}")

    # Check database
    print("\n🗄️  Database:")
    db_path = Path(settings.database_path)
    if db_path.exists():
        print(f"   ✅ {settings.database_path} ({db_path.stat().st_size / 1024 / 1024:.1f} MB)")
    else:
        print(f"   ⚠️  Database not found: {settings.database_path}")

    # Check security
    print("\n🔐 Security:")
    if settings.secret_key and len(settings.secret_key) >= 32:
        print("   ✅ Secret key configured")
    else:
        print("   ⚠️  Secret key not set or too short")
        issues.append("Set SECRET_KEY in .env (min 32 characters)")

    if settings.jwt_secret_key and len(settings.jwt_secret_key) >= 32:
        print("   ✅ JWT secret configured")
    else:
        print("   ⚠️  JWT secret not set or too short")
        issues.append("Set JWT_SECRET_KEY in .env (min 32 characters)")

    print("\n" + "=" * 60)

    if issues:
        print("\n⚠️  CONFIGURATION ISSUES:")
        for issue in issues:
            print(f"   - {issue}")
        print("\nGet free API keys from:")
        print("   - The Odds API: https://the-odds-api.com/")
        print("   - SportsData.io: https://sportsdata.io/")
        print("   - OpenWeather: https://openweathermap.org/api")
        return False
    else:
        print("\n✅ Configuration valid!")
        return True


if __name__ == "__main__":
    validate_config()
