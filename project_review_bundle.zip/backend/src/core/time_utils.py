"""Timezone-safe time utilities."""

from datetime import datetime, timezone, timedelta
from typing import Optional


def get_utc_now() -> datetime:
    """Get current time in UTC as timezone-aware datetime."""
    return datetime.now(timezone.utc)


def to_utc(dt: Optional[datetime]) -> Optional[datetime]:
    """
    Convert any datetime to UTC timezone-aware.
    
    Args:
        dt: Datetime to convert (can be naive or timezone-aware)
        
    Returns:
        Timezone-aware UTC datetime, or None if input is None
    """
    if dt is None:
        return None
    
    if dt.tzinfo is None:
        # Assume naive datetime is UTC
        return dt.replace(tzinfo=timezone.utc)
    
    # Convert to UTC if in different timezone
    return dt.astimezone(timezone.utc)


def from_utc(dt: datetime, tz: timezone) -> datetime:
    """
    Convert UTC datetime to specified timezone.
    
    Args:
        dt: UTC datetime
        tz: Target timezone
        
    Returns:
        Datetime in target timezone
    """
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    
    return dt.astimezone(tz)


def duration_to_minutes(duration: timedelta) -> float:
    """Convert timedelta to minutes."""
    return duration.total_seconds() / 60


def minutes_to_duration(minutes: float) -> timedelta:
    """Convert minutes to timedelta."""
    return timedelta(minutes=minutes)


def timestamp_seconds_since(dt: datetime) -> float:
    """
    Get seconds elapsed since given datetime.
    
    Args:
        dt: Datetime to measure from
        
    Returns:
        Seconds elapsed (negative if dt is in future)
    """
    return (get_utc_now() - to_utc(dt)).total_seconds()


def is_expired(valid_until: Optional[datetime]) -> bool:
    """Check if a validity window has expired."""
    if valid_until is None:
        return False
    
    return get_utc_now() > to_utc(valid_until)


def calculate_decay_factor(
    timestamp: datetime,
    decay_profile: str,
    as_of: Optional[datetime] = None,
) -> float:
    """
    Calculate confidence decay factor based on signal age and decay profile.
    
    Args:
        timestamp: When signal was created
        decay_profile: 'fast' (15min half-life), 'medium' (1h), 'slow' (24h), 'none'
        as_of: Evaluation time (default: now)
        
    Returns:
        Decay factor (0.0 to 1.0), where 1.0 = no decay
    """
    if as_of is None:
        as_of = get_utc_now()
    
    if decay_profile == "none":
        return 1.0
    
    # Calculate age in minutes
    age_minutes = duration_to_minutes(to_utc(as_of) - to_utc(timestamp))
    
    if age_minutes < 0:
        # Signal is from future, treat as fully confident
        return 1.0
    
    # Half-life decay: factor = 0.5^(age / half_life)
    if decay_profile == "fast":
        half_life = 15  # minutes
    elif decay_profile == "medium":
        half_life = 60  # minutes
    elif decay_profile == "slow":
        half_life = 24 * 60  # 1440 minutes
    else:
        return 1.0
    
    decay_factor = 0.5 ** (age_minutes / half_life)
    return max(0.0, min(1.0, decay_factor))  # Clamp to [0, 1]
