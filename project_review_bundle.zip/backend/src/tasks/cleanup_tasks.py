"""
Cleanup tasks — periodic maintenance for the DFS Edge Pro SaaS backend.

Currently handles:
  - Upload file purge: delete files older than ``max_age_hours`` from the
    uploads directory. Prevents unbounded disk growth in containerised envs.

This module can be invoked:
  • As a standalone script:       python -m tasks.cleanup_tasks
  • From a cron or Celery beat:   import and call run_cleanup()
  • From a Dramatiq periodic:     extend with dramatiq-cron if needed
"""
from __future__ import annotations

import logging
import os
import time
from pathlib import Path
from typing import Dict

logger = logging.getLogger(__name__)

# Uploads directory is resolved relative to UPLOADS_PATH env var, then CWD
_DEFAULT_UPLOADS: str = os.getenv(
    "UPLOADS_PATH",
    os.path.join(os.path.dirname(__file__), "..", "..", "..", "data", "uploads"),
)


def purge_old_uploads(
    uploads_dir: str = _DEFAULT_UPLOADS,
    max_age_hours: float = 24.0,
    dry_run: bool = False,
) -> Dict[str, int]:
    """
    Delete uploaded CSV/tmp files older than *max_age_hours*.

    Parameters
    ----------
    uploads_dir:   Directory to scan (default: UPLOADS_PATH env or data/uploads).
    max_age_hours: Delete files modified more than this many hours ago.
    dry_run:       Log what would be deleted without actually deleting.

    Returns
    -------
    dict with keys ``deleted``, ``skipped``, ``errors``.
    """
    path = Path(uploads_dir).resolve()
    if not path.is_dir():
        logger.warning("Upload cleanup: directory not found: %s", path)
        return {"deleted": 0, "skipped": 0, "errors": 0}

    cutoff = time.time() - max_age_hours * 3600
    stats = {"deleted": 0, "skipped": 0, "errors": 0}

    for f in path.iterdir():
        if not f.is_file():
            continue
        try:
            mtime = f.stat().st_mtime
            age_h = (time.time() - mtime) / 3600
            if mtime < cutoff:
                if dry_run:
                    logger.info("Cleanup [dry-run]: would delete %s (age=%.1fh)", f.name, age_h)
                else:
                    f.unlink()
                    logger.info("Cleanup: deleted %s (age=%.1fh)", f.name, age_h)
                stats["deleted"] += 1
            else:
                stats["skipped"] += 1
        except Exception as exc:
            logger.warning("Cleanup: error processing %s: %s", f, exc)
            stats["errors"] += 1

    logger.info(
        "Upload cleanup complete: deleted=%d skipped=%d errors=%d",
        stats["deleted"], stats["skipped"], stats["errors"],
    )
    return stats


def run_cleanup(verbose: bool = False) -> None:
    """Convenience entry point called from scripts or periodic tasks."""
    max_age = float(os.getenv("UPLOAD_MAX_AGE_HOURS", "24"))
    stats = purge_old_uploads(max_age_hours=max_age)
    if verbose:
        print(f"Cleanup: {stats}")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    run_cleanup(verbose=True)
