"""
Dramatiq task definitions for async DFS optimizer execution.

Workers are started separately::

    cd backend/
    python -m dramatiq tasks.optimizer_tasks

The broker URL is read from the ``REDIS_URL`` environment variable
(defaults to ``redis://localhost:6379/0`` for local development).

Workflow::

    POST /api/runs  →  create_run()  →  enqueue run_optimizer_task.send()
                    ↓
    run_optimizer_task (worker process)
        load_player_pool(db, slate_id)
        run_fanduel_optimizer(df, ...)
        persist_lineups(db, ...)
        complete_run(db, run_id)
"""

from __future__ import annotations

import logging
import os
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Broker setup (graceful degradation when Redis is absent)
# ---------------------------------------------------------------------------

REDIS_URL = os.environ.get("REDIS_URL", "redis://localhost:6379/0")

try:
    import dramatiq
    from dramatiq.brokers.redis import RedisBroker
    from dramatiq.middleware import CurrentMessage

    _broker = RedisBroker(url=REDIS_URL)
    dramatiq.set_broker(_broker)
    DRAMATIQ_AVAILABLE = True
    logger.info("Dramatiq Redis broker initialised: %s", REDIS_URL)
except Exception as _exc:  # pragma: no cover
    DRAMATIQ_AVAILABLE = False
    logger.warning(
        "Dramatiq unavailable (%s). Async runs will execute synchronously.", _exc
    )

    # Stub decorator so imports don't crash when Dramatiq is not installed
    class _actor:  # type: ignore[assignment]
        def __init__(self, fn):
            self._fn = fn

        def send(self, *args, **kwargs):
            logger.info(
                "Dramatiq not available — running task synchronously: %s",
                self._fn.__name__,
            )
            return self._fn(*args, **kwargs)

        def __call__(self, *args, **kwargs):
            return self._fn(*args, **kwargs)

    class dramatiq:  # type: ignore[no-redef]
        @staticmethod
        def actor(fn=None, **kwargs):
            if fn is not None:
                return _actor(fn)

            def decorator(f):
                return _actor(f)

            return decorator


# ---------------------------------------------------------------------------
# Task implementation
# ---------------------------------------------------------------------------

@dramatiq.actor(queue_name="optimizer", max_retries=1, time_limit=300_000)  # 5 min limit
def run_optimizer_task(
    run_id: str,
    slate_id: str,
    num_lineups: int = 150,
    platform: str = "fanduel",
    contest_type: str = "small_gpp",
    max_exposure: float = 0.35,
    min_salary: int = 49000,
    max_salary: int = 60000,
    exclude_injured: bool = True,
    timeout_seconds: int = 0,  # 0 = use OPTIMIZER_TIMEOUT_SECONDS env, or 300 default
) -> None:
    """
    Execute the DFS optimizer for *run_id* as a background task.

    Steps:
      1. Mark run as running.
      2. Load player pool from DB (slate_id).
      3. Normalize DataFrame for the optimizer.
      4. Run the optimizer.
      5. Persist lineups to the DB.
      6. Mark run as completed (or failed on exception).
    """
    from database.session import get_session
    from services.player_pool_loader import load_player_pool
    from services.optimizer_service import run_fanduel_optimizer, normalize_dataframe
    from services.run_service import start_run, complete_run, fail_run, persist_lineups

    logger.info("run_optimizer_task started: run_id=%s slate_id=%s", run_id, slate_id)

    try:
        with get_session() as db:
            start_run(db, run_id)

            # Load player pool from DB
            df = load_player_pool(db, slate_id, exclude_injured=exclude_injured)

        # Normalize for the optimizer (adds PosBucket etc.)
        df = normalize_dataframe(df)
        if df.empty:
            raise ValueError("Player pool is empty after normalisation")

        # Run optimizer (sync/async depending on implementation)
        import asyncio

        result = asyncio.run(
            run_fanduel_optimizer(
                df=df,
                num_lineups=num_lineups,
                platform=platform,
                contest_type=contest_type,
                max_exposure=max_exposure,
                min_salary=min_salary,
                max_salary=max_salary,
            )
        )

        # result is a dict with "lineups" key (list of list of player dicts)
        raw_lineups: List[List[Dict[str, Any]]] = result.get("lineups", [])

        with get_session() as db:
            written = persist_lineups(db, run_id, slate_id, raw_lineups)
            complete_run(db, run_id)

        logger.info(
            "run_optimizer_task completed: run_id=%s written=%d", run_id, written
        )

    except Exception as exc:
        logger.exception("run_optimizer_task failed: run_id=%s", run_id)
        try:
            from database.session import get_session
            from services.run_service import fail_run

            with get_session() as db:
                fail_run(db, run_id, reason=str(exc))
        except Exception:
            logger.exception("Could not mark run as failed: run_id=%s", run_id)
        raise
