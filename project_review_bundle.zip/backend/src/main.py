import os
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import RedirectResponse
from database.db import init_db, test_connection
from core.config import get_settings

# ── Structured JSON logging (must be imported early) ───────────────────────
try:
    from middleware.request_context import RequestContextMiddleware, configure_json_logging
    _REQUEST_CONTEXT_AVAILABLE = True
except ImportError:
    _REQUEST_CONTEXT_AVAILABLE = False

# ── Core routers (always present) ──────────────────────────────────────────
from routers import auth, projections, optimizer, ownership, workflow, results

# ── Optional routers (added incrementally; missing ones degrade gracefully) ─
try:
    from routers import observability
except ImportError:
    observability = None  # type: ignore[assignment]

try:
    from routers import jobs
except ImportError:
    jobs = None  # type: ignore[assignment]

try:
    from routers import metrics
except ImportError:
    metrics = None  # type: ignore[assignment]

try:
    from routers import health
except ImportError:
    health = None  # type: ignore[assignment]

try:
    from routers import profiles
except ImportError:
    profiles = None  # type: ignore[assignment]

try:
    from routers import admin
except ImportError:
    admin = None  # type: ignore[assignment]

try:
    from routers import signals
except ImportError:
    signals = None  # type: ignore[assignment]

try:
    from routers import realtime
except ImportError:
    realtime = None  # type: ignore[assignment]

try:
    from routers import explain as explain_router
except ImportError:
    explain_router = None  # type: ignore[assignment]

try:
    from routers import alerts as alerts_router
except ImportError:
    alerts_router = None  # type: ignore[assignment]

try:
    from routers import audit as audit_router
except ImportError:
    audit_router = None  # type: ignore[assignment]

try:
    from routers import intel as intel_router
except ImportError:
    intel_router = None  # type: ignore[assignment]

try:
    from routers import groups as groups_router
except ImportError:
    groups_router = None  # type: ignore[assignment]

try:
    from routers import analytics as analytics_router
except ImportError:
    analytics_router = None  # type: ignore[assignment]

try:
    from auth.router import router as user_auth_router
except ImportError:
    user_auth_router = None  # type: ignore[assignment]

# ── Rate-limit middleware (stub passthrough when module is absent) ──────────
try:
    from routers.middleware.rate_limit import RateLimitMiddleware
except ImportError:
    from starlette.middleware.base import BaseHTTPMiddleware

    class RateLimitMiddleware(BaseHTTPMiddleware):  # type: ignore[no-redef]
        """No-op rate limit shim – real module not yet installed."""

        async def dispatch(self, request, call_next):
            return await call_next(request)

# Phase 13: Security imports
try:
    from security.api_key import APIKeyMiddleware, is_auth_enabled
    from security.limits import LimitMiddleware, get_payload_limits
    from security.audit import log_audit_event, AuditEventType
    SECURITY_AVAILABLE = True
except ImportError:
    SECURITY_AVAILABLE = False


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan - handles startup and shutdown."""
    # ── DuckDB concurrency guardrail (must run before any DB work) ──────────
    # Raises RuntimeError immediately if DATABASE_URL points to a file-based
    # DuckDB and WEB_CONCURRENCY / UVICORN_WORKERS > 1.
    # This prevents silent data-corruption races from the exclusive file-lock.
    from db.engine import assert_single_worker_for_duckdb
    assert_single_worker_for_duckdb()

    # Startup
    init_db()
    test_connection()

    # ── Configure JSON logging early ──────────────────────────────────────
    if _REQUEST_CONTEXT_AVAILABLE:
        configure_json_logging(level=os.getenv("LOG_LEVEL", "INFO"))

    # ── DB_REQUIRED: verify Alembic has been applied before serving traffic ───
    _settings = get_settings()
    if _settings.db_required:
        from sqlalchemy import text
        from database.db import SessionLocal
        _revision: str | None = None
        try:
            with SessionLocal() as _ses:
                row = _ses.execute(
                    text("SELECT version_num FROM alembic_version LIMIT 1")
                ).fetchone()
                _revision = row[0] if row else None
        except Exception:
            _revision = None
        if _revision is None:
            raise RuntimeError(
                "DB_REQUIRED=true but alembic_version is missing or empty. "
                "Run: alembic upgrade head"
            )
        print(f"Alembic schema verified: revision={_revision}")

    # Phase 8A: Initialize SQLite persistence and recover crashed jobs
    try:
        from persistence.sqlite import is_sqlite_mode, init_sqlite_schema, recover_crashed_jobs
        if is_sqlite_mode():
            init_sqlite_schema()
            recovered = recover_crashed_jobs()
            if recovered > 0:
                print(f"Recovered {recovered} crashed jobs (marked as FAILED)")
            print("SQLite persistence initialized")
    except ImportError:
        pass  # SQLite persistence not available
    except Exception as e:
        print(f"SQLite initialization error: {e}")

    # Phase 11A: Run retention cleanup at startup
    try:
        from maintenance.retention import run_retention_cycle, get_retention_config
        config = get_retention_config()
        if config.enabled:
            stats = run_retention_cycle(dry_run=False)
            deleted = stats.get("jobs_deleted", 0) + stats.get("artifacts_deleted", 0)
            if deleted > 0:
                print(f"Retention cleanup: {stats['jobs_deleted']} jobs, {stats['artifacts_deleted']} artifacts deleted")
            else:
                print("Retention cleanup: no old items to delete")
        else:
            print("Retention cleanup disabled")
    except ImportError:
        pass  # Retention module not available
    except Exception as e:
        print(f"Retention cleanup error: {e}")

    # Phase 10B: Load optimizer profiles
    try:
        from profiles import get_profile_store
        store = get_profile_store()
        profile_count = len(store.list())
        print(f"Loaded {profile_count} optimizer profiles")
    except Exception as e:
        print(f"Profile loading error: {e}")

    # Phase 12C: Start worker utilization tracking
    try:
        from observability.profiler import get_utilization_tracker
        tracker = get_utilization_tracker()
        tracker.start()
        print("Worker utilization tracking started")
    except ImportError:
        pass
    except Exception as e:
        print(f"Utilization tracker error: {e}")

    # Phase 13: Log security status
    if SECURITY_AVAILABLE:
        auth_enabled = is_auth_enabled()
        limits = get_payload_limits()
        print(f"Security: auth={'enabled' if auth_enabled else 'disabled'}, "
              f"max_payload={limits.max_payload_bytes // 1024}KB, "
              f"max_concurrent={limits.max_concurrent_jobs}")
        if auth_enabled:
            log_audit_event(AuditEventType.SYSTEM_START, action="startup", outcome="success")
    else:
        print("Security module not available")

    # Phase 20: Initialize user auth schema
    try:
        from auth.store import init_user_schema
        init_user_schema()
        print("User auth schema initialized")
    except ImportError:
        pass
    except Exception as e:
        print(f"User auth init error: {e}")

    # Phase 14A: Initialize signals service
    try:
        from signals import is_signals_enabled, get_signal_service
        if is_signals_enabled():
            service = get_signal_service()
            stats = service.refresh(force=True)
            print(f"Signals: enabled, {stats.get('players_updated', 0)} players loaded")
        else:
            print("Signals: disabled (set OPTIMIZER_SIGNALS_ENABLED=true to enable)")
    except ImportError:
        print("Signals module not available")
    except Exception as e:
        print(f"Signals initialization error: {e}")

    # Phase 19: Initialize persistent audit trail
    try:
        from observability.audit_trail import is_audit_enabled, init_audit_schema
        if is_audit_enabled():
            init_audit_schema()
            print("Audit trail: SQLite persistence initialized")
        else:
            print("Audit trail: disabled (set OPTIMIZER_AUDIT_ENABLED=true to enable)")
    except ImportError:
        pass
    except Exception as e:
        print(f"Audit trail initialization error: {e}")

    # Phase 18: Initialize alert manager
    try:
        from observability.alerts import is_alerts_enabled, get_alert_manager
        if is_alerts_enabled():
            manager = get_alert_manager()
            rules_count = len(manager.get_rules())
            print(f"Alerts: enabled, {rules_count} rules loaded")
        else:
            print("Alerts: disabled (set OPTIMIZER_ALERTS_ENABLED=true to enable)")
    except ImportError:
        pass
    except Exception as e:
        print(f"Alerts initialization error: {e}")

    # Initialize Intel Feed
    try:
        from intel import get_intel_service
        if os.getenv("OPTIMIZER_INTEL_ENABLED", "false").lower() == "true":
            intel_svc = get_intel_service()
            stats = intel_svc.get_stats()
            print(f"Intel Feed: enabled, {stats.get('total', 0)} items in store")
        else:
            print("Intel Feed: disabled (set OPTIMIZER_INTEL_ENABLED=true to enable)")
    except ImportError:
        print("Intel module not available")
    except Exception as e:
        print(f"Intel initialization error: {e}")

    # Initialize Player Groups
    try:
        from groups import get_group_service
        if os.getenv("OPTIMIZER_GROUPS_ENABLED", "false").lower() == "true":
            groups_svc = get_group_service()
            stats = groups_svc.get_stats()
            print(f"Player Groups: enabled, {stats.get('total', 0)} groups defined")
        else:
            print("Player Groups: disabled (set OPTIMIZER_GROUPS_ENABLED=true to enable)")
    except ImportError:
        print("Groups module not available")
    except Exception as e:
        print(f"Groups initialization error: {e}")

    # Post-run exposure analytics
    if os.getenv("OPTIMIZER_RESULTS_ENABLED", "false").lower() == "true":
        print("Post-run Analytics: enabled")
    else:
        print("Post-run Analytics: disabled (set OPTIMIZER_RESULTS_ENABLED=true to enable)")

    # ── Upload cleanup (purge files older than UPLOAD_MAX_AGE_HOURS) ──────────
    try:
        from tasks.cleanup_tasks import purge_old_uploads
        max_age = float(os.getenv("UPLOAD_MAX_AGE_HOURS", "24"))
        _cleanup = purge_old_uploads(max_age_hours=max_age)
        _del = _cleanup.get("deleted", 0)
        if _del:
            print(f"Startup cleanup: {_del} old upload file(s) removed (>{max_age}h)")
    except Exception as _exc:
        print(f"Startup cleanup skipped: {_exc}")

    # ── Stale run recovery ────────────────────────────────────────────────
    try:
        from services.run_recovery import recover_stale_runs
        from database.db import SessionLocal
        with SessionLocal() as _rec_ses:
            _recovered = recover_stale_runs(_rec_ses)
        if _recovered:
            print(f"Stale run recovery: {len(_recovered)} run(s) marked failed: {_recovered}")
        else:
            print("Stale run recovery: no stale runs detected")
    except Exception as _exc:
        print(f"Stale run recovery skipped: {_exc}")

    print("DFS Edge Pro API started successfully!")
    yield
    # Shutdown
    print("DFS Edge Pro API shutting down...")

    # Phase 12C: Stop utilization tracker
    try:
        from observability.profiler import get_utilization_tracker
        tracker = get_utilization_tracker()
        tracker.stop()
    except Exception:
        pass

    # Phase 7: Shutdown job runner gracefully
    try:
        from jobs.runner import get_default_runner
        runner = get_default_runner()
        runner.shutdown(wait=True)
        print("Job runner shutdown complete")
    except Exception as e:
        print(f"Job runner shutdown error: {e}")


app = FastAPI(
    title="DFS Edge Pro API",
    description="Professional DFS projections, ownership, and lineup optimization",
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json",
    lifespan=lifespan,
)

# CORS Configuration — origins driven by ALLOWED_ORIGINS env var
_cors_origins = [o.strip() for o in get_settings().allowed_origins.split(",") if o.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=_cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Exception handler to log all unhandled exceptions
from fastapi import Request
from fastapi.responses import JSONResponse
import traceback

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Log unhandled exceptions server-side; return safe response to client."""
    import sys
    import uuid as _uuid
    error_id = str(_uuid.uuid4())[:8]
    error_msg = f"ERROR [{error_id}] in {request.method} {request.url.path}: {exc}"
    print(error_msg, file=sys.stderr)
    traceback.print_exc(file=sys.stderr)
    sys.stderr.flush()
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error", "error_id": error_id},
    )

# ── Request context + structured logging ──────────────────────────────────
if _REQUEST_CONTEXT_AVAILABLE:
    app.add_middleware(RequestContextMiddleware)

# Phase 8D: Rate limiting middleware
app.add_middleware(RateLimitMiddleware)

# Phase 13: Security middlewares (order matters: limit check before auth)
if SECURITY_AVAILABLE:
    # Payload size limits
    app.add_middleware(LimitMiddleware)
    # API key authentication (if enabled)
    app.add_middleware(APIKeyMiddleware)

# ── Convenience redirects so legacy /docs and /openapi.json still work ──────
@app.get("/docs", include_in_schema=False)
async def redirect_docs():
    return RedirectResponse(url="/api/docs")

@app.get("/redoc", include_in_schema=False)
async def redirect_redoc():
    return RedirectResponse(url="/api/redoc")

@app.get("/openapi.json", include_in_schema=False)
async def redirect_openapi():
    return RedirectResponse(url="/api/openapi.json")

# ── Core health (no prefix – standard for load balancers / k8s probes) ──────
if health is not None:
    app.include_router(health.router)

# ── Core API routers (always present) ───────────────────────────────────────
app.include_router(auth.router, prefix="/api", tags=["Authentication"])
app.include_router(projections.router, prefix="/api", tags=["Projections"])
app.include_router(ownership.router, prefix="/api", tags=["Ownership"])
app.include_router(optimizer.router, prefix="/api", tags=["Optimizer"])
app.include_router(workflow.router, prefix="/api", tags=["Workflow"])
app.include_router(results.router, prefix="/api", tags=["Results"])

# ── SaaS run management (DB-first async flow) ─────────────────────────────
try:
    from routers import runs as runs_router
    app.include_router(runs_router.router, prefix="/api", tags=["Runs"])
except ImportError:
    pass

# ── SaaS slate query endpoints ────────────────────────────────────────────
try:
    from routers import slates as slates_router
    app.include_router(slates_router.router, prefix="/api", tags=["Slates"])
except ImportError:
    pass

# ── Prometheus-style metrics endpoint ────────────────────────────────────
try:
    from routers.prom_metrics import router as prom_metrics_router
    app.include_router(prom_metrics_router)
except ImportError:
    pass

# ── Optional routers (silently absent when not yet implemented) ──────────────
if observability is not None:
    app.include_router(observability.router, prefix="/api", tags=["Observability"])
if jobs is not None:
    app.include_router(jobs.router, prefix="/api", tags=["Jobs"])
if metrics is not None:
    app.include_router(metrics.router, prefix="/api", tags=["Metrics"])
if profiles is not None:
    app.include_router(profiles.router, prefix="/api", tags=["Profiles"])
if admin is not None:
    app.include_router(admin.router, prefix="/api", tags=["Admin"])
if signals is not None:
    app.include_router(signals.router, prefix="/api", tags=["Signals"])
if realtime is not None:
    app.include_router(realtime.router, tags=["Realtime"])
if explain_router is not None:
    app.include_router(explain_router.router, prefix="/api", tags=["Explainability"])
if alerts_router is not None:
    app.include_router(alerts_router.router, prefix="/api", tags=["Alerts"])
if audit_router is not None:
    app.include_router(audit_router.router, prefix="/api", tags=["Audit"])
if user_auth_router is not None:
    app.include_router(user_auth_router, prefix="/api", tags=["User Auth"])
if intel_router is not None:
    app.include_router(intel_router.router, prefix="/api", tags=["Intel Feed"])
if groups_router is not None:
    app.include_router(groups_router.router, prefix="/api", tags=["Player Groups"])
if analytics_router is not None:
    app.include_router(analytics_router.router, tags=["Analytics"])
    if hasattr(analytics_router, "optimizer_results_router"):
        app.include_router(analytics_router.optimizer_results_router, tags=["Optimizer Results"])


@app.get("/api/health")
async def health_check():
    """Health check endpoint for monitoring."""
    return {"status": "healthy", "service": "DFS Edge Pro API"}
