"""
Database connection - Production-grade reliability for 100K+ users!
Phase 1: Database Reliability - Connection pooling, retry logic, monitoring
"""

from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import QueuePool, NullPool
from sqlalchemy.exc import OperationalError, DisconnectionError
import os
import time
import logging
from dotenv import load_dotenv
from contextlib import contextmanager
from typing import Optional, Dict, Any
from pathlib import Path

# Load environment variables — prefer backend/.env, then root .env
_backend_env = Path(__file__).resolve().parents[2] / ".env"
load_dotenv(_backend_env)
load_dotenv()  # fallback to root .env for any missing vars

# Configure logging
logger = logging.getLogger(__name__)

# Database configuration
class DatabaseConfig:
    """Centralized database configuration"""

    def __init__(self):
        self.database_url = os.getenv("DATABASE_URL")
        self.use_duckdb_fallback = os.getenv("USE_DUCKDB_FALLBACK", "true").lower() == "true"

        # Connection pool settings
        self.pool_size = int(os.getenv("DB_POOL_SIZE", "10"))
        self.max_overflow = int(os.getenv("DB_MAX_OVERFLOW", "20"))
        self.pool_timeout = int(os.getenv("DB_POOL_TIMEOUT", "30"))
        self.pool_recycle = int(os.getenv("DB_POOL_RECYCLE", "3600"))

        # Retry settings
        self.max_retries = int(os.getenv("DB_MAX_RETRIES", "3"))
        self.retry_delay = float(os.getenv("DB_RETRY_DELAY", "0.5"))

        # Health check settings
        self.health_check_interval = int(os.getenv("DB_HEALTH_CHECK_INTERVAL", "60"))

        # DuckDB path — use centralized resolver
        from db.engine import get_canonical_db_path
        self.duckdb_path = get_canonical_db_path()

    def get_database_url(self) -> str:
        """Get the appropriate database URL"""
        # Only use DuckDB fallback if DATABASE_URL is not set
        # (Previously: `or` meant DuckDB was always used when USE_DUCKDB_FALLBACK=true)
        if not self.database_url:
            if self.use_duckdb_fallback:
                return f"duckdb:///{self.duckdb_path}"
            else:
                raise ValueError("DATABASE_URL not set and DuckDB fallback disabled")
        return self.database_url

    def is_duckdb(self) -> bool:
        """Check if using DuckDB"""
        return "duckdb" in self.get_database_url().lower()

# Global config instance
db_config = DatabaseConfig()

def create_database_engine():
    """Create database engine with proper configuration"""
    database_url = db_config.get_database_url()

    if db_config.is_duckdb():
        print("Using DuckDB for local development...")
        # DuckDB with SQLAlchemy - simplified connection
        engine = create_engine(
            database_url,
            echo=False
        )
    else:
        print("Using PostgreSQL/Supabase for production...")
        # Production PostgreSQL with proper pooling
        engine = create_engine(
            database_url,
            poolclass=QueuePool,
            pool_size=db_config.pool_size,
            max_overflow=db_config.max_overflow,
            pool_timeout=db_config.pool_timeout,
            pool_recycle=db_config.pool_recycle,
            echo=False,
            pool_pre_ping=True,  # Test connections before use
        )

    return engine

# Create engine with retry logic
def create_engine_with_retry(max_retries: int = None, retry_delay: float = None) -> Any:
    """Create database engine with retry logic"""
    if max_retries is None:
        max_retries = db_config.max_retries
    if retry_delay is None:
        retry_delay = db_config.retry_delay

    last_exception = None

    for attempt in range(max_retries + 1):
        try:
            engine = create_database_engine()
            # Test the connection
            with engine.connect() as conn:
                conn.execute(text("SELECT 1"))
            logger.info(f"Database connection established on attempt {attempt + 1}")
            return engine
        except Exception as e:
            last_exception = e
            if attempt < max_retries:
                logger.warning(f"Database connection attempt {attempt + 1} failed: {e}")
                time.sleep(retry_delay * (2 ** attempt))  # Exponential backoff
            else:
                logger.error(f"Database connection failed after {max_retries + 1} attempts")

    raise last_exception

# Lazy engine initialization — avoids crashing at import time if
# DuckDB is locked by another process.
_engine = None
_session_factory = None

def get_engine():
    """Get or create the database engine (lazy initialization)."""
    global _engine
    if _engine is None:
        _engine = create_engine_with_retry()
    return _engine

# Backwards-compatible module-level alias so existing code that
# references ``engine`` directly (health monitor, validators, etc.)
# still works once the engine has been initialised via get_engine().
def __getattr__(name):
    if name == "engine":
        return get_engine()
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

def _get_session_factory():
    """Get or create the session factory (lazy)."""
    global _session_factory
    if _session_factory is None:
        _session_factory = sessionmaker(
            autocommit=False, autoflush=False, bind=get_engine()
        )
    return _session_factory

def get_db() -> Session:
    """
    Dependency for FastAPI routes
    Usage: db: Session = Depends(get_db)
    """
    db = _get_session_factory()()
    try:
        yield db
    finally:
        db.close()

@contextmanager
def get_db_context():
    """
    Context manager for manual database operations
    Usage: with get_db_context() as db:
    """
    db = _get_session_factory()()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()

def init_db():
    """
    Initialize database - create all tables
    Call this on application startup
    """
    from models.user import Base
    from models.base import DFSBase  # new DFS core schema

    print("Initializing database...")

    _db_required = os.getenv("DB_REQUIRED", "false").lower() in ("1", "true", "yes")

    try:
        engine = get_engine()

        # Legacy user tables
        Base.metadata.create_all(bind=engine)

        # DFS core tables — auto-create only in dev mode.
        # In production (DB_REQUIRED=true) Alembic is the sole schema authority:
        # run `cd backend && alembic upgrade head` before starting the app.
        if not _db_required:
            DFSBase.metadata.create_all(bind=engine)
        else:
            print("DB_REQUIRED=true: skipping DFSBase.create_all() — use alembic upgrade head")

        print("Database tables created successfully!")

        # Test connection
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
            print("Database connection verified!")

        return True

    except Exception as e:
        print(f"Database initialization failed: {e}")
        return False

def test_connection():
    """Test if database connection works"""
    try:
        db_url = db_config.get_database_url()
        with get_engine().connect() as conn:
            if db_config.is_duckdb():
                result = conn.execute(text("SELECT 'DuckDB' as version"))
            elif "sqlite" in db_url.lower():
                result = conn.execute(text("SELECT 'SQLite ' || sqlite_version() as version"))
            else:
                result = conn.execute(text("SELECT version()"))
            version = result.fetchone()[0]
            print(f"Connected to database: {version}")
            return True
    except Exception as e:
        print(f"Connection failed: {e}")
        return False

# Health monitoring
class DatabaseHealthMonitor:
    """Monitor database health and performance"""

    def __init__(self):
        self.last_health_check = 0
        self.health_status = "unknown"
        self.connection_pool_stats = {}

    def check_health(self) -> Dict[str, Any]:
        """Perform comprehensive health check"""
        current_time = time.time()

        # Only check if interval has passed
        if current_time - self.last_health_check < db_config.health_check_interval:
            return {
                "status": self.health_status,
                "last_check": self.last_health_check,
                "pool_stats": self.connection_pool_stats
            }

        try:
            _eng = get_engine()
            with _eng.connect() as conn:
                # Basic connectivity test
                conn.execute(text("SELECT 1"))

                # Get connection pool stats if available
                pool_stats = {}
                if hasattr(_eng.pool, '_pool'):
                    pool = _eng.pool._pool
                    pool_stats = {
                        "pool_size": getattr(pool, 'size', 0),
                        "checked_out": getattr(pool, 'checkedout', 0),
                        "available": getattr(pool, 'checkedin', 0),
                        "overflow": getattr(pool, 'overflow', 0)
                    }

                self.health_status = "healthy"
                self.connection_pool_stats = pool_stats
                self.last_health_check = current_time

                return {
                    "status": "healthy",
                    "timestamp": current_time,
                    "pool_stats": pool_stats,
                    "database_type": "duckdb" if db_config.is_duckdb() else "postgresql"
                }

        except Exception as e:
            self.health_status = "unhealthy"
            self.last_health_check = current_time
            logger.error(f"Database health check failed: {e}")

            return {
                "status": "unhealthy",
                "timestamp": current_time,
                "error": str(e),
                "pool_stats": {}
            }

# Global health monitor
health_monitor = DatabaseHealthMonitor()

def get_health_status() -> Dict[str, Any]:
    """Get current database health status"""
    return health_monitor.check_health()

# Data validation framework
class DataValidator:
    """Validate data integrity and consistency"""

    @staticmethod
    def validate_table_exists(table_name: str) -> bool:
        """Check if table exists"""
        try:
            with get_engine().connect() as conn:
                if db_config.is_duckdb():
                    result = conn.execute(text(f"SELECT name FROM sqlite_master WHERE type='table' AND name='{table_name}'"))
                else:
                    result = conn.execute(text("SELECT table_name FROM information_schema.tables WHERE table_name = :table_name"), {"table_name": table_name})
                return result.fetchone() is not None
        except Exception as e:
            logger.error(f"Table existence check failed: {e}")
            return False

    @staticmethod
    def validate_row_count(table_name: str, expected_min: int = 0) -> Dict[str, Any]:
        """Validate table has expected minimum row count"""
        try:
            with get_engine().connect() as conn:
                result = conn.execute(text(f"SELECT COUNT(*) FROM {table_name}"))
                count = result.fetchone()[0]

                return {
                    "table": table_name,
                    "row_count": count,
                    "meets_minimum": count >= expected_min,
                    "status": "valid" if count >= expected_min else "warning"
                }
        except Exception as e:
            logger.error(f"Row count validation failed for {table_name}: {e}")
            return {
                "table": table_name,
                "error": str(e),
                "status": "error"
            }

    @staticmethod
    def validate_data_freshness(table_name: str, date_column: str, max_age_days: int = 7) -> Dict[str, Any]:
        """Check if table data is fresh enough"""
        try:
            with get_engine().connect() as conn:
                query = f"""
                SELECT MAX({date_column}) as latest_date,
                       CURRENT_DATE - MAX({date_column}) as days_old
                FROM {table_name}
                WHERE {date_column} IS NOT NULL
                """
                result = conn.execute(text(query))
                row = result.fetchone()

                if row and row[0]:
                    days_old = row[1] if row[1] is not None else 0
                    return {
                        "table": table_name,
                        "latest_date": str(row[0]),
                        "days_old": days_old,
                        "is_fresh": days_old <= max_age_days,
                        "status": "valid" if days_old <= max_age_days else "stale"
                    }
                else:
                    return {
                        "table": table_name,
                        "status": "empty",
                        "is_fresh": False
                    }
        except Exception as e:
            logger.error(f"Data freshness validation failed for {table_name}: {e}")
            return {
                "table": table_name,
                "error": str(e),
                "status": "error"
            }

# Backup and recovery
class DatabaseBackupManager:
    """Handle database backups and recovery"""

    def __init__(self):
        from db.engine import get_canonical_db_path
        self.backup_dir = get_canonical_db_path().parent / "backups"
        self.backup_dir.mkdir(parents=True, exist_ok=True)

    def create_backup(self, backup_name: str = None) -> Dict[str, Any]:
        """Create database backup"""
        if not db_config.is_duckdb():
            return {"status": "error", "message": "Backup only supported for DuckDB"}

        if backup_name is None:
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            backup_name = f"dfs_master_backup_{timestamp}.duckdb"

        backup_path = self.backup_dir / backup_name
        source_path = db_config.duckdb_path

        try:
            if source_path.exists():
                # For DuckDB, we can simply copy the file
                import shutil
                shutil.copy2(source_path, backup_path)

                backup_size = backup_path.stat().st_size

                return {
                    "status": "success",
                    "backup_path": str(backup_path),
                    "backup_size": backup_size,
                    "timestamp": time.time()
                }
            else:
                return {"status": "error", "message": "Source database not found"}

        except Exception as e:
            logger.error(f"Backup creation failed: {e}")
            return {"status": "error", "message": str(e)}

    def list_backups(self) -> list:
        """List available backups"""
        try:
            backups = []
            for backup_file in self.backup_dir.glob("dfs_master_backup_*.duckdb"):
                stat = backup_file.stat()
                backups.append({
                    "filename": backup_file.name,
                    "path": str(backup_file),
                    "size": stat.st_size,
                    "created": stat.st_ctime,
                    "created_iso": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(stat.st_ctime))
                })

            # Sort by creation time, newest first
            backups.sort(key=lambda x: x["created"], reverse=True)
            return backups

        except Exception as e:
            logger.error(f"Failed to list backups: {e}")
            return []

    def restore_backup(self, backup_name: str) -> Dict[str, Any]:
        """Restore from backup"""
        if not db_config.is_duckdb():
            return {"status": "error", "message": "Restore only supported for DuckDB"}

        backup_path = self.backup_dir / backup_name
        source_path = db_config.duckdb_path

        if not backup_path.exists():
            return {"status": "error", "message": f"Backup {backup_name} not found"}

        try:
            # Create backup of current database before restore
            current_backup = self.create_backup(f"pre_restore_{int(time.time())}.duckdb")

            # Restore the backup
            import shutil
            shutil.copy2(backup_path, source_path)

            return {
                "status": "success",
                "restored_from": str(backup_path),
                "pre_restore_backup": current_backup.get("backup_path"),
                "timestamp": time.time()
            }

        except Exception as e:
            logger.error(f"Backup restore failed: {e}")
            return {"status": "error", "message": str(e)}

# Global backup manager
backup_manager = DatabaseBackupManager()

def perform_data_validation() -> Dict[str, Any]:
    """Perform comprehensive data validation"""
    validation_results = {
        "timestamp": time.time(),
        "tables": {},
        "overall_status": "unknown"
    }

    # Critical tables to validate
    critical_tables = [
        ("players", 1, "player_id"),  # At least 1 player, check freshness
        ("player_game_logs", 1000, "date"),  # At least 1000 games, check last 30 days
        ("games", 10, "date"),  # At least 10 games, check last 7 days
        ("contest_results", 100, "contest_date")  # At least 100 results, check last 30 days
    ]

    all_valid = True

    for table_name, min_rows, date_column in critical_tables:
        # Check table exists
        if not DataValidator.validate_table_exists(table_name):
            validation_results["tables"][table_name] = {"status": "missing"}
            all_valid = False
            continue

        # Check row count
        row_validation = DataValidator.validate_row_count(table_name, min_rows)
        validation_results["tables"][table_name] = row_validation

        if row_validation["status"] != "valid":
            all_valid = False

        # Check data freshness
        if date_column:
            freshness_validation = DataValidator.validate_data_freshness(table_name, date_column)
            validation_results["tables"][table_name]["freshness"] = freshness_validation

            if freshness_validation["status"] not in ["valid", "empty"]:
                all_valid = False

    validation_results["overall_status"] = "valid" if all_valid else "issues_found"

    return validation_results
