"""
Supplemental session utilities for the DFS core schema.

Provides a straightforward SQLAlchemy session factory and context manager
that works independently of the legacy database/db.py session helpers.

Usage
-----
    from database.session import get_session

    with get_session() as session:
        slate = session.get(Slate, slate_id)
"""

from __future__ import annotations

import os
from contextlib import contextmanager
from typing import Generator

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session

# ---------------------------------------------------------------------------
# Engine factory (lazy singleton)
# ---------------------------------------------------------------------------

_session_factory: sessionmaker | None = None


def _get_factory() -> sessionmaker:
    """Return (and lazily create) the shared session factory."""
    global _session_factory
    if _session_factory is None:
        db_url = os.environ.get("DATABASE_URL", "")
        if not db_url:
            # Fallback: delegate to the legacy db helper if DATABASE_URL is absent
            from database.db import get_engine  # type: ignore[import]
            engine = get_engine()
        else:
            engine = create_engine(
                db_url,
                pool_pre_ping=True,
                future=True,
            )
        _session_factory = sessionmaker(bind=engine, autoflush=False, autocommit=False)
    return _session_factory


# ---------------------------------------------------------------------------
# Public helpers
# ---------------------------------------------------------------------------

@contextmanager
def get_session() -> Generator[Session, None, None]:
    """
    Yield a SQLAlchemy Session; commit on clean exit, rollback on error.

    Example::

        with get_session() as db:
            db.add(some_model_instance)
    """
    factory = _get_factory()
    session: Session = factory()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def get_db_session():
    """
    FastAPI dependency — yields a session per request.

    Usage in a router::

        from database.session import get_db_session

        @router.get("/endpoint")
        def endpoint(db: Session = Depends(get_db_session)):
            ...
    """
    factory = _get_factory()
    session: Session = factory()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()
