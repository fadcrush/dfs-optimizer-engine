#!/bin/bash
# Run API server in development mode

cd "$(dirname "$0")"

echo "Installing dependencies..."
pip install -r backend/requirements-api.txt

echo "Starting API server..."
python -m uvicorn backend.api.main:app \
    --host 0.0.0.0 \
    --port 8000 \
    --reload \
    --log-level info

# API will be available at:
# - http://localhost:8000/docs (OpenAPI UI)
# - http://localhost:8000/openapi.json (OpenAPI schema)
# - http://localhost:8000/api/v1/health (Health check)
