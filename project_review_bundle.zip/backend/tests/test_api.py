"""Tests for API endpoints."""

import pytest
from fastapi.testclient import TestClient
from datetime import datetime
from unittest.mock import Mock, patch

from api.main import create_app
from core import get_utc_now


@pytest.fixture
def client():
    """Create test client."""
    app = create_app()
    return TestClient(app)


class TestHealthEndpoints:
    """Test health check endpoints."""
    
    def test_health_check(self, client):
        """Test health check endpoint."""
        response = client.get("/api/v1/health")
        
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "healthy"
        assert "timestamp" in data
        assert data["version"] == "1.0.0"
    
    def test_readiness_check(self, client):
        """Test readiness check endpoint."""
        response = client.get("/api/v1/health/ready")
        
        assert response.status_code == 200
        data = response.json()
        assert data["ready"] is True
        assert "timestamp" in data


class TestRootEndpoint:
    """Test root endpoint."""
    
    def test_root(self, client):
        """Test root endpoint."""
        response = client.get("/")
        
        assert response.status_code == 200
        data = response.json()
        assert data["service"] == "DFS Optimizer API"
        assert data["version"] == "1.0.0"
        assert data["status"] == "running"


class TestSlatesEndpoints:
    """Test slate endpoints."""

    def test_list_slates_empty(self, client):
        """Test listing slates returns 200 or 500 (no live DB)."""
        response = client.get("/api/v1/slates")

        # Without a live database the endpoint may return an error
        assert response.status_code in [200, 500]
    
    def test_get_slate_not_found(self, client):
        """Test getting non-existent slate."""
        response = client.get("/api/v1/slates/nonexistent")
        
        # Should return 404 or 500
        assert response.status_code in [404, 500]


class TestProjectionsEndpoints:
    """Test projection endpoints."""
    
    def test_get_slate_projections(self, client):
        """Test getting slate projections."""
        response = client.get("/api/v1/projections/slate/fd_nba_20260122?version=v1")
        
        # Should return success or 500 (no DB)
        assert response.status_code in [200, 500]
    
    def test_get_player_game_projection_not_found(self, client):
        """Test getting projection for non-existent player."""
        response = client.get(
            "/api/v1/projections/player/nonexistent/game/nonexistent?version=v1"
        )
        
        # Should return 404 or 500
        assert response.status_code in [404, 500]


class TestSignalsEndpoints:
    """Test signal endpoints."""
    
    def test_get_slate_signals(self, client):
        """Test getting slate signals."""
        response = client.get("/api/v1/signals/slate/fd_nba_20260122")
        
        # Should succeed or 500 (no DB)
        assert response.status_code in [200, 500]
    
    def test_get_player_signals(self, client):
        """Test getting player signals."""
        response = client.get("/api/v1/signals/player/lbj_123?league=NBA")
        
        # Should succeed or 500 (no DB)
        assert response.status_code in [200, 500]


class TestIngestEndpoints:
    """Test ingestion endpoints."""
    
    def test_ingest_fd_csv_invalid_file(self, client):
        """Test FanDuel CSV ingestion with invalid file."""
        response = client.post(
            "/api/v1/ingest/fd-csv",
            files={"file": ("test.txt", b"not csv", "text/plain")},
        )
        
        assert response.status_code == 400
    
    def test_ingest_dk_csv_invalid_file(self, client):
        """Test DraftKings CSV ingestion with invalid file."""
        response = client.post(
            "/api/v1/ingest/dk-csv",
            files={"file": ("test.txt", b"not csv", "text/plain")},
        )
        
        assert response.status_code == 400
    
    def test_ingest_results_empty_csv(self, client):
        """Test results ingestion with empty CSV."""
        csv_content = b"player_id,actual_fppg\n"
        
        response = client.post(
            "/api/v1/ingest/results?slate_id=test",
            files={"file": ("results.csv", csv_content, "text/csv")},
        )
        
        assert response.status_code == 400


class TestEvaluationEndpoints:
    """Test evaluation endpoints."""
    
    def test_get_accuracy_metrics(self, client):
        """Test getting accuracy metrics."""
        response = client.get("/api/v1/evaluation/accuracy")
        
        # Should succeed or 500 (no DB)
        assert response.status_code in [200, 500]
    
    def test_get_bias_metrics(self, client):
        """Test getting bias metrics."""
        response = client.get("/api/v1/evaluation/bias?league=NBA")
        
        # Should succeed or 500 (no DB)
        assert response.status_code in [200, 500]
    
    def test_get_source_reliability(self, client):
        """Test getting source reliability."""
        response = client.get("/api/v1/evaluation/source-reliability?league=NBA")
        
        # Should succeed or 500 (no DB)
        assert response.status_code in [200, 500]


class TestErrorHandling:
    """Test error handling."""
    
    def test_invalid_route(self, client):
        """Test accessing invalid route."""
        response = client.get("/api/v1/invalid/route")
        
        assert response.status_code == 404


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
