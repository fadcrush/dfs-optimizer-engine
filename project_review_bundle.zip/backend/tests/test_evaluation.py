"""Tests for evaluation layer - accuracy, bias, reliability."""

import pytest
from datetime import datetime, timedelta
from unittest.mock import Mock

from evaluation import (
    ProjectionAccuracy,
    AccuracyMetricsComputer,
    SourceReliability,
    SourceReliabilityTracker,
    BiasMetrics,
    BiasAnalyzer,
)
from core import get_utc_now


class TestProjectionAccuracy:
    """Test accuracy computation."""
    
    def test_create_accuracy(self):
        """Test creating accuracy record."""
        now = get_utc_now()
        
        acc = ProjectionAccuracy(
            projection_id=123,
            player_id="lbj_123",
            game_id="game_456",
            slate_id="fd_nba_20260122",
            league="NBA",
            projected_fppg=45.0,
            projected_floor=30.0,
            projected_ceiling=60.0,
            projected_confidence=0.85,
            actual_fppg=48.0,
        )
        
        assert acc.error == 3.0  # 48 - 45
        assert acc.abs_error == 3.0
        assert acc.squared_error == 9.0
        assert acc.is_within_range is True
    
    def test_percentile_rank_within_range(self):
        """Test percentile rank for value within range."""
        now = get_utc_now()
        
        acc = ProjectionAccuracy(
            projection_id=123,
            player_id="lbj_123",
            game_id="game_456",
            slate_id="fd_nba_20260122",
            league="NBA",
            projected_fppg=45.0,
            projected_floor=30.0,
            projected_ceiling=60.0,
            projected_confidence=0.85,
            actual_fppg=45.0,  # At median
        )
        
        # Should be around 50th percentile
        assert 45 < acc.percentile_rank < 55
    
    def test_percentile_rank_below_floor(self):
        """Test percentile rank for value below floor."""
        now = get_utc_now()
        
        acc = ProjectionAccuracy(
            projection_id=123,
            player_id="lbj_123",
            game_id="game_456",
            slate_id="fd_nba_20260122",
            league="NBA",
            projected_fppg=45.0,
            projected_floor=30.0,
            projected_ceiling=60.0,
            projected_confidence=0.85,
            actual_fppg=20.0,  # Below floor
        )
        
        # Should be below 25th percentile
        assert acc.percentile_rank < 25
    
    def test_percentile_rank_above_ceiling(self):
        """Test percentile rank for value above ceiling."""
        now = get_utc_now()
        
        acc = ProjectionAccuracy(
            projection_id=123,
            player_id="lbj_123",
            game_id="game_456",
            slate_id="fd_nba_20260122",
            league="NBA",
            projected_fppg=45.0,
            projected_floor=30.0,
            projected_ceiling=60.0,
            projected_confidence=0.85,
            actual_fppg=70.0,  # Above ceiling
        )
        
        # Should be above 75th percentile
        assert acc.percentile_rank > 75


class TestAccuracyMetricsComputer:
    """Test accuracy metrics computation."""
    
    def test_compute_rmse(self):
        """Test RMSE computation."""
        now = get_utc_now()
        
        accuracies = [
            ProjectionAccuracy(
                projection_id=1,
                player_id="p1",
                game_id="g1",
                slate_id="s1",
                league="NBA",
                projected_fppg=40.0,
                projected_floor=30.0,
                projected_ceiling=50.0,
                projected_confidence=0.85,
                actual_fppg=42.0,  # Error = 2
            ),
            ProjectionAccuracy(
                projection_id=2,
                player_id="p2",
                game_id="g1",
                slate_id="s1",
                league="NBA",
                projected_fppg=30.0,
                projected_floor=20.0,
                projected_ceiling=40.0,
                projected_confidence=0.85,
                actual_fppg=26.0,  # Error = -4
            ),
        ]
        
        rmse = AccuracyMetricsComputer.compute_rmse(accuracies)
        
        # RMSE = sqrt((4 + 16) / 2) = sqrt(10) ≈ 3.16
        assert 3.0 < rmse < 3.3
    
    def test_compute_mae(self):
        """Test MAE computation."""
        accuracies = [
            ProjectionAccuracy(
                projection_id=1,
                player_id="p1",
                game_id="g1",
                slate_id="s1",
                league="NBA",
                projected_fppg=40.0,
                projected_floor=30.0,
                projected_ceiling=50.0,
                projected_confidence=0.85,
                actual_fppg=43.0,  # Error = 3
            ),
            ProjectionAccuracy(
                projection_id=2,
                player_id="p2",
                game_id="g1",
                slate_id="s1",
                league="NBA",
                projected_fppg=30.0,
                projected_floor=20.0,
                projected_ceiling=40.0,
                projected_confidence=0.85,
                actual_fppg=27.0,  # Error = -3
            ),
        ]
        
        mae = AccuracyMetricsComputer.compute_mae(accuracies)
        
        # MAE = (3 + 3) / 2 = 3
        assert mae == 3.0
    
    def test_compute_hit_rate(self):
        """Test hit rate computation."""
        now = get_utc_now()
        
        accuracies = [
            ProjectionAccuracy(
                projection_id=1,
                player_id="p1",
                game_id="g1",
                slate_id="s1",
                league="NBA",
                projected_fppg=40.0,
                projected_floor=30.0,
                projected_ceiling=50.0,
                projected_confidence=0.85,
                actual_fppg=42.0,  # Within range
            ),
            ProjectionAccuracy(
                projection_id=2,
                player_id="p2",
                game_id="g1",
                slate_id="s1",
                league="NBA",
                projected_fppg=30.0,
                projected_floor=20.0,
                projected_ceiling=40.0,
                projected_confidence=0.85,
                actual_fppg=50.0,  # Outside range
            ),
            ProjectionAccuracy(
                projection_id=3,
                player_id="p3",
                game_id="g1",
                slate_id="s1",
                league="NBA",
                projected_fppg=35.0,
                projected_floor=25.0,
                projected_ceiling=45.0,
                projected_confidence=0.85,
                actual_fppg=30.0,  # Within range
            ),
        ]
        
        hit_rate = AccuracyMetricsComputer.compute_hit_rate(accuracies)
        
        # 2 out of 3 within range
        assert hit_rate == pytest.approx(2.0 / 3.0)
    
    def test_compute_bias(self):
        """Test bias (mean error) computation."""
        accuracies = [
            ProjectionAccuracy(
                projection_id=1,
                player_id="p1",
                game_id="g1",
                slate_id="s1",
                league="NBA",
                projected_fppg=40.0,
                projected_floor=30.0,
                projected_ceiling=50.0,
                projected_confidence=0.85,
                actual_fppg=45.0,  # Error = 5
            ),
            ProjectionAccuracy(
                projection_id=2,
                player_id="p2",
                game_id="g1",
                slate_id="s1",
                league="NBA",
                projected_fppg=30.0,
                projected_floor=20.0,
                projected_ceiling=40.0,
                projected_confidence=0.85,
                actual_fppg=25.0,  # Error = -5
            ),
        ]
        
        bias = AccuracyMetricsComputer.compute_bias(accuracies)
        
        # Mean error = (5 - 5) / 2 = 0
        assert bias == 0.0
    
    def test_compute_correlation(self):
        """Test correlation computation."""
        accuracies = [
            ProjectionAccuracy(
                projection_id=1,
                player_id="p1",
                game_id="g1",
                slate_id="s1",
                league="NBA",
                projected_fppg=30.0,
                projected_floor=20.0,
                projected_ceiling=40.0,
                projected_confidence=0.85,
                actual_fppg=32.0,
            ),
            ProjectionAccuracy(
                projection_id=2,
                player_id="p2",
                game_id="g1",
                slate_id="s1",
                league="NBA",
                projected_fppg=40.0,
                projected_floor=30.0,
                projected_ceiling=50.0,
                projected_confidence=0.85,
                actual_fppg=42.0,
            ),
            ProjectionAccuracy(
                projection_id=3,
                player_id="p3",
                game_id="g1",
                slate_id="s1",
                league="NBA",
                projected_fppg=50.0,
                projected_floor=40.0,
                projected_ceiling=60.0,
                projected_confidence=0.85,
                actual_fppg=52.0,
            ),
        ]
        
        corr = AccuracyMetricsComputer.compute_correlation(accuracies)
        
        # Perfectly correlated (same offset)
        assert corr > 0.95


class TestSourceReliability:
    """Test source reliability tracking."""
    
    def test_create_reliability(self):
        """Test creating reliability tracker."""
        rel = SourceReliability(
            source="official",
            signal_type="INJURY_OUT",
            league="NBA",
        )
        
        assert rel.source == "official"
        assert rel.hit_rate == 0.0
        assert rel.confidence_score == 0.5  # Default
    
    def test_update_from_accuracy(self):
        """Test updating reliability from accuracy."""
        rel = SourceReliability(
            source="official",
            signal_type="INJURY_OUT",
            league="NBA",
        )
        
        # Simulate 3 signals
        for i in range(3):
            acc = ProjectionAccuracy(
                projection_id=i,
                player_id=f"p{i}",
                game_id="g1",
                slate_id="s1",
                league="NBA",
                projected_fppg=40.0,
                projected_floor=30.0,
                projected_ceiling=50.0,
                projected_confidence=0.85,
                actual_fppg=42.0 if i < 2 else 60.0,  # 2 hits, 1 miss
            )
            rel.update_from_accuracy(acc)
        
        assert rel.total_signals_issued == 3
        assert rel.accurate_signals == 2
        assert rel.hit_rate == pytest.approx(2.0 / 3.0)
    
    def test_downweight(self):
        """Test downweighting reliability."""
        rel = SourceReliability(
            source="twitter",
            signal_type="OWNERSHIP",
            league="NBA",
        )
        rel.confidence_score = 0.8
        
        rel.downweight(penalty=0.2)
        
        assert rel.confidence_score == pytest.approx(0.6)
    
    def test_upweight(self):
        """Test upweighting reliability."""
        rel = SourceReliability(
            source="official",
            signal_type="CONFIRMED_STARTER",
            league="NBA",
        )
        rel.confidence_score = 0.7
        
        rel.upweight(bonus=0.1)
        
        assert rel.confidence_score == pytest.approx(0.8)


class TestSourceReliabilityTracker:
    """Test tracking multiple sources."""
    
    def test_register_source(self):
        """Test registering source."""
        tracker = SourceReliabilityTracker()
        
        rel = tracker.register_source("official", "INJURY_OUT", "NBA")
        
        assert rel.source == "official"
        assert rel.signal_type == "INJURY_OUT"
    
    def test_get_source_weight(self):
        """Test getting source weight."""
        tracker = SourceReliabilityTracker()
        
        # Register and update
        tracker.register_source("official", "INJURY_OUT", "NBA")
        weight = tracker.get_source_weight("official", "INJURY_OUT", "NBA")
        
        assert weight == 0.5  # Default
    
    def test_identify_unreliable_sources(self):
        """Test identifying unreliable sources."""
        tracker = SourceReliabilityTracker()
        
        # Create unreliable source
        rel = tracker.register_source("twitter", "OWNERSHIP", "NBA")
        rel.total_signals_issued = 10
        rel.accurate_signals = 2
        rel.confidence_score = 0.3  # Below threshold
        
        unreliable = tracker.identify_unreliable_sources(threshold=0.4)
        
        assert len(unreliable) == 1
        assert unreliable[0].source == "twitter"


class TestBiasMetrics:
    """Test bias tracking."""
    
    def test_create_bias_metrics(self):
        """Test creating bias metrics."""
        metrics = BiasMetrics(
            group_key="team_LAL",
            category="team",
        )
        
        assert metrics.group_key == "team_LAL"
        assert metrics.total_projections == 0
        assert metrics.mean_bias == 0.0
    
    def test_add_projection(self):
        """Test adding projection to bias metrics."""
        metrics = BiasMetrics(
            group_key="league_NBA",
            category="league",
        )
        
        acc = ProjectionAccuracy(
            projection_id=1,
            player_id="p1",
            game_id="g1",
            slate_id="s1",
            league="NBA",
            projected_fppg=40.0,
            projected_floor=30.0,
            projected_ceiling=50.0,
            projected_confidence=0.85,
            actual_fppg=45.0,  # Error = 5
        )
        
        metrics.add_projection(acc)
        
        assert metrics.total_projections == 1
        assert metrics.mean_bias == 5.0


class TestBiasAnalyzer:
    """Test bias analysis."""
    
    def test_process_accuracies(self):
        """Test processing batch of accuracies."""
        analyzer = BiasAnalyzer()
        
        accuracies = [
            ProjectionAccuracy(
                projection_id=1,
                player_id="p1",
                game_id="g1",
                slate_id="s1",
                league="NBA",
                projected_fppg=40.0,
                projected_floor=30.0,
                projected_ceiling=50.0,
                projected_confidence=0.85,
                actual_fppg=45.0,
                contest_type="Cash",
            ),
            ProjectionAccuracy(
                projection_id=2,
                player_id="p2",
                game_id="g1",
                slate_id="s1",
                league="NFL",
                projected_fppg=20.0,
                projected_floor=10.0,
                projected_ceiling=30.0,
                projected_confidence=0.80,
                actual_fppg=18.0,
                contest_type="Tournament",
            ),
        ]
        
        analyzer.process_accuracies(accuracies)
        
        # Should have metrics for both leagues
        assert len(analyzer.bias_by_league) == 2
        assert len(analyzer.bias_by_contest_type) == 2


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
