"""Tests for derive layer - canonicalization, features, modifiers."""

import pytest
from datetime import datetime, timedelta
from unittest.mock import Mock, MagicMock

from derive import (
    CanonicalPlayer,
    CanonicalTeam,
    CanonicalGame,
    CanonicalSlate,
    Canonicalizer,
    MinutesBaseline,
    UsageBaseline,
    MatchupContext,
    FeatureBuilder,
    FeatureCache,
    OpportunityModifier,
    OpportunityModifiers,
)
from signals import InjuryOutSignal, ConfirmedStarterSignal
from core import get_utc_now


class TestCanonicalPlayer:
    """Test canonical player dimension."""
    
    def test_create_player(self):
        """Test creating a canonical player."""
        player = CanonicalPlayer(
            player_id="lbj_123",
            league="NBA",
            canonical_name="LeBron James",
            position="SF",
        )
        
        assert player.player_id == "lbj_123"
        assert player.league == "NBA"
        assert player.canonical_name == "LeBron James"
        assert player.position == "SF"
        assert player.active is True
    
    def test_player_to_dict(self):
        """Test converting player to dict."""
        player = CanonicalPlayer(
            player_id="sc_456",
            league="NBA",
            canonical_name="Stephen Curry",
            position="PG",
        )
        
        data = player.to_dict()
        
        assert data["player_id"] == "sc_456"
        assert data["league"] == "NBA"
        assert data["position"] == "PG"
        assert "created_at" in data


class TestCanonicalTeam:
    """Test canonical team dimension."""
    
    def test_create_team(self):
        """Test creating a canonical team."""
        team = CanonicalTeam(
            team_id="GSW",
            league="NBA",
            canonical_code="gsw",
            full_name="Golden State Warriors",
            city="San Francisco",
        )
        
        assert team.team_id == "GSW"
        assert team.canonical_code == "gsw"
        assert team.full_name == "Golden State Warriors"
        assert team.city == "San Francisco"


class TestCanonicalGame:
    """Test canonical game dimension."""
    
    def test_create_game(self):
        """Test creating a canonical game."""
        now = get_utc_now()
        
        game = CanonicalGame(
            game_id="game_2026_01_22_gsw_lal",
            league="NBA",
            season=2026,
            game_date=now,
            game_datetime_utc=now,
            home_team_id="LAL",
            away_team_id="GSW",
        )
        
        assert game.game_id == "game_2026_01_22_gsw_lal"
        assert game.season == 2026
        assert game.home_team_id == "LAL"
        assert game.away_team_id == "GSW"


class TestCanonicalSlate:
    """Test canonical slate dimension."""
    
    def test_create_slate(self):
        """Test creating a canonical slate."""
        now = get_utc_now()
        
        slate = CanonicalSlate(
            slate_id="fd_nba_20260122_main",
            league="NBA",
            site="FanDuel",
            slate_date=now,
            lock_time=now + timedelta(hours=1),
            salary_cap=60000,
        )
        
        assert slate.slate_id == "fd_nba_20260122_main"
        assert slate.league == "NBA"
        assert slate.salary_cap == 60000
        assert slate.slate_type == "Main"


class TestCanonicalizer:
    """Test canonicalization."""
    
    def test_get_or_create_player_new(self):
        """Test creating new player."""
        mock_connection = Mock()
        mock_connection.execute.return_value.first.return_value = None
        
        canonicalizer = Canonicalizer(mock_connection)
        
        player = canonicalizer.get_or_create_player(
            player_id="lbj_123",
            league="NBA",
            canonical_name="LeBron James",
            position="SF",
        )
        
        assert player.player_id == "lbj_123"
        assert player.canonical_name == "LeBron James"
    
    def test_caching(self):
        """Test that canonicalizer caches players."""
        mock_connection = Mock()
        mock_connection.execute.return_value.first.return_value = None
        canonicalizer = Canonicalizer(mock_connection)
        
        # Create first player
        player1 = canonicalizer.get_or_create_player(
            player_id="lbj_123",
            league="NBA",
            canonical_name="LeBron James",
            position="SF",
        )
        
        # Get same player again
        player2 = canonicalizer.get_or_create_player(
            player_id="lbj_123",
            league="NBA",
            canonical_name="LeBron James",
            position="SF",
        )
        
        # Should be same cached instance
        assert player1 is player2


class TestMinutesBaseline:
    """Test minutes baseline."""
    
    def test_create_baseline(self):
        """Test creating minutes baseline."""
        baseline = MinutesBaseline(
            player_id="lbj_123",
            season=2025,
        )
        
        baseline.avg_minutes = 32.5
        baseline.floor_minutes = 20.0
        baseline.ceiling_minutes = 38.0
        baseline.games_played = 50
        
        assert baseline.avg_minutes == 32.5
        assert baseline.floor_minutes == 20.0
        assert baseline.ceiling_minutes == 38.0
    
    def test_baseline_to_dict(self):
        """Test converting baseline to dict."""
        baseline = MinutesBaseline(
            player_id="sc_456",
            season=2025,
        )
        baseline.avg_minutes = 30.0
        baseline.games_played = 60
        
        data = baseline.to_dict()
        
        assert data["player_id"] == "sc_456"
        assert data["avg_minutes"] == 30.0
        assert data["games_played"] == 60


class TestFeatureBuilder:
    """Test feature builder."""
    
    def test_builder_creation(self):
        """Test creating feature builder."""
        mock_connection = Mock()
        builder = FeatureBuilder(mock_connection)
        
        assert builder.connection is mock_connection
    
    def test_matchup_context(self):
        """Test creating matchup context."""
        context = MatchupContext("game_123", "NBA")
        
        assert context.game_id == "game_123"
        assert context.league == "NBA"
        assert context.pace == 100.0


class TestFeatureCache:
    """Test feature cache."""
    
    def test_cache_creation(self):
        """Test creating feature cache."""
        cache = FeatureCache()
        
        assert cache.minutes_cache == {}
        assert cache.usage_cache == {}
        assert cache.matchup_cache == {}
    
    def test_cache_get_or_compute(self):
        """Test cache returns cached value."""
        cache = FeatureCache()
        
        baseline = MinutesBaseline("lbj_123", 2025)
        baseline.avg_minutes = 32.5
        
        cache.minutes_cache["NBA_lbj_123_2025"] = baseline
        
        retrieved = cache.get_minutes_baseline(
            "lbj_123",
            2025,
            "NBA",
        )
        
        assert retrieved is baseline
        assert retrieved.avg_minutes == 32.5


class TestOpportunityModifiers:
    """Test opportunity modifiers."""
    
    def test_create_modifiers(self):
        """Test creating opportunity modifiers."""
        mods = OpportunityModifiers(
            player_id="lbj_123",
            game_id="game_456",
        )
        
        mods.minutes_floor_baseline = 20.0
        mods.minutes_ceiling_baseline = 36.0
        
        assert mods.player_id == "lbj_123"
        assert mods.minutes_floor_baseline == 20.0
        assert mods.minutes_ceiling_baseline == 36.0
    
    def test_modifiers_to_dict(self):
        """Test converting modifiers to dict."""
        mods = OpportunityModifiers(
            player_id="sc_456",
            game_id="game_789",
        )
        mods.is_starter = True
        mods.starter_minutes_adjustment = 4.0
        
        data = mods.to_dict()
        
        assert data["player_id"] == "sc_456"
        assert data["is_starter"] is True
        assert data["starter_minutes_adjustment"] == 4.0


class TestOpportunityModifier:
    """Test opportunity modifier engine."""
    
    def test_apply_injury_out(self):
        """Test applying injury OUT modifier."""
        now = get_utc_now()
        injury_signal = InjuryOutSignal(
            entity_id="lbj_123",
            league="NBA",
            source="official",
            announced_at=now,
        )
        
        modifier = OpportunityModifier()
        mods = modifier.apply_modifiers(
            player_id="lbj_123",
            game_id="game_456",
            baseline_minutes_floor=20.0,
            baseline_minutes_ceiling=36.0,
            baseline_usage_floor=0.20,
            baseline_usage_ceiling=0.30,
            signals=[injury_signal],
        )
        
        assert mods.is_out is True
        assert mods.minutes_floor_final == 0
        assert mods.minutes_ceiling_final == 0
    
    def test_apply_confirmed_starter(self):
        """Test applying confirmed starter modifier."""
        now = get_utc_now()
        starter_signal = ConfirmedStarterSignal(
            entity_id="sc_456",
            league="NBA",
            game_id="game_789",
            announced_at=now,
        )
        
        modifier = OpportunityModifier()
        mods = modifier.apply_modifiers(
            player_id="sc_456",
            game_id="game_789",
            baseline_minutes_floor=15.0,
            baseline_minutes_ceiling=30.0,
            baseline_usage_floor=0.15,
            baseline_usage_ceiling=0.25,
            signals=[starter_signal],
        )
        
        assert mods.is_starter is True
        assert mods.starter_minutes_adjustment == 4.0
        # Ceiling should increase by adjustment
        assert mods.minutes_ceiling_final > mods.minutes_ceiling_baseline
    
    def test_apply_depth_promotion(self):
        """Test applying depth chart promotion."""
        modifier = OpportunityModifier()
        
        mods = OpportunityModifiers(
            player_id="player_123",
            game_id="game_456",
        )
        mods.minutes_floor_baseline = 10.0
        mods.minutes_ceiling_baseline = 20.0
        
        updated = modifier.apply_depth_change(
            mods,
            "promoted",
            severity=0.8,
        )
        
        assert updated.depth_change == "promoted"
        assert updated.depth_chart_adjustment > 0
    
    def test_apply_foul_trouble(self):
        """Test applying foul trouble modifier."""
        modifier = OpportunityModifier()
        
        mods = OpportunityModifiers(
            player_id="player_123",
            game_id="game_456",
        )
        mods.minutes_ceiling_baseline = 30.0
        mods.minutes_ceiling_final = 30.0
        mods.minutes_multiplier = 1.0
        
        # Apply 4 fouls
        updated = modifier.apply_foul_trouble(mods, fouls=4)
        
        # Should reduce multiplier and ceiling
        assert updated.minutes_multiplier < 1.0
        assert updated.minutes_ceiling_final < 30.0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
