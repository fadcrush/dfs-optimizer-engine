"""Tests for ingest layer - idempotency, schema drift, CSV connectors."""

import pytest
import tempfile
import csv
from pathlib import Path
from unittest.mock import Mock, MagicMock

from ingest import (
    FanDuelConnector,
    DraftKingsConnector,
    IdempotencyKey,
    SchemaDrift,
    DeduplicateCheck,
    IdempotentWriter,
)


class TestIdempotencyKey:
    """Test idempotency key generation."""
    
    def test_generate_from_dict(self):
        """Test generating key from dictionary."""
        data = {"id": "123", "name": "Player", "salary": 5000}
        
        key1 = IdempotencyKey.generate_from_dict(data)
        key2 = IdempotencyKey.generate_from_dict(data)
        
        # Same data should produce same key
        assert key1 == key2
        assert len(key1) == 64  # SHA256 hex digest
    
    def test_different_dicts_different_keys(self):
        """Test that different data produces different keys."""
        data1 = {"id": "123", "name": "Player1"}
        data2 = {"id": "124", "name": "Player2"}
        
        key1 = IdempotencyKey.generate_from_dict(data1)
        key2 = IdempotencyKey.generate_from_dict(data2)
        
        assert key1 != key2
    
    def test_order_independent(self):
        """Test that key is independent of dict key order."""
        data1 = {"id": "123", "name": "Player"}
        data2 = {"name": "Player", "id": "123"}
        
        key1 = IdempotencyKey.generate_from_dict(data1)
        key2 = IdempotencyKey.generate_from_dict(data2)
        
        # Same data in different order should produce same key
        assert key1 == key2
    
    def test_generate_from_csv_row(self):
        """Test generating key from CSV row."""
        row = {"player_id": "123", "salary": "5000", "position": "PG"}
        
        key = IdempotencyKey.generate_from_csv_row(row)
        
        assert len(key) == 64
        assert isinstance(key, str)


class TestSchemaDrift:
    """Test schema drift detection."""
    
    def test_register_new_schema(self):
        """Test registering a new schema."""
        drift = SchemaDrift()
        columns = {"id", "name", "salary"}
        
        result = drift.register_schema("players", columns)
        
        assert result is True
        assert drift.seen_schemas["players"] == columns
    
    def test_detect_schema_drift(self):
        """Test detecting schema drift."""
        drift = SchemaDrift()
        
        # Register initial schema
        drift.register_schema("players", {"id", "name", "salary"})
        
        # Try to register different schema
        result = drift.register_schema("players", {"id", "name", "salary", "team"})
        
        assert result is False
        assert len(drift.drift_events) == 1
        assert "team" in drift.drift_events[0]["extra_columns"]
    
    def test_detect_drift_in_batch(self):
        """Test detecting drift in a batch of records."""
        drift = SchemaDrift()
        
        records = [
            {"id": "1", "name": "Player1", "salary": "5000"},
            {"id": "2", "name": "Player2", "salary": "6000", "team": "LAL"},
        ]
        
        report = drift.detect_drift_in_batch("players", records)
        
        assert report["drift_detected"] is True
        assert "team" in report["union_columns"]
    
    def test_handle_missing_column(self):
        """Test handling missing column."""
        drift = SchemaDrift()
        record = {"id": "1", "name": "Player"}
        
        result = drift.handle_missing_column(record, "salary", default_value=5000)
        
        assert "salary" in result
        assert result["salary"] == 5000
    
    def test_handle_extra_column_drop(self):
        """Test dropping extra column."""
        drift = SchemaDrift()
        record = {"id": "1", "name": "Player", "extra_field": "value"}
        
        result = drift.handle_extra_column(record, "extra_field", action="drop")
        
        assert "extra_field" not in result
    
    def test_get_drift_report(self):
        """Test getting drift report."""
        drift = SchemaDrift()
        
        drift.register_schema("players", {"id", "name"})
        drift.register_schema("games", {"game_id", "home", "away"})
        drift.register_schema("players", {"id", "name", "salary"})  # Drift
        
        report = drift.get_drift_report()
        
        assert report["tables_seen"] == 2
        assert report["drift_events_count"] == 1


class TestFanDuelConnector:
    """Test FanDuel CSV connector."""
    
    def test_connector_creation(self):
        """Test creating FanDuel connector."""
        connector = FanDuelConnector("NBA")
        
        assert connector.name == "FanDuelCSV"
        assert connector.league == "NBA"
        assert "Salary" in connector.required_columns
    
    def test_ingest_csv(self):
        """Test ingesting FanDuel CSV file."""
        # Create a temporary CSV file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
            writer = csv.DictWriter(f, fieldnames=[
                "Id", "First Name", "Last Name", "Position", "Salary", "Game",
                "Injury Indicator", "Injury Details", "Played", "Salary Change",
                "Game Info", "Link"
            ])
            writer.writeheader()
            writer.writerow({
                "Id": "12345",
                "First Name": "Stephen",
                "Last Name": "Curry",
                "Position": "PG",
                "Salary": "11000",
                "Game": "BOS@LAL",
                "Injury Indicator": "",
                "Injury Details": "",
                "Played": "true",
                "Salary Change": "0",
                "Game Info": "BOS@LAL 10:30PM ET",
                "Link": "http://example.com",
            })
            csv_file = f.name
        
        try:
            connector = FanDuelConnector("NBA")
            records = connector.ingest(csv_file)
            
            assert len(records) == 1
            assert records[0]["Id"] == "12345"
        finally:
            Path(csv_file).unlink()
    
    def test_validate_record(self):
        """Test validating FanDuel record."""
        connector = FanDuelConnector("NBA")
        
        # Valid record
        valid_record = {
            "Id": "12345",
            "First Name": "Stephen",
            "Last Name": "Curry",
            "Position": "PG",
            "Salary": "11000",
            "Game": "BOS@LAL",
            "Injury Indicator": "",
            "Injury Details": "",
            "Played": "true",
            "Salary Change": "0",
            "Game Info": "BOS@LAL 10:30PM ET",
            "Link": "http://example.com",
        }
        
        errors = connector.validate(valid_record)
        assert len(errors) == 0
    
    def test_validate_invalid_salary(self):
        """Test validation catches invalid salary."""
        connector = FanDuelConnector("NBA")
        
        invalid_record = {
            "Id": "12345",
            "Position": "PG",
            "Salary": "50000",  # Too high
            "Game": "BOS@LAL",
            "Injury Indicator": "",
            "Injury Details": "",
            "Played": "true",
            "Salary Change": "0",
            "Game Info": "BOS@LAL 10:30PM ET",
            "Link": "http://example.com",
        }
        
        errors = connector.validate(invalid_record)
        assert any("Salary" in e for e in errors)
    
    def test_transform_record(self):
        """Test transforming FanDuel record."""
        connector = FanDuelConnector("NBA")
        
        raw_record = {
            "Id": "12345",
            "First Name": "Stephen",
            "Last Name": "Curry",
            "Position": "PG",
            "Salary": "11000",
            "Game": "BOS@LAL",
            "Injury Indicator": "",
            "Injury Details": "",
            "Played": "true",
            "Salary Change": "0",
            "Game Info": "BOS@LAL 10:30PM ET",
            "Link": "http://example.com",
        }
        
        transformed = connector.transform(raw_record)
        
        assert transformed["site_player_id"] == "FD_12345"
        assert transformed["first_name"] == "Stephen"
        assert transformed["last_name"] == "Curry"
        assert transformed["salary"] == 11000
        assert transformed["team"] == "LAL"
        assert transformed["opponent"] == "BOS"
    
    def test_parse_slate_info(self):
        """Test parsing FanDuel filename."""
        connector = FanDuelConnector("NBA")
        
        filename = "FanDuel-NBA-2026 EST-01 EST-05 EST-125225-players-list.csv"
        info = connector.parse_slate_info_from_filename(filename)
        
        assert info["league"] == "NBA"
        assert info["slate_date"] == "2026-01-05"
        assert info["contest_id"] == "125225"


class TestDraftKingsConnector:
    """Test DraftKings CSV connector."""
    
    def test_connector_creation(self):
        """Test creating DraftKings connector."""
        connector = DraftKingsConnector("NBA")
        
        assert connector.name == "DraftKingsCSV"
        assert connector.league == "NBA"
        assert "Salary" in connector.required_columns
    
    def test_transform_record(self):
        """Test transforming DraftKings record."""
        connector = DraftKingsConnector("NBA")
        
        raw_record = {
            "ID": "12345",
            "First Name": "LeBron",
            "Last Name": "James",
            "Position": "SF",
            "Salary": "11500",
            "Game": "BOS-LAL",
            "Injury Indicator": "",
            "Injury Details": "",
            "Played": "true",
            "Salary Change": "0",
            "Avg Points": "50.5",
            "Tier": "Tier 1",
        }
        
        transformed = connector.transform(raw_record)
        
        assert transformed["site_player_id"] == "DK_12345"
        assert transformed["first_name"] == "LeBron"
        assert transformed["position"] == "SF"
        assert transformed["salary"] == 11500
        assert transformed["team"] == "LAL"
        assert transformed["opponent"] == "BOS"
    
    def test_parse_slate_info(self):
        """Test parsing DraftKings filename."""
        connector = DraftKingsConnector("NBA")
        
        filename = "DraftKings-NBA-2026-01-05-Main-players-list.csv"
        info = connector.parse_slate_info_from_filename(filename)
        
        assert info["league"] == "NBA"
        assert info["slate_date"] == "2026-01-05"
        assert info["slate_type"] == "Main"


class TestIdempotentWriter:
    """Test idempotent writing."""
    
    def test_writer_creation(self):
        """Test creating idempotent writer."""
        mock_connection = Mock()
        writer = IdempotentWriter(mock_connection)
        
        assert writer.connection is mock_connection
        assert writer.dedup is not None
    
    def test_write_record_new(self):
        """Test writing a new record."""
        mock_connection = Mock()
        mock_dedup = Mock()
        mock_dedup.is_duplicate.return_value = False
        
        writer = IdempotentWriter(mock_connection)
        writer.dedup = mock_dedup
        
        record = {"player_id": "123", "name": "Player"}
        success, msg = writer.write_record(
            "players",
            record,
            "file_hash",
            "abc123"
        )
        
        # Verify dedup check was called
        mock_dedup.is_duplicate.assert_called_once()
    
    def test_write_record_duplicate(self):
        """Test that duplicate records are skipped."""
        mock_connection = Mock()
        mock_dedup = Mock()
        mock_dedup.is_duplicate.return_value = True
        
        writer = IdempotentWriter(mock_connection)
        writer.dedup = mock_dedup
        
        record = {"player_id": "123", "name": "Player"}
        success, msg = writer.write_record(
            "players",
            record,
            "file_hash",
            "abc123"
        )
        
        assert success is False
        assert "Duplicate" in msg


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
