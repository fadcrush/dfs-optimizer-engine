"""Tests for projection layer - distributions, rules, building."""

import pytest
from datetime import datetime, timedelta
from unittest.mock import Mock, MagicMock

from projection import (
    ProjectionDistribution,
    ProjectionRuleApplication,
    ProjectionBuilderRules,
    ProjectionBuilder,
    ProjectionStore,
)
from signals import InjuryOutSignal, ConfirmedStarterSignal, FatigueSignal
from core import get_utc_now


class TestProjectionDistribution:
    """Test projection distribution."""
    
    def test_create_distribution(self):
        """Test creating projection distribution."""
        now = get_utc_now()
        
        proj = ProjectionDistribution(
            player_id="lbj_123",
            game_id="game_456",
            slate_id="fd_nba_20260122",
            league="NBA",
            as_of_time=now,
            median_fppg=45.0,
            floor_fppg=30.0,
            ceiling_fppg=60.0,
            volatility=8.0,
            confidence=0.85,
        )
        
        assert proj.player_id == "lbj_123"
        assert proj.median_fppg == 45.0
        assert proj.confidence == 0.85
    
    def test_distribution_to_dict(self):
        """Test converting distribution to dict."""
        now = get_utc_now()
        
        proj = ProjectionDistribution(
            player_id="sc_456",
            game_id="game_789",
            slate_id="fd_nba_20260122",
            league="NBA",
            as_of_time=now,
            median_fppg=40.0,
            floor_fppg=25.0,
            ceiling_fppg=55.0,
            volatility=7.5,
            confidence=0.80,
        )
        
        data = proj.to_dict()
        
        assert data["player_id"] == "sc_456"
        assert data["median_fppg"] == 40.0
        assert "created_at" in data
    
    def test_compute_percentile(self):
        """Test computing percentile from distribution."""
        now = get_utc_now()
        
        proj = ProjectionDistribution(
            player_id="player_123",
            game_id="game_456",
            slate_id="slate_789",
            league="NBA",
            as_of_time=now,
            median_fppg=40.0,
            floor_fppg=20.0,
            ceiling_fppg=60.0,
            volatility=10.0,
            confidence=0.80,
        )
        
        # Test floor (25th percentile)
        p25 = proj.compute_percentile(25)
        assert p25 <= proj.median_fppg
        
        # Test median (50th percentile)
        p50 = proj.compute_percentile(50)
        assert abs(p50 - proj.median_fppg) < 1.0
        
        # Test ceiling (75th percentile)
        p75 = proj.compute_percentile(75)
        assert p75 >= proj.median_fppg
        
        # Test ordered (p25 == p50 is valid since the interpolation
        # maps percentile 25 to the median boundary)
        assert p25 <= p50 <= p75
    
    def test_percentile_validation(self):
        """Test percentile validation."""
        now = get_utc_now()
        
        proj = ProjectionDistribution(
            player_id="player_123",
            game_id="game_456",
            slate_id="slate_789",
            league="NBA",
            as_of_time=now,
            median_fppg=40.0,
            floor_fppg=20.0,
            ceiling_fppg=60.0,
            volatility=10.0,
            confidence=0.80,
        )
        
        with pytest.raises(ValueError):
            proj.compute_percentile(-5)
        
        with pytest.raises(ValueError):
            proj.compute_percentile(105)


class TestProjectionRuleApplication:
    """Test rule application tracking."""
    
    def test_create_rule_application(self):
        """Test creating rule application."""
        app = ProjectionRuleApplication(
            rule_name="Injury OUT",
            applied=True,
            effect_on_ceiling=-36.0,
            reason="Player officially OUT",
        )
        
        assert app.rule_name == "Injury OUT"
        assert app.applied is True
        assert app.effect_on_ceiling == -36.0


class TestProjectionBuilderRules:
    """Test projection builder rules engine."""
    
    def test_injury_out_rule(self):
        """Test injury OUT hard override."""
        now = get_utc_now()
        
        injury_signal = InjuryOutSignal(
            entity_id="lbj_123",
            league="NBA",
            source="official",
            announced_at=now,
        )
        
        rules = ProjectionBuilderRules()
        floor, ceiling, vol, conf = rules.apply_rules(
            floor=20.0,
            ceiling=36.0,
            volatility=5.0,
            signals=[injury_signal],
        )
        
        # Hard override
        assert floor == 0
        assert ceiling == 0
        assert vol == 0
        assert conf == 0
        assert len(rules.rules_applied) == 1
        assert rules.rules_applied[0].rule_name == "Injury OUT"
    
    def test_confirmed_starter_rule(self):
        """Test confirmed starter applies ceiling bonus."""
        now = get_utc_now()
        
        starter_signal = ConfirmedStarterSignal(
            entity_id="sc_456",
            league="NBA",
            game_id="game_789",
            announced_at=now,
        )
        
        rules = ProjectionBuilderRules()
        floor, ceiling, vol, conf = rules.apply_rules(
            floor=10.0,
            ceiling=25.0,
            volatility=4.0,
            signals=[starter_signal],
            confidence_base=0.75,
        )
        
        # Starter adds 4 to ceiling
        assert ceiling == 25.0 + 4.0
        assert floor == 10.0  # Floor unchanged
        assert conf == 0.95  # High confidence
        assert len(rules.rules_applied) == 1
        assert rules.rules_applied[0].rule_name == "Confirmed Starter"
    
    def test_fatigue_rule(self):
        """Test fatigue reduces ceiling."""
        from core import SIGNAL_TYPE

        fatigue_signal = MagicMock()
        fatigue_signal.signal_type = SIGNAL_TYPE.FATIGUE_SIGNAL
        fatigue_signal.severity = 0.5

        rules = ProjectionBuilderRules()

        # Only return signal for FATIGUE_SIGNAL type, None for others
        original_get = ProjectionBuilderRules._get_signal_by_type

        def _selective_get(self_inner, signals, signal_type):
            if signal_type == SIGNAL_TYPE.FATIGUE_SIGNAL:
                return fatigue_signal
            return None

        rules._get_signal_by_type = lambda sigs, st: _selective_get(None, sigs, st)

        floor, ceiling, vol, conf = rules.apply_rules(
            floor=15.0,
            ceiling=35.0,
            volatility=5.0,
            signals=[fatigue_signal],
            confidence_base=0.80,
        )

        # Ceiling reduced by severity * 15%
        expected_reduction = 35.0 * 0.5 * 0.15
        assert abs(ceiling - (35.0 - expected_reduction)) < 0.1
    
    def test_multiple_signals_priority(self):
        """Test that only highest priority rule applies."""
        now = get_utc_now()
        
        # Both injury OUT and confirmed starter
        injury = InjuryOutSignal(
            entity_id="player_123",
            league="NBA",
            source="official",
            announced_at=now,
        )
        starter = ConfirmedStarterSignal(
            entity_id="player_123",
            league="NBA",
            game_id="game_456",
            announced_at=now,
        )
        
        rules = ProjectionBuilderRules()
        floor, ceiling, vol, conf = rules.apply_rules(
            floor=15.0,
            ceiling=30.0,
            volatility=5.0,
            signals=[injury, starter],
        )
        
        # Injury OUT wins (highest priority)
        assert floor == 0
        assert ceiling == 0
        # Only 1 rule applied (injury)
        assert len(rules.rules_applied) == 1


class TestProjectionBuilder:
    """Test projection builder."""
    
    def test_create_builder(self):
        """Test creating projection builder."""
        mock_connection = Mock()
        builder = ProjectionBuilder(mock_connection)
        
        assert builder.connection is mock_connection
    
    def test_build_projection(self):
        """Test building projection."""
        mock_connection = Mock()
        builder = ProjectionBuilder(mock_connection)
        builder.signal_store = Mock()
        builder.signal_store.get_for_entity = Mock(return_value=[])

        now = get_utc_now()
        
        proj = builder.build_projection(
            player_id="lbj_123",
            game_id="game_456",
            slate_id="fd_nba_20260122",
            league="NBA",
            as_of_time=now,
            minutes_baseline_floor=15.0,
            minutes_baseline_ceiling=32.0,
            usage_baseline_floor=0.20,
            usage_baseline_ceiling=0.30,
            fppg_baseline=45.0,
            position="SF",
            salary=10000,
        )
        
        assert proj.player_id == "lbj_123"
        assert proj.league == "NBA"
        assert proj.median_fppg > 0
        assert proj.floor_fppg > 0
        assert proj.ceiling_fppg > 0
        assert proj.confidence == 0.75  # Default
    
    def test_projection_with_injury_out(self):
        """Test projection with injury OUT signal."""
        mock_connection = Mock()
        builder = ProjectionBuilder(mock_connection)

        now = get_utc_now()
        injury = InjuryOutSignal(
            entity_id="player_123",
            league="NBA",
            source="official",
            announced_at=now,
        )

        # Mock signal store to return the injury signal
        builder.signal_store = Mock()
        builder.signal_store.get_for_entity = Mock(return_value=[injury])

        proj = builder.build_projection(
            player_id="player_123",
            game_id="game_456",
            slate_id="fd_nba_20260122",
            league="NBA",
            as_of_time=now,
            minutes_baseline_floor=15.0,
            minutes_baseline_ceiling=32.0,
            usage_baseline_floor=0.20,
            usage_baseline_ceiling=0.30,
            fppg_baseline=45.0,
            position="PG",
            salary=8000,
        )

        # Should have zero FPPG
        assert proj.floor_fppg == 0
        assert proj.ceiling_fppg == 0
        assert proj.confidence == 0
    
    def test_inputs_hash_determinism(self):
        """Test that same inputs produce same hash."""
        mock_connection = Mock()
        builder = ProjectionBuilder(mock_connection)
        builder.signal_store = Mock()
        builder.signal_store.get_for_entity = Mock(return_value=[])
        
        now = get_utc_now()
        
        proj1 = builder.build_projection(
            player_id="sc_456",
            game_id="game_789",
            slate_id="fd_nba_20260122",
            league="NBA",
            as_of_time=now,
            minutes_baseline_floor=10.0,
            minutes_baseline_ceiling=25.0,
            usage_baseline_floor=0.15,
            usage_baseline_ceiling=0.25,
            fppg_baseline=40.0,
            position="PG",
            salary=7500,
        )
        
        proj2 = builder.build_projection(
            player_id="sc_456",
            game_id="game_789",
            slate_id="fd_nba_20260122",
            league="NBA",
            as_of_time=now,
            minutes_baseline_floor=10.0,
            minutes_baseline_ceiling=25.0,
            usage_baseline_floor=0.15,
            usage_baseline_ceiling=0.25,
            fppg_baseline=40.0,
            position="PG",
            salary=7500,
        )
        
        # Same inputs → same hash
        assert proj1.inputs_hash == proj2.inputs_hash
    
    def test_build_slate_projections(self):
        """Test building projections for entire slate."""
        mock_connection = Mock()
        builder = ProjectionBuilder(mock_connection)
        builder.signal_store = Mock()
        builder.signal_store.get_for_entity = Mock(return_value=[])
        
        now = get_utc_now()
        
        player_data = {
            "player_1": {
                "game_1": {
                    "league": "NBA",
                    "minutes_baseline_floor": 10.0,
                    "minutes_baseline_ceiling": 25.0,
                    "usage_baseline_floor": 0.15,
                    "usage_baseline_ceiling": 0.25,
                    "fppg_baseline": 30.0,
                    "position": "PG",
                    "salary": 7000,
                }
            },
            "player_2": {
                "game_1": {
                    "league": "NBA",
                    "minutes_baseline_floor": 5.0,
                    "minutes_baseline_ceiling": 15.0,
                    "usage_baseline_floor": 0.10,
                    "usage_baseline_ceiling": 0.20,
                    "fppg_baseline": 20.0,
                    "position": "SG",
                    "salary": 6000,
                }
            },
        }
        
        projections = builder.build_slate_projections(
            slate_id="fd_nba_20260122",
            game_ids=["game_1"],
            player_game_data=player_data,
            as_of_time=now,
        )
        
        assert len(projections) == 2
        assert "player_1" in projections
        assert "player_2" in projections


class TestProjectionStore:
    """Test projection storage."""
    
    def test_create_store(self):
        """Test creating store."""
        mock_connection = Mock()
        store = ProjectionStore(mock_connection)
        
        assert store.connection is mock_connection
    
    def test_insert_projection(self):
        """Test inserting projection."""
        mock_connection = Mock()
        mock_result = Mock()
        mock_result.first.return_value = [123]  # projection_id
        mock_connection.execute.return_value = mock_result
        
        store = ProjectionStore(mock_connection)
        
        now = get_utc_now()
        proj = ProjectionDistribution(
            player_id="lbj_123",
            game_id="game_456",
            slate_id="fd_nba_20260122",
            league="NBA",
            as_of_time=now,
            median_fppg=45.0,
            floor_fppg=30.0,
            ceiling_fppg=60.0,
            volatility=8.0,
            confidence=0.85,
        )
        
        projection_id = store.insert(proj)
        
        assert projection_id == 123
        assert mock_connection.execute.called


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
