"""Tests for signals layer - decay, overrides, snapshots."""

import pytest
from datetime import timedelta

from core import get_utc_now, to_utc, SIGNAL_TYPE, DECAY_PROFILE
from signals import (
    SignalSpec,
    InjuryOutSignal,
    ConfirmedStarterSignal,
    OverrideEngine,
    DecisionSnapshot,
)
from signals.snapshot import SnapshotBuilder

class TestSignalSpec:
    """Test signal specification and decay."""

    def test_signal_creation(self):
        """Test creating a basic signal."""
        now = get_utc_now()

        signal = SignalSpec(
            signal_type=SIGNAL_TYPE.INJURY_OUT,
            entity_type="player",
            entity_id="player_123",
            league="NBA",
            timestamp_utc=now,
            decay_profile=DECAY_PROFILE.NONE,
            validity_start=now,
            validity_end=now + timedelta(hours=48),
            source="official",
            source_confidence=1.0,
            applies_to=["minutes", "usage"],
            payload={"reason": "test"},
        )

        assert signal.signal_type == SIGNAL_TYPE.INJURY_OUT
        assert signal.source_confidence == 1.0
        assert signal.is_valid_at(now)

    def test_signal_validity_window(self):
        """Test signal validity window checking."""
        now = get_utc_now()
        start = now + timedelta(hours=1)
        end = now + timedelta(hours=2)

        signal = SignalSpec(
            signal_type=SIGNAL_TYPE.INJURY_OUT,
            entity_type="player",
            entity_id="player_123",
            league="NBA",
            timestamp_utc=start,
            decay_profile=DECAY_PROFILE.NONE,
            validity_start=start,
            validity_end=end,
            source="official",
            source_confidence=1.0,
            applies_to=["minutes"],
            payload={"reason": "test"},
        )

        assert not signal.is_valid_at(now)  # Before window
        assert signal.is_valid_at(start + timedelta(minutes=30))  # Inside
        assert not signal.is_valid_at(end + timedelta(minutes=1))  # After

    def test_confidence_decay_none(self):
        """Test no decay profile."""
        now = get_utc_now()

        signal = SignalSpec(
            signal_type=SIGNAL_TYPE.INJURY_OUT,
            entity_type="player",
            entity_id="player_123",
            league="NBA",
            timestamp_utc=now - timedelta(hours=24),
            decay_profile=DECAY_PROFILE.NONE,
            validity_start=now - timedelta(hours=24),
            validity_end=None,
            source="official",
            source_confidence=1.0,
            applies_to=["minutes"],
            payload={"reason": "test"},
        )

        conf = signal.get_effective_confidence(now)
        assert conf == 1.0

    def test_confidence_decay_fast(self):
        """Test fast decay profile (15-min half-life)."""
        now = get_utc_now()
        signal_time = now - timedelta(minutes=15)

        signal = SignalSpec(
            signal_type=SIGNAL_TYPE.OWNERSHIP_PROJECTION,
            entity_type="player",
            entity_id="player_123",
            league="NBA",
            timestamp_utc=signal_time,
            decay_profile=DECAY_PROFILE.FAST,
            validity_start=signal_time,
            validity_end=signal_time + timedelta(minutes=30),
            source="model",
            source_confidence=0.8,
            applies_to=["ownership"],
            payload={"ownership": 0.22},
        )

        conf = signal.get_effective_confidence(now)
        expected = 0.8 * 0.5
        assert abs(conf - expected) < 0.01

    def test_applies_to_domain(self):
        """Test applies_to domain checking."""
        now = get_utc_now()

        signal = SignalSpec(
            signal_type=SIGNAL_TYPE.INJURY_OUT,
            entity_type="player",
            entity_id="player_123",
            league="NBA",
            timestamp_utc=now,
            decay_profile=DECAY_PROFILE.NONE,
            validity_start=now,
            validity_end=None,
            source="official",
            source_confidence=1.0,
            applies_to=["minutes", "usage"],
            cannot_apply_to=["efficiency"],
            payload={"reason": "test"},
        )

        assert signal.applies_to_domain("minutes")
        assert signal.applies_to_domain("usage")
        assert not signal.applies_to_domain("efficiency")
        assert not signal.applies_to_domain("projection")


class TestSignalTemplates:
    def test_injury_out_creation(self):
        now = get_utc_now()
        return_date = now + timedelta(days=7)

        signal = InjuryOutSignal(
            entity_id="player_123",
            league="NBA",
            source="official",
            announced_at=now,
            expected_return=return_date,
            reason="Knee injury",
        )

        assert signal.signal_type == SIGNAL_TYPE.INJURY_OUT
        assert signal.source_confidence == 1.0
        assert signal.decay_profile == DECAY_PROFILE.NONE
        assert "minutes" in signal.applies_to
        assert "efficiency" not in signal.applies_to
        assert signal.payload["reason"] == "Knee injury"

    def test_confirmed_starter_creation(self):
        now = get_utc_now()

        signal = ConfirmedStarterSignal(
            entity_id="player_123",
            league="NBA",
            game_id="game_456",
            announced_at=now,
        )

        assert signal.signal_type == SIGNAL_TYPE.CONFIRMED_STARTER
        assert signal.decay_profile == DECAY_PROFILE.NONE
        assert "minutes" in signal.applies_to
        assert "usage" in signal.applies_to
        assert "efficiency" not in signal.applies_to
        assert signal.payload["status"] == "confirmed_starter"


class TestOverrideEngine:
    def test_injury_out_override(self):
        now = get_utc_now()

        signal = InjuryOutSignal(
            entity_id="player_123",
            league="NBA",
            source="official",
            announced_at=now,
        )

        engine = OverrideEngine()
        baseline = {
            "minutes_floor": 10,
            "minutes_ceiling": 35,
            "usage_floor": 0.15,
            "usage_ceiling": 0.35,
        }

        result = engine.apply_overrides([signal], "minutes", baseline, now)

        assert result["minutes_floor"] == 0
        assert result["minutes_ceiling"] == 0
        assert result["is_out"] is True

    def test_confirmed_starter_opportunity_expansion(self):
        """Starter expands minutes ceiling more than floor (opportunity access, not boost)."""
        now = get_utc_now()

        signal = ConfirmedStarterSignal(
            entity_id="player_123",
            league="NBA",
            game_id="game_456",
            announced_at=now,
        )

        engine = OverrideEngine()
        baseline = {
            "minutes_floor": 10,
            "minutes_ceiling": 30,
            "is_starter": False,
        }

        result = engine.apply_overrides([signal], "minutes", baseline, now)

        assert result["is_starter"] is True
        assert result["starter_status"] == "confirmed"

        # Stronger assertion: ceiling adjustment should exceed any floor adjustment
        ceil_adj = result.get("minutes_ceiling_adjustment", 0)
        floor_adj = result.get("minutes_floor_adjustment", 0)
        assert ceil_adj > 0
        assert ceil_adj >= floor_adj

    def test_override_priority_injury_beats_starter(self):
        now = get_utc_now()

        injury_signal = InjuryOutSignal(
            entity_id="player_123",
            league="NBA",
            source="official",
            announced_at=now,
        )

        starter_signal = ConfirmedStarterSignal(
            entity_id="player_123",
            league="NBA",
            game_id="game_456",
            announced_at=now - timedelta(hours=1),
        )

        engine = OverrideEngine()
        baseline = {"minutes_floor": 10, "minutes_ceiling": 30}

        result = engine.apply_overrides(
            [starter_signal, injury_signal],
            "minutes",
            baseline,
            now,
        )

        assert result["minutes_ceiling"] == 0
        assert result["is_out"] is True

    def test_override_engine_accepts_plain_signalspec(self):
        """DB-hydrated signals are SignalSpec (not subclasses). Ensure overrides still work."""
        now = get_utc_now()

        starter = SignalSpec(
            signal_type=SIGNAL_TYPE.CONFIRMED_STARTER,
            entity_type="player",
            entity_id="player_123",
            league="NBA",
            timestamp_utc=now,
            decay_profile=DECAY_PROFILE.NONE,
            validity_start=now - timedelta(hours=1),
            validity_end=now + timedelta(hours=6),
            source="official",
            source_confidence=1.0,
            applies_to=["minutes", "usage"],
            payload={"status": "confirmed_starter", "game_id": "game_456"},
        )

        engine = OverrideEngine()
        baseline = {"minutes_floor": 10, "minutes_ceiling": 30, "is_starter": False}

        result = engine.apply_overrides([starter], "minutes", baseline, now)
        assert result["is_starter"] is True


class TestDecisionSnapshot:
    def test_snapshot_creation(self):
        now = get_utc_now()

        snapshot = DecisionSnapshot(
            entity_type="player",
            entity_id="player_123",
            league="NBA",
            as_of_time=now,
        )

        assert snapshot.entity_id == "player_123"
        assert snapshot.league == "NBA"
        assert snapshot.as_of_time == to_utc(now)

    def test_snapshot_inputs_hash_reproducible(self):
        now = get_utc_now()

        signal = InjuryOutSignal(
            entity_id="player_123",
            league="NBA",
            source="official",
            announced_at=now,
        )
        signal.signal_id = 1

        snapshot1 = DecisionSnapshot(
            entity_type="player",
            entity_id="player_123",
            league="NBA",
            as_of_time=now,
        )
        snapshot1.add_signals([signal])
        hash1 = snapshot1.compute_inputs_hash()

        snapshot2 = DecisionSnapshot(
            entity_type="player",
            entity_id="player_123",
            league="NBA",
            as_of_time=now,
        )
        snapshot2.add_signals([signal])
        hash2 = snapshot2.compute_inputs_hash()

        assert hash1 == hash2

    def test_snapshot_audit_trail(self):
        """Test generating audit trail."""
        now = get_utc_now()

        signal = InjuryOutSignal(
            entity_id="player_123",
            league="NBA",
            source="official",
            announced_at=now,
        )
        signal.signal_id = 1

        snapshot = DecisionSnapshot(
            entity_type="player",
            entity_id="player_123",
            league="NBA",
            as_of_time=now,
        )
        snapshot.add_signals([signal])
        snapshot.compute_signal_contributions()
        snapshot.compute_inputs_hash()

        builder = SnapshotBuilder(None)
        audit = builder.audit_trail(snapshot)

        assert "DECISION SNAPSHOT AUDIT TRAIL" in audit
        assert "player_123" in audit
        assert SIGNAL_TYPE.INJURY_OUT.name in audit