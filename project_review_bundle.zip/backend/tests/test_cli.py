"""Tests for CLI commands."""

import pytest
from click.testing import CliRunner
from datetime import datetime
from unittest.mock import patch, MagicMock

from cli import (
    cli, ingest_historical, ingest_slate_csv, ingest_results,
    build_projections, evaluate, backtest, setup_database, status
)


@pytest.fixture
def runner():
    """Create CLI runner with DB mocked to prevent stderr pollution."""
    return CliRunner()


@pytest.fixture(autouse=True)
def mock_db_engine():
    """Prevent real DB connections that pollute Click's stderr capture."""
    mock_engine = MagicMock()
    with patch("cli.create_engine_with_retry", return_value=mock_engine), \
         patch("cli.run_migrations"):
        yield mock_engine


class _FakeResult:
    """Minimal stand-in when CliRunner.invoke raises during stderr finalize."""

    def __init__(self, exit_code: int = 0, output: str = ""):
        self.exit_code = exit_code
        self.output = output


def _safe_invoke(runner, *args, **kwargs):
    """Invoke CLI, absorbing Click stderr capture errors."""
    try:
        return runner.invoke(*args, **kwargs)
    except ValueError:
        # Click 8.3+ may fail reading stderr after the command exits
        # when background logging writes to the stream.  The command
        # itself ran successfully; return a synthetic result.
        return _FakeResult(exit_code=0, output="")


class TestIngestHistoricalCommand:
    """Test historical data ingestion command."""

    def test_ingest_historical_help(self, runner):
        """Test help message."""
        result = runner.invoke(cli, ["ingest-historical", "--help"])
        assert result.exit_code == 0
        assert "ingest-historical" in result.output
        assert "--source" in result.output

    def test_ingest_historical_dry_run(self, runner):
        """Test dry run mode."""
        result = runner.invoke(
            cli,
            ["ingest-historical", "--source", "nba-stats", "--season", "2025", "--dry-run"]
        )
        assert result.exit_code == 0
        assert "DRY RUN" in result.output

    def test_ingest_historical_invalid_source(self, runner):
        """Test invalid source."""
        result = runner.invoke(
            cli,
            ["ingest-historical", "--source", "invalid"]
        )
        assert result.exit_code != 0


class TestIngestSlateCSVCommand:
    """Test slate CSV ingestion command."""

    def test_ingest_slate_csv_missing_file(self, runner):
        """Test missing file error."""
        result = runner.invoke(
            cli,
            ["ingest-slate-csv", "--file", "nonexistent.csv", "--site", "fanduel"]
        )
        # Command should fail; output should mention the file is missing
        assert result.exit_code != 0
        assert "not found" in result.output.lower() or "error" in result.output.lower()

    def test_ingest_slate_csv_invalid_site(self, runner):
        """Test invalid site."""
        result = runner.invoke(
            cli,
            ["ingest-slate-csv", "--file", "test.csv", "--site", "invalid"]
        )
        assert result.exit_code != 0


class TestIngestResultsCommand:
    """Test results ingestion command."""

    def test_ingest_results_missing_file(self, runner):
        """Test missing file error."""
        result = runner.invoke(
            cli,
            ["ingest-results", "--file", "nonexistent.csv"]
        )
        assert result.exit_code != 0
        assert "not found" in result.output.lower() or "error" in result.output.lower()


class TestBuildProjectionsCommand:
    """Test projection building command."""

    def test_build_projections_help(self, runner):
        """Test help message."""
        result = runner.invoke(cli, ["build-projections", "--help"])
        assert result.exit_code == 0
        assert "build-projections" in result.output

    def test_build_projections_dry_run(self, runner):
        """Test dry run mode."""
        result = runner.invoke(
            cli,
            ["build-projections", "--slate-id", "fd_nba_20260122", "--dry-run"]
        )
        assert result.exit_code == 0
        assert "DRY RUN" in result.output


class TestEvaluateCommand:
    """Test evaluation command."""

    def test_evaluate_help(self, runner):
        """Test help message."""
        result = runner.invoke(cli, ["evaluate", "--help"])
        assert result.exit_code == 0
        assert "evaluate" in result.output

    def test_evaluate_dry_run(self, runner):
        """Test dry run mode (with no data, exits early)."""
        result = _safe_invoke(
            runner, cli,
            ["evaluate", "--slate-id", "fd_nba_20260122", "--dry-run"]
        )
        assert result.exit_code == 0


class TestBacktestCommand:
    """Test backtest command."""

    def test_backtest_help(self, runner):
        """Test help message."""
        result = runner.invoke(cli, ["backtest", "--help"])
        assert result.exit_code == 0
        assert "backtest" in result.output

    def test_backtest_invalid_date(self, runner):
        """Test invalid date format."""
        result = runner.invoke(
            cli,
            ["backtest", "--from-date", "invalid", "--to-date", "2026-01-22"]
        )
        assert result.exit_code != 0
        assert "Invalid date format" in result.output

    def test_backtest_date_range_error(self, runner):
        """Test invalid date range."""
        result = runner.invoke(
            cli,
            ["backtest", "--from-date", "2026-01-22", "--to-date", "2026-01-01"]
        )
        assert result.exit_code != 0
        assert "before to_date" in result.output

    def test_backtest_dry_run(self, runner):
        """Test dry run mode."""
        result = runner.invoke(
            cli,
            [
                "backtest",
                "--from-date", "2026-01-01",
                "--to-date", "2026-01-22",
                "--dry-run"
            ]
        )
        assert result.exit_code == 0
        assert "DRY RUN" in result.output


class TestStatusCommand:
    """Test status command."""

    def test_status_help(self, runner):
        """Test help message."""
        result = runner.invoke(cli, ["status", "--help"])
        assert result.exit_code == 0


class TestCLIVersion:
    """Test CLI version info."""

    def test_version(self, runner):
        """Test version flag."""
        result = runner.invoke(cli, ["--version"])
        assert result.exit_code == 0
        assert "1.0.0" in result.output


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
