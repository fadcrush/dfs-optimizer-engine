"""End-to-end integration tests."""

import pytest
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import Mock
import tempfile
import csv

from core import get_utc_now
from ingest import FanDuelConnector, DraftKingsConnector
from derive import Canonicalizer, FeatureBuilder
from projection import ProjectionBuilder, ProjectionStore
from evaluation import (
    EvaluationStore, ProjectionAccuracy, AccuracyMetricsComputer
)


class TestEndToEndPipeline:
    """Test complete pipeline from ingest to evaluation."""

    @pytest.fixture(scope="function")
    def mock_connection(self):
        """Provide a mock database connection for integration tests."""
        conn = Mock()
        conn.execute.return_value.first.return_value = None
        conn.execute.return_value.fetchall.return_value = []
        return conn

    def test_fanduel_ingest_to_projections(self, mock_connection):
        """Test FanDuel CSV -> canonicalize -> project pipeline."""
        connection = mock_connection

        # Step 1: Create sample FD CSV file (all required columns)
        # Note: empty strings are stripped by the ingest layer so values
        # must be non-empty for required columns to pass validation.
        fd_rows = [
            {"Id": "12345", "First Name": "LeBron", "Last Name": "James",
             "Position": "SF", "Salary": "10500", "Game": "LAL@BOS",
             "Injury Indicator": "GTD", "Injury Details": "Knee",
             "Played": "true", "Salary Change": "0",
             "Game Info": "LAL@BOS 01/22/2026 07:00PM ET",
             "Link": "https://fd.com/12345"},
            {"Id": "12346", "First Name": "Stephen", "Last Name": "Curry",
             "Position": "PG", "Salary": "9500", "Game": "GSW@LAL",
             "Injury Indicator": "O", "Injury Details": "Rest",
             "Played": "false", "Salary Change": "100",
             "Game Info": "GSW@LAL 01/22/2026 07:00PM ET",
             "Link": "https://fd.com/12346"},
        ]

        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".csv", delete=False, newline=""
        ) as f:
            writer = csv.DictWriter(f, fieldnames=fd_rows[0].keys())
            writer.writeheader()
            writer.writerows(fd_rows)
            csv_path = f.name

        try:
            # Step 2: Ingest with FanDuel connector
            connector = FanDuelConnector()
            valid_records, invalid = connector.ingest_and_validate(csv_path)

            assert len(valid_records) == 2
            assert len(invalid) == 0

            # Step 3: Canonicalize
            canonicalizer = Canonicalizer(connection)

            for record in valid_records:
                # After transform, records use canonical field names
                pid = record.get("player_id", record.get("Id", ""))
                fname = record.get("first_name", record.get("First Name", ""))
                lname = record.get("last_name", record.get("Last Name", ""))
                pos = record.get("position", record.get("Position", ""))
                player = canonicalizer.get_or_create_player(
                    player_id=f"fd_{pid}",
                    league="NBA",
                    canonical_name=f"{fname} {lname}",
                    position=pos,
                )
                assert player.canonical_name in ["LeBron James", "Stephen Curry"]

            # Step 4: Build projections
            builder = ProjectionBuilder(connection)
            builder.signal_store = Mock()
            builder.signal_store.get_for_entity = Mock(return_value=[])

            proj = builder.build_projection(
                player_id="fd_12345",
                game_id="game_123",
                slate_id="fd_nba_20260122",
                league="NBA",
                as_of_time=get_utc_now(),
                minutes_baseline_floor=15.0,
                minutes_baseline_ceiling=32.0,
                usage_baseline_floor=0.20,
                usage_baseline_ceiling=0.30,
                fppg_baseline=45.0,
                position="SF",
                salary=10500,
            )

            assert proj.player_id == "fd_12345"
            assert proj.median_fppg > 0
            assert proj.floor_fppg < proj.ceiling_fppg
        finally:
            Path(csv_path).unlink(missing_ok=True)

    def test_accuracy_evaluation_pipeline(self, mock_connection):
        """Test projection -> results -> accuracy -> evaluation pipeline."""
        now = get_utc_now()

        # Step 1: Create projections
        projections = [
            ProjectionAccuracy(
                projection_id=1,
                player_id="p1",
                game_id="g1",
                slate_id="s1",
                league="NBA",
                projected_fppg=45.0,
                projected_floor=30.0,
                projected_ceiling=60.0,
                projected_confidence=0.85,
                actual_fppg=48.0,
            ),
            ProjectionAccuracy(
                projection_id=2,
                player_id="p2",
                game_id="g1",
                slate_id="s1",
                league="NBA",
                projected_fppg=35.0,
                projected_floor=25.0,
                projected_ceiling=45.0,
                projected_confidence=0.80,
                actual_fppg=32.0,
            ),
        ]

        # Step 2: Compute accuracy metrics
        rmse = AccuracyMetricsComputer.compute_rmse(projections)
        mae = AccuracyMetricsComputer.compute_mae(projections)
        hit_rate = AccuracyMetricsComputer.compute_hit_rate(projections)
        bias = AccuracyMetricsComputer.compute_bias(projections)

        # Step 3: Validate metrics
        assert rmse > 0
        assert mae > 0
        assert 0 <= hit_rate <= 1
        assert isinstance(bias, float)

    def test_draftkings_pipeline(self, mock_connection):
        """Test DraftKings CSV ingest pipeline."""
        # Step 1: Create sample DK CSV file
        dk_rows = [
            {"ID": "12345", "First Name": "LeBron", "Last Name": "James",
             "Salary": "10000", "Game": "LAL-BOS", "Position": "SF",
             "Injury": ""},
        ]

        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".csv", delete=False, newline=""
        ) as f:
            writer = csv.DictWriter(f, fieldnames=dk_rows[0].keys())
            writer.writeheader()
            writer.writerows(dk_rows)
            csv_path = f.name

        try:
            # Step 2: Ingest
            connector = DraftKingsConnector()
            valid_records, invalid = connector.ingest_and_validate(csv_path)

            assert len(valid_records) >= 0  # May have validation issues
        finally:
            Path(csv_path).unlink(missing_ok=True)


class TestDataIntegrity:
    """Test data integrity across pipeline."""

    def test_canonicalization_consistency(self):
        """Test that canonicalization produces consistent IDs."""
        mock_connection = Mock()
        mock_connection.execute.return_value.first.return_value = None
        canonicalizer = Canonicalizer(mock_connection)

        # Create player twice
        player1 = canonicalizer.get_or_create_player(
            player_id="nba_123",
            league="NBA",
            canonical_name="Test Player",
            position="PG",
        )

        player2 = canonicalizer.get_or_create_player(
            player_id="nba_123",
            league="NBA",
            canonical_name="Test Player",
            position="PG",
        )

        # Should be same object (cached)
        assert player1 is player2

    def test_projection_reproducibility(self):
        """Test that same inputs produce same projections."""
        mock_connection = Mock()
        mock_connection.execute.return_value.first.return_value = None
        mock_connection.execute.return_value.fetchall.return_value = []
        builder = ProjectionBuilder(mock_connection)
        builder.signal_store = Mock()
        builder.signal_store.get_for_entity = Mock(return_value=[])

        now = get_utc_now()

        # Build projection twice with same inputs
        proj1 = builder.build_projection(
            player_id="p1",
            game_id="g1",
            slate_id="s1",
            league="NBA",
            as_of_time=now,
            minutes_baseline_floor=15.0,
            minutes_baseline_ceiling=30.0,
            usage_baseline_floor=0.20,
            usage_baseline_ceiling=0.30,
            fppg_baseline=40.0,
            position="PG",
            salary=7000,
        )

        proj2 = builder.build_projection(
            player_id="p1",
            game_id="g1",
            slate_id="s1",
            league="NBA",
            as_of_time=now,
            minutes_baseline_floor=15.0,
            minutes_baseline_ceiling=30.0,
            usage_baseline_floor=0.20,
            usage_baseline_ceiling=0.30,
            fppg_baseline=40.0,
            position="PG",
            salary=7000,
        )

        # Same inputs = same hash
        assert proj1.inputs_hash == proj2.inputs_hash
        # Same hash = reproducible
        assert proj1.median_fppg == proj2.median_fppg


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
