"""CLI usage guide."""

# DFS OPTIMIZER COMMAND-LINE INTERFACE

## Installation

```bash
pip install click==8.1.7
python cli.py --help
```

## Available Commands

### 1. ingest-historical

Ingest historical data from various sources.

Usage:

```bash
python cli.py ingest-historical \
    --source nba-stats \
    --season 2025 \
    [--dry-run]
```

Options:
--source {nba-stats, nfl-stats, fanduel, draftkings}
--season INTEGER (default: 2025)
--dry-run (optional flag)

Examples:

```bash
# Ingest NBA historical data for 2025
python cli.py ingest-historical --source nba-stats --season 2025

# Dry run to preview
python cli.py ingest-historical --source nba-stats --season 2025 --dry-run

# Ingest DraftKings data
python cli.py ingest-historical --source draftkings --season 2025
```

### 2. ingest-slate-csv

Ingest a single slate CSV (FanDuel or DraftKings).

Usage:

```bash
python cli.py ingest-slate-csv \
    --file <path/to/file.csv> \
    --site {fanduel, draftkings} \
    [--slate-id <id>] \
    [--dry-run]
```

Options:
--file (required) - CSV file path
--site (required) - DFS site
--slate-id (optional) - Override detected slate ID
--dry-run (optional flag)

Examples:

```bash
# Ingest FanDuel slate
python cli.py ingest-slate-csv \
    --file FanDuel-NBA-2026-01-22-Main.csv \
    --site fanduel

# Ingest DraftKings with custom slate ID
python cli.py ingest-slate-csv \
    --file DraftKings-NBA-20260122.csv \
    --site draftkings \
    --slate-id dk_nba_20260122_main

# Dry run to see validation results
python cli.py ingest-slate-csv \
    --file slate.csv \
    --site fanduel \
    --dry-run
```

### 3. ingest-results

Ingest contest results (actual FPPG by player).

CSV format required:

```csv
player_id,actual_fppg
nba_12345,45.5
nba_67890,32.0
```

Usage:

```bash
python cli.py ingest-results \
    --file <path/to/results.csv> \
    [--slate-id <id>] \
    [--dry-run]
```

Options:
--file (required) - Results CSV path
--slate-id (optional) - Slate identifier
--dry-run (optional flag)

Examples:

```bash
# Ingest results
python cli.py ingest-results \
    --file results.csv \
    --slate-id fd_nba_20260122

# Dry run
python cli.py ingest-results \
    --file results.csv \
    --dry-run
```

### 4. build-projections

Build projections for a slate at a specific point-in-time.

Usage:

```bash
python cli.py build-projections \
    --slate-id <slate_id> \
    [--as-of-time <ISO-timestamp>] \
    [--version <version>] \
    [--dry-run]
```

Options:
--slate-id (required) - Slate identifier
--as-of-time (optional) - ISO format timestamp (default: now)
--version (optional) - Projection version label (default: v1)
--dry-run (optional flag)

Examples:

```bash
# Build projections for slate right now
python cli.py build-projections --slate-id fd_nba_20260122

# Build projections at specific time
python cli.py build-projections \
    --slate-id fd_nba_20260122 \
    --as-of-time "2026-01-22T18:00:00Z"

# Build with custom version
python cli.py build-projections \
    --slate-id fd_nba_20260122 \
    --version v2_updated

# Dry run
python cli.py build-projections \
    --slate-id fd_nba_20260122 \
    --dry-run
```

### 5. evaluate

Run evaluation and update source reliability scores.

Usage:

```bash
python cli.py evaluate \
    --slate-id <slate_id> \
    [--dry-run]
```

Options:
--slate-id (required) - Slate to evaluate
--dry-run (optional flag)

Examples:

```bash
# Evaluate slate and update source reliability
python cli.py evaluate --slate-id fd_nba_20260122

# Dry run to see what would change
python cli.py evaluate --slate-id fd_nba_20260122 --dry-run
```

Output includes:

- RMSE, MAE, hit_rate, bias metrics
- Source reliability updates
- Recommendations for improvement

### 6. backtest

Backtest projections against historical slates.

Usage:

```bash
python cli.py backtest \
    --from-date <YYYY-MM-DD> \
    --to-date <YYYY-MM-DD> \
    [--league {NBA, NFL}] \
    [--version <version>] \
    [--dry-run]
```

Options:
--from-date (required) - Start date (YYYY-MM-DD)
--to-date (required) - End date (YYYY-MM-DD)
--league (optional) - NBA or NFL (default: NBA)
--version (optional) - Projection version (default: v1)
--dry-run (optional flag)

Examples:

```bash
# Backtest all NBA slates in January
python cli.py backtest \
    --from-date 2026-01-01 \
    --to-date 2026-01-31

# Backtest NFL for specific version
python cli.py backtest \
    --from-date 2025-09-01 \
    --to-date 2025-12-31 \
    --league NFL \
    --version v2_updated

# Dry run to see slates that would be tested
python cli.py backtest \
    --from-date 2026-01-01 \
    --to-date 2026-01-22 \
    --dry-run
```

### 7. setup-database

Initialize database and run migrations.

Usage:

```bash
python cli.py setup-database
```

This:

- Creates database schema
- Runs all pending migrations
- Initializes system tables

### 8. status

Show system status and record counts.

Usage:

```bash
python cli.py status
```

Output:

- Slates: count
- Players: count
- Teams: count
- Games: count
- Signals: count
- Projections: count
- Accuracy Records: count
- Source Reliability: count

## Typical Workflow

### Day-of-slate workflow:

```bash
# 1. Ingest new slate CSV
python cli.py ingest-slate-csv --file slate.csv --site fanduel

# 2. Build projections for now
python cli.py build-projections --slate-id fd_nba_20260122

# 3. Get status
python cli.py status
```

### Post-contest workflow:

```bash
# 1. Ingest contest results
python cli.py ingest-results --file results.csv --slate-id fd_nba_20260122

# 2. Evaluate accuracy
python cli.py evaluate --slate-id fd_nba_20260122

# 3. Review recommendations
# (Output shows improved/worsened sources)
```

### Periodic backtest:

```bash
# Weekly backtest
python cli.py backtest --from-date 2026-01-15 --to-date 2026-01-22

# Monthly backtest
python cli.py backtest --from-date 2026-01-01 --to-date 2026-01-31
```

## Dry-Run Mode

All commands support `--dry-run` to preview changes:

```bash
# See what would be ingested
python cli.py ingest-slate-csv --file slate.csv --site fanduel --dry-run

# See what would be evaluated
python cli.py evaluate --slate-id fd_nba_20260122 --dry-run

# See what slates would be backtested
python cli.py backtest --from-date 2026-01-01 --to-date 2026-01-22 --dry-run
```

## Global Options

```bash
python cli.py --version     # Show version
python cli.py --help        # Show help
python cli.py <command> -h  # Show command-specific help
```

## Error Handling

All commands:

- Validate inputs before processing
- Show clear error messages
- Return non-zero exit code on failure
- Support `--dry-run` for safe exploration

## Exit Codes

0 - Success
1 - Error (invalid arguments, missing file, etc.)
