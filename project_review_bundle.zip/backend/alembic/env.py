"""
Alembic environment script.

Adds backend/src to sys.path so that model imports work when alembic is
invoked from the backend/ directory (where alembic.ini lives).

Usage::

    cd backend/
    alembic upgrade head
    alembic revision --autogenerate -m "describe change"
"""

from __future__ import annotations

import os
import sys
from logging.config import fileConfig
from pathlib import Path

from alembic import context
from sqlalchemy import engine_from_config, pool

# ---------------------------------------------------------------------------
# Ensure backend/src is importable
# ---------------------------------------------------------------------------

_HERE = Path(__file__).resolve().parent          # backend/alembic/
_SRC = _HERE.parent / "src"                      # backend/src/
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

# ---------------------------------------------------------------------------
# Import all models so their metadata is populated before autogenerate
# ---------------------------------------------------------------------------

# Order matters: base first, then models that depend on it.
from models.base import DFSBase          # noqa: E402
import models.slate                      # noqa: E402, F401
import models.player                     # noqa: E402, F401
import models.projection                 # noqa: E402, F401
import models.ownership_model            # noqa: E402, F401
import models.run                        # noqa: E402, F401
import models.lineup                     # noqa: E402, F401
import models.lineup_entry               # noqa: E402, F401

target_metadata = DFSBase.metadata

# ---------------------------------------------------------------------------
# Alembic config object (provides access to alembic.ini values)
# ---------------------------------------------------------------------------

config = context.config

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# Override sqlalchemy.url from env var so secrets stay out of alembic.ini
DATABASE_URL = os.environ.get("DATABASE_URL", "")
if DATABASE_URL:
    config.set_main_option("sqlalchemy.url", DATABASE_URL)


# ---------------------------------------------------------------------------
# Migration helpers
# ---------------------------------------------------------------------------

def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode (no live DB connection needed)."""
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations against a live DB connection."""
    connectable = engine_from_config(
        config.get_section(config.config_ini_section),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        # render_as_batch=True is required for SQLite / DuckDB which do not
        # support ALTER TABLE ADD/DROP COLUMN natively.  It is a safe no-op
        # on PostgreSQL.
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            compare_type=True,      # detect column type changes
            render_as_batch=True,   # SQLite/DuckDB ALTER TABLE support
        )
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
