"""DFS core schema: slates, players, projections, ownership, runs, lineups, entries

Revision ID: 0001
Revises:
Create Date: 2025-01-01 00:00:00.000000

"""
from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0001"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # ------------------------------------------------------------------
    # slates
    # ------------------------------------------------------------------
    op.create_table(
        "slates",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("sport", sa.String(), nullable=False, server_default="nba"),
        sa.Column("platform", sa.String(), nullable=False, server_default="fanduel"),
        sa.Column("slate_date", sa.Date(), nullable=True),
        sa.Column("source_filename", sa.String(), nullable=True),
        sa.Column("player_count", sa.Integer(), nullable=True, server_default="0"),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
    )

    # ------------------------------------------------------------------
    # slate_players
    # ------------------------------------------------------------------
    op.create_table(
        "slate_players",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("slate_id", sa.String(), nullable=False),
        sa.Column("external_id", sa.String(), nullable=False),
        sa.Column("name", sa.String(), nullable=False),
        sa.Column("position", sa.String(), nullable=True),
        sa.Column("team", sa.String(), nullable=True),
        sa.Column("opponent", sa.String(), nullable=True),
        sa.Column("salary", sa.Integer(), nullable=True, server_default="0"),
        sa.Column("game", sa.String(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(["slate_id"], ["slates.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("slate_id", "external_id", name="uq_slate_player_external"),
    )
    op.create_index("ix_slate_players_slate_id", "slate_players", ["slate_id"])

    # ------------------------------------------------------------------
    # projections
    # ------------------------------------------------------------------
    op.create_table(
        "projections",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("slate_id", sa.String(), nullable=False),
        sa.Column("player_id", sa.String(), nullable=False),
        sa.Column("projection", sa.Float(), nullable=True, server_default="0.0"),
        sa.Column("floor", sa.Float(), nullable=True, server_default="0.0"),
        sa.Column("ceiling", sa.Float(), nullable=True, server_default="0.0"),
        sa.Column("value", sa.Float(), nullable=True, server_default="0.0"),
        sa.Column("injury_status", sa.String(), nullable=True),
        sa.Column("ownership_pct", sa.Float(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(["player_id"], ["slate_players.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["slate_id"], ["slates.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("slate_id", "player_id", name="uq_projection_slate_player"),
    )
    op.create_index("ix_projections_slate_id", "projections", ["slate_id"])
    op.create_index("ix_projections_player_id", "projections", ["player_id"])

    # ------------------------------------------------------------------
    # ownership_data
    # ------------------------------------------------------------------
    op.create_table(
        "ownership_data",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("slate_id", sa.String(), nullable=False),
        sa.Column("player_id", sa.String(), nullable=False),
        sa.Column("ownership_pct", sa.Float(), nullable=False),
        sa.Column("source", sa.String(), nullable=True, server_default="upload"),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(["player_id"], ["slate_players.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["slate_id"], ["slates.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_ownership_data_slate_id", "ownership_data", ["slate_id"])
    op.create_index("ix_ownership_data_player_id", "ownership_data", ["player_id"])

    # ------------------------------------------------------------------
    # runs
    # ------------------------------------------------------------------
    op.create_table(
        "runs",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("slate_id", sa.String(), nullable=True),
        sa.Column("status", sa.String(), nullable=False, server_default="queued"),
        sa.Column("num_lineups", sa.Integer(), nullable=True, server_default="0"),
        sa.Column("settings", sa.Text(), nullable=True),
        sa.Column("error_message", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.Column("started_at", sa.DateTime(), nullable=True),
        sa.Column("completed_at", sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(["slate_id"], ["slates.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_runs_slate_id", "runs", ["slate_id"])
    op.create_index("ix_runs_status", "runs", ["status"])

    # ------------------------------------------------------------------
    # lineups
    # ------------------------------------------------------------------
    op.create_table(
        "lineups",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("run_id", sa.String(), nullable=False),
        sa.Column("lineup_number", sa.Integer(), nullable=False),
        sa.Column("total_salary", sa.Integer(), nullable=True, server_default="0"),
        sa.Column("total_projection", sa.Float(), nullable=True, server_default="0.0"),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(["run_id"], ["runs.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_lineups_run_id", "lineups", ["run_id"])

    # ------------------------------------------------------------------
    # lineup_entries
    # ------------------------------------------------------------------
    op.create_table(
        "lineup_entries",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("lineup_id", sa.String(), nullable=False),
        sa.Column("player_id", sa.String(), nullable=False),
        sa.Column("slate_id", sa.String(), nullable=True),
        sa.Column("position", sa.String(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.ForeignKeyConstraint(["lineup_id"], ["lineups.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["player_id"], ["slate_players.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_lineup_entries_lineup_id", "lineup_entries", ["lineup_id"])
    op.create_index("ix_lineup_entries_player_id", "lineup_entries", ["player_id"])
    op.create_index("ix_lineup_entries_slate_id", "lineup_entries", ["slate_id"])


def downgrade() -> None:
    op.drop_index("ix_lineup_entries_slate_id", table_name="lineup_entries")
    op.drop_index("ix_lineup_entries_player_id", table_name="lineup_entries")
    op.drop_index("ix_lineup_entries_lineup_id", table_name="lineup_entries")
    op.drop_table("lineup_entries")

    op.drop_index("ix_lineups_run_id", table_name="lineups")
    op.drop_table("lineups")

    op.drop_index("ix_runs_status", table_name="runs")
    op.drop_index("ix_runs_slate_id", table_name="runs")
    op.drop_table("runs")

    op.drop_index("ix_ownership_data_player_id", table_name="ownership_data")
    op.drop_index("ix_ownership_data_slate_id", table_name="ownership_data")
    op.drop_table("ownership_data")

    op.drop_index("ix_projections_player_id", table_name="projections")
    op.drop_index("ix_projections_slate_id", table_name="projections")
    op.drop_table("projections")

    op.drop_index("ix_slate_players_slate_id", table_name="slate_players")
    op.drop_table("slate_players")

    op.drop_table("slates")
