"""
Test Vegas Odds Service
"""

import asyncio
from services.vegas_service import VegasOddsService, get_vegas_odds

async def main():
    print("\n" + "="*70)
    print("💰 TESTING VEGAS ODDS SERVICE")
    print("="*70)
    
    # Test 1: Get odds
    print("\n📋 Test 1: Fetching Vegas odds...")
    result = await get_vegas_odds()
    
    if result['success']:
        print(f"✅ Found odds for {result['total_games']} games")
        
        if result['games']:
            print("\nFirst game:")
            game = result['games'][0]
            print(f"   {game['away_team']} @ {game['home_team']}")
            print(f"   Total: {game.get('total')}")
            print(f"   Spread: {game.get('home_spread')}")
            print(f"   Implied totals: {game.get('away_implied_points')} / {game.get('home_implied_points')}")
    
    # Test 2: Get report
    print("\n📋 Test 2: Generating Vegas report...")
    service = VegasOddsService()
    report = service.get_vegas_report()
    print(report)
    
    # Test 3: Team total lookup
    print("\n📋 Test 3: Looking up specific team...")
    lal_total = service.get_team_total('LAL')
    print(f"   Lakers implied total: {lal_total}")
    
    print("\n✅ All tests complete!")
    print("="*70 + "\n")

if __name__ == "__main__":
    asyncio.run(main())