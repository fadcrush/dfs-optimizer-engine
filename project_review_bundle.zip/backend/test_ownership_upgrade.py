"""
Test ownership model upgrade
Compare predictions and analyze patterns
"""

import pandas as pd
from pathlib import Path

# Find most recent projections file
projections_dir = Path("uploads/projections")
projection_files = sorted(projections_dir.glob("projections_*.csv"), key=lambda x: x.stat().st_mtime, reverse=True)

if projection_files:
    latest_file = projection_files[0]
    print(f"\n📊 Using: {latest_file.name}\n")
    
    # Load it
    df = pd.read_csv(latest_file)
    
    if len(df) == 0:
        print("❌ File is empty! Generate projections first!")
        print("\nSteps:")
        print("1. Go to http://localhost:8000/docs")
        print("2. Use POST /api/projections/generate-from-upload")
        print("3. Upload your FanDuel slate")
        print("4. Wait for completion")
        print("5. Run this script again\n")
        exit()
    
    df.columns = [c.lower() for c in df.columns]
    
    print(f"✅ Loaded {len(df)} players")
    
    # Check for injury column
    if 'injury_status' in df.columns:
        out_count = len(df[df['injury_status'] == 'O'])
        print(f"   OUT players: {out_count}")
    else:
        print(f"   No injury status column")
    
    # Check for team column
    if 'team' in df.columns:
        print(f"   Teams: {df['team'].nunique()} unique teams")
    
    # Now run ownership
    from services.ownership_simulator import simulate_ownership
    
    print(f"\n🎲 Running ownership simulator...")
    result = simulate_ownership(str(latest_file))
    
    if result['success']:
        print(f"\n✅ OWNERSHIP ANALYSIS COMPLETE!")
        print(f"="*70)
        print(f"   Total players analyzed: {result['stats']['total_players']}")
        print(f"   Average ownership: {result['stats']['avg_ownership']:.1f}%")
        print(f"   High owned (>30%): {result['stats']['high_owned_count']}")
        print(f"   Low owned (<15%): {result['stats']['low_owned_count']}")
        
        print(f"\n💎 TOP LEVERAGE PLAYS:")
        for play in result['stats']['top_leverage_plays'][:5]:
            print(f"      {play['name']:<25} Proj:{play['projection']:>5.1f} Own:{play['predicted_ownership']:>5.1f}% Lev:{play['leverage']:>5.1f}")
        
        print(f"\n{'='*70}\n")
    else:
        print(f"\n❌ Ownership simulation failed: {result.get('error')}")
else:
    print("❌ No projection files found!")
    print("\nGenerate projections first:")
    print("1. Go to http://localhost:8000/docs")
    print("2. Use POST /api/projections/generate-from-upload")
    print("3. Upload your FanDuel slate\n")