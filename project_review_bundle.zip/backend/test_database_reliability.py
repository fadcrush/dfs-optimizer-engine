#!/usr/bin/env python
"""
Test Database Reliability - Phase 1 Implementation
Tests connection pooling, retry logic, health monitoring, and backup/recovery
"""

import pytest
import os
import time
from unittest.mock import patch, MagicMock
from pathlib import Path

# Add parent directory to path for imports
import sys
sys.path.insert(0, str(Path(__file__).parent))

from database.db import (
    DatabaseConfig,
    create_engine_with_retry,
    get_health_status,
    DataValidator,
    DatabaseBackupManager,
    perform_data_validation
)

class TestDatabaseConfig:
    """Test database configuration management"""

    def test_default_config_values(self):
        """Test that default configuration values are set correctly"""
        config = DatabaseConfig()

        # Check default values
        assert config.pool_size == 10
        assert config.max_overflow == 20
        assert config.pool_timeout == 30
        assert config.pool_recycle == 3600
        assert config.max_retries == 3
        assert config.retry_delay == 0.5
        assert config.health_check_interval == 60

    def test_environment_variable_loading(self):
        """Test that environment variables override defaults"""
        with patch.dict(os.environ, {
            'DB_POOL_SIZE': '15',
            'DB_MAX_RETRIES': '5',
            'DB_RETRY_DELAY': '1.0'
        }):
            config = DatabaseConfig()
            assert config.pool_size == 15
            assert config.max_retries == 5
            assert config.retry_delay == 1.0

    def test_duckdb_detection(self):
        """Test DuckDB vs PostgreSQL detection"""
        config = DatabaseConfig()

        # Default should be DuckDB (fallback)
        assert config.is_duckdb() == True

        # With PostgreSQL URL, should detect PostgreSQL
        config.database_url = "postgresql://user:pass@localhost/db"
        assert config.is_duckdb() == False

class TestConnectionRetry:
    """Test database connection retry logic"""

    @patch('database.db.create_database_engine')
    def test_successful_connection_first_try(self, mock_create_engine):
        """Test successful connection on first attempt"""
        mock_engine = MagicMock()
        mock_create_engine.return_value = mock_engine

        # Mock successful connection test
        mock_conn = MagicMock()
        mock_engine.connect.return_value.__enter__.return_value = mock_conn
        mock_conn.execute.return_value.fetchone.return_value = (1,)

        engine = create_engine_with_retry(max_retries=3, retry_delay=0.1)

        assert engine == mock_engine
        assert mock_create_engine.call_count == 1  # Only called once

    @patch('database.db.create_database_engine')
    @patch('time.sleep')
    def test_connection_retry_on_failure(self, mock_sleep, mock_create_engine):
        """Test retry logic when connection fails"""
        mock_engine = MagicMock()
        mock_create_engine.return_value = mock_engine

        # Mock connection failure twice, then success
        mock_conn = MagicMock()
        mock_engine.connect.return_value.__enter__.return_value = mock_conn

        # First two calls fail, third succeeds
        mock_conn.execute.side_effect = [Exception("Connection failed"), Exception("Connection failed"), (1,)]

        engine = create_engine_with_retry(max_retries=3, retry_delay=0.1)

        assert engine == mock_engine
        assert mock_create_engine.call_count == 3  # Called 3 times (initial + 2 retries)
        assert mock_sleep.call_count == 2  # Slept twice during retries

    @patch('database.db.create_database_engine')
    @patch('time.sleep')
    def test_connection_retry_exhaustion(self, mock_sleep, mock_create_engine):
        """Test that retries are exhausted and exception is raised"""
        mock_engine = MagicMock()
        mock_create_engine.return_value = mock_engine

        # Mock persistent connection failure
        mock_conn = MagicMock()
        mock_engine.connect.return_value.__enter__.return_value = mock_conn
        mock_conn.execute.side_effect = Exception("Persistent failure")

        with pytest.raises(Exception, match="Persistent failure"):
            create_engine_with_retry(max_retries=2, retry_delay=0.1)

        assert mock_create_engine.call_count == 3  # Initial + 2 retries
        assert mock_sleep.call_count == 2

class TestHealthMonitoring:
    """Test database health monitoring"""

    @patch('database.db.engine')
    def test_health_check_structure(self, mock_engine):
        """Test that health check returns proper structure"""
        mock_conn = MagicMock()
        mock_engine.connect.return_value.__enter__.return_value = mock_conn
        mock_conn.execute.return_value.fetchone.return_value = (1,)

        health = get_health_status()

        required_keys = ['status', 'timestamp', 'pool_stats', 'database_type']
        for key in required_keys:
            assert key in health

        assert health['status'] in ['healthy', 'unhealthy']
        assert isinstance(health['timestamp'], (int, float))

class TestDataValidation:
    """Test data validation framework"""

    @patch('database.db.engine')
    def test_table_existence_check(self, mock_engine):
        """Test table existence validation"""
        mock_conn = MagicMock()
        mock_engine.connect.return_value.__enter__.return_value = mock_conn

        # Mock DuckDB table check
        mock_result = MagicMock()
        mock_conn.execute.return_value = mock_result
        mock_result.fetchone.return_value = ('players',)  # Table exists

        exists = DataValidator.validate_table_exists('players')
        assert exists == True

        # Mock table not found
        mock_result.fetchone.return_value = None
        exists = DataValidator.validate_table_exists('nonexistent_table')
        assert exists == False

    @patch('database.db.engine')
    def test_row_count_validation(self, mock_engine):
        """Test row count validation"""
        mock_conn = MagicMock()
        mock_engine.connect.return_value.__enter__.return_value = mock_conn

        mock_result = MagicMock()
        mock_conn.execute.return_value = mock_result
        mock_result.fetchone.return_value = (1500,)  # 1500 rows

        result = DataValidator.validate_row_count('player_game_logs', 1000)

        assert result['table'] == 'player_game_logs'
        assert result['row_count'] == 1500
        assert result['meets_minimum'] == True
        assert result['status'] == 'valid'

class TestBackupManager:
    """Test database backup and recovery"""

    @patch('pathlib.Path.exists')
    @patch('shutil.copy2')
    def test_backup_creation(self, mock_copy, mock_exists):
        """Test backup creation"""
        mock_exists.return_value = True

        backup_manager = DatabaseBackupManager()
        result = backup_manager.create_backup('test_backup')

        assert result['status'] == 'success'
        assert 'backup_path' in result
        assert 'backup_size' in result
        assert mock_copy.called

    def test_backup_listing(self):
        """Test backup listing"""
        backup_manager = DatabaseBackupManager()
        backups = backup_manager.list_backups()

        assert isinstance(backups, list)
        # Should return empty list if no backups exist

class TestDataValidationIntegration:
    """Test comprehensive data validation"""

    @patch('database.db.DataValidator.validate_table_exists')
    @patch('database.db.DataValidator.validate_row_count')
    @patch('database.db.DataValidator.validate_data_freshness')
    def test_comprehensive_validation(self, mock_freshness, mock_row_count, mock_exists):
        """Test full data validation pipeline"""
        # Mock all validation methods
        mock_exists.return_value = True
        mock_row_count.return_value = {
            'table': 'players',
            'row_count': 500,
            'meets_minimum': True,
            'status': 'valid'
        }
        mock_freshness.return_value = {
            'table': 'players',
            'status': 'valid',
            'is_fresh': True
        }

        result = perform_data_validation()

        assert 'timestamp' in result
        assert 'tables' in result
        assert 'overall_status' in result
        assert result['overall_status'] in ['valid', 'issues_found']

def run_tests():
    """Run all tests and report results"""
    print("="*60)
    print("PHASE 1: DATABASE RELIABILITY - TEST SUITE")
    print("="*60)

    # Run pytest programmatically
    import subprocess
    result = subprocess.run([
        'python', '-m', 'pytest', __file__, '-v', '--tb=short'
    ], capture_output=True, text=True)

    print(result.stdout)
    if result.stderr:
        print("STDERR:", result.stderr)

    print("="*60)
    if result.returncode == 0:
        print("✅ ALL TESTS PASSED - Phase 1 Database Reliability is working!")
    else:
        print("❌ SOME TESTS FAILED - Check implementation")

    print("="*60)

if __name__ == "__main__":
    run_tests()
