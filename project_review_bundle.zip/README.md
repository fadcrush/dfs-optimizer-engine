# AI-Powered DFS System

Professional daily fantasy sports platform with AI injury analysis.

## Project Structure Overview

```
N_B_A_and_N_F_L/
├── backend/           # FastAPI application, services, and database layer
├── frontend/          # Next.js React web application
├── analysis/          # Domain-specific analytics (NBA/NFL)
├── scripts/           # Utility and maintenance scripts
├── dashboard/         # Streamlit dashboard
├── config/            # Configuration files
├── data/              # DuckDB and data processing
├── docs/              # Documentation
└── tests/             # Test suites
```

## Primary Entry Points

| Entry Point | Purpose |
|-------------|---------|
| `backend/main.py` | FastAPI application server |
| `backend/cli.py` | Command-line interface |
| `analysis/entrypoints/workflow.py` | Analytics workflows |
| `scripts/` | One-off utilities and maintenance scripts |

## Running the Project

### Backend (API)

```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload
```

### Frontend (Next.js)

```bash
cd frontend
npm install
npm run dev
```

### Analysis Workflows

```bash
python -m analysis.entrypoints.workflow
```

### Utility Scripts

```bash
# Database setup
python scripts/setup_database.py

# Run automation
python scripts/run_automation.py path/to/slate.csv --num-lineups 150

# Late swap during games
python scripts/run_late_swap.py lineups.csv slate.csv

# Backtest after slate
python scripts/run_backtest.py --date 2026-01-02
```

## Notes

- `analysis/` contains domain logic for NBA and NFL analytics, projections, and optimization algorithms
- `backend/` contains the API layer, orchestration services, and database access
- `scripts/` contains standalone utilities that can be run independently
- Configuration files (`config.py`, `config_template.py`) remain at the project root
