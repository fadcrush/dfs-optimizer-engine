-- ============================================================================
-- MASTER DFS DATABASE SCHEMA
-- Complete database structure for professional DFS analysis
-- ============================================================================

-- ============================================================================
-- CORE PLAYER DATA
-- ============================================================================

-- Player master table
CREATE TABLE IF NOT EXISTS players (
    player_id VARCHAR PRIMARY KEY,
    player_name VARCHAR NOT NULL,
    primary_position VARCHAR,
    team VARCHAR,
    sport VARCHAR NOT NULL,  -- 'NBA' or 'NFL'
    height VARCHAR,
    weight INTEGER,
    age INTEGER,
    experience INTEGER,
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Player game logs (every game, every stat)
CREATE TABLE IF NOT EXISTS player_game_logs (
    game_log_id INTEGER PRIMARY KEY,
    game_id VARCHAR NOT NULL,
    player_id VARCHAR NOT NULL,
    player_name VARCHAR NOT NULL,
    date DATE NOT NULL,
    season VARCHAR,
    
    -- Team info
    team VARCHAR,
    opponent VARCHAR,
    home_away VARCHAR,  -- 'Home' or 'Away'
    
    -- Game context
    started BOOLEAN,
    minutes_played FLOAT,
    rest_days INTEGER,
    game_number INTEGER,  -- Game number in season
    
    -- NBA Stats
    points INTEGER,
    rebounds INTEGER,
    assists INTEGER,
    steals INTEGER,
    blocks INTEGER,
    turnovers INTEGER,
    fgm INTEGER,
    fga INTEGER,
    fg3m INTEGER,
    fg3a INTEGER,
    ftm INTEGER,
    fta INTEGER,
    offensive_rebounds INTEGER,
    defensive_rebounds INTEGER,
    
    -- NFL Stats
    pass_attempts INTEGER,
    pass_completions INTEGER,
    pass_yards INTEGER,
    pass_tds INTEGER,
    interceptions INTEGER,
    rush_attempts INTEGER,
    rush_yards INTEGER,
    rush_tds INTEGER,
    targets INTEGER,
    receptions INTEGER,
    receiving_yards INTEGER,
    receiving_tds INTEGER,
    fumbles_lost INTEGER,
    
    -- Fantasy Points
    dk_points FLOAT,
    fd_points FLOAT,
    yahoo_points FLOAT,
    
    -- Advanced Stats
    usage_rate FLOAT,
    true_shooting_pct FLOAT,
    plus_minus INTEGER,
    
    -- Metadata
    source VARCHAR,  -- 'NBA_API', 'ESPN', etc.
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_game_logs_player ON player_game_logs(player_id);
CREATE INDEX IF NOT EXISTS idx_game_logs_date ON player_game_logs(date);
CREATE INDEX IF NOT EXISTS idx_game_logs_team ON player_game_logs(team);

-- ============================================================================
-- TEAM DEFENSE ANALYTICS
-- ============================================================================

-- Team defense by position
CREATE TABLE IF NOT EXISTS team_defense_by_position (
    defense_id INTEGER PRIMARY KEY,
    date DATE NOT NULL,
    season VARCHAR,
    team VARCHAR NOT NULL,
    sport VARCHAR NOT NULL,
    
    -- Position (PG, SG, SF, PF, C for NBA; QB, RB, WR, TE for NFL)
    position VARCHAR NOT NULL,
    
    -- Fantasy points allowed
    games_played INTEGER,
    total_fpts_allowed FLOAT,
    avg_fpts_allowed FLOAT,
    
    -- Rank (1 = allows least, 30/32 = allows most)
    rank INTEGER,
    
    -- Advanced metrics
    pace FLOAT,
    defensive_efficiency FLOAT,
    
    -- Metadata
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_defense_team_pos ON team_defense_by_position(team, position);
CREATE INDEX IF NOT EXISTS idx_defense_date ON team_defense_by_position(date);

-- ============================================================================
-- GAME CONTEXT
-- ============================================================================

-- Game information and context
CREATE TABLE IF NOT EXISTS games (
    game_id VARCHAR PRIMARY KEY,
    date DATE NOT NULL,
    season VARCHAR,
    sport VARCHAR NOT NULL,
    
    -- Teams
    home_team VARCHAR,
    away_team VARCHAR,
    
    -- Vegas lines
    vegas_total FLOAT,
    home_spread FLOAT,
    over_under FLOAT,
    
    -- Game flow
    home_score INTEGER,
    away_score INTEGER,
    total_score INTEGER,
    
    -- Pace metrics
    pace FLOAT,
    possessions INTEGER,
    
    -- Weather (NFL only)
    temperature INTEGER,
    wind_speed INTEGER,
    precipitation VARCHAR,
    dome BOOLEAN,
    
    -- Game type
    playoff_game BOOLEAN DEFAULT false,
    nationally_televised BOOLEAN DEFAULT false,
    
    -- Metadata
    status VARCHAR,  -- 'scheduled', 'in_progress', 'final'
    source VARCHAR,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_games_date ON games(date);
CREATE INDEX IF NOT EXISTS idx_games_teams ON games(home_team, away_team);

-- ============================================================================
-- PROJECTIONS & ACCURACY TRACKING
-- ============================================================================

-- Historical projections (multiple sources)
CREATE TABLE IF NOT EXISTS projections (
    projection_id INTEGER PRIMARY KEY,
    date DATE NOT NULL,
    player_id VARCHAR NOT NULL,
    player_name VARCHAR NOT NULL,
    
    -- Platform
    platform VARCHAR,  -- 'DK', 'FD', etc.
    sport VARCHAR,
    salary INTEGER,
    position VARCHAR,
    
    -- Projection sources
    sabersim_proj FLOAT,
    fantasypros_proj FLOAT,
    rotogrinders_proj FLOAT,
    fanduel_proj FLOAT,
    draftkings_proj FLOAT,
    your_proj FLOAT,
    
    -- Actual result
    actual_points FLOAT,
    
    -- Ownership
    projected_ownership FLOAT,
    actual_ownership FLOAT,
    
    -- Error metrics (calculated)
    ss_error FLOAT,
    your_error FLOAT,
    ss_abs_error FLOAT,
    your_abs_error FLOAT,
    
    -- Metadata
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_proj_player_date ON projections(player_id, date);
CREATE INDEX IF NOT EXISTS idx_proj_date ON projections(date);

-- ============================================================================
-- INJURIES & NEWS
-- ============================================================================

-- Injury tracking
CREATE TABLE IF NOT EXISTS injuries (
    injury_id INTEGER PRIMARY KEY,
    player_id VARCHAR NOT NULL,
    player_name VARCHAR NOT NULL,
    date DATE NOT NULL,
    
    -- Injury details
    status VARCHAR,  -- 'OUT', 'DOUBTFUL', 'QUESTIONABLE', 'PROBABLE', 'GTD'
    injury_type VARCHAR,
    body_part VARCHAR,
    
    -- Timeline
    injury_date DATE,
    expected_return DATE,
    games_missed INTEGER,
    
    -- Source
    source VARCHAR,
    reported_by VARCHAR,
    
    -- Metadata
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_injuries_player ON injuries(player_id);
CREATE INDEX IF NOT EXISTS idx_injuries_date ON injuries(date);

-- News and updates
CREATE TABLE IF NOT EXISTS news (
    news_id INTEGER PRIMARY KEY,
    date TIMESTAMP NOT NULL,
    player_id VARCHAR,
    player_name VARCHAR,
    team VARCHAR,
    
    -- News content
    headline VARCHAR,
    content TEXT,
    impact VARCHAR,  -- 'HIGH', 'MEDIUM', 'LOW'
    
    -- Classification
    news_type VARCHAR,  -- 'INJURY', 'LINEUP', 'TRADE', 'SUSPENSION', etc.
    
    -- Source
    source VARCHAR,
    url VARCHAR,
    
    -- Metadata
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_news_player ON news(player_id);
CREATE INDEX IF NOT EXISTS idx_news_date ON news(date);

-- ============================================================================
-- SITUATIONAL PERFORMANCE
-- ============================================================================

-- Performance in specific situations
CREATE TABLE IF NOT EXISTS situational_stats (
    situation_id INTEGER PRIMARY KEY,
    player_id VARCHAR NOT NULL,
    player_name VARCHAR NOT NULL,
    season VARCHAR,
    
    -- Situation type
    situation_type VARCHAR NOT NULL,  -- 'back_to_back', 'home', 'vs_weak_defense', etc.
    situation_value VARCHAR,  -- Additional context
    
    -- Performance
    games_played INTEGER,
    avg_fantasy_points FLOAT,
    std_dev FLOAT,
    min_points FLOAT,
    max_points FLOAT,
    
    -- Comparison to baseline
    baseline_avg FLOAT,
    boost FLOAT,  -- difference from baseline
    
    -- Statistical significance
    t_statistic FLOAT,
    p_value FLOAT,
    
    -- Metadata
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_situation_player ON situational_stats(player_id);
CREATE INDEX IF NOT EXISTS idx_situation_type ON situational_stats(situation_type);

-- ============================================================================
-- DISCOVERED PATTERNS
-- ============================================================================

-- Auto-discovered patterns and edges
CREATE TABLE IF NOT EXISTS patterns (
    pattern_id INTEGER PRIMARY KEY,
    pattern_name VARCHAR NOT NULL,
    pattern_type VARCHAR,  -- 'player', 'team', 'position', 'situational'
    
    -- Pattern definition
    description TEXT,
    condition_sql TEXT,  -- SQL query that defines the pattern
    
    -- Performance
    sample_size INTEGER,
    avg_boost FLOAT,
    confidence_level VARCHAR,
    
    -- Statistical validation
    t_statistic FLOAT,
    p_value FLOAT,
    r_squared FLOAT,
    
    -- Actionability
    recommendation TEXT,
    active BOOLEAN DEFAULT true,
    
    -- Metadata
    discovered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_validated TIMESTAMP,
    sport VARCHAR
);

-- ============================================================================
-- VEGAS ODDS & PROPS
-- ============================================================================

-- Game odds (totals, spreads)
CREATE TABLE IF NOT EXISTS vegas_odds (
    odds_id INTEGER PRIMARY KEY,
    game_id VARCHAR NOT NULL,
    date DATE NOT NULL,
    
    -- Book
    bookmaker VARCHAR,
    
    -- Lines
    home_spread FLOAT,
    away_spread FLOAT,
    over_under FLOAT,
    home_ml INTEGER,
    away_ml INTEGER,
    
    -- Line movement
    opening_total FLOAT,
    current_total FLOAT,
    total_movement FLOAT,
    
    opening_spread FLOAT,
    current_spread FLOAT,
    spread_movement FLOAT,
    
    -- Timestamp
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_odds_game ON vegas_odds(game_id);
CREATE INDEX IF NOT EXISTS idx_odds_date ON vegas_odds(date);

-- Player props
CREATE TABLE IF NOT EXISTS player_props (
    prop_id INTEGER PRIMARY KEY,
    date DATE NOT NULL,
    player_id VARCHAR NOT NULL,
    player_name VARCHAR NOT NULL,
    
    -- Book
    bookmaker VARCHAR,
    
    -- Prop details
    prop_type VARCHAR,  -- 'points', 'rebounds', 'assists', etc.
    line FLOAT,
    over_odds INTEGER,
    under_odds INTEGER,
    
    -- Implied probability
    over_probability FLOAT,
    under_probability FLOAT,
    
    -- Metadata
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_props_player ON player_props(player_id);
CREATE INDEX IF NOT EXISTS idx_props_date ON player_props(date);

-- ============================================================================
-- CONTEST RESULTS (Your existing data)
-- ============================================================================

-- DFS contest results
CREATE TABLE IF NOT EXISTS contest_results (
    result_id INTEGER PRIMARY KEY,
    contest_date DATE NOT NULL,
    player_id VARCHAR,
    player_name VARCHAR NOT NULL,
    
    -- Contest info
    platform VARCHAR,
    sport VARCHAR,
    slate_type VARCHAR,
    
    -- Player info
    position VARCHAR,
    team VARCHAR,
    opponent VARCHAR,
    salary INTEGER,
    
    -- Performance
    actual_fpts FLOAT NOT NULL,
    
    -- Projections
    my_proj FLOAT,
    sabersim_proj FLOAT,
    platform_proj FLOAT,
    
    -- Ownership
    my_ownership FLOAT,
    actual_ownership FLOAT,
    
    -- Metadata
    source_file VARCHAR,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_contest_player ON contest_results(player_id);
CREATE INDEX IF NOT EXISTS idx_contest_date ON contest_results(contest_date);

-- ============================================================================
-- DAILY SLATE TRACKING
-- ============================================================================

-- Track daily slates
CREATE TABLE IF NOT EXISTS daily_slates (
    slate_id INTEGER PRIMARY KEY,
    date DATE NOT NULL,
    platform VARCHAR,
    sport VARCHAR,
    slate_type VARCHAR,
    
    -- Slate info
    num_games INTEGER,
    num_players INTEGER,
    
    -- Your performance
    lineups_entered INTEGER,
    total_entries FLOAT,
    total_winnings FLOAT,
    net_profit FLOAT,
    roi FLOAT,
    
    -- Accuracy
    avg_projection_error FLOAT,
    r_squared FLOAT,
    
    -- Notes
    notes TEXT,
    
    -- Metadata
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_slates_date ON daily_slates(date);

-- ============================================================================
-- VIEWS FOR COMMON QUERIES
-- ============================================================================

-- View: Recent performance by player
CREATE VIEW IF NOT EXISTS vw_player_recent_performance AS
SELECT 
    player_id,
    player_name,
    team,
    AVG(dk_points) as avg_dk_last10,
    AVG(fd_points) as avg_fd_last10,
    COUNT(*) as games
FROM player_game_logs
WHERE date >= CURRENT_DATE - INTERVAL '10 days'
GROUP BY player_id, player_name, team;

-- View: Defense rankings by position
CREATE VIEW IF NOT EXISTS vw_current_defense_rankings AS
WITH latest AS (
    SELECT MAX(date) as max_date FROM team_defense_by_position
)
SELECT 
    d.team,
    d.position,
    d.avg_fpts_allowed,
    d.rank
FROM team_defense_by_position d
JOIN latest l ON d.date = l.max_date
ORDER BY d.position, d.rank;

-- View: Projection accuracy summary
CREATE VIEW IF NOT EXISTS vw_projection_accuracy AS
SELECT 
    player_name,
    COUNT(*) as contests,
    AVG(actual_fpts) as avg_actual,
    AVG(my_proj) as avg_my_proj,
    AVG(sabersim_proj) as avg_ss_proj,
    AVG(ABS(actual_fpts - my_proj)) as my_mae,
    AVG(ABS(actual_fpts - sabersim_proj)) as ss_mae
FROM contest_results
WHERE my_proj IS NOT NULL AND sabersim_proj IS NOT NULL
GROUP BY player_name
HAVING contests >= 5;

-- ============================================================================
-- SUMMARY
-- ============================================================================

-- Table count
SELECT 
    'players' as table_name, COUNT(*) as row_count FROM players
UNION ALL
SELECT 'player_game_logs', COUNT(*) FROM player_game_logs
UNION ALL
SELECT 'team_defense_by_position', COUNT(*) FROM team_defense_by_position
UNION ALL
SELECT 'games', COUNT(*) FROM games
UNION ALL
SELECT 'projections', COUNT(*) FROM projections
UNION ALL
SELECT 'injuries', COUNT(*) FROM injuries
UNION ALL
SELECT 'news', COUNT(*) FROM news
UNION ALL
SELECT 'situational_stats', COUNT(*) FROM situational_stats
UNION ALL
SELECT 'patterns', COUNT(*) FROM patterns
UNION ALL
SELECT 'vegas_odds', COUNT(*) FROM vegas_odds
UNION ALL
SELECT 'player_props', COUNT(*) FROM player_props
UNION ALL
SELECT 'contest_results', COUNT(*) FROM contest_results
UNION ALL
SELECT 'daily_slates', COUNT(*) FROM daily_slates;
