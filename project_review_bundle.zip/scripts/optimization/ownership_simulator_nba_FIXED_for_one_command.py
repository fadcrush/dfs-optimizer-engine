
#!/usr/bin/env python
"""
ownership_simulator_nba.py  (FIXED + one-command compatible)

- FanDuel strict slots: PG,PG,SG,SG,SF,SF,PF,PF,C
- Simulates many valid lineups and produces simulated ownership.
- Optionally uses latest projections output from:
    outputs/projections_today*.csv
  If none is found, falls back to FanDuel FPPG.

This version fixes common "unterminated string literal" corruption issues by providing a clean,
self-contained implementation and adds CLI aliases so it works with wrappers:

Accepted args:
  positional: slate_csv
  --n / --num / --num-lineups : number of successful lineups to generate (default 10000)
  --max-attempts : maximum total attempts (default 50000)
  --projections : path to projections CSV (optional)
  --min-salary / --max-salary : salary bounds (FD cap 60000; min default 38500)
  --seed : RNG seed

Output:
  outputs/ownership_study_nba_YYYYMMDD_HHMMSS.csv
"""

from __future__ import annotations

import argparse
import os
import random
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd


FD_SALARY_CAP = 60000
FD_SLOTS = ["PG", "PG", "SG", "SG", "SF", "SF", "PF", "PF", "C"]


def norm_name(s: str) -> str:
    s = (s or "").strip().lower()
    s = re.sub(r"[^a-z\s\-\.']", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def latest_file(pattern: str) -> Optional[str]:
    files = sorted(Path(".").glob(pattern), key=lambda p: p.stat().st_mtime, reverse=True)
    return str(files[0]) if files else None


def load_slate(fd_csv: str) -> pd.DataFrame:
    df = pd.read_csv(fd_csv)

    # Standardize key columns
    if "Id" in df.columns:
        df["ID"] = df["Id"].astype(str)
    elif "ID" in df.columns:
        df["ID"] = df["ID"].astype(str)
    else:
        raise ValueError("Slate CSV must contain Id or ID column")

    # Name: prefer Nickname (full name)
    if "Nickname" in df.columns:
        df["Name"] = df["Nickname"].astype(str)
    elif "Name" in df.columns:
        df["Name"] = df["Name"].astype(str)
    else:
        df["Name"] = (df.get("First Name", "").astype(str) + " " + df.get("Last Name", "").astype(str)).str.strip()

    df["Name_norm"] = df["Name"].map(norm_name)

    if "Position" not in df.columns:
        raise ValueError("Slate CSV must contain Position column")
    df["Position"] = df["Position"].astype(str)

    df["Salary"] = pd.to_numeric(df.get("Salary", np.nan), errors="coerce").fillna(0).astype(int)
    df["FPPG"] = pd.to_numeric(df.get("FPPG", np.nan), errors="coerce")

    # Primary pos bucket for slot assignment
    def primary_bucket(pos: str) -> str:
        pos = (pos or "").upper()
        for b in ["PG", "SG", "SF", "PF", "C"]:
            if b in pos:
                return b
        return ""

    df["PosBucket"] = df["Position"].map(primary_bucket)

    # Keep only players with a usable bucket and salary
    df = df[(df["PosBucket"].isin(["PG", "SG", "SF", "PF", "C"])) & (df["Salary"] > 0)].copy()
    return df


def load_projections(proj_path: Optional[str]) -> Optional[pd.DataFrame]:
    if not proj_path:
        proj_path = latest_file("outputs/projections_today*.csv")
    if not proj_path:
        return None
    p = Path(proj_path)
    if not p.exists():
        return None

    proj = pd.read_csv(p)
    # Expect columns like: ID, Name, Projection, StdDev, FieldProjection
    if "Name" in proj.columns:
        proj["Name_norm"] = proj["Name"].astype(str).map(norm_name)
    elif "Nickname" in proj.columns:
        proj["Name_norm"] = proj["Nickname"].astype(str).map(norm_name)
    else:
        # fallback
        proj["Name_norm"] = proj.get("player_name", "").astype(str).map(norm_name)

    # Ensure Projection exists
    if "Projection" not in proj.columns:
        # Try common alt
        for c in ["Proj", "proj", "projection", "ProjPts"]:
            if c in proj.columns:
                proj["Projection"] = pd.to_numeric(proj[c], errors="coerce")
                break
    if "Projection" not in proj.columns:
        return None

    proj["Projection"] = pd.to_numeric(proj["Projection"], errors="coerce")
    if "StdDev" in proj.columns:
        proj["StdDev"] = pd.to_numeric(proj["StdDev"], errors="coerce")
    else:
        proj["StdDev"] = np.nan

    return proj


@dataclass
class SimConfig:
    n_lineups: int = 10000
    max_attempts: int = 50000
    min_salary: int = 38500
    max_salary: int = FD_SALARY_CAP
    seed: int = 7
    rand_proj: bool = True


def build_player_pool(slate: pd.DataFrame, proj: Optional[pd.DataFrame]) -> pd.DataFrame:
    df = slate.copy()
    if proj is not None:
        # Prefer ID join if proj has ID
        if "ID" in proj.columns:
            proj_id = proj[["ID", "Projection", "StdDev"]].copy()
            proj_id["ID"] = proj_id["ID"].astype(str)
            df = df.merge(proj_id, on="ID", how="left")
        else:
            proj_small = proj[["Name_norm", "Projection", "StdDev"]].copy()
            df = df.merge(proj_small, on="Name_norm", how="left")
    # Fill missing Projection with FPPG
    if "Projection" not in df.columns:
        df["Projection"] = df["FPPG"]
    df["Projection"] = pd.to_numeric(df["Projection"], errors="coerce")
    df.loc[df["Projection"].isna(), "Projection"] = df.loc[df["Projection"].isna(), "FPPG"]
    df["Projection"] = df["Projection"].fillna(0.0)

    # StdDev fallback
    df["StdDev"] = pd.to_numeric(df.get("StdDev", np.nan), errors="coerce")
    df.loc[df["StdDev"].isna(), "StdDev"] = (0.20 * df["Projection"]).clip(lower=3.0)

    return df


def choose_player(candidates: pd.DataFrame, rng: np.random.Generator, cfg: SimConfig) -> Optional[pd.Series]:
    if candidates.empty:
        return None
    proj = candidates["Projection"].to_numpy(float)
    if cfg.rand_proj:
        sd = candidates["StdDev"].to_numpy(float)
        # sample a "field-like" noisy projection
        sampled = rng.normal(loc=proj, scale=sd)
        sampled = np.maximum(sampled, 0.01)
        weights = sampled
    else:
        weights = np.maximum(proj, 0.01)
    weights = weights / weights.sum()
    idx = rng.choice(len(candidates), p=weights)
    return candidates.iloc[int(idx)]


def generate_lineup(pool: pd.DataFrame, rng: np.random.Generator, cfg: SimConfig) -> Optional[pd.DataFrame]:
    used_ids = set()
    lineup_rows = []

    # Pre-split by bucket (FD roster slots are fixed)
    by_bucket = {b: pool[pool["PosBucket"] == b].copy() for b in ["PG", "SG", "SF", "PF", "C"]}

    salary = 0
    for slot in FD_SLOTS:
        cand = by_bucket[slot]
        cand = cand[~cand["ID"].isin(used_ids)]
        pick = choose_player(cand, rng, cfg)
        if pick is None:
            return None
        used_ids.add(pick["ID"])
        lineup_rows.append({**pick.to_dict(), "RosterSlot": slot})
        salary += int(pick["Salary"])

    if salary < cfg.min_salary or salary > cfg.max_salary:
        return None

    return pd.DataFrame(lineup_rows)


def run_simulation(pool: pd.DataFrame, cfg: SimConfig) -> Tuple[pd.DataFrame, List[pd.DataFrame]]:
    rng = np.random.default_rng(cfg.seed)
    counts: Dict[str, int] = {}
    lineups: List[pd.DataFrame] = []

    successes = 0
    attempts = 0
    while successes < cfg.n_lineups and attempts < cfg.max_attempts:
        attempts += 1
        lu = generate_lineup(pool, rng, cfg)
        if lu is None:
            continue
        successes += 1
        lineups.append(lu)
        for name in lu["Name"].astype(str).tolist():
            counts[name] = counts.get(name, 0) + 1

        if successes % 1000 == 0:
            print(f"  Progress: {successes:,} / {cfg.n_lineups:,}")

    if successes == 0:
        own = pd.DataFrame(columns=["Name", "SimOwnership", "Lineups"])
    else:
        own = pd.DataFrame({"Name": list(counts.keys()), "Lineups": list(counts.values())})
        own["SimOwnership"] = own["Lineups"] / float(successes)
        own = own.sort_values("SimOwnership", ascending=False).reset_index(drop=True)

    print(f"\n[OK] Generated {successes:,} lineups in {attempts:,} attempts")
    return own, lineups


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("slate_csv", help="FanDuel NBA players-list CSV")
    ap.add_argument("--projections", default=None, help="Optional projections csv (else latest outputs/projections_today*.csv)")
    ap.add_argument("--n", type=int, default=None, help="Alias for --num (number of simulated lineups)")
    ap.add_argument("--num", type=int, default=10000, help="Number of simulated lineups")
    ap.add_argument("--num-lineups", type=int, default=None, help="Alias for --num")
    ap.add_argument("--max-attempts", type=int, default=50000, help="Maximum attempts to generate lineups")
    ap.add_argument("--min-salary", type=int, default=38500, help="Minimum salary spend")
    ap.add_argument("--max-salary", type=int, default=60000, help="Maximum salary spend")
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--no-rand-proj", action="store_true", help="Disable projection randomness")
    args = ap.parse_args()

    n_lineups = args.num
    if args.n is not None:
        n_lineups = args.n
    if args.num_lineups is not None:
        n_lineups = args.num_lineups

    cfg = SimConfig(
        n_lineups=int(n_lineups),
        max_attempts=int(args.max_attempts),
        min_salary=int(args.min_salary),
        max_salary=int(args.max_salary),
        seed=int(args.seed),
        rand_proj=not args.no_rand_proj,
    )

    print("=" * 80)
    print("DFS OWNERSHIP SIMULATOR - NBA (FanDuel)")
    print("=" * 80)
    print(f" Loading NBA slate: {Path(args.slate_csv).name}")

    slate = load_slate(args.slate_csv)
    print(f"[OK] Loaded {len(slate)} NBA players")

    proj = load_projections(args.projections)
    if proj is not None:
        print(f"[OK] Using projections: {args.projections or 'latest outputs/projections_today*.csv'}")
    else:
        print("[WARNING]  No projections found; using FanDuel FPPG as fallback")

    pool = build_player_pool(slate, proj)

    print(f"\n Running {cfg.n_lineups:,} lineup simulation...")
    own, _ = run_simulation(pool, cfg)

    outdir = Path("outputs")
    outdir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_path = outdir / f"ownership_study_nba_{ts}.csv"
    own.to_csv(out_path, index=False)
    print(f"\n[OK] Saved to: {out_path}")
    print("=" * 80)
    print("[OK] NBA OWNERSHIP SIMULATION COMPLETE!")
    print("=" * 80)


if __name__ == "__main__":
    main()
