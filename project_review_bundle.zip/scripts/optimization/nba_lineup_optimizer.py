#!/usr/bin/env python
"""
nba_lineup_optimizer.py

Builds NBA lineups using:
1. Latest projections (from nba_today_projections_v3_dvp_posmap.py)
2. Latest ownership (from ownership_simulator_nba_FIXED.py)
3. Leverage optimization (High Projection / Low Ownership)

Usage:
    python nba_lineup_optimizer.py "slate.csv" --num-lineups 50
"""

import argparse
import re
from pathlib import Path
from datetime import datetime
from collections import defaultdict
import pandas as pd
import numpy as np

print("="*80)
print("NBA LINEUP OPTIMIZER - LEVERAGE-BASED")
print("="*80)

def norm_name(s: str) -> str:
    """Normalize name for matching"""
    s = (s or "").strip().lower()
    s = re.sub(r"[^a-z\s\-\.']", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s

def latest_file(pattern: str) -> Path:
    """Get most recent file matching pattern"""
    files = sorted(Path("outputs").glob(pattern), key=lambda p: p.stat().st_mtime, reverse=True)
    if not files:
        return None
    return files[0]

def load_slate(csv_path: str) -> pd.DataFrame:
    """Load FanDuel slate CSV"""
    df = pd.read_csv(csv_path)
    
    # Standardize columns
    if "Id" in df.columns:
        df["ID"] = df["Id"].astype(str)
    elif "ID" not in df.columns:
        raise ValueError("Need Id or ID column")
    
    if "Nickname" in df.columns:
        df["Name"] = df["Nickname"].astype(str)
    elif "Name" not in df.columns:
        df["Name"] = (df.get("First Name", "").astype(str) + " " + df.get("Last Name", "").astype(str)).str.strip()
    
    df["Name_norm"] = df["Name"].map(norm_name)
    df["Position"] = df["Position"].astype(str)
    df["Salary"] = pd.to_numeric(df["Salary"], errors="coerce").fillna(0).astype(int)
    
    # Primary position bucket
    def primary_pos(pos: str) -> str:
        pos = (pos or "").upper()
        for bucket in ["PG", "SG", "SF", "PF", "C"]:
            if bucket in pos:
                return bucket
        return ""
    
    df["PosBucket"] = df["Position"].map(primary_pos)
    
    return df

def load_projections() -> pd.DataFrame:
    """Load latest projections"""
    proj_file = latest_file("projections_today*.csv")
    if not proj_file:
        print("\n[ERROR] No projections found!")
        print("   Run: python nba_today_projections_v3_dvp_posmap.py \"slate.csv\" --season 2024-25")
        return None
    
    print(f"\n[OK] Loading projections: {proj_file.name}")
    proj = pd.read_csv(proj_file)
    
    if "Name" in proj.columns:
        proj["Name_norm"] = proj["Name"].astype(str).map(norm_name)
    
    # Ensure Projection column exists
    if "Projection" not in proj.columns:
        print("[ERROR] Projections file missing 'Projection' column!")
        return None
    
    proj["Projection"] = pd.to_numeric(proj["Projection"], errors="coerce")
    
    return proj

def load_ownership() -> pd.DataFrame:
    """Load latest ownership simulation"""
    own_file = latest_file("ownership_study_nba*.csv")
    if not own_file:
        print("\n[WARNING]  No ownership data found")
        print("   Run: python ownership_simulator_nba_FIXED.py \"slate.csv\" --num 10000")
        return None
    
    print(f"[OK] Loading ownership: {own_file.name}")
    own = pd.read_csv(own_file)
    
    if "Name" in own.columns:
        own["Name_norm"] = own["Name"].astype(str).map(norm_name)
    
    if "SimOwnership" in own.columns:
        own["Ownership"] = pd.to_numeric(own["SimOwnership"], errors="coerce")
    elif "Ownership" in own.columns:
        own["Ownership"] = pd.to_numeric(own["Ownership"], errors="coerce")
    else:
        print("[ERROR] Ownership file missing ownership column!")
        return None
    
    return own[["Name_norm", "Ownership"]]

def build_player_pool(slate: pd.DataFrame, projections: pd.DataFrame, ownership: pd.DataFrame) -> pd.DataFrame:
    """Merge slate + projections + ownership"""
    
    # Merge projections
    pool = slate.merge(
        projections[["Name_norm", "Projection"]],
        on="Name_norm",
        how="left"
    )
    
    # Fill missing projections with 0
    pool["Projection"] = pool["Projection"].fillna(0.0)
    
    # Merge ownership
    if ownership is not None:
        pool = pool.merge(ownership, on="Name_norm", how="left")
        pool["Ownership"] = pool["Ownership"].fillna(0.50)  # Default 50% if missing
    else:
        pool["Ownership"] = 0.50
    
    # Calculate leverage (High Proj / Low Own = High Leverage)
    pool["Leverage"] = pool["Projection"] / (pool["Ownership"] + 0.01)
    
    # Calculate value
    pool["Value"] = pool["Projection"] / (pool["Salary"] / 1000)
    
    # Clean up any NaN or inf values
    pool["Leverage"] = pool["Leverage"].replace([np.inf, -np.inf], 0.0).fillna(0.0)
    pool["Value"] = pool["Value"].replace([np.inf, -np.inf], 0.0).fillna(0.0)
    pool["Projection"] = pool["Projection"].fillna(0.0)
    pool["Ownership"] = pool["Ownership"].fillna(0.5)
    
    return pool

def can_fill_slot(position: str, slot: str) -> bool:
    """Check if position can fill FanDuel slot"""
    positions = [p.strip() for p in str(position).split('/')]
    
    if slot == 'PG': return 'PG' in positions
    elif slot == 'SG': return 'SG' in positions
    elif slot == 'SF': return 'SF' in positions
    elif slot == 'PF': return 'PF' in positions
    elif slot == 'C': return 'C' in positions
    return False

def build_lineup(pool: pd.DataFrame, used_count: dict, config: dict, strategy: str = 'balanced') -> list:
    """
    Build single lineup
    
    Strategies:
    - 'balanced': Mix leverage + value
    - 'gpp': High leverage (contrarian)
    - 'cash': High floor (safe)
    """
    
    available = pool.copy()
    
    # Filter over-exposed
    max_uses = int(config['num_lineups'] * config['max_exposure'])
    available = available[available['Name'].map(lambda x: used_count.get(x, 0) < max_uses)]
    
    if len(available) < 9:
        return None
    
    lineup = []
    salary_used = 0
    
    # FanDuel slots: PG, PG, SG, SG, SF, SF, PF, PF, C
    needed = {'PG': 2, 'SG': 2, 'SF': 2, 'PF': 2, 'C': 1}
    
    # Sort by strategy
    if strategy == 'gpp':
        # GPP: High leverage (contrarian plays)
        available = available.sort_values('Leverage', ascending=False)
    elif strategy == 'cash':
        # Cash: High projection (safe)
        available = available.sort_values('Projection', ascending=False)
    else:
        # Balanced: Mix of leverage and value
        available['Score'] = available['Leverage'] * 0.6 + available['Value'] * 0.4
        available = available.sort_values('Score', ascending=False)
    
    # Build lineup
    for slot in ['PG', 'SG', 'SF', 'PF', 'C']:
        while needed[slot] > 0:
            # Get eligible players
            eligible = available[
                available['Name'].map(lambda n: n not in [p['Name'] for p in lineup])
            ]
            eligible = eligible[eligible['PosBucket'] == slot]
            
            if eligible.empty:
                return None
            
            # Try players in order
            for _, player in eligible.iterrows():
                if salary_used + player['Salary'] <= config['max_salary']:
                    lineup.append(player.to_dict())
                    salary_used += player['Salary']
                    needed[slot] -= 1
                    break
            else:
                # No valid player found
                return None
    
    # Validate
    if len(lineup) == 9 and config['min_salary'] <= salary_used <= config['max_salary']:
        return lineup
    return None

def generate_lineups(pool: pd.DataFrame, config: dict, strategy: str = 'balanced'):
    """Generate multiple lineups"""
    
    print(f"\n Generating {config['num_lineups']} lineups ({strategy} strategy)...")
    
    lineups = []
    used_count = defaultdict(int)
    
    attempts = 0
    max_attempts = config['num_lineups'] * 20
    
    while len(lineups) < config['num_lineups'] and attempts < max_attempts:
        attempts += 1
        
        lineup = build_lineup(pool, used_count, config, strategy)
        
        if lineup:
            lineups.append(lineup)
            for p in lineup:
                used_count[p['Name']] += 1
            
            if len(lineups) % 10 == 0:
                print(f"  Progress: {len(lineups)}/{config['num_lineups']}")
    
    print(f"[OK] Generated {len(lineups)} lineups in {attempts} attempts")
    
    return lineups, used_count

def export_lineups(lineups: list, output_file: Path):
    """Export to FanDuel CSV format"""
    
    print(f"\n Exporting to FanDuel format...")
    
    with open(output_file, 'w') as f:
        f.write("Lineup,PG,PG,SG,SG,SF,SF,PF,PF,C,Salary,Projection\n")
        
        for i, lineup in enumerate(lineups):
            row = [f'Lineup_{i+1}']
            
            # Sort by slots
            sorted_lu = []
            used = set()
            
            for slot in ['PG', 'PG', 'SG', 'SG', 'SF', 'SF', 'PF', 'PF', 'C']:
                for p in lineup:
                    if p['Name'] not in used and can_fill_slot(p['PosBucket'], slot):
                        sorted_lu.append(p)
                        used.add(p['Name'])
                        break
            
            # Add player IDs
            for p in sorted_lu:
                row.append(f"{p['ID']}:{p['Name']}")
            
            row.append(str(sum(p['Salary'] for p in lineup)))
            row.append(f"{sum(p['Projection'] for p in lineup):.1f}")
            
            f.write(','.join(row) + '\n')
    
    print(f"[OK] Saved to: {output_file}")

def show_analytics(lineups: list, pool: pd.DataFrame):
    """Show lineup analytics"""
    
    print(f"\n LINEUP ANALYTICS")
    print("="*80)
    
    all_proj = [sum(p['Projection'] for p in lu) for lu in lineups]
    all_sal = [sum(p['Salary'] for p in lu) for lu in lineups]
    all_own = [np.mean([p['Ownership'] for p in lu]) for lu in lineups]
    
    print(f"Avg Projection: {np.mean(all_proj):.1f} pts")
    print(f"Projection Range: {np.min(all_proj):.1f} - {np.max(all_proj):.1f}")
    print(f"Avg Ownership: {np.mean(all_own)*100:.1f}%")
    print(f"Ownership Range: {np.min(all_own)*100:.1f}% - {np.max(all_own)*100:.1f}%")
    print(f"Avg Salary: ${np.mean(all_sal):,.0f}")
    print(f"Salary Range: ${np.min(all_sal):,} - ${np.max(all_sal):,}")
    
    # Player exposures
    exposure = defaultdict(int)
    for lu in lineups:
        for p in lu:
            exposure[p['Name']] += 1
    
    print(f"\n TOP 10 EXPOSURES:")
    top_exp = sorted(exposure.items(), key=lambda x: x[1], reverse=True)[:10]
    
    for name, count in top_exp:
        pct = (count / len(lineups)) * 100
        player = pool[pool['Name'] == name].iloc[0]
        own_pct = player['Ownership'] * 100
        proj = player['Projection']
        
        print(f"  {name:<30} {count:>3} ({pct:>4.1f}%) | Proj:{proj:>5.1f} Own:{own_pct:>4.1f}%")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("slate_csv", help="FanDuel NBA slate CSV")
    ap.add_argument("--num-lineups", type=int, default=50)
    ap.add_argument("--max-exposure", type=float, default=0.35)
    ap.add_argument("--min-salary", type=int, default=44000)
    ap.add_argument("--max-salary", type=int, default=60000)
    ap.add_argument("--strategy", choices=['balanced', 'gpp', 'cash'], default='balanced')
    args = ap.parse_args()
    
    # Load data
    print(f"\n Loading slate: {Path(args.slate_csv).name}")
    slate = load_slate(args.slate_csv)
    print(f"[OK] Loaded {len(slate)} players")
    
    projections = load_projections()
    if projections is None:
        return
    
    ownership = load_ownership()
    
    # Build player pool
    print(f"\n Building player pool...")
    pool = build_player_pool(slate, projections, ownership)
    print(f"[OK] Pool ready: {len(pool)} players")
    
    if ownership is not None:
        print(f"   Avg Ownership: {pool['Ownership'].mean()*100:.1f}%")
    print(f"   Avg Projection: {pool['Projection'].mean():.1f} pts")
    print(f"   Avg Leverage: {pool['Leverage'].mean():.2f}")
    
    # Generate lineups
    config = {
        'num_lineups': args.num_lineups,
        'max_exposure': args.max_exposure,
        'min_salary': args.min_salary,
        'max_salary': args.max_salary
    }
    
    lineups, used_count = generate_lineups(pool, config, args.strategy)
    
    if not lineups:
        print("\n[ERROR] Failed to generate lineups")
        return
    
    # Analytics
    show_analytics(lineups, pool)
    
    # Export
    outdir = Path("outputs")
    outdir.mkdir(exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = outdir / f"nba_lineups_{args.strategy}_{ts}.csv"
    
    export_lineups(lineups, output_file)
    
    print(f"\n{'='*80}")
    print("[OK] LINEUP GENERATION COMPLETE!")
    print(f"{'='*80}")
    print(f"\n Upload to FanDuel: {output_file}")

if __name__ == "__main__":
    main()
