"""
scripts/check_indexes.py — Verify required DB indexes exist.

Checks that performance-critical indexes are present:
  - projections(slate_id)
  - ownership_data(slate_id)
  - lineup_entries(run_id)
  - lineup_entries(player_id)
  - runs(status)
  - runs(slate_id)

Usage:
    python scripts/check_indexes.py [--database-url postgresql://...]
"""
from __future__ import annotations

import argparse
import os
import sys
import textwrap
from typing import Dict, List, Set


REQUIRED_INDEXES: List[Dict] = [
    {"table": "projections",    "column": "slate_id",  "name": "ix_projections_slate_id"},
    {"table": "ownership_data", "column": "slate_id",  "name": "ix_ownership_data_slate_id"},
    {"table": "lineup_entries", "column": "run_id",    "name": "ix_lineup_entries_run_id"},
    {"table": "lineup_entries", "column": "player_id", "name": "ix_lineup_entries_player_id"},
    {"table": "runs",           "column": "status",    "name": "ix_runs_status"},
    {"table": "runs",           "column": "slate_id",  "name": "ix_runs_slate_id"},
]


def _get_pg_indexes(conn) -> Set[str]:
    """Return a set of index names from PostgreSQL information_schema."""
    rows = conn.execute(
        "SELECT index_name FROM information_schema.statistics"
    ).fetchall()
    return {r[0] for r in rows}


def _get_all_indexes_pg(conn) -> Set[str]:
    from sqlalchemy import text
    rows = conn.execute(
        text(
            "SELECT indexname FROM pg_indexes WHERE schemaname = 'public'"
        )
    ).fetchall()
    return {r[0] for r in rows}


def _get_all_indexes_sqlite(conn) -> Set[str]:
    from sqlalchemy import text
    rows = conn.execute(text("SELECT name FROM sqlite_master WHERE type='index'")).fetchall()
    return {r[0] for r in rows}


def _get_duckdb_indexes(conn) -> Set[str]:
    # DuckDB doesn't have traditional B-tree indexes in the same way;
    # return empty set — user must verify manually.
    return set()


def main() -> int:
    parser = argparse.ArgumentParser(description="Verify required DB indexes")
    parser.add_argument(
        "--database-url",
        default=os.getenv("DATABASE_URL", ""),
        help="Database URL (defaults to DATABASE_URL env var)",
    )
    args = parser.parse_args()

    db_url = args.database_url
    if not db_url:
        print("ERROR: DATABASE_URL not set. Pass --database-url or set the env var.")
        return 1

    print(f"\n{'='*60}")
    print("  DFS EDGE PRO — INDEX VERIFICATION")
    print(f"  Database: {db_url[:40]}...")
    print(f"{'='*60}\n")

    try:
        from sqlalchemy import create_engine, inspect, text
    except ImportError:
        print("ERROR: sqlalchemy not installed.")
        return 1

    try:
        engine = create_engine(db_url, connect_args={"connect_timeout": 10} if "postgresql" in db_url else {})
        with engine.connect() as conn:
            # Detect dialect and get existing indexes
            dialect = engine.dialect.name
            if "postgresql" in dialect:
                existing = _get_all_indexes_pg(conn)
            elif "sqlite" in dialect:
                existing = _get_all_indexes_sqlite(conn)
            elif "duckdb" in dialect:
                existing = _get_duckdb_indexes(conn)
                print("  NOTE: DuckDB has limited index introspection. "
                      "Verify indexes via PRAGMA or DuckDB system tables.")
            else:
                # Generic fallback via SQLAlchemy inspector
                insp = inspect(engine)
                existing = set()
                for tbl in ["projections", "ownership_data", "lineup_entries", "runs"]:
                    try:
                        for idx in insp.get_indexes(tbl):
                            existing.add(idx["name"])
                    except Exception:
                        pass

    except Exception as e:
        print(f"  ERROR connecting to database: {e}")
        return 1

    missing = []
    found = []

    for req in REQUIRED_INDEXES:
        name = req["name"]
        if name in existing:
            found.append(req)
            print(f"  ✓  {name:<45} (table={req['table']})")
        else:
            # Try partial match — index may be named differently
            partial = [n for n in existing if req["column"] in n and req["table"] in n]
            if partial:
                found.append(req)
                print(f"  ~  {name:<45} → found as: {partial[0]}")
            else:
                missing.append(req)
                print(f"  ✗  {name:<45} MISSING")

    print(f"\n  Summary: {len(found)}/{len(REQUIRED_INDEXES)} required indexes present")

    if missing:
        print("\n  To create missing indexes, run Alembic migration or:")
        for m in missing:
            idx_sql = (
                f"  CREATE INDEX IF NOT EXISTS {m['name']} "
                f"ON {m['table']}({m['column']});"
            )
            print(f"    {idx_sql}")
        print()
        return 1

    print("\n  ✓  All required indexes present\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
