#!/usr/bin/env python
"""
FIX_DASHBOARD_PATHS.py

Updates the dashboard to use correct script paths after reorganization.
"""

from pathlib import Path

print("="*80)
print("FIXING DASHBOARD SCRIPT PATHS")
print("="*80)

dashboard_path = Path('dashboard/dfs_injury_dashboard.py')

if not dashboard_path.exists():
    print(f"\n[ERROR] Dashboard not found: {dashboard_path}")
    print("Make sure you're in the project root directory")
    exit(1)

print(f"\nUpdating: {dashboard_path}")

# Read current content
with open(dashboard_path, 'r', encoding='utf-8') as f:
    content = f.read()

# Define replacements - old paths to new paths
replacements = {
    # Injury scanner
    'subprocess.run([sys.executable, "auto_injury_scanner.py"':
        'subprocess.run([sys.executable, str(Path(__file__).parent.parent / "scripts" / "detection" / "auto_injury_scanner.py")',
    
    # Injury beneficiary analyzer
    'subprocess.run([sys.executable, "injury_beneficiary_analyzer.py"':
        'subprocess.run([sys.executable, str(Path(__file__).parent.parent / "scripts" / "detection" / "injury_beneficiary_analyzer.py")',
    
    # Injury value detector
    'subprocess.run([sys.executable, "injury_value_detector.py"':
        'subprocess.run([sys.executable, str(Path(__file__).parent.parent / "scripts" / "detection" / "injury_value_detector.py")',
    
    # Lineup optimizer
    'subprocess.run([sys.executable, "nba_lineup_optimizer.py"':
        'subprocess.run([sys.executable, str(Path(__file__).parent.parent / "scripts" / "optimization" / "nba_lineup_optimizer.py")',
    
    # Any remaining references to root-level scripts
    '"auto_injury_scanner.py"': 
        'str(Path(__file__).parent.parent / "scripts" / "detection" / "auto_injury_scanner.py")',
    
    '"injury_beneficiary_analyzer.py"':
        'str(Path(__file__).parent.parent / "scripts" / "detection" / "injury_beneficiary_analyzer.py")',
    
    '"injury_value_detector.py"':
        'str(Path(__file__).parent.parent / "scripts" / "detection" / "injury_value_detector.py")',
    
    '"nba_lineup_optimizer.py"':
        'str(Path(__file__).parent.parent / "scripts" / "optimization" / "nba_lineup_optimizer.py")',
}

# Apply replacements
original_content = content
for old_path, new_path in replacements.items():
    content = content.replace(old_path, new_path)

# Make sure Path is imported
if 'from pathlib import Path' not in content:
    # Add after streamlit import
    import_section = content.find('import streamlit as st')
    if import_section != -1:
        # Find end of line
        end_of_line = content.find('\n', import_section)
        content = content[:end_of_line+1] + 'from pathlib import Path\n' + content[end_of_line+1:]

# Write back
if content != original_content:
    with open(dashboard_path, 'w', encoding='utf-8') as f:
        f.write(content)
    print("  [OK] Updated script paths!")
else:
    print("  [INFO] No changes needed (already updated)")

print(f"\n{'='*80}")
print("COMPLETE!")
print(f"{'='*80}")

print("\nDashboard now uses correct script paths:")
print("  - scripts/detection/auto_injury_scanner.py")
print("  - scripts/detection/injury_beneficiary_analyzer.py")
print("  - scripts/detection/injury_value_detector.py")
print("  - scripts/optimization/nba_lineup_optimizer.py")

print("\nRefresh the dashboard in your browser (F5) to see changes!")

print(f"\n{'='*80}")