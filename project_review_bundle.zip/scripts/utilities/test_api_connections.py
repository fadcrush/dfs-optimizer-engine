"""
Test API Connections
Verifies all external API integrations are working correctly.
"""

import os
import sys
from pathlib import Path
import requests
from dotenv import load_dotenv

# Add project root to path
PROJECT_ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(PROJECT_ROOT))
sys.path.insert(0, str(PROJECT_ROOT / "backend"))

# Load environment
load_dotenv(PROJECT_ROOT / ".env")


def test_odds_api():
    """Test The Odds API connection"""
    api_key = os.getenv('THE_ODDS_API_KEY', '')

    if not api_key:
        return False, "API key not configured", None

    try:
        url = 'https://api.the-odds-api.com/v4/sports/basketball_nba/odds/'
        params = {
            'apiKey': api_key,
            'regions': 'us',
            'markets': 'totals',
            'oddsFormat': 'american'
        }

        response = requests.get(url, params=params, timeout=10)

        if response.status_code == 200:
            games = response.json()
            return True, "Connected", f"{len(games)} NBA games found"
        elif response.status_code == 401:
            return False, "Invalid API key", None
        elif response.status_code == 429:
            return False, "Rate limit exceeded", None
        else:
            return False, f"HTTP {response.status_code}", None

    except requests.exceptions.Timeout:
        return False, "Connection timeout", None
    except Exception as e:
        return False, str(e), None


def test_sportsdata_api():
    """Test SportsData.io API connection"""
    api_key = os.getenv('SPORTSDATA_API_KEY', '')

    if not api_key:
        return False, "API key not configured", None

    try:
        # Test with Teams endpoint (more reliable than Injuries)
        url = f'https://api.sportsdata.io/v3/nba/scores/json/Teams?key={api_key}'

        response = requests.get(url, timeout=10)

        if response.status_code == 200:
            teams = response.json()
            return True, "Connected", f"{len(teams)} NBA teams found"
        elif response.status_code == 401:
            return False, "Invalid API key", None
        elif response.status_code == 403:
            return False, "Subscription required", None
        else:
            return False, f"HTTP {response.status_code}", None

    except requests.exceptions.Timeout:
        return False, "Connection timeout", None
    except Exception as e:
        return False, str(e), None


def test_nba_stats_api():
    """Test NBA Stats API (no key required)"""
    try:
        # Simple endpoint that doesn't require authentication
        url = 'https://stats.nba.com/stats/leaguegamefinder'
        params = {
            'LeagueID': '00',
            'Season': '2024-25',
            'SeasonType': 'Regular Season'
        }
        headers = {
            'User-Agent': 'Mozilla/5.0',
            'Referer': 'https://www.nba.com/'
        }

        response = requests.get(url, params=params, headers=headers, timeout=15)

        if response.status_code == 200:
            return True, "Connected (no key required)", None
        else:
            return False, f"HTTP {response.status_code}", None

    except requests.exceptions.Timeout:
        return False, "Connection timeout (common - still works)", None
    except Exception as e:
        return False, str(e), None


def test_openweather_api():
    """Test OpenWeather API connection"""
    api_key = os.getenv('OPENWEATHER_API_KEY', '')

    if not api_key:
        return None, "Not configured (optional)", None

    try:
        # Test with a simple weather query
        url = 'https://api.openweathermap.org/data/2.5/weather'
        params = {
            'q': 'New York,US',
            'appid': api_key
        }

        response = requests.get(url, params=params, timeout=10)

        if response.status_code == 200:
            return True, "Connected", None
        elif response.status_code == 401:
            return False, "Invalid API key", None
        else:
            return False, f"HTTP {response.status_code}", None

    except Exception as e:
        return False, str(e), None


def main():
    """Run all API tests"""
    print("\n" + "=" * 60)
    print("DFS EDGE PRO - API CONNECTION TESTS")
    print("=" * 60)

    tests = [
        ("The Odds API (Vegas Lines)", test_odds_api, True),
        ("SportsData.io (Player Data)", test_sportsdata_api, True),
        ("NBA Stats API", test_nba_stats_api, False),
        ("OpenWeather API (NFL Weather)", test_openweather_api, False),
    ]

    results = []

    for name, test_func, required in tests:
        print(f"\n[Testing] {name}...")

        success, status, details = test_func()

        if success is True:
            status_icon = "OK"
            print(f"  Status: {status_icon} - {status}")
            if details:
                print(f"  Details: {details}")
        elif success is False:
            status_icon = "FAIL" if required else "WARN"
            print(f"  Status: {status_icon} - {status}")
        else:
            status_icon = "SKIP"
            print(f"  Status: {status_icon} - {status}")

        results.append((name, success, required))

    # Summary
    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)

    all_required_ok = True
    for name, success, required in results:
        if required and success is not True:
            all_required_ok = False
            print(f"  MISSING: {name}")

    if all_required_ok:
        print("\n  All required APIs are connected!")
        print("  You're ready to generate projections.")
    else:
        print("\n  Some required APIs are not configured.")
        print("  Check your .env file and API subscriptions.")

    print("\n" + "=" * 60)

    return 0 if all_required_ok else 1


if __name__ == "__main__":
    sys.exit(main())
