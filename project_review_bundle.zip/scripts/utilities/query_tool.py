"""Interactive DFS query tool"""
import duckdb

con = duckdb.connect('data/dfs_warehouse.duckdb')

print("="*80)
print("DFS DATA WAREHOUSE - INTERACTIVE QUERY TOOL")
print("="*80)

while True:
    print("\n Available Queries:")
    print("  1. Search player by name")
    print("  2. Compare two players")
    print("  3. Find high-value plays for salary range")
    print("  4. Custom SQL query")
    print("  5. Exit")
    
    choice = input("\nSelect option (1-5): ").strip()
    
    if choice == '1':
        player_name = input("Enter player name: ").strip()
        results = con.execute(f"""
            SELECT 
                player_id,
                sport,
                site_code,
                COUNT(*) as games,
                ROUND(AVG(fantasy_points), 1) as avg_fpts,
                ROUND(AVG(salary), 0) as avg_salary,
                ROUND(AVG(value), 2) as avg_value,
                ROUND(MIN(fantasy_points), 1) as min_fpts,
                ROUND(MAX(fantasy_points), 1) as max_fpts
            FROM fact_player_performance
            WHERE LOWER(player_id) LIKE LOWER('%{player_name}%')
            GROUP BY player_id, sport, site_code
            ORDER BY COUNT(*) DESC
        """).fetchdf()
        print(f"\n{results.to_string(index=False)}")
    
    elif choice == '2':
        p1 = input("Player 1 name: ").strip()
        p2 = input("Player 2 name: ").strip()
        results = con.execute(f"""
            SELECT 
                player_id,
                sport,
                COUNT(*) as games,
                ROUND(AVG(fantasy_points), 1) as avg_fpts,
                ROUND(STDDEV(fantasy_points), 1) as std_fpts,
                ROUND(AVG(value), 2) as avg_value
            FROM fact_player_performance
            WHERE LOWER(player_id) IN (LOWER('{p1}'), LOWER('{p2}'))
              AND fantasy_points > 0
            GROUP BY player_id, sport
        """).fetchdf()
        print(f"\n{results.to_string(index=False)}")
    
    elif choice == '3':
        min_sal = input("Min salary (e.g. 5000): ").strip()
        max_sal = input("Max salary (e.g. 8000): ").strip()
        sport = input("Sport (NBA/NFL): ").strip().upper()
        results = con.execute(f"""
            SELECT 
                player_id,
                COUNT(*) as games,
                ROUND(AVG(salary), 0) as avg_salary,
                ROUND(AVG(fantasy_points), 1) as avg_fpts,
                ROUND(AVG(value), 2) as avg_value
            FROM fact_player_performance
            WHERE salary BETWEEN {min_sal} AND {max_sal}
              AND sport = '{sport}'
              AND fantasy_points > 0
            GROUP BY player_id
            HAVING COUNT(*) >= 3
            ORDER BY AVG(value) DESC
            LIMIT 20
        """).fetchdf()
        print(f"\n{results.to_string(index=False)}")
    
    elif choice == '4':
        print("\nEnter SQL query (or 'back' to return):")
        sql = input("> ").strip()
        if sql.lower() != 'back':
            try:
                results = con.execute(sql).fetchdf()
                print(f"\n{results.to_string(index=False)}")
            except Exception as e:
                print(f"Error: {e}")
    
    elif choice == '5':
        break

con.close()
print("\n Session ended")