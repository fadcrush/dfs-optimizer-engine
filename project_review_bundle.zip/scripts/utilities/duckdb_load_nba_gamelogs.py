"""Load NBA season game logs CSV into DuckDB for DFS projections.

Reads the league-wide player game logs CSV produced by nba_api_client.py:
  api_integrations/data_cache/nba/player_game_logs_<season>.csv

Creates/updates a DuckDB database:
  data/dfs_warehouse.duckdb

Usage (from your project root):
  python duckdb_load_nba_gamelogs.py --season 2024-25

Notes:
- This script recreates the table from the CSV each time to avoid duplicates
  while you iterate.
"""
import argparse
from pathlib import Path
import duckdb
import pandas as pd

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--season", default="2024-25", help="NBA season string, e.g. 2024-25")
    ap.add_argument("--csv", default=None, help="Override path to player_game_logs CSV")
    ap.add_argument("--db", default="data/dfs_warehouse.duckdb", help="DuckDB path")
    args = ap.parse_args()

    season = args.season
    csv_path = Path(args.csv) if args.csv else Path(f"api_integrations/data_cache/nba/player_game_logs_{season}.csv")
    if not csv_path.exists():
        raise FileNotFoundError(f"Could not find game logs CSV: {csv_path}")

    db_path = Path(args.db)
    db_path.parent.mkdir(parents=True, exist_ok=True)

    print(f" Loading: {csv_path}")
    df = pd.read_csv(csv_path)

    required = ["PLAYER_ID","PLAYER_NAME","GAME_DATE","MATCHUP","MIN","PTS","REB","AST","STL","BLK","TOV","FG3M"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns in logs CSV: {missing}\nColumns found: {list(df.columns)[:30]}...")

    matchup = df["MATCHUP"].astype(str)
    df["TEAM_ABBR"] = matchup.str.slice(0,3)
    df["HOME"] = matchup.str.contains("vs\.", na=False).astype(int)
    df["OPP_ABBR"] = matchup.str[-3:]

    # FanDuel NBA scoring
    df["FD_POINTS"] = (
        df["PTS"].fillna(0)*1.0 +
        df["REB"].fillna(0)*1.2 +
        df["AST"].fillna(0)*1.5 +
        df["STL"].fillna(0)*3.0 +
        df["BLK"].fillna(0)*3.0 +
        df["TOV"].fillna(0)*-1.0
    )

    df["PLAYER_ID"] = df["PLAYER_ID"].astype("int64")
    df["PLAYER_NAME"] = df["PLAYER_NAME"].astype(str)
    df["GAME_DATE"] = pd.to_datetime(df["GAME_DATE"], errors="coerce").dt.date
    df["MIN"] = pd.to_numeric(df["MIN"], errors="coerce").fillna(0.0)

    out = df[[
        "PLAYER_ID","PLAYER_NAME","GAME_DATE","TEAM_ABBR","OPP_ABBR","HOME","MIN","FD_POINTS",
        "PTS","REB","AST","STL","BLK","TOV","FG3M"
    ]].copy()
    out["SEASON"] = season

    con = duckdb.connect(str(db_path))
    con.execute("PRAGMA threads=4;")

    con.execute("DROP TABLE IF EXISTS nba_player_game_logs;")
    con.execute("""
        CREATE TABLE nba_player_game_logs (
            season TEXT,
            game_date DATE,
            player_id BIGINT,
            player_name TEXT,
            team_abbr TEXT,
            opp_abbr TEXT,
            home INTEGER,
            minutes DOUBLE,
            fd_points DOUBLE,
            pts DOUBLE,
            reb DOUBLE,
            ast DOUBLE,
            stl DOUBLE,
            blk DOUBLE,
            tov DOUBLE,
            fg3m DOUBLE
        );
    """)
    con.register("logs_df", out)
    con.execute("""
        INSERT INTO nba_player_game_logs
        SELECT
            SEASON as season,
            GAME_DATE as game_date,
            PLAYER_ID as player_id,
            PLAYER_NAME as player_name,
            TEAM_ABBR as team_abbr,
            OPP_ABBR as opp_abbr,
            HOME as home,
            MIN as minutes,
            FD_POINTS as fd_points,
            PTS as pts,
            REB as reb,
            AST as ast,
            STL as stl,
            BLK as blk,
            TOV as tov,
            FG3M as fg3m
        FROM logs_df
        WHERE GAME_DATE IS NOT NULL;
    """)
    con.execute("CREATE INDEX IF NOT EXISTS idx_nba_logs_name_date ON nba_player_game_logs(player_name, game_date);")
    con.close()

    print(f"[OK] DuckDB updated: {db_path}")
    print("   Table: nba_player_game_logs")

if __name__ == "__main__":
    main()
