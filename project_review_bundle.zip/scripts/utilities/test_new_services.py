"""
Test Script for New DFS Services
Tests all the newly created services: caching, correlation, real-time, etc.
"""

import asyncio
import sys
from pathlib import Path

# Add project root to path
PROJECT_ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

# Load environment variables
from dotenv import load_dotenv
load_dotenv(PROJECT_ROOT / '.env')


def test_caching_service():
    """Test the caching service"""
    print("\n" + "="*50)
    print("Testing Caching Service")
    print("="*50)

    try:
        from backend.services.caching_service import get_cache, get_dfs_cache, CacheConfig

        # Test basic cache operations
        cache = get_cache()

        # Set a value
        cache.set("test_key", {"player": "LeBron", "projection": 52.5}, ttl=60)
        print("[OK] Cache set operation")

        # Get the value
        value, hit = cache.get("test_key")
        assert hit == True
        assert value["player"] == "LeBron"
        print("[OK] Cache get operation (hit)")

        # Test cache miss
        value, hit = cache.get("nonexistent_key")
        assert hit == False
        print("[OK] Cache miss handled correctly")

        # Test get_or_set
        result = cache.get_or_set("computed_key", lambda: {"computed": True}, ttl=60)
        assert result["computed"] == True
        print("[OK] Cache get_or_set operation")

        # Test DFS-specific cache
        dfs_cache = get_dfs_cache()
        dfs_cache.set_vegas_lines({"game1": {"total": 225}}, sport='nba')
        vegas, hit = dfs_cache.get_vegas_lines('nba')
        assert hit == True
        print("[OK] DFS Vegas lines caching")

        # Get stats
        stats = cache.get_stats()
        print(f"[OK] Cache stats: {stats['hits']} hits, {stats['misses']} misses, {stats['entries']} entries")

        print("\nCaching Service: ALL TESTS PASSED")
        return True

    except Exception as e:
        print(f"[FAILED] Caching Service Error: {e}")
        return False


def test_correlation_builder():
    """Test the correlation builder service"""
    print("\n" + "="*50)
    print("Testing Correlation Builder")
    print("="*50)

    try:
        from backend.services.correlation_builder import CorrelationBuilder, CorrelationConfig
        import numpy as np

        # Create builder with config
        config = CorrelationConfig(
            min_shared_games=5,
            lookback_days=180,
            teammate_prior=0.15
        )
        builder = CorrelationBuilder(config)
        print("[OK] Correlation builder created")

        # Test correlation lookup (using priors since we may not have data)
        corr = builder.get_correlation(
            "Player1", "Player2",
            team1="LAL", team2="LAL",
            pos1="PG", pos2="SG",
            same_game=True
        )
        assert -1 <= corr <= 1
        print(f"[OK] Teammate correlation: {corr:.3f}")

        # Test opponent correlation
        corr_opp = builder.get_correlation(
            "Player1", "Player3",
            team1="LAL", team2="BOS",
            same_game=True
        )
        print(f"[OK] Opponent correlation: {corr_opp:.3f}")

        # Test building correlation matrix for players
        players = [
            {"player_name": "P1", "team": "LAL", "position": "PG"},
            {"player_name": "P2", "team": "LAL", "position": "SG"},
            {"player_name": "P3", "team": "BOS", "position": "C"},
            {"player_name": "P4", "team": "BOS", "position": "PF"}
        ]

        matrix = builder.build_correlation_matrix(players)
        assert matrix.shape == (4, 4)
        assert np.allclose(np.diag(matrix), 1.0)  # Diagonal should be 1
        print(f"[OK] Built 4x4 correlation matrix")

        # Verify matrix is positive semi-definite
        eigenvalues = np.linalg.eigvalsh(matrix)
        assert np.all(eigenvalues >= -1e-10)
        print("[OK] Matrix is positive semi-definite")

        # Try loading from database
        df = builder.load_game_logs(lookback_days=30)
        print(f"[OK] Loaded {len(df)} game logs from database")

        print("\nCorrelation Builder: ALL TESTS PASSED")
        return True

    except Exception as e:
        print(f"[FAILED] Correlation Builder Error: {e}")
        import traceback
        traceback.print_exc()
        return False


async def test_realtime_service():
    """Test the real-time data service"""
    print("\n" + "="*50)
    print("Testing Real-Time Service")
    print("="*50)

    try:
        from backend.services.realtime_service import get_realtime_service, RealTimeService
        import os

        service = get_realtime_service()
        print("[OK] Real-time service created")

        # Check API keys (support multiple env var names)
        has_odds_key = bool(os.getenv('THEODDS_API_KEY') or os.getenv('ODDS_API_KEY'))
        has_sportsdata_key = bool(os.getenv('SPORTSDATA_API_KEY'))

        print(f"[INFO] THEODDS_API_KEY configured: {has_odds_key}")
        print(f"[INFO] SPORTSDATA_API_KEY configured: {has_sportsdata_key}")

        # Test Vegas lines fetch
        if has_odds_key:
            vegas = await service.fetch_vegas_lines('nba')
            print(f"[OK] Fetched {len(vegas)} NBA games with Vegas lines")

            if vegas:
                sample = vegas[0]
                print(f"    Sample: {sample.away_team} @ {sample.home_team}")
                print(f"    Spread: {sample.spread}, Total: {sample.total}")
        else:
            print("[SKIP] Vegas lines test (no API key)")

        # Test injuries fetch
        if has_sportsdata_key:
            injuries = await service.fetch_injuries('nba')
            print(f"[OK] Fetched {len(injuries)} injury reports")

            if injuries:
                out_players = [i for i in injuries if i.is_out]
                questionable = [i for i in injuries if i.is_questionable]
                print(f"    OUT: {len(out_players)}, Questionable: {len(questionable)}")
        else:
            print("[SKIP] Injuries test (no API key)")

        # Test projection context (doesn't require API)
        context = service.get_projection_context(
            {"player_name": "LeBron James", "team": "LAL"},
            sport='nba'
        )
        assert 'player_name' in context
        assert 'team' in context
        print("[OK] Projection context generation")

        # Test projection adjustment
        adjustment = service.adjust_projection_for_realtime(
            base_projection=45.0,
            player={"player_name": "Test Player", "team": "LAL"},
            sport='nba'
        )
        assert 'projection' in adjustment
        assert 'factors' in adjustment
        print(f"[OK] Projection adjustment: {adjustment['base_projection']} -> {adjustment['projection']:.1f}")

        print("\nReal-Time Service: ALL TESTS PASSED")
        return True

    except Exception as e:
        print(f"[FAILED] Real-Time Service Error: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_simulation_engine():
    """Test the Monte Carlo simulation engine"""
    print("\n" + "="*50)
    print("Testing Simulation Engine")
    print("="*50)

    try:
        from backend.services.simulation_engine import MonteCarloEngine, SimulationConfig
        import pandas as pd
        import numpy as np

        # Create test data
        df = pd.DataFrame({
            'player_id': [f'p{i}' for i in range(8)],
            'player_name': [f'Player {i}' for i in range(8)],
            'base_projection': [30.0 + i*2 for i in range(8)],
            'team': ['LAL'] * 4 + ['BOS'] * 4,
            'opponent': ['BOS'] * 4 + ['LAL'] * 4,
            'position': ['PG', 'SG', 'SF', 'PF', 'C', 'PG', 'SG', 'SF'],
            'game_id': ['g1'] * 8,
            'salary': [6000 + i*500 for i in range(8)]
        })

        # Create engine
        config = SimulationConfig(num_simulations=1000, random_seed=42)
        engine = MonteCarloEngine(config)
        print("[OK] Simulation engine created")

        # Load data
        engine.load_player_data(df)
        print(f"[OK] Loaded {len(df)} players")

        # Build correlation matrix
        engine.build_correlation_matrix()
        print("[OK] Built correlation matrix")

        # Simulate single player
        player_sim = engine.simulate_player_outcomes(0)
        assert len(player_sim.simulated_outcomes) == 1000
        print(f"[OK] Player simulation: mean={player_sim.mean_projection:.1f}, std={player_sim.std_deviation:.1f}")
        print(f"    Floor risk: {player_sim.floor_risk:.1%}, Ceiling potential: {player_sim.ceiling_potential:.1%}")

        # Simulate lineup
        lineup = [{'player_id': f'p{i}', 'salary': 6000} for i in range(8)]
        lineup_sim = engine.simulate_lineup(lineup, "test_lineup")

        assert lineup_sim.mean_total > 0
        print(f"[OK] Lineup simulation: mean={lineup_sim.mean_total:.1f}, std={lineup_sim.std_total:.1f}")
        print(f"    10th percentile: {lineup_sim.percentile_10_total:.1f}")
        print(f"    90th percentile: {lineup_sim.percentile_90_total:.1f}")

        # Compare lineups
        lineups = [
            [{'player_id': f'p{i}'} for i in range(8)],
            [{'player_id': f'p{(i+1) % 8}'} for i in range(8)]
        ]

        results = engine.run_lineup_comparison(lineups)
        assert 'lineup_simulations' in results
        assert 'win_probability_matrix' in results
        print(f"[OK] Lineup comparison: {len(results['lineup_simulations'])} lineups compared")

        print("\nSimulation Engine: ALL TESTS PASSED")
        return True

    except Exception as e:
        print(f"[FAILED] Simulation Engine Error: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_uncertainty_modeling():
    """Test the uncertainty modeling service"""
    print("\n" + "="*50)
    print("Testing Uncertainty Modeling")
    print("="*50)

    try:
        from backend.services.uncertainty_modeling import UncertaintyModeler

        modeler = UncertaintyModeler()
        print("[OK] Uncertainty modeler created")

        # Test distribution calculation
        result = modeler.calculate_distribution(
            base_projection=35.0,
            position='PG',
            minutes_proj=32.0,
            salary=7500
        )

        assert 'mean' in result
        assert 'std_dev' in result
        assert 'floor' in result
        assert 'ceiling' in result

        print(f"[OK] Distribution calculated:")
        print(f"    Mean: {result['mean']:.1f}, Std: {result['std_dev']:.1f}")
        print(f"    Floor: {result['floor']:.1f}, Ceiling: {result['ceiling']:.1f}")

        # Test with different positions
        for pos in ['PG', 'C', 'SF']:
            dist = modeler.calculate_distribution(30.0, pos, 28.0, 6000)
            print(f"[OK] {pos} volatility factor applied: std={dist['std_dev']:.2f}")

        print("\nUncertainty Modeling: ALL TESTS PASSED")
        return True

    except ImportError:
        print("[SKIP] Uncertainty modeling module not found")
        return True
    except Exception as e:
        print(f"[FAILED] Uncertainty Modeling Error: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_opportunity_modeling():
    """Test the opportunity modeling service"""
    print("\n" + "="*50)
    print("Testing Opportunity Modeling")
    print("="*50)

    try:
        from backend.services.opportunity_modeling import OpportunityModelingService, GameContext

        service = OpportunityModelingService()
        print("[OK] Opportunity modeling service created")

        # Test game context analysis
        game_data = {
            'home_team': 'LAL',
            'away_team': 'BOS',
            'vegas_spread': -5.5,
            'total_points': 228.5,
            'home_rest_days': 2,
            'away_rest_days': 1
        }

        context = service.analyze_game_context(game_data)
        assert context.home_team == 'LAL'
        assert context.away_team == 'BOS'
        print(f"[OK] Game context: {context.home_team} vs {context.away_team}")
        print(f"    Spread: {context.vegas_spread}, Total: {context.total_points}")

        # Test blowout risk
        blowout = service.assess_blowout_risk(context)
        print(f"[OK] Blowout probability: {blowout['blowout_probability']:.1%}")

        # Test rotation volatility
        rotation = service.model_rotation_volatility('LAL', context)
        print(f"[OK] Rotation volatility: {rotation['rotation_volatility']:.2f}")

        # Test opportunity adjustment
        player_data = {
            'player_id': 'lebron_1',
            'player_name': 'LeBron James',
            'team': 'LAL',
            'base_minutes': 35.0,
            'role': 'star'
        }

        opportunity = service.calculate_opportunity_adjustment(
            player_data, context, rotation, blowout
        )

        print(f"[OK] Opportunity adjustment:")
        print(f"    Base minutes: {opportunity.base_minutes}")
        print(f"    Adjusted minutes: {opportunity.adjusted_minutes:.1f}")
        print(f"    Multiplier: {opportunity.opportunity_multiplier:.2f}")

        if opportunity.upside_factors:
            print(f"    Upside: {', '.join(opportunity.upside_factors)}")
        if opportunity.risk_factors:
            print(f"    Risk: {', '.join(opportunity.risk_factors)}")

        print("\nOpportunity Modeling: ALL TESTS PASSED")
        return True

    except Exception as e:
        print(f"[FAILED] Opportunity Modeling Error: {e}")
        import traceback
        traceback.print_exc()
        return False


async def main():
    """Run all service tests"""
    print("\n" + "#"*60)
    print("# DFS New Services Test Suite")
    print("#"*60)

    results = {}

    # Run sync tests
    results['Caching'] = test_caching_service()
    results['Correlation'] = test_correlation_builder()
    results['Simulation'] = test_simulation_engine()
    results['Uncertainty'] = test_uncertainty_modeling()
    results['Opportunity'] = test_opportunity_modeling()

    # Run async tests
    results['RealTime'] = await test_realtime_service()

    # Summary
    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)

    passed = sum(1 for v in results.values() if v)
    total = len(results)

    for service, result in results.items():
        status = "PASSED" if result else "FAILED"
        print(f"  {service}: {status}")

    print(f"\nTotal: {passed}/{total} services passed")

    if passed == total:
        print("\nAll services are working correctly!")
    else:
        print("\nSome services have issues. Check the output above.")

    return passed == total


if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)
