
#!/usr/bin/env python
"""
build_player_position_map_duckdb.py

Builds/updates a DuckDB dimension table that maps FanDuel player Ids to a single position bucket.
This enables Defense-vs-Position (DvP) even when nba_player_game_logs does not contain positions.

Table created/updated:
  nba_player_position_map(
      player_id TEXT PRIMARY KEY,
      name TEXT,
      position_raw TEXT,
      pos_bucket TEXT,
      last_seen_date DATE
  )

Inputs:
- One "today" slate file (optional but recommended)
- A folder of past FanDuel slate CSVs (optional; use for coverage/stability)

Notes:
- FanDuel "Id" values look like "125017-84680" (slate-specific prefix + player id).
  We'll store that full Id string as player_id to match your slate CSV.
- If you later store a different player_id format in logs, we can add a second key.

Usage:
  python build_player_position_map_duckdb.py --db "C:\...\dfs_warehouse.duckdb" \
     --today "C:\...\FanDuel-NBA-...-players-list.csv" \
     --past "C:\...\FD_NBA_Past_Games"

You can run this daily before projections.
"""
import argparse
import re
from datetime import datetime
from pathlib import Path

import duckdb
import pandas as pd


def _primary_pos_bucket(pos_str: str) -> str:
    s = (pos_str or "").upper()
    for bucket in ["PG", "SG", "SF", "PF", "C"]:
        if bucket in s:
            return bucket
    return ""


def _fd_name(row: pd.Series) -> str:
    # Prefer Nickname (usually full name)
    for col in ["Nickname", "Name"]:
        if col in row and pd.notna(row[col]) and str(row[col]).strip():
            return str(row[col]).strip()
    fn = str(row.get("First Name", "")).strip()
    ln = str(row.get("Last Name", "")).strip()
    return (fn + " " + ln).strip()


def load_one_csv(csv_path: Path) -> pd.DataFrame:
    df = pd.read_csv(csv_path)
    id_col = "Id" if "Id" in df.columns else ("ID" if "ID" in df.columns else None)
    if not id_col:
        raise ValueError(f"{csv_path.name}: missing Id/ID column")

    if "Position" not in df.columns:
        raise ValueError(f"{csv_path.name}: missing Position column")

    out = pd.DataFrame()
    out["player_id"] = df[id_col].astype(str)
    out["name"] = df.apply(_fd_name, axis=1)
    out["position_raw"] = df["Position"].astype(str)
    out["pos_bucket"] = out["position_raw"].map(_primary_pos_bucket)

    # last_seen_date: parse from filename if possible else file mtime
    # Expected filename contains: EST-12 EST-31 EST-2025 or similar; we'll just use mtime safely.
    mtime = datetime.fromtimestamp(csv_path.stat().st_mtime).date()
    out["last_seen_date"] = mtime

    # keep only valid buckets
    out = out[out["pos_bucket"].isin(["PG", "SG", "SF", "PF", "C"])].copy()
    return out


def scan_folder(folder: Path) -> list[Path]:
    # Scan typical FD slate csv names
    patterns = ["*.csv", "*.CSV"]
    paths = []
    for pat in patterns:
        paths.extend(folder.glob(pat))
    # Filter for FD NBA players list files if present
    # If folder contains mixed, we still allow but require Position/Id columns.
    return sorted(set(paths))


def upsert(con: duckdb.DuckDBPyConnection, rows: pd.DataFrame):
    con.execute("""
    CREATE TABLE IF NOT EXISTS nba_player_position_map(
        player_id TEXT PRIMARY KEY,
        name TEXT,
        position_raw TEXT,
        pos_bucket TEXT,
        last_seen_date DATE
    );
    """)
    con.register("incoming", rows)

    # Upsert: keep most recent last_seen_date
    con.execute("""
    INSERT INTO nba_player_position_map AS t
    SELECT player_id, name, position_raw, pos_bucket, last_seen_date
    FROM incoming
    ON CONFLICT(player_id) DO UPDATE SET
      name = excluded.name,
      position_raw = excluded.position_raw,
      pos_bucket = excluded.pos_bucket,
      last_seen_date = CASE
        WHEN excluded.last_seen_date >= t.last_seen_date THEN excluded.last_seen_date
        ELSE t.last_seen_date
      END;
    """)
    con.unregister("incoming")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", required=True, help="Path to dfs_warehouse.duckdb")
    ap.add_argument("--today", default=None, help="Path to today's FanDuel NBA players-list.csv")
    ap.add_argument("--past", default=None, help="Folder containing past FanDuel NBA players-list CSVs")
    ap.add_argument("--max-files", type=int, default=0, help="Optional cap for debugging (0 = no cap)")
    args = ap.parse_args()

    all_parts = []

    if args.past:
        folder = Path(args.past)
        if not folder.exists():
            raise SystemExit(f"--past folder not found: {folder}")
        files = scan_folder(folder)
        if args.max_files and args.max_files > 0:
            files = files[: args.max_files]
        if not files:
            print(f"[WARNING]  No CSVs found in {folder}")
        else:
            print(f" Loading past slates: {len(files)} files from {folder}")
            for p in files:
                try:
                    all_parts.append(load_one_csv(p))
                except Exception:
                    # skip non-slate csvs quietly
                    continue

    if args.today:
        p = Path(args.today)
        if not p.exists():
            raise SystemExit(f"--today file not found: {p}")
        print(f" Loading today slate: {p.name}")
        all_parts.append(load_one_csv(p))

    if not all_parts:
        raise SystemExit("No valid slate rows found. Provide --today and/or --past folder with FD slate CSVs.")

    combined = pd.concat(all_parts, ignore_index=True)
    combined = combined.dropna(subset=["player_id", "pos_bucket"]).copy()

    # Deduplicate by player_id keeping most recent
    combined["last_seen_date"] = pd.to_datetime(combined["last_seen_date"]).dt.date
    combined = combined.sort_values("last_seen_date").drop_duplicates("player_id", keep="last")

    con = duckdb.connect(args.db)
    upsert(con, combined)
    n = con.execute("SELECT COUNT(*) AS n FROM nba_player_position_map").df()["n"].iloc[0]
    print(f"[OK] Updated nba_player_position_map. Total players mapped: {n}")
    print("Sample:")
    print(con.execute("SELECT * FROM nba_player_position_map ORDER BY last_seen_date DESC LIMIT 10").df().to_string(index=False))
    con.close()


if __name__ == "__main__":
    main()
