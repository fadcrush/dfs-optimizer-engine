"""
Database Sync Script
Syncs data from dfs_warehouse.duckdb to dfs_master.duckdb

This script:
1. Extracts NBA player game logs from warehouse
2. Transforms to master schema format
3. Loads into master database
4. Builds player dimension table
"""

import duckdb
from pathlib import Path
from datetime import datetime

# Paths
BASE_DIR = Path(__file__).parent.parent.parent
WAREHOUSE_PATH = BASE_DIR / "data" / "dfs_warehouse.duckdb"
MASTER_PATH = BASE_DIR / "data" / "dfs_master.duckdb"


def sync_nba_game_logs():
    """Sync NBA player game logs from warehouse to master"""
    print("\n" + "=" * 60)
    print("SYNCING NBA PLAYER GAME LOGS")
    print("=" * 60)

    # Connect to both databases
    warehouse = duckdb.connect(str(WAREHOUSE_PATH), read_only=True)
    master = duckdb.connect(str(MASTER_PATH))

    # Get count before
    before_count = master.execute("SELECT COUNT(*) FROM player_game_logs").fetchone()[0]
    print(f"Master player_game_logs before: {before_count:,} records")

    # Extract from warehouse and transform
    print("Extracting from warehouse...")

    # Transform warehouse schema to master schema
    transform_query = """
    SELECT
        ROW_NUMBER() OVER () as game_log_id,
        CONCAT(player_id, '_', game_date) as game_id,
        CAST(player_id AS VARCHAR) as player_id,
        player_name,
        game_date as date,
        season,
        team_abbr as team,
        opp_abbr as opponent,
        CASE WHEN home = 1 THEN 'HOME' ELSE 'AWAY' END as home_away,
        CASE WHEN minutes >= 20 THEN TRUE ELSE FALSE END as started,
        CAST(minutes AS FLOAT) as minutes_played,
        NULL as rest_days,
        NULL as game_number,
        CAST(pts AS INTEGER) as points,
        CAST(reb AS INTEGER) as rebounds,
        CAST(ast AS INTEGER) as assists,
        CAST(stl AS INTEGER) as steals,
        CAST(blk AS INTEGER) as blocks,
        CAST(tov AS INTEGER) as turnovers,
        NULL as fgm,
        NULL as fga,
        CAST(fg3m AS INTEGER) as fg3m,
        NULL as fg3a,
        NULL as ftm,
        NULL as fta,
        NULL as offensive_rebounds,
        NULL as defensive_rebounds,
        NULL as pass_attempts,
        NULL as pass_completions,
        NULL as pass_yards,
        NULL as pass_tds,
        NULL as interceptions,
        NULL as rush_attempts,
        NULL as rush_yards,
        NULL as rush_tds,
        NULL as targets,
        NULL as receptions,
        NULL as receiving_yards,
        NULL as receiving_tds,
        NULL as fumbles_lost,
        NULL as dk_points,
        CAST(fd_points AS FLOAT) as fd_points,
        NULL as yahoo_points,
        NULL as usage_rate,
        NULL as true_shooting_pct,
        NULL as plus_minus,
        'warehouse_sync' as source,
        CURRENT_TIMESTAMP as created_at
    FROM nba_player_game_logs
    WHERE player_name IS NOT NULL
    """

    df = warehouse.execute(transform_query).fetchdf()
    print(f"Extracted {len(df):,} records from warehouse")

    # Clear existing synced data and insert new
    print("Loading into master database...")
    master.execute("DELETE FROM player_game_logs WHERE source = 'warehouse_sync'")

    # Register the dataframe and insert
    master.register('sync_data', df)
    master.execute("""
        INSERT INTO player_game_logs
        SELECT * FROM sync_data
    """)

    # Get count after
    after_count = master.execute("SELECT COUNT(*) FROM player_game_logs").fetchone()[0]
    print(f"Master player_game_logs after: {after_count:,} records")
    print(f"Added: {after_count - before_count:,} records")

    warehouse.close()
    master.close()

    return after_count - before_count


def sync_players():
    """Build players dimension table from game logs"""
    print("\n" + "=" * 60)
    print("SYNCING PLAYERS DIMENSION TABLE")
    print("=" * 60)

    master = duckdb.connect(str(MASTER_PATH))

    # Get count before
    before_count = master.execute("SELECT COUNT(*) FROM players").fetchone()[0]
    print(f"Players table before: {before_count:,} records")

    # Build players from game logs
    build_query = """
    INSERT INTO players (player_id, player_name, primary_position, team, sport, active, created_at, updated_at)
    SELECT DISTINCT
        player_id,
        player_name,
        NULL as primary_position,
        FIRST_VALUE(team) OVER (PARTITION BY player_id ORDER BY date DESC) as team,
        'NBA' as sport,
        TRUE as active,
        CURRENT_TIMESTAMP as created_at,
        CURRENT_TIMESTAMP as updated_at
    FROM player_game_logs
    WHERE player_id NOT IN (SELECT player_id FROM players WHERE player_id IS NOT NULL)
    GROUP BY player_id, player_name
    """

    # First get unique players not already in table
    unique_players_query = """
    SELECT DISTINCT
        player_id,
        player_name,
        NULL as primary_position,
        team,
        'NBA' as sport,
        NULL as height,
        NULL as weight,
        NULL as age,
        NULL as experience,
        TRUE as active,
        CURRENT_TIMESTAMP as created_at,
        CURRENT_TIMESTAMP as updated_at
    FROM (
        SELECT
            player_id,
            player_name,
            team,
            ROW_NUMBER() OVER (PARTITION BY player_id ORDER BY date DESC) as rn
        FROM player_game_logs
        WHERE player_id IS NOT NULL
    ) sub
    WHERE rn = 1
    AND player_id NOT IN (SELECT player_id FROM players WHERE player_id IS NOT NULL)
    """

    df = master.execute(unique_players_query).fetchdf()
    print(f"Found {len(df):,} new players to add")

    if len(df) > 0:
        master.register('new_players', df)
        master.execute("""
            INSERT INTO players (player_id, player_name, primary_position, team, sport,
                                 height, weight, age, experience, active, created_at, updated_at)
            SELECT * FROM new_players
        """)

    # Get count after
    after_count = master.execute("SELECT COUNT(*) FROM players").fetchone()[0]
    print(f"Players table after: {after_count:,} records")

    master.close()

    return after_count - before_count


def sync_player_positions():
    """Sync player positions from warehouse position map"""
    print("\n" + "=" * 60)
    print("SYNCING PLAYER POSITIONS")
    print("=" * 60)

    warehouse = duckdb.connect(str(WAREHOUSE_PATH), read_only=True)
    master = duckdb.connect(str(MASTER_PATH))

    # Get position map from warehouse
    pos_map = warehouse.execute("""
        SELECT name as player_name, pos_bucket as position
        FROM nba_player_position_map
    """).fetchdf()

    print(f"Found {len(pos_map):,} position mappings in warehouse")

    # Update players table with positions
    updated = 0
    for _, row in pos_map.iterrows():
        try:
            master.execute("""
                UPDATE players
                SET primary_position = ?, updated_at = CURRENT_TIMESTAMP
                WHERE player_name = ? AND primary_position IS NULL
            """, [row['position'], row['player_name']])
            updated += 1
        except Exception:
            pass

    print(f"Updated {updated:,} player positions")

    warehouse.close()
    master.close()

    return updated


def sync_contest_performance():
    """Sync contest performance data from warehouse"""
    print("\n" + "=" * 60)
    print("SYNCING CONTEST PERFORMANCE DATA")
    print("=" * 60)

    warehouse = duckdb.connect(str(WAREHOUSE_PATH), read_only=True)
    master = duckdb.connect(str(MASTER_PATH))

    # Check if we have the table
    tables = master.execute("""
        SELECT table_name FROM information_schema.tables
        WHERE table_schema='main'
    """).fetchall()
    table_names = [t[0] for t in tables]

    print(f"Available tables: {table_names}")

    # Get fact_player_performance stats
    perf_count = warehouse.execute("SELECT COUNT(*) FROM fact_player_performance").fetchone()[0]
    print(f"Warehouse fact_player_performance: {perf_count:,} records")

    warehouse.close()
    master.close()


def verify_sync():
    """Verify the sync was successful"""
    print("\n" + "=" * 60)
    print("VERIFICATION")
    print("=" * 60)

    master = duckdb.connect(str(MASTER_PATH), read_only=True)

    # Check all tables
    tables = ['players', 'player_game_logs', 'contest_results', 'games', 'vegas_odds', 'projections']

    for table in tables:
        try:
            count = master.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
            status = "OK" if count > 0 else "EMPTY"
            print(f"  {table}: {count:,} records [{status}]")
        except Exception as e:
            print(f"  {table}: ERROR - {e}")

    # Sample data
    print("\n=== Sample Game Logs ===")
    sample = master.execute("""
        SELECT player_name, date, team, opponent, points, rebounds, assists, fd_points
        FROM player_game_logs
        ORDER BY date DESC
        LIMIT 5
    """).fetchdf()
    print(sample.to_string())

    print("\n=== Sample Players ===")
    sample2 = master.execute("""
        SELECT player_name, primary_position, team, sport
        FROM players
        LIMIT 5
    """).fetchdf()
    print(sample2.to_string())

    master.close()


def main():
    """Run full sync"""
    print("\n" + "=" * 60)
    print("DFS DATABASE SYNC")
    print(f"Started: {datetime.now()}")
    print("=" * 60)

    # Check paths exist
    if not WAREHOUSE_PATH.exists():
        print(f"ERROR: Warehouse not found at {WAREHOUSE_PATH}")
        return

    if not MASTER_PATH.exists():
        print(f"ERROR: Master not found at {MASTER_PATH}")
        return

    print(f"Warehouse: {WAREHOUSE_PATH}")
    print(f"Master: {MASTER_PATH}")

    # Run syncs
    game_logs_added = sync_nba_game_logs()
    players_added = sync_players()
    sync_player_positions()
    sync_contest_performance()

    # Verify
    verify_sync()

    print("\n" + "=" * 60)
    print("SYNC COMPLETE")
    print(f"Finished: {datetime.now()}")
    print("=" * 60)


if __name__ == "__main__":
    main()
