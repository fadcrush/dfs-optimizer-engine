#!/usr/bin/env python
"""
update_duckdb.py

Automatically update DuckDB with latest game results.

This keeps your injury beneficiary analysis SMART by continuously
learning from new data!

Usage:
    # Update with yesterday's games
    python update_duckdb.py --date yesterday
    
    # Update specific date
    python update_duckdb.py --date 2026-01-02
    
    # Update date range
    python update_duckdb.py --start 2026-01-01 --end 2026-01-07
    
    # Auto-update (checks for missing dates)
    python update_duckdb.py --auto
"""

import argparse
import duckdb
import pandas as pd
import requests
from pathlib import Path
from datetime import datetime, timedelta
import time

print("="*80)
print("DuckDB AUTO-UPDATE SYSTEM")
print("="*80)

# You'll need to add your API keys here
# Free options: balldontlie.io, sportsdata.io (limited free tier)
API_CONFIGS = {
    'balldontlie': {
        'base_url': 'https://api.balldontlie.io/v1',
        'key': None,  # Add your key
        'rate_limit': 60  # requests per minute
    },
    'sportsdata': {
        'base_url': 'https://api.sportsdata.io/v3/nba',
        'key': None,  # Add your key
        'rate_limit': 10
    }
}

def get_game_logs_csv(date: str) -> pd.DataFrame:
    """
    Alternative: Load from CSV export
    
    You can manually download game logs from:
    - Basketball Reference
    - RotoWire
    - FantasyLabs
    
    Save as: data/game_logs/YYYY-MM-DD.csv
    """
    
    csv_path = Path(f"data/game_logs/{date}.csv")
    
    if not csv_path.exists():
        print(f"[WARNING]  CSV not found: {csv_path}")
        return pd.DataFrame()
    
    print(f" Loading from CSV: {csv_path}")
    df = pd.read_csv(csv_path)
    
    # Standardize columns
    # This depends on your CSV format
    # Adjust column names as needed
    
    return df

def get_game_logs_api(date: str, api: str = 'balldontlie') -> pd.DataFrame:
    """
    Fetch game logs from API
    
    NOTE: You need to add API keys above!
    """
    
    config = API_CONFIGS.get(api)
    if not config or not config['key']:
        print(f"[WARNING]  {api} API not configured")
        print("   Add your API key in API_CONFIGS")
        return pd.DataFrame()
    
    print(f" Fetching from {api} API...")
    
    # Example for balldontlie API
    if api == 'balldontlie':
        url = f"{config['base_url']}/stats"
        params = {
            'dates[]': date,
            'per_page': 100
        }
        headers = {
            'Authorization': config['key']
        }
        
        try:
            response = requests.get(url, params=params, headers=headers)
            response.raise_for_status()
            
            data = response.json()
            
            # Parse response
            # This is API-specific, adjust as needed
            game_logs = []
            
            for stat in data.get('data', []):
                game_logs.append({
                    'player_name': stat['player']['name'],
                    'team_abbr': stat['team']['abbreviation'],
                    'game_date': date,
                    'minutes': stat.get('min', 0),
                    'points': stat.get('pts', 0),
                    'rebounds': stat.get('reb', 0),
                    'assists': stat.get('ast', 0),
                    'steals': stat.get('stl', 0),
                    'blocks': stat.get('blk', 0),
                    'turnovers': stat.get('to', 0),
                    'fg_made': stat.get('fgm', 0),
                    'fg_attempts': stat.get('fga', 0),
                    'three_made': stat.get('fg3m', 0),
                    'three_attempts': stat.get('fg3a', 0),
                    'ft_made': stat.get('ftm', 0),
                    'ft_attempts': stat.get('fta', 0),
                })
            
            df = pd.DataFrame(game_logs)
            
            # Calculate FD points
            if not df.empty:
                df['fd_points'] = (
                    df['points'] +
                    df['rebounds'] * 1.2 +
                    df['assists'] * 1.5 +
                    df['steals'] * 3 +
                    df['blocks'] * 3 -
                    df['turnovers']
                )
            
            return df
        
        except Exception as e:
            print(f"[ERROR] API error: {e}")
            return pd.DataFrame()
    
    return pd.DataFrame()

def calculate_fd_points(df: pd.DataFrame) -> pd.DataFrame:
    """Calculate FanDuel points from box score stats"""
    
    if 'fd_points' in df.columns:
        return df
    
    # FanDuel scoring:
    # Points: 1
    # Rebounds: 1.2
    # Assists: 1.5
    # Steals: 3
    # Blocks: 3
    # Turnovers: -1
    
    df['fd_points'] = (
        df['points'] +
        df['rebounds'] * 1.2 +
        df['assists'] * 1.5 +
        df['steals'] * 3 +
        df['blocks'] * 3 -
        df['turnovers']
    )
    
    return df

def insert_game_logs(con: duckdb.DuckDBPyConnection, df: pd.DataFrame, season: str):
    """Insert game logs into DuckDB"""
    
    if df.empty:
        print("[WARNING]  No data to insert")
        return 0
    
    # Add season
    df['season'] = season
    
    # Required columns
    required_cols = [
        'player_name', 'team_abbr', 'game_date', 'season',
        'minutes', 'points', 'rebounds', 'assists',
        'steals', 'blocks', 'turnovers', 'fd_points'
    ]
    
    # Check columns
    missing = [col for col in required_cols if col not in df.columns]
    if missing:
        print(f"[WARNING]  Missing columns: {missing}")
        return 0
    
    # Clean data
    df = df[required_cols].copy()
    df = df.dropna(subset=['player_name', 'game_date'])
    
    # Convert types
    df['minutes'] = pd.to_numeric(df['minutes'], errors='coerce').fillna(0)
    df['fd_points'] = pd.to_numeric(df['fd_points'], errors='coerce').fillna(0)
    
    # Insert
    try:
        # Create table if not exists
        con.execute("""
        CREATE TABLE IF NOT EXISTS nba_player_game_logs (
            player_id VARCHAR,
            player_name VARCHAR,
            team_abbr VARCHAR,
            opp_abbr VARCHAR,
            game_date DATE,
            season VARCHAR,
            is_home BOOLEAN,
            minutes FLOAT,
            points INTEGER,
            rebounds FLOAT,
            assists FLOAT,
            steals FLOAT,
            blocks FLOAT,
            turnovers FLOAT,
            fg_made INTEGER,
            fg_attempts INTEGER,
            three_made INTEGER,
            three_attempts INTEGER,
            ft_made INTEGER,
            ft_attempts INTEGER,
            fd_points FLOAT,
            PRIMARY KEY (player_name, team_abbr, game_date, season)
        )
        """)
        
        # Insert data
        con.execute("""
        INSERT OR REPLACE INTO nba_player_game_logs
        SELECT * FROM df
        """)
        
        rows_inserted = len(df)
        print(f"[OK] Inserted {rows_inserted} game logs")
        
        return rows_inserted
    
    except Exception as e:
        print(f"[ERROR] Insert error: {e}")
        return 0

def find_missing_dates(con: duckdb.DuckDBPyConnection, 
                       start_date: str, 
                       end_date: str) -> list:
    """Find dates with no game logs"""
    
    query = """
    SELECT DISTINCT game_date 
    FROM nba_player_game_logs
    WHERE game_date BETWEEN ? AND ?
    ORDER BY game_date
    """
    
    existing_dates = con.execute(query, [start_date, end_date]).df()
    
    # Generate all dates in range
    start = datetime.strptime(start_date, '%Y-%m-%d')
    end = datetime.strptime(end_date, '%Y-%m-%d')
    
    all_dates = []
    current = start
    while current <= end:
        all_dates.append(current.strftime('%Y-%m-%d'))
        current += timedelta(days=1)
    
    # Find missing
    existing = set(existing_dates['game_date'].astype(str).tolist())
    missing = [d for d in all_dates if d not in existing]
    
    return missing

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default="data/dfs_warehouse.duckdb",
                   help="Path to DuckDB database")
    ap.add_argument("--date", help="Specific date (YYYY-MM-DD or 'yesterday')")
    ap.add_argument("--start", help="Start date for range")
    ap.add_argument("--end", help="End date for range")
    ap.add_argument("--auto", action="store_true",
                   help="Auto-find missing dates")
    ap.add_argument("--season", default="2024-25",
                   help="NBA season")
    ap.add_argument("--source", default="csv",
                   choices=['csv', 'balldontlie', 'sportsdata'],
                   help="Data source")
    args = ap.parse_args()
    
    # Connect to database
    db_path = Path(args.db)
    db_path.parent.mkdir(exist_ok=True, parents=True)
    
    print(f"\n Database: {db_path}")
    con = duckdb.connect(str(db_path))
    
    # Determine dates to update
    dates_to_update = []
    
    if args.date:
        if args.date == 'yesterday':
            date = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
        else:
            date = args.date
        dates_to_update = [date]
    
    elif args.start and args.end:
        # Find missing in range
        missing = find_missing_dates(con, args.start, args.end)
        dates_to_update = missing
    
    elif args.auto:
        # Auto-detect missing
        # Look back 7 days
        end_date = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
        start_date = (datetime.now() - timedelta(days=7)).strftime('%Y-%m-%d')
        
        missing = find_missing_dates(con, start_date, end_date)
        dates_to_update = missing
    
    else:
        print("[ERROR] Specify --date, --start/--end, or --auto")
        return
    
    if not dates_to_update:
        print("[OK] No missing dates found - database is up to date!")
        return
    
    print(f"\n Updating {len(dates_to_update)} dates:")
    for d in dates_to_update:
        print(f"   - {d}")
    
    # Update each date
    total_inserted = 0
    
    for date in dates_to_update:
        print(f"\n{'='*80}")
        print(f"Processing: {date}")
        print(f"{'='*80}")
        
        # Get game logs
        if args.source == 'csv':
            df = get_game_logs_csv(date)
        else:
            df = get_game_logs_api(date, args.source)
        
        if df.empty:
            print(f"[WARNING]  No data for {date}")
            continue
        
        # Calculate FD points
        df = calculate_fd_points(df)
        
        # Insert
        inserted = insert_game_logs(con, df, args.season)
        total_inserted += inserted
        
        # Rate limit
        if args.source != 'csv':
            time.sleep(1)  # Be nice to APIs
    
    con.close()
    
    print(f"\n{'='*80}")
    print(f"[OK] UPDATE COMPLETE!")
    print(f"{'='*80}")
    print(f"\nTotal game logs inserted: {total_inserted}")
    print(f"Dates updated: {len(dates_to_update)}")
    
    print(f"\n[TIP] TIP:")
    print(f"   Run this daily to keep your injury analysis smart:")
    print(f"   python update_duckdb.py --date yesterday")
    
    print(f"\n{'='*80}")

if __name__ == "__main__":
    main()
