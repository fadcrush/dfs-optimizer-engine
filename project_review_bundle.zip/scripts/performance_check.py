"""
scripts/performance_check.py — Pipeline performance benchmark.

Measures wall-clock time for each stage of the DFS workflow:
  1. CSV ingestion           (POST /api/projections/upload-slate-to-db)
  2. Ownership ingestion     (POST /api/ownership/upload-to-db)
  3. Run creation + inline   (POST /api/runs  async_mode=false)
  4. Lineups fetch           (GET /api/results/{run_id}/lineups)
  5. Exposure query          (GET /api/results/{run_id}/exposure)

Usage:
    python scripts/performance_check.py [--base-url http://localhost:8000]
                                         [--num-lineups 20]
                                         [--timeout 180]
"""
from __future__ import annotations

import argparse
import io
import json
import sys
import time
from typing import Any, Dict, Optional

try:
    import httpx

    def _post_json(url, payload, timeout=30):
        r = httpx.post(url, json=payload, timeout=timeout)
        r.raise_for_status()
        return r.json()

    def _post_file(url, field, filename, content, params=None, timeout=30):
        files = {field: (filename, io.BytesIO(content), "text/csv")}
        r = httpx.post(url, files=files, params=params or {}, timeout=timeout)
        r.raise_for_status()
        return r.json()

    def _get_json(url, timeout=30):
        r = httpx.get(url, timeout=timeout)
        r.raise_for_status()
        return r.json()

except ImportError:
    import urllib.request, urllib.parse

    def _post_json(url, payload, timeout=30):
        data = json.dumps(payload).encode()
        req = urllib.request.Request(url, data=data,
                                     headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read())

    def _post_file(url, field, filename, content, params=None, timeout=30):
        boundary = "----PerfBoundary"
        body = (f"--{boundary}\r\nContent-Disposition: form-data; "
                f'name="{field}"; filename="{filename}"\r\nContent-Type: text/csv\r\n\r\n').encode()
        body += content + f"\r\n--{boundary}--\r\n".encode()
        if params:
            url = f"{url}?{urllib.parse.urlencode(params)}"
        req = urllib.request.Request(url, data=body,
                                     headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
                                     method="POST")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read())

    def _get_json(url, timeout=30):
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            return json.loads(resp.read())


# ---------------------------------------------------------------------------
# Inline test slate (10 FD NBA players)
# ---------------------------------------------------------------------------

_PROJ_CSV = b"""\
Nickname,Position,FPPG,Id,Salary,Team,Game,Opponent,Injury Indicator
LeBron James,SF,48.2,1001,9800,LAL,LAL@GSW,GSW,
Stephen Curry,PG,44.1,1002,9600,GSW,LAL@GSW,LAL,
Anthony Davis,C,42.7,1003,9400,LAL,LAL@GSW,GSW,
Klay Thompson,SG,33.5,1004,7200,GSW,LAL@GSW,LAL,
Draymond Green,PF,31.8,1005,7000,GSW,LAL@GSW,LAL,
Austin Reaves,SG,28.4,1006,6200,LAL,LAL@GSW,GSW,
D'Angelo Russell,PG,27.9,1007,6000,LAL,LAL@GSW,GSW,
Kevon Looney,C,22.1,1008,4800,GSW,LAL@GSW,LAL,
Rui Hachimura,PF,20.5,1009,4600,LAL,LAL@GSW,GSW,
Gui Santos,SF,18.3,1010,3500,GSW,LAL@GSW,LAL,
"""

_OWN_CSV = b"""\
Player,Own%
LeBron James,32.5
Stephen Curry,28.4
Anthony Davis,25.1
Klay Thompson,18.7
Draymond Green,15.3
Austin Reaves,12.8
D'Angelo Russell,11.4
Kevon Looney,8.2
Rui Hachimura,7.9
Gui Santos,5.1
"""


def _timed(label: str, fn) -> tuple[Any, float]:
    t0 = time.perf_counter()
    result = fn()
    elapsed = (time.perf_counter() - t0) * 1000  # ms
    return result, elapsed


THRESHOLDS_MS = {
    "ingestion": 3_000,
    "ownership": 2_000,
    "optimizer": 60_000,
    "lineups": 1_000,
    "exposure": 1_000,
}

WIDTH = 28


def _row(label, ms, threshold_ms):
    status = "✓" if ms <= threshold_ms else "✗"
    bar = "█" * min(int(ms / (threshold_ms / 20)), 40)
    return f"  {status}  {label:<{WIDTH}}  {ms:>8.1f} ms   (limit {threshold_ms:>6} ms)  {bar}"


def main() -> int:
    parser = argparse.ArgumentParser(description="DFS Edge Pro performance checker")
    parser.add_argument("--base-url", default="http://localhost:8000")
    parser.add_argument("--num-lineups", type=int, default=10)
    parser.add_argument("--timeout", type=float, default=180.0)
    args = parser.parse_args()

    base = args.base_url.rstrip("/")

    print(f"\n{'='*70}")
    print("  DFS EDGE PRO — PERFORMANCE BENCHMARK")
    print(f"  Target: {base}  |  lineups: {args.num_lineups}")
    print(f"{'='*70}\n")

    timings: Dict[str, float] = {}
    failures = []

    # ── Pre-flight ──────────────────────────────────────────────────────────
    try:
        _get_json(f"{base}/api/health", timeout=5)
    except Exception as e:
        print(f"  ✗  Server not reachable: {e}")
        return 1

    # ── 1  Projection ingestion ─────────────────────────────────────────────
    print("  Benchmarking projections upload...")
    resp, ms = _timed("ingestion", lambda: _post_file(
        f"{base}/api/projections/upload-slate-to-db",
        "file", "perf_test.csv", _PROJ_CSV, timeout=args.timeout,
    ))
    timings["ingestion"] = ms
    slate_id = resp.get("slate_id")
    if not slate_id:
        print("  ✗  No slate_id returned — aborting")
        return 1

    # ── 2  Ownership ingestion ──────────────────────────────────────────────
    print("  Benchmarking ownership upload...")
    _, ms = _timed("ownership", lambda: _post_file(
        f"{base}/api/ownership/upload-to-db",
        "file", "perf_own.csv", _OWN_CSV,
        params={"slate_id": slate_id}, timeout=args.timeout,
    ))
    timings["ownership"] = ms

    # ── 3  Optimizer (inline) ───────────────────────────────────────────────
    print(f"  Running optimizer for {args.num_lineups} lineups (inline)...")
    payload = {
        "slate_id": slate_id,
        "num_lineups": args.num_lineups,
        "platform": "fanduel",
        "contest_type": "small_gpp",
        "max_exposure": 0.9,
        "min_salary": 49000,
        "max_salary": 60000,
        "async_mode": False,
    }
    try:
        resp_run, ms = _timed("optimizer", lambda: _post_json(
            f"{base}/api/runs", payload, timeout=args.timeout,
        ))
        timings["optimizer"] = ms
        run_id = resp_run.get("run_id")
    except Exception as e:
        print(f"  ✗  Optimizer failed: {e}")
        failures.append(f"optimizer: {e}")
        run_id = None

    if not run_id:
        _report(timings, failures)
        return 1

    # ── 4  Lineups fetch ─────────────────────────────────────────────────────
    _, ms = _timed("lineups", lambda: _get_json(
        f"{base}/api/results/{run_id}/lineups", timeout=args.timeout,
    ))
    timings["lineups"] = ms

    # ── 5  Exposure fetch ────────────────────────────────────────────────────
    _, ms = _timed("exposure", lambda: _get_json(
        f"{base}/api/results/{run_id}/exposure", timeout=args.timeout,
    ))
    timings["exposure"] = ms

    return _report(timings, failures)


def _report(timings, failures) -> int:
    print(f"\n  {'─'*66}")
    print(f"  {'STAGE':<{WIDTH}}  {'TIME':>12}   {'LIMIT':>12}  USAGE")
    print(f"  {'─'*66}")
    all_ok = True
    for key, threshold in THRESHOLDS_MS.items():
        if key in timings:
            ms = timings[key]
            line = _row(key, ms, threshold)
            print(line)
            if ms > threshold:
                all_ok = False
    print(f"  {'─'*66}")

    if failures:
        print(f"\n  ERRORS:")
        for f in failures:
            print(f"    • {f}")
        all_ok = False

    total = sum(timings.values())
    print(f"\n  Total wall time: {total:.1f} ms")

    if all_ok:
        print(f"\n  ✓  All stages within thresholds\n")
        return 0
    else:
        print(f"\n  ✗  One or more stages exceeded threshold\n")
        return 1


if __name__ == "__main__":
    sys.exit(main())
