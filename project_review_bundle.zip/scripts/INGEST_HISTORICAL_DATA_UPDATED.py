#!/usr/bin/env python
"""
INGEST_HISTORICAL_DATA_UPDATED.py

Updated version that handles BOTH CSV and XLSX files.
Ingests all historical DFS data from your folders.
"""

import duckdb
import pandas as pd
from pathlib import Path
from datetime import datetime

print("="*80)
print("HISTORICAL DATA INGESTION SYSTEM (CSV + XLSX)")
print("="*80)

# Configuration
DB_PATH = 'data/dfs_warehouse.duckdb'
DATA_DIRS = {
    'DK_NBA': Path('DK_NBA_Past_Games'),
    'DK_NFL': Path('DK_NFL_Past_Games'),
    'FD_NBA': Path('FD_NBA_Past_Games'),
    'FD_NFL': Path('FD_NFL_Past_Games'),
}

# Install openpyxl if needed
try:
    import openpyxl
except ImportError:
    print("\n[INFO] Installing openpyxl for Excel support...")
    import subprocess
    subprocess.run(['pip', 'install', 'openpyxl'], check=True)
    import openpyxl

# Connect to DuckDB
print(f"\nConnecting to: {DB_PATH}")
conn = duckdb.connect(DB_PATH)

# Create schema
print("\nCreating database schema...")

conn.execute("""
CREATE TABLE IF NOT EXISTS historical_results (
    result_id INTEGER PRIMARY KEY,
    game_date DATE NOT NULL,
    player_name VARCHAR NOT NULL,
    player_id VARCHAR,
    platform VARCHAR NOT NULL,
    sport VARCHAR NOT NULL,
    team VARCHAR,
    opponent VARCHAR,
    home_away VARCHAR,
    salary INTEGER,
    position VARCHAR,
    fantasy_points FLOAT NOT NULL,
    minutes_played FLOAT,
    points INTEGER,
    rebounds INTEGER,
    assists INTEGER,
    steals INTEGER,
    blocks INTEGER,
    turnovers INTEGER,
    passing_yards FLOAT,
    passing_tds INTEGER,
    rushing_yards FLOAT,
    rushing_tds INTEGER,
    receptions INTEGER,
    receiving_yards FLOAT,
    receiving_tds INTEGER,
    loaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    source_file VARCHAR
);
""")

print("  [OK] Schema created")

# Helper functions
def is_lineup_file(filename):
    """Check if file is a lineup export (not historical data)"""
    lower = filename.lower()
    return 'lineup' in lower or 'entries' in lower

def read_file(file_path):
    """Read CSV or XLSX file"""
    if file_path.suffix == '.xlsx':
        return pd.read_excel(file_path)
    else:
        return pd.read_csv(file_path)

def standardize_dk_nba(df, source_file):
    """Standardize DraftKings NBA data"""
    standard = pd.DataFrame()
    
    # Handle different column names
    standard['player_name'] = df.get('Name', df.get('Player', df.get('Nickname', None)))
    standard['player_id'] = df.get('ID', df.get('Id', None))
    standard['team'] = df.get('TeamAbbrev', df.get('Team', None))
    standard['opponent'] = df.get('Opp', df.get('OpponentAbbrev', df.get('Opponent', None)))
    standard['salary'] = df.get('Salary', None)
    standard['position'] = df.get('Pos', df.get('Position', None))
    
    # Fantasy points - try multiple column names
    for col in ['DraftKings points', 'FPTS', 'FantasyPoints', 'Fantasy Points', 'FP']:
        if col in df.columns:
            standard['fantasy_points'] = df[col]
            break
    
    # Stats
    standard['minutes_played'] = df.get('Minutes', df.get('MIN', None))
    standard['points'] = df.get('Points', df.get('PTS', None))
    standard['rebounds'] = df.get('Rebounds', df.get('REB', None))
    standard['assists'] = df.get('Assists', df.get('AST', None))
    standard['steals'] = df.get('Steals', df.get('STL', None))
    standard['blocks'] = df.get('Blocks', df.get('BLK', None))
    standard['turnovers'] = df.get('Turnovers', df.get('TO', None))
    
    # Extract date from filename
    # Format: NBA_2025-11-13-700pm_DK_Main.csv
    try:
        date_str = source_file.split('_')[1]  # 2025-11-13-700pm
        game_date = date_str.split('-')[:3]  # [2025, 11, 13]
        standard['game_date'] = '-'.join(game_date)
    except:
        standard['game_date'] = None
    
    standard['platform'] = 'DraftKings'
    standard['sport'] = 'NBA'
    standard['source_file'] = source_file
    
    return standard

def standardize_fd_nba(df, source_file):
    """Standardize FanDuel NBA data"""
    standard = pd.DataFrame()
    
    standard['player_name'] = df.get('Nickname', df.get('Player', df.get('Name', None)))
    standard['player_id'] = df.get('Id', df.get('ID', None))
    standard['team'] = df.get('Team', None)
    standard['opponent'] = df.get('Opponent', df.get('Opp', None))
    standard['salary'] = df.get('Salary', None)
    standard['position'] = df.get('Position', df.get('Pos', None))
    
    # Fantasy points
    for col in ['FD points', 'FPTS', 'FantasyPoints', 'Fantasy Points', 'FP']:
        if col in df.columns:
            standard['fantasy_points'] = df[col]
            break
    
    # Stats
    standard['minutes_played'] = df.get('Minutes', df.get('MIN', None))
    standard['points'] = df.get('Points', df.get('PTS', None))
    standard['rebounds'] = df.get('Rebounds', df.get('REB', None))
    standard['assists'] = df.get('Assists', df.get('AST', None))
    standard['steals'] = df.get('Steals', df.get('STL', None))
    standard['blocks'] = df.get('Blocks', df.get('BLK', None))
    standard['turnovers'] = df.get('Turnovers', df.get('TO', None))
    
    # Extract date
    try:
        date_str = source_file.split('_')[1]
        game_date = date_str.split('-')[:3]
        standard['game_date'] = '-'.join(game_date)
    except:
        standard['game_date'] = None
    
    standard['platform'] = 'FanDuel'
    standard['sport'] = 'NBA'
    standard['source_file'] = source_file
    
    return standard

def standardize_nfl(df, source_file, platform):
    """Standardize NFL data"""
    standard = pd.DataFrame()
    
    if platform == 'DraftKings':
        standard['player_name'] = df.get('Name', df.get('Player', None))
    else:
        standard['player_name'] = df.get('Nickname', df.get('Name', df.get('Player', None)))
    
    standard['player_id'] = df.get('Id', df.get('ID', None))
    standard['team'] = df.get('Team', df.get('TeamAbbrev', None))
    standard['opponent'] = df.get('Opponent', df.get('Opp', df.get('OpponentAbbrev', None)))
    standard['salary'] = df.get('Salary', None)
    standard['position'] = df.get('Position', df.get('Pos', None))
    
    # Fantasy points
    for col in ['DraftKings points', 'FD points', 'FPTS', 'FantasyPoints', 'Fantasy Points', 'FP']:
        if col in df.columns:
            standard['fantasy_points'] = df[col]
            break
    
    # NFL stats
    standard['passing_yards'] = df.get('PassYds', df.get('Passing Yards', None))
    standard['passing_tds'] = df.get('PassTD', df.get('Passing TDs', None))
    standard['rushing_yards'] = df.get('RushYds', df.get('Rushing Yards', None))
    standard['rushing_tds'] = df.get('RushTD', df.get('Rushing TDs', None))
    standard['receptions'] = df.get('Rec', df.get('Receptions', None))
    standard['receiving_yards'] = df.get('RecYds', df.get('Receiving Yards', None))
    standard['receiving_tds'] = df.get('RecTD', df.get('Receiving TDs', None))
    
    # Extract date
    try:
        if 'week' in source_file.lower():
            # NFL_2025-09-04_week1.csv
            date_str = source_file.split('_')[1]
            standard['game_date'] = date_str
        else:
            date_str = source_file.split('_')[1]
            game_date = date_str.split('-')[:3]
            standard['game_date'] = '-'.join(game_date)
    except:
        standard['game_date'] = None
    
    standard['platform'] = platform
    standard['sport'] = 'NFL'
    standard['source_file'] = source_file
    
    return standard

def ingest_directory(directory, platform, sport):
    """Ingest all CSV and XLSX files from directory"""
    
    if not directory.exists():
        print(f"\n  [WARNING] Directory not found: {directory}")
        return 0
    
    # Get both CSV and XLSX files
    csv_files = list(directory.glob('*.csv'))
    xlsx_files = list(directory.glob('*.xlsx'))
    all_files = csv_files + xlsx_files
    
    # Filter out lineup files
    data_files = [f for f in all_files if not is_lineup_file(f.name)]
    
    if not data_files:
        print(f"\n  [WARNING] No data files in: {directory}")
        return 0
    
    print(f"\n  Processing {len(data_files)} files from {directory.name}...")
    
    total_rows = 0
    success_count = 0
    skip_count = 0
    
    for file_path in data_files:
        try:
            print(f"    - {file_path.name}...", end=' ')
            
            # Read file
            df = read_file(file_path)
            
            # Standardize
            if platform == 'DraftKings' and sport == 'NBA':
                standard = standardize_dk_nba(df, file_path.name)
            elif platform == 'FanDuel' and sport == 'NBA':
                standard = standardize_fd_nba(df, file_path.name)
            elif sport == 'NFL':
                standard = standardize_nfl(df, file_path.name, platform)
            else:
                print("SKIPPED (unknown format)")
                skip_count += 1
                continue
            
            # Filter valid rows
            standard = standard[standard['fantasy_points'].notna()]
            standard = standard[standard['player_name'].notna()]
            
            if len(standard) == 0:
                print("SKIPPED (no valid data)")
                skip_count += 1
                continue
            
            # Insert into DuckDB
            conn.execute("""
                INSERT INTO historical_results 
                SELECT NULL as result_id, * FROM standard
            """)
            
            total_rows += len(standard)
            success_count += 1
            print(f"OK ({len(standard)} rows)")
            
        except Exception as e:
            print(f"ERROR: {str(e)[:50]}")
            skip_count += 1
            continue
    
    print(f"\n  Successfully loaded: {success_count} files")
    print(f"  Skipped: {skip_count} files")
    
    return total_rows

# Main ingestion
print("\n" + "="*80)
print("INGESTING HISTORICAL DATA")
print("="*80)

total_ingested = 0

for key, directory in DATA_DIRS.items():
    platform, sport = key.split('_')
    
    if platform == 'DK':
        platform = 'DraftKings'
    else:
        platform = 'FanDuel'
    
    print(f"\n{platform} {sport}")
    print("-" * 40)
    
    rows = ingest_directory(directory, platform, sport)
    total_ingested += rows
    
    print(f"  Total rows ingested: {rows:,}")

# Summary
print("\n" + "="*80)
print("INGESTION COMPLETE!")
print("="*80)

print(f"\nTotal rows ingested: {total_ingested:,}")

if total_ingested > 0:
    summary = conn.execute("""
        SELECT 
            platform,
            sport,
            COUNT(*) as num_rows,
            COUNT(DISTINCT player_name) as num_players,
            COUNT(DISTINCT game_date) as num_dates,
            MIN(game_date) as earliest_date,
            MAX(game_date) as latest_date,
            ROUND(AVG(fantasy_points), 1) as avg_fpts
        FROM historical_results
        GROUP BY platform, sport
        ORDER BY platform, sport
    """).fetchdf()
    
    print("\nDatabase Summary:")
    print(summary.to_string(index=False))
else:
    print("\n[WARNING] No data was loaded!")
    print("Check that your files have the expected columns")

conn.close()

print(f"\n{'='*80}")
print("READY FOR ANALYSIS!")
print(f"{'='*80}")

if total_ingested > 0:
    print("\nNext steps:")
    print("  1. Run: python DISCOVER_PATTERNS.py")
    print("  2. Run: python ANALYZE_PROJECTION_ACCURACY.py")
else:
    print("\nTroubleshooting:")
    print("  - Make sure files contain actual game results")
    print("  - Check that columns include fantasy points")
    print("  - Files should have player names and stats")

print(f"\n{'='*80}")
