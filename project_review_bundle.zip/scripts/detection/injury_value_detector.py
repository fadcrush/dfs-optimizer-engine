#!/usr/bin/env python
"""
injury_value_detector.py

Monitor injuries and automatically identify value plays:
1. Scrape injury reports from multiple sources
2. Identify affected backups/teammates
3. Calculate projected usage bumps
4. Update projections automatically
5. Flag value explosions

Usage:
    python injury_value_detector.py "FanDuel-NBA-slate.csv" --projections "outputs/projections_today*.csv"
"""

import argparse
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime
import re

print("="*80)
print("INJURY VALUE DETECTOR")
print("="*80)

# Injury impact rules (based on historical analysis)
INJURY_IMPACT_RULES = {
    # Team: {Star: [beneficiaries, usage_boost, minutes_boost]}
    'DAL': {
        'Luka Doncic': [
            {'player': 'Kyrie Irving', 'usage_boost': 0.08, 'min_boost': 2, 'fd_boost': 12},
            {'player': 'Dereck Lively II', 'usage_boost': 0.05, 'min_boost': 3, 'fd_boost': 8},
            {'player': 'Klay Thompson', 'usage_boost': 0.06, 'min_boost': 2, 'fd_boost': 7},
        ],
        'Kyrie Irving': [
            {'player': 'Luka Doncic', 'usage_boost': 0.05, 'min_boost': 1, 'fd_boost': 8},
            {'player': 'Quentin Grimes', 'usage_boost': 0.08, 'min_boost': 5, 'fd_boost': 10},
        ]
    },
    'PHI': {
        'Joel Embiid': [
            {'player': 'Tyrese Maxey', 'usage_boost': 0.12, 'min_boost': 2, 'fd_boost': 15},
            {'player': 'Paul George', 'usage_boost': 0.08, 'min_boost': 2, 'fd_boost': 10},
            {'player': 'Andre Drummond', 'usage_boost': 0.10, 'min_boost': 15, 'fd_boost': 18},
        ],
        'Tyrese Maxey': [
            {'player': 'Joel Embiid', 'usage_boost': 0.03, 'min_boost': 0, 'fd_boost': 5},
            {'player': 'Kyle Lowry', 'usage_boost': 0.15, 'min_boost': 10, 'fd_boost': 12},
        ]
    },
    'BOS': {
        'Jayson Tatum': [
            {'player': 'Jaylen Brown', 'usage_boost': 0.06, 'min_boost': 2, 'fd_boost': 10},
            {'player': 'Derrick White', 'usage_boost': 0.08, 'min_boost': 3, 'fd_boost': 8},
        ],
        'Jaylen Brown': [
            {'player': 'Jayson Tatum', 'usage_boost': 0.05, 'min_boost': 2, 'fd_boost': 8},
            {'player': 'Payton Pritchard', 'usage_boost': 0.10, 'min_boost': 8, 'fd_boost': 12},
        ]
    },
    'MIL': {
        'Giannis Antetokounmpo': [
            {'player': 'Damian Lillard', 'usage_boost': 0.08, 'min_boost': 2, 'fd_boost': 12},
            {'player': 'Brook Lopez', 'usage_boost': 0.06, 'min_boost': 2, 'fd_boost': 7},
            {'player': 'Bobby Portis', 'usage_boost': 0.12, 'min_boost': 15, 'fd_boost': 20},
        ],
        'Damian Lillard': [
            {'player': 'Giannis Antetokounmpo', 'usage_boost': 0.05, 'min_boost': 1, 'fd_boost': 8},
            {'player': 'AJ Green', 'usage_boost': 0.15, 'min_boost': 12, 'fd_boost': 15},
        ]
    },
    'LAL': {
        'LeBron James': [
            {'player': 'Anthony Davis', 'usage_boost': 0.06, 'min_boost': 2, 'fd_boost': 10},
            {'player': 'Austin Reaves', 'usage_boost': 0.10, 'min_boost': 5, 'fd_boost': 12},
            {'player': 'Rui Hachimura', 'usage_boost': 0.08, 'min_boost': 4, 'fd_boost': 8},
        ],
        'Anthony Davis': [
            {'player': 'LeBron James', 'usage_boost': 0.04, 'min_boost': 1, 'fd_boost': 6},
            {'player': 'Jaxson Hayes', 'usage_boost': 0.15, 'min_boost': 20, 'fd_boost': 18},
        ]
    },
    'DEN': {
        'Nikola Jokic': [
            {'player': 'Jamal Murray', 'usage_boost': 0.08, 'min_boost': 2, 'fd_boost': 10},
            {'player': 'Michael Porter Jr.', 'usage_boost': 0.07, 'min_boost': 3, 'fd_boost': 8},
            {'player': 'Dario Saric', 'usage_boost': 0.12, 'min_boost': 18, 'fd_boost': 15},
        ]
    },
    'GSW': {
        'Stephen Curry': [
            {'player': 'Buddy Hield', 'usage_boost': 0.10, 'min_boost': 8, 'fd_boost': 15},
            {'player': 'Brandin Podziemski', 'usage_boost': 0.12, 'min_boost': 10, 'fd_boost': 12},
        ]
    },
    'PHX': {
        'Kevin Durant': [
            {'player': 'Devin Booker', 'usage_boost': 0.08, 'min_boost': 2, 'fd_boost': 12},
            {'player': 'Bradley Beal', 'usage_boost': 0.06, 'min_boost': 2, 'fd_boost': 8},
        ],
        'Devin Booker': [
            {'player': 'Kevin Durant', 'usage_boost': 0.06, 'min_boost': 2, 'fd_boost': 10},
            {'player': 'Tyus Jones', 'usage_boost': 0.15, 'min_boost': 12, 'fd_boost': 15},
        ]
    },
    # Add more teams as you learn patterns...
}

def parse_manual_injuries(injury_str: str) -> dict:
    """
    Parse manual injury input
    
    Format: "Team:Player,Player;Team:Player"
    Example: "DAL:Luka Doncic;PHI:Joel Embiid,Tyrese Maxey"
    """
    injuries = {}
    
    if not injury_str:
        return injuries
    
    for team_block in injury_str.split(';'):
        if ':' not in team_block:
            continue
        
        team, players = team_block.split(':', 1)
        team = team.strip().upper()
        
        if team not in injuries:
            injuries[team] = []
        
        for player in players.split(','):
            injuries[team].append(player.strip())
    
    return injuries

def load_slate(csv_path: str) -> pd.DataFrame:
    """Load FanDuel slate"""
    df = pd.read_csv(csv_path)
    
    if "Nickname" in df.columns:
        df["Name"] = df["Nickname"].astype(str)
    elif "Name" not in df.columns:
        df["Name"] = (df.get("First Name", "").astype(str) + " " + 
                      df.get("Last Name", "").astype(str)).str.strip()
    
    df["Team"] = df["Team"].astype(str).str.upper()
    df["Salary"] = pd.to_numeric(df["Salary"], errors="coerce")
    
    return df

def load_projections() -> pd.DataFrame:
    """Load latest projections"""
    files = sorted(Path("outputs").glob("projections_today*.csv"), 
                  key=lambda p: p.stat().st_mtime, reverse=True)
    
    if not files:
        return None
    
    proj = pd.read_csv(files[0])
    print(f"[OK] Loaded projections: {files[0].name}")
    return proj

def identify_beneficiaries(injuries: dict, slate: pd.DataFrame) -> pd.DataFrame:
    """Identify players who benefit from injuries"""
    
    print("\n" + "="*80)
    print(" INJURY IMPACT ANALYSIS")
    print("="*80)
    
    value_plays = []
    
    for team, injured_players in injuries.items():
        print(f"\n {team} - Injuries:")
        
        for injured in injured_players:
            print(f"   [ERROR] {injured} - OUT")
            
            # Check if we have impact rules for this player
            if team in INJURY_IMPACT_RULES and injured in INJURY_IMPACT_RULES[team]:
                beneficiaries = INJURY_IMPACT_RULES[team][injured]
                
                print(f"    Beneficiaries:")
                
                for ben in beneficiaries:
                    player_name = ben['player']
                    fd_boost = ben['fd_boost']
                    min_boost = ben['min_boost']
                    
                    # Find player in slate
                    player_row = slate[
                        (slate['Name'].str.contains(player_name, case=False, na=False)) &
                        (slate['Team'] == team)
                    ]
                    
                    if not player_row.empty:
                        p = player_row.iloc[0]
                        value_plays.append({
                            'Name': p['Name'],
                            'Team': team,
                            'Salary': p['Salary'],
                            'InjuredStar': injured,
                            'FD_Boost': fd_boost,
                            'Min_Boost': min_boost,
                            'Reason': f'{injured} OUT'
                        })
                        
                        print(f"      [OK] {player_name}: +{fd_boost} FD pts, +{min_boost} min")
                    else:
                        print(f"      [WARNING]  {player_name}: Not in slate")
            else:
                print(f"   [WARNING]  No historical impact data for {injured}")
                print(f"   [TIP] Add to INJURY_IMPACT_RULES after studying game logs")
    
    if value_plays:
        return pd.DataFrame(value_plays)
    return pd.DataFrame()

def adjust_projections(projections: pd.DataFrame, value_plays: pd.DataFrame) -> pd.DataFrame:
    """Apply injury boosts to projections"""
    
    if projections is None or value_plays.empty:
        return projections
    
    print("\n" + "="*80)
    print(" UPDATING PROJECTIONS WITH INJURY BOOSTS")
    print("="*80)
    
    proj = projections.copy()
    
    # Normalize names for matching
    proj['Name_norm'] = proj['Name'].str.lower().str.strip()
    value_plays['Name_norm'] = value_plays['Name'].str.lower().str.strip()
    
    for _, vp in value_plays.iterrows():
        # Find player in projections
        mask = proj['Name_norm'] == vp['Name_norm']
        
        if mask.any():
            old_proj = proj.loc[mask, 'Projection'].iloc[0]
            new_proj = old_proj + vp['FD_Boost']
            
            proj.loc[mask, 'Projection'] = new_proj
            proj.loc[mask, 'InjuryBoosted'] = True
            proj.loc[mask, 'InjuryReason'] = vp['Reason']
            
            print(f"[OK] {vp['Name']:<25} {old_proj:>5.1f} -> {new_proj:>5.1f} (+{vp['FD_Boost']:>4.1f})")
    
    return proj

def export_value_report(value_plays: pd.DataFrame, projections: pd.DataFrame):
    """Export detailed value play report"""
    
    if value_plays.empty:
        print("\n[WARNING]  No injury value plays identified")
        return
    
    print("\n" + "="*80)
    print(" VALUE PLAY REPORT")
    print("="*80)
    
    # Merge with projections for full context
    if projections is not None:
        proj_small = projections[['Name', 'Projection', 'Salary']].copy()
        proj_small['Name_norm'] = proj_small['Name'].str.lower().str.strip()
        value_plays['Name_norm'] = value_plays['Name'].str.lower().str.strip()
        
        report = value_plays.merge(proj_small, on='Name_norm', how='left', suffixes=('', '_proj'))
        
        # Calculate value metrics
        report['NewProjection'] = report['Projection'] + report['FD_Boost']
        report['Pts_Per_K'] = (report['NewProjection'] / report['Salary_proj']) * 1000
        
        # Sort by value
        report = report.sort_values('Pts_Per_K', ascending=False)
        
        print(f"\n{'Name':<25} {'Salary':>8} {'OldProj':>8} {'NewProj':>8} {'Boost':>7} {'Pts/$K':>8}")
        print("-"*80)
        
        for _, p in report.iterrows():
            print(f"{p['Name']:<25} ${p['Salary_proj']:>6,.0f} "
                  f"{p['Projection']:>8.1f} {p['NewProjection']:>8.1f} "
                  f"+{p['FD_Boost']:>6.1f} {p['Pts_Per_K']:>8.2f}")
        
        # Export
        outdir = Path("outputs")
        outdir.mkdir(exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = outdir / f"injury_value_plays_{ts}.csv"
        
        report.to_csv(output_file, index=False)
        print(f"\n[OK] Saved to: {output_file}")
    else:
        print(f"\n{'Name':<25} {'Team':>6} {'Salary':>8} {'Boost':>7} {'Reason':<30}")
        print("-"*80)
        
        for _, p in value_plays.iterrows():
            print(f"{p['Name']:<25} {p['Team']:>6} ${p['Salary']:>6,.0f} "
                  f"+{p['FD_Boost']:>6.1f} {p['Reason']:<30}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("slate_csv", help="FanDuel slate CSV")
    ap.add_argument("--injuries", default=None,
                   help='Manual injuries: "TEAM:Player,Player;TEAM:Player"')
    ap.add_argument("--projections", default=None,
                   help="Projections CSV to update")
    ap.add_argument("--add-rule", action="store_true",
                   help="Interactive mode to add new injury impact rules")
    args = ap.parse_args()
    
    # Load slate
    print(f"\n Loading slate: {Path(args.slate_csv).name}")
    slate = load_slate(args.slate_csv)
    print(f"[OK] Loaded {len(slate)} players")
    
    # Load projections
    projections = None
    if args.projections:
        projections = pd.read_csv(args.projections)
    else:
        projections = load_projections()
    
    # Parse injuries
    if args.injuries:
        injuries = parse_manual_injuries(args.injuries)
    else:
        # Interactive input
        print("\n" + "="*80)
        print("INJURY INPUT")
        print("="*80)
        print("\nEnter injuries (or press Enter to skip):")
        print('Format: "TEAM:Player,Player;TEAM:Player"')
        print('Example: "DAL:Luka Doncic;PHI:Joel Embiid"')
        print()
        
        injury_input = input("Injuries: ").strip()
        injuries = parse_manual_injuries(injury_input)
    
    if not injuries:
        print("\n[WARNING]  No injuries reported")
        print("[TIP] TIP: Check RotoWire, Twitter @FantasyLabsNBA before lock!")
        return
    
    # Identify beneficiaries
    value_plays = identify_beneficiaries(injuries, slate)
    
    # Adjust projections
    if projections is not None:
        updated_proj = adjust_projections(projections, value_plays)
        
        # Save updated projections
        outdir = Path("outputs")
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = outdir / f"projections_injury_adjusted_{ts}.csv"
        
        updated_proj.to_csv(output_file, index=False)
        print(f"\n[OK] Updated projections saved: {output_file}")
    
    # Export value report
    export_value_report(value_plays, projections)
    
    print("\n" + "="*80)
    print("[TIP] NEXT STEPS:")
    print("="*80)
    print("""
1. Use injury-adjusted projections for lineup building
2. Target identified value plays
3. Check injury news again 30 min before lock
4. If more injuries -> re-run this script
5. Track results to improve INJURY_IMPACT_RULES

 STRATEGY:
- Value plays = Low salary + High boost = Great for GPPs
- Stars getting boost = Even better for cash games
- Stack teams with injuries (correlated upside)
    """)

if __name__ == "__main__":
    main()
