#!/usr/bin/env python
"""
auto_injury_scanner.py

Automatically scan FanDuel slate for injuries and identify value plays.
Reads "Injury Indicator" column (O/P/Q) and finds high-value injury opportunities.

Usage:
    python auto_injury_scanner.py "FanDuel-NBA-slate.csv"
"""

import argparse
import pandas as pd
from pathlib import Path

print("="*80)
print("AUTO INJURY SCANNER - Find Value Plays from Injuries")
print("="*80)

def load_slate(csv_path: str) -> pd.DataFrame:
    """Load FanDuel slate"""
    df = pd.read_csv(csv_path)
    
    # Standardize columns
    if "Nickname" in df.columns:
        df["Name"] = df["Nickname"].astype(str)
    elif "Name" not in df.columns:
        df["Name"] = (df.get("First Name", "").astype(str) + " " + 
                      df.get("Last Name", "").astype(str)).str.strip()
    
    df["Team"] = df["Team"].astype(str).str.upper()
    df["Salary"] = pd.to_numeric(df["Salary"], errors="coerce")
    
    return df

def find_injured_stars(df: pd.DataFrame, min_salary: int = 8000) -> pd.DataFrame:
    """Find OUT players who are stars (high salary)"""
    
    # Check if Injury Indicator column exists
    injury_col = None
    for col in df.columns:
        if 'injury' in col.lower() and 'indicator' in col.lower():
            injury_col = col
            break
    
    if not injury_col:
        print("[ERROR] No 'Injury Indicator' column found in slate")
        print(f"Available columns: {', '.join(df.columns)}")
        return pd.DataFrame()
    
    # Find all OUT players
    out_players = df[df[injury_col].astype(str).str.upper() == 'O'].copy()
    
    if out_players.empty:
        print("[OK] No players listed as OUT")
        return out_players
    
    # Find stars (high salary)
    stars_out = out_players[out_players['Salary'] >= min_salary].copy()
    stars_out = stars_out.sort_values('Salary', ascending=False)
    
    return stars_out

def find_questionable_stars(df: pd.DataFrame, min_salary: int = 9000) -> pd.DataFrame:
    """Find QUESTIONABLE stars to monitor"""
    
    injury_col = None
    for col in df.columns:
        if 'injury' in col.lower() and 'indicator' in col.lower():
            injury_col = col
            break
    
    if not injury_col:
        return pd.DataFrame()
    
    # Find questionable stars
    gtd_players = df[df[injury_col].astype(str).str.upper() == 'Q'].copy()
    stars_gtd = gtd_players[gtd_players['Salary'] >= min_salary].copy()
    stars_gtd = stars_gtd.sort_values('Salary', ascending=False)
    
    return stars_gtd

def generate_injury_command(stars_out: pd.DataFrame) -> str:
    """Generate injury_value_detector.py command"""
    
    if stars_out.empty:
        return None
    
    # Group by team
    team_injuries = {}
    for _, player in stars_out.iterrows():
        team = player['Team']
        name = player['Name']
        
        if team not in team_injuries:
            team_injuries[team] = []
        team_injuries[team].append(name)
    
    # Build command string
    injury_parts = []
    for team, players in team_injuries.items():
        player_list = ','.join(players)
        injury_parts.append(f"{team}:{player_list}")
    
    injury_string = ';'.join(injury_parts)
    
    return injury_string

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("slate_csv", help="FanDuel slate CSV")
    ap.add_argument("--min-salary", type=int, default=8000,
                   help="Minimum salary to consider a 'star' (default: 8000)")
    args = ap.parse_args()
    
    print(f"\n Loading slate: {Path(args.slate_csv).name}")
    
    df = load_slate(args.slate_csv)
    print(f"[OK] Loaded {len(df)} players")
    
    # Find injured stars
    print(f"\n[!] STARS OUT (Salary >= ${args.min_salary:,}):")
    print("="*80)
    
    stars_out = find_injured_stars(df, args.min_salary)
    
    if stars_out.empty:
        print("[OK] No high-salary players OUT tonight")
        print("   (This is unusual - check your injury indicator column)")
    else:
        print(f"\n{'Name':<25} {'Team':>6} {'Pos':>8} {'Salary':>10} {'FPPG':>8}")
        print("-"*80)
        
        for _, player in stars_out.iterrows():
            pos = player.get('Position', 'N/A')
            fppg = player.get('FPPG', 0)
            print(f"{player['Name']:<25} {player['Team']:>6} {pos:>8} "
                  f"${player['Salary']:>8,.0f} {fppg:>8.1f}")
        
        # Generate command
        injury_string = generate_injury_command(stars_out)
        
        print("\n" + "="*80)
        print(" COPY THIS COMMAND:")
        print("="*80)
        print(f'\npython injury_value_detector.py "{args.slate_csv}" --injuries "{injury_string}"')
        print()
    
    # Find questionable stars
    print("\n" + "="*80)
    print("[WARNING]  QUESTIONABLE STARS TO MONITOR (Salary >= $9,000):")
    print("="*80)
    
    stars_gtd = find_questionable_stars(df, min_salary=9000)
    
    if stars_gtd.empty:
        print("[OK] No high-salary players Questionable")
    else:
        print(f"\n{'Name':<25} {'Team':>6} {'Pos':>8} {'Salary':>10}")
        print("-"*80)
        
        for _, player in stars_gtd.iterrows():
            pos = player.get('Position', 'N/A')
            print(f"{player['Name']:<25} {player['Team']:>6} {pos:>8} "
                  f"${player['Salary']:>8,.0f}")
        
        print("\n[TIP] Monitor these 30 min before lock!")
        print("   If they're ruled OUT, re-run injury detector")
    
    # Summary
    print("\n" + "="*80)
    print(" SUMMARY:")
    print("="*80)
    print(f"\nTotal players OUT: {len(df[df.get('Injury Indicator', '').astype(str).str.upper() == 'O'])}")
    print(f"Stars OUT (>=${args.min_salary:,}): {len(stars_out)}")
    print(f"Stars Questionable (>=$9,000): {len(stars_gtd)}")
    
    if not stars_out.empty:
        print(f"\n VALUE OPPORTUNITY LEVEL: {''*len(stars_out)} ({'HIGH' if len(stars_out) >= 3 else 'MODERATE'})")
    
    print("\n" + "="*80)
    print("[OK] SCAN COMPLETE!")
    print("="*80)

if __name__ == "__main__":
    main()