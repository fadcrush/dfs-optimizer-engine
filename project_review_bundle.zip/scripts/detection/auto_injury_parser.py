#!/usr/bin/env python
"""
auto_injury_parser.py

Automatically extract injury data from multiple sources:
1. FanDuel slate CSV (Injury Indicator column) - RECOMMENDED
2. PDF injury report (if available)
3. Manual input as fallback

Usage:
    # From slate CSV (best option)
    python auto_injury_parser.py --slate "FanDuel-NBA-slate.csv"
    
    # From PDF
    python auto_injury_parser.py --pdf "Injury-Report.pdf"
    
    # Output beneficiaries command automatically
"""

import argparse
import pandas as pd
import PyPDF2
import re
from pathlib import Path
from typing import List, Dict, Tuple

print("="*80)
print("AUTO INJURY PARSER - Extract Injuries Automatically")
print("="*80)

# NBA teams mapping
TEAM_ABBREV_MAP = {
    'ATL': 'Atlanta Hawks', 'BOS': 'Boston Celtics', 'BKN': 'Brooklyn Nets',
    'CHA': 'Charlotte Hornets', 'CHI': 'Chicago Bulls', 'CLE': 'Cleveland Cavaliers',
    'DAL': 'Dallas Mavericks', 'DEN': 'Denver Nuggets', 'DET': 'Detroit Pistons',
    'GSW': 'Golden State Warriors', 'HOU': 'Houston Rockets', 'IND': 'Indiana Pacers',
    'LAC': 'LA Clippers', 'LAL': 'Los Angeles Lakers', 'MEM': 'Memphis Grizzlies',
    'MIA': 'Miami Heat', 'MIL': 'Milwaukee Bucks', 'MIN': 'Minnesota Timberwolves',
    'NOP': 'New Orleans Pelicans', 'NYK': 'New York Knicks', 'OKC': 'Oklahoma City Thunder',
    'ORL': 'Orlando Magic', 'PHI': 'Philadelphia 76ers', 'PHX': 'Phoenix Suns',
    'POR': 'Portland Trail Blazers', 'SAC': 'Sacramento Kings', 'SAS': 'San Antonio Spurs',
    'TOR': 'Toronto Raptors', 'UTA': 'Utah Jazz', 'WAS': 'Washington Wizards'
}

def parse_slate_csv(csv_path: str, min_salary: int = 8000) -> pd.DataFrame:
    """Parse FanDuel slate CSV for OUT players"""
    
    print(f"\n Loading slate: {Path(csv_path).name}")
    df = pd.read_csv(csv_path)
    
    # Standardize columns
    if "Nickname" in df.columns:
        df["Name"] = df["Nickname"].astype(str)
    elif "Name" not in df.columns:
        df["Name"] = (df.get("First Name", "").astype(str) + " " + 
                      df.get("Last Name", "").astype(str)).str.strip()
    
    df["Team"] = df["Team"].astype(str).str.upper()
    df["Salary"] = pd.to_numeric(df["Salary"], errors="coerce")
    
    # Find injury indicator column
    injury_col = None
    for col in df.columns:
        if 'injury' in col.lower() and 'indicator' in col.lower():
            injury_col = col
            break
    
    if not injury_col:
        print("[ERROR] No injury indicator column found")
        return pd.DataFrame()
    
    # Find OUT players
    out_players = df[df[injury_col].astype(str).str.upper() == 'O'].copy()
    
    # Filter for stars
    stars_out = out_players[out_players['Salary'] >= min_salary].copy()
    stars_out = stars_out.sort_values('Salary', ascending=False)
    
    return stars_out

def parse_pdf_report(pdf_path: str, min_salary: int = 8000) -> List[Dict]:
    """Parse PDF injury report"""
    
    print(f"\n Loading PDF: {Path(pdf_path).name}")
    
    try:
        with open(pdf_path, 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            text = ""
            for page in reader.pages:
                text += page.extract_text()
        
        # Parse text for OUT players
        # Format: "Player Name    OUT    Injury reason"
        injuries = []
        
        lines = text.split('\n')
        current_team = None
        
        for line in lines:
            # Detect team names
            for abbrev, full_name in TEAM_ABBREV_MAP.items():
                if full_name in line:
                    current_team = abbrev
                    break
            
            # Detect OUT status
            if 'Out' in line and current_team:
                # Extract player name (before "Out")
                parts = line.split('Out')
                if len(parts) > 0:
                    name = parts[0].strip()
                    # Clean up name
                    name = re.sub(r'[^a-zA-Z\s\-\']', '', name).strip()
                    
                    if len(name) > 3:  # Valid name
                        injuries.append({
                            'Name': name,
                            'Team': current_team,
                            'Status': 'OUT'
                        })
        
        print(f"[OK] Found {len(injuries)} OUT players in PDF")
        return injuries
        
    except Exception as e:
        print(f"[ERROR] Error parsing PDF: {e}")
        return []

def format_injury_command(stars_out: pd.DataFrame) -> str:
    """Format injury detector command"""
    
    if stars_out.empty:
        return None
    
    # Group by team
    team_injuries = {}
    for _, player in stars_out.iterrows():
        team = player['Team']
        name = player['Name']
        
        if team not in team_injuries:
            team_injuries[team] = []
        team_injuries[team].append(name)
    
    # Build command string
    injury_parts = []
    for team, players in sorted(team_injuries.items()):
        player_list = ','.join(players)
        injury_parts.append(f"{team}:{player_list}")
    
    return ';'.join(injury_parts)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--slate", help="FanDuel slate CSV (recommended)")
    ap.add_argument("--pdf", help="Injury report PDF")
    ap.add_argument("--min-salary", type=int, default=8000,
                   help="Minimum salary for 'star' classification")
    ap.add_argument("--output", help="Save results to file")
    args = ap.parse_args()
    
    stars_out = pd.DataFrame()
    
    # Method 1: Slate CSV (preferred)
    if args.slate:
        stars_out = parse_slate_csv(args.slate, args.min_salary)
    
    # Method 2: PDF
    elif args.pdf:
        injuries = parse_pdf_report(args.pdf, args.min_salary)
        if injuries:
            stars_out = pd.DataFrame(injuries)
    
    # Method 3: Manual input
    else:
        print("\n[WARNING]  No input provided!")
        print("Options:")
        print("  --slate 'FanDuel-NBA-slate.csv'  (recommended)")
        print("  --pdf 'Injury-Report.pdf'")
        return
    
    if stars_out.empty:
        print("\n[OK] No star players OUT (or none found)")
        return
    
    # Display results
    print("\n" + "="*80)
    print(f"[!] STARS OUT (Salary >= ${args.min_salary:,})")
    print("="*80)
    
    print(f"\n{'Name':<25} {'Team':>6} {'Salary':>10}")
    print("-"*80)
    
    for _, player in stars_out.iterrows():
        salary_str = f"${player.get('Salary', 0):,.0f}" if 'Salary' in player else "N/A"
        print(f"{player['Name']:<25} {player['Team']:>6} {salary_str:>10}")
    
    # Generate command
    injury_string = format_injury_command(stars_out)
    
    print("\n" + "="*80)
    print(" NEXT STEP: Run Beneficiary Analyzer")
    print("="*80)
    
    print(f'\npython injury_beneficiary_analyzer.py --injuries "{injury_string}" --db "data/dfs_warehouse.duckdb"')
    print()
    
    # Save to file if requested
    if args.output:
        with open(args.output, 'w') as f:
            f.write(injury_string)
        print(f"[OK] Saved injury string to: {args.output}")
    
    print("\n" + "="*80)
    print("[OK] PARSING COMPLETE!")
    print("="*80)

if __name__ == "__main__":
    main()
