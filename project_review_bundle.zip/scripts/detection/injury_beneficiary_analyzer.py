#!/usr/bin/env python
"""
injury_beneficiary_analyzer.py

AUTOMATICALLY discovers injury beneficiaries from historical data!

Instead of manual rules, this analyzes your DuckDB game logs to find:
1. Games when Star X was OUT
2. How teammates performed in those games vs normally
3. Statistical uplift (FD points, minutes, usage)
4. Auto-generates beneficiary rules

This is DATA-DRIVEN, not guesswork!

Usage:
    python injury_beneficiary_analyzer.py --injuries "SAS:Victor Wembanyama;DEN:Nikola Jokic" --db "data/dfs_warehouse.duckdb"
"""

import argparse
import duckdb
import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, List, Tuple
import json

print("="*80)
print("AI BENEFICIARY ANALYZER - Learn From Historical Data")
print("="*80)

def parse_injuries(injury_string: str) -> Dict[str, List[str]]:
    """Parse injury string into dict"""
    injuries = {}
    
    for team_block in injury_string.split(';'):
        if ':' not in team_block:
            continue
        
        team, players = team_block.split(':', 1)
        team = team.strip().upper()
        injuries[team] = [p.strip() for p in players.split(',')]
    
    return injuries

def find_teammate_uplift(con: duckdb.DuckDBPyConnection, 
                        injured_player: str, 
                        team: str, 
                        season: str = "2024-25",
                        min_games: int = 3) -> pd.DataFrame:
    """
    Find how teammates performed when injured_player was OUT
    
    This is the MAGIC function that learns beneficiaries!
    """
    
    print(f"\n Analyzing: {injured_player} ({team})")
    print("-"*80)
    
    # Step 1: Find all games this season for this team
    team_games_query = """
    SELECT DISTINCT game_date
    FROM nba_player_game_logs
    WHERE team_abbr = ?
      AND season = ?
    ORDER BY game_date
    """
    
    all_games = con.execute(team_games_query, [team, season]).df()
    
    if all_games.empty:
        print(f"[ERROR] No games found for {team} in {season}")
        return pd.DataFrame()
    
    # Step 2: Find games where injured player played
    player_games_query = """
    SELECT DISTINCT game_date
    FROM nba_player_game_logs
    WHERE player_name = ?
      AND team_abbr = ?
      AND season = ?
      AND minutes > 0
    """
    
    player_games = con.execute(player_games_query, 
                              [injured_player, team, season]).df()
    
    # Step 3: Games where player was OUT = all games - games played
    if player_games.empty:
        # Player missed entire season
        games_out = all_games['game_date'].tolist()
    else:
        games_out = all_games[~all_games['game_date'].isin(
            player_games['game_date'])]['game_date'].tolist()
    
    if len(games_out) < min_games:
        print(f"[WARNING]  Only {len(games_out)} games OUT (need {min_games}+)")
        print(f"   Not enough data to analyze")
        return pd.DataFrame()
    
    print(f" Found {len(games_out)} games where {injured_player} was OUT")
    print(f" Found {len(player_games)} games where {injured_player} played")
    
    # Step 4: Analyze teammate performance
    # When star OUT
    teammate_out_query = """
    SELECT 
        player_name,
        COUNT(*) as games_star_out,
        AVG(fd_points) as avg_fd_star_out,
        AVG(minutes) as avg_min_star_out,
        STDDEV(fd_points) as std_fd_star_out
    FROM nba_player_game_logs
    WHERE team_abbr = ?
      AND season = ?
      AND game_date IN ({})
      AND player_name != ?
      AND minutes > 10
    GROUP BY player_name
    HAVING COUNT(*) >= ?
    """.format(','.join(['?' for _ in games_out]))
    
    params_out = [team, season] + games_out + [injured_player, min_games]
    teammates_out = con.execute(teammate_out_query, params_out).df()
    
    # When star IN
    if not player_games.empty:
        games_in = player_games['game_date'].tolist()
        
        teammate_in_query = """
        SELECT 
            player_name,
            COUNT(*) as games_star_in,
            AVG(fd_points) as avg_fd_star_in,
            AVG(minutes) as avg_min_star_in,
            STDDEV(fd_points) as std_fd_star_in
        FROM nba_player_game_logs
        WHERE team_abbr = ?
          AND season = ?
          AND game_date IN ({})
          AND player_name != ?
          AND minutes > 10
        GROUP BY player_name
        HAVING COUNT(*) >= ?
        """.format(','.join(['?' for _ in games_in]))
        
        params_in = [team, season] + games_in + [injured_player, min_games]
        teammates_in = con.execute(teammate_in_query, params_in).df()
        
        # Merge
        uplift = teammates_out.merge(teammates_in, on='player_name', how='inner')
        
        # Calculate uplift
        uplift['fd_uplift'] = uplift['avg_fd_star_out'] - uplift['avg_fd_star_in']
        uplift['min_uplift'] = uplift['avg_min_star_out'] - uplift['avg_min_star_in']
        uplift['pct_uplift'] = (uplift['fd_uplift'] / uplift['avg_fd_star_in']) * 100
        
        # Statistical significance (simple t-test approximation)
        uplift['std_combined'] = np.sqrt(
            (uplift['std_fd_star_out']**2 / uplift['games_star_out']) +
            (uplift['std_fd_star_in']**2 / uplift['games_star_in'])
        )
        uplift['t_stat'] = uplift['fd_uplift'] / (uplift['std_combined'] + 0.01)
        uplift['significant'] = uplift['t_stat'].abs() > 1.5  # Rough threshold
        
        # Sort by uplift
        uplift = uplift.sort_values('fd_uplift', ascending=False)
        
        return uplift
    
    else:
        # Star never played this season - can't compare
        print(f"[WARNING]  {injured_player} never played - can't calculate uplift")
        return pd.DataFrame()

def display_beneficiaries(uplift: pd.DataFrame, 
                         injured_player: str,
                         min_uplift: float = 5.0) -> List[Dict]:
    """Display and return beneficiaries"""
    
    if uplift.empty:
        return []
    
    # Filter for significant positive uplift
    beneficiaries = uplift[
        (uplift['fd_uplift'] >= min_uplift) &
        (uplift['significant'] == True)
    ].copy()
    
    if beneficiaries.empty:
        print(f"\n[WARNING]  No significant beneficiaries found (min uplift: {min_uplift} pts)")
        return []
    
    print(f"\n BENEFICIARIES (when {injured_player} OUT):")
    print(f"\n{'Player':<25} {'Games':>6} {'FD +/-':>8} {'Min +/-':>8} {'% Change':>10} {'Conf':>6}")
    print("-"*80)
    
    beneficiary_list = []
    
    for _, b in beneficiaries.iterrows():
        conf = "HIGH" if b['t_stat'] > 2.0 else "MED"
        
        print(f"{b['player_name']:<25} "
              f"{b['games_star_out']:>6.0f} "
              f"{b['fd_uplift']:>+8.1f} "
              f"{b['min_uplift']:>+8.1f} "
              f"{b['pct_uplift']:>+9.1f}% "
              f"{conf:>6}")
        
        beneficiary_list.append({
            'player': b['player_name'],
            'fd_boost': round(b['fd_uplift'], 1),
            'min_boost': round(b['min_uplift'], 1),
            'pct_boost': round(b['pct_uplift'], 1),
            'games': int(b['games_star_out']),
            'confidence': conf
        })
    
    return beneficiary_list

def generate_injury_rules(all_beneficiaries: Dict[str, List[Dict]], 
                         output_file: str = None) -> str:
    """Generate Python code for injury impact rules"""
    
    print("\n" + "="*80)
    print(" AUTO-GENERATED INJURY RULES")
    print("="*80)
    
    # Build Python dict
    rules_code = "# Auto-generated injury impact rules\n"
    rules_code += "# Generated: " + pd.Timestamp.now().strftime("%Y-%m-%d %H:%M:%S") + "\n\n"
    rules_code += "INJURY_IMPACT_RULES = {\n"
    
    for team_player, beneficiaries in sorted(all_beneficiaries.items()):
        team, injured_player = team_player.split(':', 1)
        
        rules_code += f"    # {team}\n"
        rules_code += f"    '{team}': {{\n"
        rules_code += f"        '{injured_player}': [\n"
        
        for b in beneficiaries:
            rules_code += f"            {{'player': '{b['player']}', "
            rules_code += f"'fd_boost': {b['fd_boost']}, "
            rules_code += f"'min_boost': {b['min_boost']}}},  "
            rules_code += f"# {b['pct_boost']:+.1f}% ({b['confidence']})\n"
        
        rules_code += f"        ],\n"
        rules_code += f"    }},\n"
    
    rules_code += "}\n"
    
    # Display
    print("\n" + rules_code)
    
    # Save to file
    if output_file:
        with open(output_file, 'w') as f:
            f.write(rules_code)
        print(f"\n[OK] Saved rules to: {output_file}")
    
    return rules_code

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--injuries", required=True,
                   help='Injury string: "TEAM:Player;TEAM:Player"')
    ap.add_argument("--db", required=True,
                   help="Path to DuckDB database")
    ap.add_argument("--season", default="2024-25",
                   help="Season to analyze")
    ap.add_argument("--min-games", type=int, default=3,
                   help="Minimum games to analyze")
    ap.add_argument("--min-uplift", type=float, default=5.0,
                   help="Minimum FD uplift to consider")
    ap.add_argument("--output", default="outputs/auto_injury_rules.py",
                   help="Output file for rules")
    args = ap.parse_args()
    
    # Connect to database
    db_path = Path(args.db)
    if not db_path.exists():
        print(f"[ERROR] Database not found: {db_path}")
        return
    
    print(f"\n Database: {db_path}")
    con = duckdb.connect(str(db_path), read_only=True)
    
    # Parse injuries
    injuries = parse_injuries(args.injuries)
    
    print(f"\n[!] Analyzing {sum(len(p) for p in injuries.values())} injured players")
    
    # Analyze each injured player
    all_beneficiaries = {}
    
    for team, players in injuries.items():
        for injured_player in players:
            # Find beneficiaries
            uplift = find_teammate_uplift(
                con, injured_player, team, 
                args.season, args.min_games
            )
            
            # Display results
            beneficiaries = display_beneficiaries(
                uplift, injured_player, args.min_uplift
            )
            
            if beneficiaries:
                key = f"{team}:{injured_player}"
                all_beneficiaries[key] = beneficiaries
    
    con.close()
    
    # Generate rules
    if all_beneficiaries:
        generate_injury_rules(all_beneficiaries, args.output)
        
        print("\n" + "="*80)
        print("[TIP] NEXT STEPS:")
        print("="*80)
        print(f"""
1. Review auto-generated rules in: {args.output}
2. Copy rules to injury_value_detector.py INJURY_IMPACT_RULES
3. Or run injury detector with these beneficiaries:

   python injury_value_detector.py "slate.csv" --injuries "{args.injuries}"
   
4. The beneficiaries above will boost projections automatically!
        """)
    else:
        print("\n[WARNING]  No beneficiaries found with current criteria")
        print(f"   Try lowering --min-uplift (current: {args.min_uplift})")
        print(f"   Or lowering --min-games (current: {args.min_games})")
    
    print("\n" + "="*80)
    print("[OK] ANALYSIS COMPLETE!")
    print("="*80)

if __name__ == "__main__":
    main()
