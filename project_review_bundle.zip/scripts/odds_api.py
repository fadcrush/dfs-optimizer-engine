#!/usr/bin/env python
"""
ODDS_API.py

Connector for The Odds API (FREE tier: 500 requests/month)
Gets Vegas lines, spreads, totals, player props

Sign up: https://the-odds-api.com/
"""

import requests
import pandas as pd
import time
from datetime import datetime

class OddsAPI:
    """Wrapper for The Odds API"""
    
    BASE_URL = 'https://api.the-odds-api.com/v4'
    
    SPORTS = {
        'NBA': 'basketball_nba',
        'NFL': 'americanfootball_nfl'
    }
    
    def __init__(self, api_key, delay=6):
        """
        Initialize API wrapper
        
        Args:
            api_key: Your Odds API key
            delay: Seconds between requests (default: 6)
        """
        self.api_key = api_key
        self.delay = delay
        self.last_request_time = 0
        self.requests_remaining = None
        self.requests_used = None
    
    def _make_request(self, endpoint, params=None):
        """Make API request with rate limiting"""
        
        # Rate limiting
        time_since_last = time.time() - self.last_request_time
        if time_since_last < self.delay:
            time.sleep(self.delay - time_since_last)
        
        # Add API key
        if params is None:
            params = {}
        params['apiKey'] = self.api_key
        
        # Make request
        url = f"{self.BASE_URL}/{endpoint}"
        
        try:
            response = requests.get(url, params=params, timeout=30)
            response.raise_for_status()
            
            # Track usage
            self.requests_remaining = response.headers.get('x-requests-remaining')
            self.requests_used = response.headers.get('x-requests-used')
            
            self.last_request_time = time.time()
            
            return response.json()
        
        except requests.exceptions.RequestException as e:
            print(f"  [ERROR] API request failed: {e}")
            return None
    
    def get_usage(self):
        """Get API usage stats"""
        if self.requests_remaining:
            print(f"\nAPI Usage:")
            print(f"  Requests used: {self.requests_used}")
            print(f"  Requests remaining: {self.requests_remaining}")
            
            if int(self.requests_remaining) < 50:
                print(f"  ⚠️  Warning: Running low on requests!")
        
        return {
            'used': self.requests_used,
            'remaining': self.requests_remaining
        }
    
    def get_upcoming_games(self, sport='NBA'):
        """
        Get upcoming games with odds
        
        Args:
            sport: 'NBA' or 'NFL'
        
        Returns:
            List of games with odds
        """
        
        sport_key = self.SPORTS.get(sport)
        if not sport_key:
            print(f"  [ERROR] Unknown sport: {sport}")
            return []
        
        endpoint = f"sports/{sport_key}/odds"
        
        params = {
            'regions': 'us',
            'markets': 'h2h,spreads,totals',
            'oddsFormat': 'american',
        }
        
        print(f"  Fetching odds for {sport}...")
        
        data = self._make_request(endpoint, params)
        
        if not data:
            return []
        
        print(f"    [OK] Got odds for {len(data)} games")
        
        return data
    
    def get_player_props(self, sport='NBA'):
        """
        Get player props
        
        Args:
            sport: 'NBA' or 'NFL'
        
        Returns:
            List of player props
        """
        
        sport_key = self.SPORTS.get(sport)
        if not sport_key:
            print(f"  [ERROR] Unknown sport: {sport}")
            return []
        
        endpoint = f"sports/{sport_key}/odds"
        
        params = {
            'regions': 'us',
            'markets': 'player_points,player_rebounds,player_assists',  # NBA
            'oddsFormat': 'american',
        }
        
        print(f"  Fetching player props for {sport}...")
        
        data = self._make_request(endpoint, params)
        
        if not data:
            return []
        
        print(f"    [OK] Got player props for {len(data)} games")
        
        return data
    
    def parse_game_odds(self, game_data):
        """Parse game odds into clean format"""
        
        parsed = {
            'game_id': game_data.get('id'),
            'date': game_data.get('commence_time'),
            'home_team': game_data.get('home_team'),
            'away_team': game_data.get('away_team'),
        }
        
        # Get best odds from multiple books
        bookmakers = game_data.get('bookmakers', [])
        
        if not bookmakers:
            return parsed
        
        # Use first bookmaker (or aggregate across books)
        book = bookmakers[0]
        parsed['bookmaker'] = book.get('title')
        
        markets = book.get('markets', [])
        
        for market in markets:
            market_key = market.get('key')
            outcomes = market.get('outcomes', [])
            
            if market_key == 'h2h':
                # Moneylines
                for outcome in outcomes:
                    team = outcome.get('name')
                    price = outcome.get('price')
                    
                    if team == parsed['home_team']:
                        parsed['home_ml'] = price
                    else:
                        parsed['away_ml'] = price
            
            elif market_key == 'spreads':
                # Point spreads
                for outcome in outcomes:
                    team = outcome.get('name')
                    point = outcome.get('point')
                    
                    if team == parsed['home_team']:
                        parsed['home_spread'] = point
                    else:
                        parsed['away_spread'] = point
            
            elif market_key == 'totals':
                # Over/Under
                for outcome in outcomes:
                    name = outcome.get('name')
                    point = outcome.get('point')
                    
                    if name == 'Over':
                        parsed['over_under'] = point
                    
                    parsed[name.lower() + '_price'] = outcome.get('price')
        
        return parsed
    
    def get_games_dataframe(self, sport='NBA'):
        """Get games as DataFrame"""
        
        games = self.get_upcoming_games(sport)
        
        if not games:
            return pd.DataFrame()
        
        parsed_games = [self.parse_game_odds(g) for g in games]
        df = pd.DataFrame(parsed_games)
        
        return df

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def standardize_team_name(team_name, sport='NBA'):
    """Standardize team names to abbreviations"""
    
    # NBA team mapping
    NBA_TEAMS = {
        'Atlanta Hawks': 'ATL',
        'Boston Celtics': 'BOS',
        'Brooklyn Nets': 'BKN',
        'Charlotte Hornets': 'CHA',
        'Chicago Bulls': 'CHI',
        'Cleveland Cavaliers': 'CLE',
        'Dallas Mavericks': 'DAL',
        'Denver Nuggets': 'DEN',
        'Detroit Pistons': 'DET',
        'Golden State Warriors': 'GSW',
        'Houston Rockets': 'HOU',
        'Indiana Pacers': 'IND',
        'Los Angeles Clippers': 'LAC',
        'Los Angeles Lakers': 'LAL',
        'Memphis Grizzlies': 'MEM',
        'Miami Heat': 'MIA',
        'Milwaukee Bucks': 'MIL',
        'Minnesota Timberwolves': 'MIN',
        'New Orleans Pelicans': 'NOP',
        'New York Knicks': 'NYK',
        'Oklahoma City Thunder': 'OKC',
        'Orlando Magic': 'ORL',
        'Philadelphia 76ers': 'PHI',
        'Phoenix Suns': 'PHX',
        'Portland Trail Blazers': 'POR',
        'Sacramento Kings': 'SAC',
        'San Antonio Spurs': 'SAS',
        'Toronto Raptors': 'TOR',
        'Utah Jazz': 'UTA',
        'Washington Wizards': 'WAS',
    }
    
    # NFL team mapping
    NFL_TEAMS = {
        'Arizona Cardinals': 'ARI',
        'Atlanta Falcons': 'ATL',
        'Baltimore Ravens': 'BAL',
        'Buffalo Bills': 'BUF',
        'Carolina Panthers': 'CAR',
        'Chicago Bears': 'CHI',
        'Cincinnati Bengals': 'CIN',
        'Cleveland Browns': 'CLE',
        'Dallas Cowboys': 'DAL',
        'Denver Broncos': 'DEN',
        'Detroit Lions': 'DET',
        'Green Bay Packers': 'GB',
        'Houston Texans': 'HOU',
        'Indianapolis Colts': 'IND',
        'Jacksonville Jaguars': 'JAX',
        'Kansas City Chiefs': 'KC',
        'Las Vegas Raiders': 'LV',
        'Los Angeles Chargers': 'LAC',
        'Los Angeles Rams': 'LAR',
        'Miami Dolphins': 'MIA',
        'Minnesota Vikings': 'MIN',
        'New England Patriots': 'NE',
        'New Orleans Saints': 'NO',
        'New York Giants': 'NYG',
        'New York Jets': 'NYJ',
        'Philadelphia Eagles': 'PHI',
        'Pittsburgh Steelers': 'PIT',
        'San Francisco 49ers': 'SF',
        'Seattle Seahawks': 'SEA',
        'Tampa Bay Buccaneers': 'TB',
        'Tennessee Titans': 'TEN',
        'Washington Commanders': 'WAS',
    }
    
    teams = NBA_TEAMS if sport == 'NBA' else NFL_TEAMS
    
    return teams.get(team_name, team_name)

def calculate_implied_probability(odds):
    """Calculate implied probability from American odds"""
    
    if odds > 0:
        # Underdog
        prob = 100 / (odds + 100)
    else:
        # Favorite
        prob = abs(odds) / (abs(odds) + 100)
    
    return round(prob * 100, 2)

# ============================================================================
# USAGE EXAMPLE
# ============================================================================

if __name__ == '__main__':
    
    print("="*80)
    print("THE ODDS API - TEST")
    print("="*80)
    
    # You need to provide your API key
    api_key = input("\nEnter your Odds API key (or press Enter to skip): ")
    
    if not api_key:
        print("\n⚠️  No API key provided. Get one at: https://the-odds-api.com/")
        print("="*80)
        exit()
    
    # Initialize API
    api = OddsAPI(api_key, delay=6)
    
    # Test: Get NBA games
    print("\nFetching NBA games...")
    nba_games = api.get_games_dataframe('NBA')
    
    if not nba_games.empty:
        print(f"\n✅ Found {len(nba_games)} NBA games")
        print("\nSample:")
        print(nba_games[['home_team', 'away_team', 'over_under', 'home_spread']].head())
        
        # Show totals
        print("\nGame Totals:")
        for _, game in nba_games.iterrows():
            total = game.get('over_under', 'N/A')
            print(f"  {game['away_team']} @ {game['home_team']}: O/U {total}")
    
    # Test: Get NFL games (if in season)
    print("\nFetching NFL games...")
    nfl_games = api.get_games_dataframe('NFL')
    
    if not nfl_games.empty:
        print(f"\n✅ Found {len(nfl_games)} NFL games")
    else:
        print("\n  No NFL games found (off-season?)")
    
    # Show usage
    api.get_usage()
    
    print("\n" + "="*80)
    print("TEST COMPLETE!")
    print("="*80)
