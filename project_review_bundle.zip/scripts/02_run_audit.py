"""
Run audit of historical data directories
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from data_warehouse.audit.directory_scanner import DFSDataAuditor
from data_warehouse.utils.logger import get_logger

logger = get_logger(__name__)


def main():
    """Run audit"""
    
    auditor = DFSDataAuditor()
    results = auditor.run_full_audit()
    
    print("\nAudit complete! Check 'data_warehouse/audit_reports/' for detailed reports.")


if __name__ == '__main__':
    main()