#!/usr/bin/env python
"""
SETUP_DATABASE_FIXED.py

Initialize the master DFS database with better error handling
"""

import duckdb
import pandas as pd
from pathlib import Path
import sys

print("="*80)
print("MASTER DFS DATABASE - SETUP (FIXED)")
print("="*80)

# Database path
DB_PATH = 'data/dfs_master.duckdb'

# Ensure data directory exists
Path('data').mkdir(exist_ok=True)

# Connect to database
print(f"\nConnecting to: {DB_PATH}")
conn = duckdb.connect(DB_PATH)

# =============================================================================
# STEP 1: Create Schema Directly
# =============================================================================

print("\nStep 1: Creating database schema...")

# Create tables one by one with better error handling

tables_created = 0

# Players table
try:
    conn.execute("""
    CREATE TABLE IF NOT EXISTS players (
        player_id VARCHAR PRIMARY KEY,
        player_name VARCHAR NOT NULL,
        primary_position VARCHAR,
        team VARCHAR,
        sport VARCHAR NOT NULL,
        height VARCHAR,
        weight INTEGER,
        age INTEGER,
        experience INTEGER,
        active BOOLEAN DEFAULT true,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)
    print("  [OK] players")
    tables_created += 1
except Exception as e:
    print(f"  [ERROR] players: {e}")

# Player game logs
try:
    conn.execute("""
    CREATE TABLE IF NOT EXISTS player_game_logs (
        game_log_id INTEGER PRIMARY KEY,
        game_id VARCHAR NOT NULL,
        player_id VARCHAR NOT NULL,
        player_name VARCHAR NOT NULL,
        date DATE NOT NULL,
        season VARCHAR,
        team VARCHAR,
        opponent VARCHAR,
        home_away VARCHAR,
        started BOOLEAN,
        minutes_played FLOAT,
        rest_days INTEGER,
        game_number INTEGER,
        points INTEGER,
        rebounds INTEGER,
        assists INTEGER,
        steals INTEGER,
        blocks INTEGER,
        turnovers INTEGER,
        fgm INTEGER,
        fga INTEGER,
        fg3m INTEGER,
        fg3a INTEGER,
        ftm INTEGER,
        fta INTEGER,
        offensive_rebounds INTEGER,
        defensive_rebounds INTEGER,
        pass_attempts INTEGER,
        pass_completions INTEGER,
        pass_yards INTEGER,
        pass_tds INTEGER,
        interceptions INTEGER,
        rush_attempts INTEGER,
        rush_yards INTEGER,
        rush_tds INTEGER,
        targets INTEGER,
        receptions INTEGER,
        receiving_yards INTEGER,
        receiving_tds INTEGER,
        fumbles_lost INTEGER,
        dk_points FLOAT,
        fd_points FLOAT,
        yahoo_points FLOAT,
        usage_rate FLOAT,
        true_shooting_pct FLOAT,
        plus_minus INTEGER,
        source VARCHAR,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_game_logs_player ON player_game_logs(player_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_game_logs_date ON player_game_logs(date)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_game_logs_team ON player_game_logs(team)")
    print("  [OK] player_game_logs")
    tables_created += 1
except Exception as e:
    print(f"  [ERROR] player_game_logs: {e}")

# Team defense
try:
    conn.execute("""
    CREATE TABLE IF NOT EXISTS team_defense_by_position (
        defense_id INTEGER PRIMARY KEY,
        date DATE NOT NULL,
        season VARCHAR,
        team VARCHAR NOT NULL,
        sport VARCHAR NOT NULL,
        position VARCHAR NOT NULL,
        games_played INTEGER,
        total_fpts_allowed FLOAT,
        avg_fpts_allowed FLOAT,
        rank INTEGER,
        pace FLOAT,
        defensive_efficiency FLOAT,
        last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_defense_team_pos ON team_defense_by_position(team, position)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_defense_date ON team_defense_by_position(date)")
    print("  [OK] team_defense_by_position")
    tables_created += 1
except Exception as e:
    print(f"  [ERROR] team_defense_by_position: {e}")

# Games
try:
    conn.execute("""
    CREATE TABLE IF NOT EXISTS games (
        game_id VARCHAR PRIMARY KEY,
        date DATE NOT NULL,
        season VARCHAR,
        sport VARCHAR NOT NULL,
        home_team VARCHAR,
        away_team VARCHAR,
        vegas_total FLOAT,
        home_spread FLOAT,
        over_under FLOAT,
        home_score INTEGER,
        away_score INTEGER,
        total_score INTEGER,
        pace FLOAT,
        possessions INTEGER,
        temperature INTEGER,
        wind_speed INTEGER,
        precipitation VARCHAR,
        dome BOOLEAN,
        playoff_game BOOLEAN DEFAULT false,
        nationally_televised BOOLEAN DEFAULT false,
        status VARCHAR,
        source VARCHAR,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_games_date ON games(date)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_games_teams ON games(home_team, away_team)")
    print("  [OK] games")
    tables_created += 1
except Exception as e:
    print(f"  [ERROR] games: {e}")

# Projections
try:
    conn.execute("""
    CREATE TABLE IF NOT EXISTS projections (
        projection_id INTEGER PRIMARY KEY,
        date DATE NOT NULL,
        player_id VARCHAR NOT NULL,
        player_name VARCHAR NOT NULL,
        platform VARCHAR,
        sport VARCHAR,
        salary INTEGER,
        position VARCHAR,
        sabersim_proj FLOAT,
        fantasypros_proj FLOAT,
        rotogrinders_proj FLOAT,
        fanduel_proj FLOAT,
        draftkings_proj FLOAT,
        your_proj FLOAT,
        actual_points FLOAT,
        projected_ownership FLOAT,
        actual_ownership FLOAT,
        ss_error FLOAT,
        your_error FLOAT,
        ss_abs_error FLOAT,
        your_abs_error FLOAT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_proj_player_date ON projections(player_id, date)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_proj_date ON projections(date)")
    print("  [OK] projections")
    tables_created += 1
except Exception as e:
    print(f"  [ERROR] projections: {e}")

# Injuries
try:
    conn.execute("""
    CREATE TABLE IF NOT EXISTS injuries (
        injury_id INTEGER PRIMARY KEY,
        player_id VARCHAR NOT NULL,
        player_name VARCHAR NOT NULL,
        date DATE NOT NULL,
        status VARCHAR,
        injury_type VARCHAR,
        body_part VARCHAR,
        injury_date DATE,
        expected_return DATE,
        games_missed INTEGER,
        source VARCHAR,
        reported_by VARCHAR,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_injuries_player ON injuries(player_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_injuries_date ON injuries(date)")
    print("  [OK] injuries")
    tables_created += 1
except Exception as e:
    print(f"  [ERROR] injuries: {e}")

# News
try:
    conn.execute("""
    CREATE TABLE IF NOT EXISTS news (
        news_id INTEGER PRIMARY KEY,
        date TIMESTAMP NOT NULL,
        player_id VARCHAR,
        player_name VARCHAR,
        team VARCHAR,
        headline VARCHAR,
        content TEXT,
        impact VARCHAR,
        news_type VARCHAR,
        source VARCHAR,
        url VARCHAR,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_news_player ON news(player_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_news_date ON news(date)")
    print("  [OK] news")
    tables_created += 1
except Exception as e:
    print(f"  [ERROR] news: {e}")

# Situational stats
try:
    conn.execute("""
    CREATE TABLE IF NOT EXISTS situational_stats (
        situation_id INTEGER PRIMARY KEY,
        player_id VARCHAR NOT NULL,
        player_name VARCHAR NOT NULL,
        season VARCHAR,
        situation_type VARCHAR NOT NULL,
        situation_value VARCHAR,
        games_played INTEGER,
        avg_fantasy_points FLOAT,
        std_dev FLOAT,
        min_points FLOAT,
        max_points FLOAT,
        baseline_avg FLOAT,
        boost FLOAT,
        t_statistic FLOAT,
        p_value FLOAT,
        last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_situation_player ON situational_stats(player_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_situation_type ON situational_stats(situation_type)")
    print("  [OK] situational_stats")
    tables_created += 1
except Exception as e:
    print(f"  [ERROR] situational_stats: {e}")

# Patterns
try:
    conn.execute("""
    CREATE TABLE IF NOT EXISTS patterns (
        pattern_id INTEGER PRIMARY KEY,
        pattern_name VARCHAR NOT NULL,
        pattern_type VARCHAR,
        description TEXT,
        condition_sql TEXT,
        sample_size INTEGER,
        avg_boost FLOAT,
        confidence_level VARCHAR,
        t_statistic FLOAT,
        p_value FLOAT,
        r_squared FLOAT,
        recommendation TEXT,
        active BOOLEAN DEFAULT true,
        discovered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        last_validated TIMESTAMP,
        sport VARCHAR
    )
    """)
    print("  [OK] patterns")
    tables_created += 1
except Exception as e:
    print(f"  [ERROR] patterns: {e}")

# Vegas odds
try:
    conn.execute("""
    CREATE TABLE IF NOT EXISTS vegas_odds (
        odds_id INTEGER PRIMARY KEY,
        game_id VARCHAR NOT NULL,
        date DATE NOT NULL,
        bookmaker VARCHAR,
        home_spread FLOAT,
        away_spread FLOAT,
        over_under FLOAT,
        home_ml INTEGER,
        away_ml INTEGER,
        opening_total FLOAT,
        current_total FLOAT,
        total_movement FLOAT,
        opening_spread FLOAT,
        current_spread FLOAT,
        spread_movement FLOAT,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_odds_game ON vegas_odds(game_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_odds_date ON vegas_odds(date)")
    print("  [OK] vegas_odds")
    tables_created += 1
except Exception as e:
    print(f"  [ERROR] vegas_odds: {e}")

# Player props
try:
    conn.execute("""
    CREATE TABLE IF NOT EXISTS player_props (
        prop_id INTEGER PRIMARY KEY,
        date DATE NOT NULL,
        player_id VARCHAR NOT NULL,
        player_name VARCHAR NOT NULL,
        bookmaker VARCHAR,
        prop_type VARCHAR,
        line FLOAT,
        over_odds INTEGER,
        under_odds INTEGER,
        over_probability FLOAT,
        under_probability FLOAT,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_props_player ON player_props(player_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_props_date ON player_props(date)")
    print("  [OK] player_props")
    tables_created += 1
except Exception as e:
    print(f"  [ERROR] player_props: {e}")

# Contest results (MOST IMPORTANT - your existing data)
try:
    conn.execute("""
    CREATE TABLE IF NOT EXISTS contest_results (
        result_id INTEGER PRIMARY KEY,
        contest_date DATE NOT NULL,
        player_id VARCHAR,
        player_name VARCHAR NOT NULL,
        platform VARCHAR,
        sport VARCHAR,
        slate_type VARCHAR,
        position VARCHAR,
        team VARCHAR,
        opponent VARCHAR,
        salary INTEGER,
        actual_fpts FLOAT NOT NULL,
        my_proj FLOAT,
        sabersim_proj FLOAT,
        platform_proj FLOAT,
        my_ownership FLOAT,
        actual_ownership FLOAT,
        source_file VARCHAR,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_contest_player ON contest_results(player_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_contest_date ON contest_results(contest_date)")
    print("  [OK] contest_results")
    tables_created += 1
except Exception as e:
    print(f"  [ERROR] contest_results: {e}")

# Daily slates
try:
    conn.execute("""
    CREATE TABLE IF NOT EXISTS daily_slates (
        slate_id INTEGER PRIMARY KEY,
        date DATE NOT NULL,
        platform VARCHAR,
        sport VARCHAR,
        slate_type VARCHAR,
        num_games INTEGER,
        num_players INTEGER,
        lineups_entered INTEGER,
        total_entries FLOAT,
        total_winnings FLOAT,
        net_profit FLOAT,
        roi FLOAT,
        avg_projection_error FLOAT,
        r_squared FLOAT,
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_slates_date ON daily_slates(date)")
    print("  [OK] daily_slates")
    tables_created += 1
except Exception as e:
    print(f"  [ERROR] daily_slates: {e}")

print(f"\n  Created {tables_created}/13 tables")

# =============================================================================
# STEP 2: Load Existing Contest Results
# =============================================================================

print("\nStep 2: Loading existing contest results...")

# Check if contest_results table has data
existing_count = conn.execute("SELECT COUNT(*) FROM contest_results").fetchone()[0]

if existing_count > 0:
    print(f"  Found {existing_count:,} existing contest results")
    response = input("  Keep existing data? (y/n): ")
    
    if response.lower() != 'y':
        print("  Clearing existing data...")
        conn.execute("DELETE FROM contest_results")
        existing_count = 0

if existing_count == 0:
    # Try to load from dfs_warehouse.duckdb
    old_db = Path('data/dfs_warehouse.duckdb')
    
    if old_db.exists():
        print(f"  Found existing database: {old_db}")
        print("  Importing contest results...")
        
        try:
            # Attach old database
            conn.execute(f"ATTACH '{old_db}' AS old_db")
            
            # Copy data
            conn.execute("""
                INSERT INTO contest_results 
                SELECT 
                    ROW_NUMBER() OVER () as result_id,
                    contest_date,
                    NULL as player_id,
                    player_name,
                    platform,
                    sport,
                    NULL as slate_type,
                    position,
                    team,
                    opponent,
                    salary,
                    actual_fpts,
                    my_proj,
                    sabersim_proj,
                    NULL as platform_proj,
                    my_ownership,
                    NULL as actual_ownership,
                    source_file,
                    CURRENT_TIMESTAMP
                FROM old_db.contest_results
            """)
            
            imported = conn.execute("SELECT COUNT(*) FROM contest_results").fetchone()[0]
            print(f"    [OK] Imported {imported:,} contest results")
            
            # Detach
            conn.execute("DETACH old_db")
            
        except Exception as e:
            print(f"  [ERROR] Failed to import: {e}")
    else:
        print("  No existing data found to import")

# =============================================================================
# STEP 3: Summary
# =============================================================================

print("\n" + "="*80)
print("DATABASE SUMMARY")
print("="*80)

summary = conn.execute("""
    SELECT 
        'players' as table_name, 
        COUNT(*) as row_count 
    FROM players
    
    UNION ALL
    SELECT 'player_game_logs', COUNT(*) FROM player_game_logs
    
    UNION ALL
    SELECT 'team_defense_by_position', COUNT(*) FROM team_defense_by_position
    
    UNION ALL
    SELECT 'games', COUNT(*) FROM games
    
    UNION ALL
    SELECT 'projections', COUNT(*) FROM projections
    
    UNION ALL
    SELECT 'injuries', COUNT(*) FROM injuries
    
    UNION ALL
    SELECT 'news', COUNT(*) FROM news
    
    UNION ALL
    SELECT 'contest_results', COUNT(*) FROM contest_results
    
    UNION ALL
    SELECT 'vegas_odds', COUNT(*) FROM vegas_odds
    
    UNION ALL
    SELECT 'player_props', COUNT(*) FROM player_props
    
    UNION ALL
    SELECT 'situational_stats', COUNT(*) FROM situational_stats
    
    UNION ALL
    SELECT 'patterns', COUNT(*) FROM patterns
    
    UNION ALL
    SELECT 'daily_slates', COUNT(*) FROM daily_slates
    
    ORDER BY row_count DESC
""").fetchdf()

print("\n" + summary.to_string(index=False))

# Close connection
conn.close()

print("\n" + "="*80)
print("SETUP COMPLETE!")
print("="*80)

print("\nYour master database is ready at:")
print(f"  {DB_PATH}")

print("\nNext steps:")
print("  1. Set up API keys in config.py")
print("  2. Test: python query_library.py")
print("  3. Get data: python odds_api.py")

print("\n" + "="*80)
