#!/usr/bin/env python
"""
QUERY_LIBRARY.py

20+ Pre-built analytical queries for DFS edge discovery
Run these to find patterns, edges, and insights from your data
"""

import duckdb
import pandas as pd
from pathlib import Path

DB_PATH = 'data/dfs_master.duckdb'

class QueryLibrary:
    """Collection of analytical queries"""
    
    def __init__(self, db_path=DB_PATH):
        self.db_path = db_path
        self.conn = duckdb.connect(db_path, read_only=True)
    
    def close(self):
        self.conn.close()
    
    # =========================================================================
    # PLAYER PERFORMANCE QUERIES
    # =========================================================================
    
    def get_players_by_matchup(self, opponent, position=None, min_games=5):
        """Find players who dominate specific opponents"""
        
        query = """
        SELECT 
            player_name,
            position,
            COUNT(*) as games,
            AVG(dk_points) as avg_dk_pts,
            AVG(fd_points) as avg_fd_pts,
            MIN(dk_points) as min_pts,
            MAX(dk_points) as max_pts
        FROM player_game_logs
        WHERE opponent = ?
        """ + (f"AND position = '{position}'" if position else "") + f"""
        GROUP BY player_name, position
        HAVING games >= {min_games}
        ORDER BY avg_dk_pts DESC
        LIMIT 20
        """
        
        return self.conn.execute(query, [opponent]).fetchdf()
    
    def get_home_away_splits(self, player_name):
        """Analyze player's home vs away performance"""
        
        query = """
        SELECT 
            home_away,
            COUNT(*) as games,
            AVG(dk_points) as avg_dk_pts,
            STDDEV(dk_points) as std_dev,
            MIN(dk_points) as floor,
            MAX(dk_points) as ceiling
        FROM player_game_logs
        WHERE player_name = ?
        GROUP BY home_away
        """
        
        return self.conn.execute(query, [player_name]).fetchdf()
    
    def get_rest_day_impact(self, min_games=10):
        """Analyze impact of rest days on performance"""
        
        query = f"""
        SELECT 
            CASE 
                WHEN rest_days = 0 THEN 'Back-to-back'
                WHEN rest_days = 1 THEN '1 day rest'
                WHEN rest_days >= 2 AND rest_days <= 3 THEN '2-3 days'
                ELSE '4+ days'
            END as rest_category,
            COUNT(*) as games,
            AVG(dk_points) as avg_dk_pts,
            STDDEV(dk_points) as std_dev
        FROM player_game_logs
        WHERE rest_days IS NOT NULL
        GROUP BY rest_category
        HAVING games >= {min_games}
        ORDER BY 
            CASE rest_category
                WHEN 'Back-to-back' THEN 1
                WHEN '1 day rest' THEN 2
                WHEN '2-3 days' THEN 3
                ELSE 4
            END
        """
        
        return self.conn.execute(query).fetchdf()
    
    def get_recent_form(self, num_games=10):
        """Get players with best recent form"""
        
        query = f"""
        WITH recent_games AS (
            SELECT 
                player_name,
                team,
                date,
                dk_points,
                ROW_NUMBER() OVER (PARTITION BY player_name ORDER BY date DESC) as game_num
            FROM player_game_logs
            WHERE date >= CURRENT_DATE - INTERVAL '30 days'
        )
        SELECT 
            player_name,
            team,
            COUNT(*) as games,
            AVG(dk_points) as avg_recent_pts,
            MIN(dk_points) as floor,
            MAX(dk_points) as ceiling
        FROM recent_games
        WHERE game_num <= {num_games}
        GROUP BY player_name, team
        HAVING games >= {num_games - 2}
        ORDER BY avg_recent_pts DESC
        LIMIT 20
        """
        
        return self.conn.execute(query).fetchdf()
    
    # =========================================================================
    # TEAM DEFENSE QUERIES
    # =========================================================================
    
    def get_worst_defenses_by_position(self, position, sport='NBA'):
        """Find worst defenses vs specific position"""
        
        query = """
        WITH latest AS (
            SELECT MAX(date) as max_date 
            FROM team_defense_by_position
            WHERE sport = ?
        )
        SELECT 
            d.team,
            d.position,
            d.avg_fpts_allowed,
            d.rank,
            d.games_played
        FROM team_defense_by_position d
        JOIN latest l ON d.date = l.max_date
        WHERE d.position = ? AND d.sport = ?
        ORDER BY d.avg_fpts_allowed DESC
        LIMIT 10
        """
        
        return self.conn.execute(query, [sport, position, sport]).fetchdf()
    
    def get_defense_rankings_all_positions(self, sport='NBA'):
        """Get complete defense rankings"""
        
        query = """
        WITH latest AS (
            SELECT MAX(date) as max_date 
            FROM team_defense_by_position
            WHERE sport = ?
        )
        SELECT 
            d.position,
            d.team,
            d.avg_fpts_allowed,
            d.rank
        FROM team_defense_by_position d
        JOIN latest l ON d.date = l.max_date
        WHERE d.sport = ?
        ORDER BY d.position, d.rank
        """
        
        return self.conn.execute(query, [sport, sport]).fetchdf()
    
    # =========================================================================
    # GAME CONTEXT QUERIES
    # =========================================================================
    
    def get_high_total_games(self, min_total=230, days=30):
        """Find high-scoring game environments"""
        
        query = f"""
        SELECT 
            date,
            home_team,
            away_team,
            vegas_total,
            home_spread,
            total_score
        FROM games
        WHERE vegas_total >= {min_total}
          AND date >= CURRENT_DATE - INTERVAL '{days} days'
        ORDER BY vegas_total DESC
        LIMIT 20
        """
        
        return self.conn.execute(query).fetchdf()
    
    def get_pace_impact(self):
        """Analyze impact of game pace on scoring"""
        
        query = """
        WITH game_stats AS (
            SELECT 
                g.game_id,
                g.pace,
                AVG(l.dk_points) as avg_player_pts
            FROM games g
            JOIN player_game_logs l ON g.game_id = l.game_id
            WHERE g.pace IS NOT NULL
            GROUP BY g.game_id, g.pace
        )
        SELECT 
            CASE 
                WHEN pace < 95 THEN 'Slow (<95)'
                WHEN pace < 100 THEN 'Medium (95-100)'
                ELSE 'Fast (>100)'
            END as pace_category,
            COUNT(*) as games,
            AVG(avg_player_pts) as avg_pts_per_player
        FROM game_stats
        GROUP BY pace_category
        ORDER BY avg_pts_per_player DESC
        """
        
        return self.conn.execute(query).fetchdf()
    
    # =========================================================================
    # VALUE & PRICING QUERIES
    # =========================================================================
    
    def get_value_plays(self, max_salary=6000, min_avg_pts=25, sport='NBA'):
        """Find underpriced players"""
        
        query = f"""
        WITH recent_performance AS (
            SELECT 
                c.player_name,
                c.position,
                c.team,
                AVG(c.salary) as avg_salary,
                AVG(c.actual_fpts) as avg_actual,
                AVG(c.actual_fpts / (c.salary / 1000.0)) as value,
                COUNT(*) as contests
            FROM contest_results c
            WHERE c.sport = '{sport}'
              AND c.contest_date >= CURRENT_DATE - INTERVAL '30 days'
              AND c.salary <= {max_salary}
            GROUP BY c.player_name, c.position, c.team
            HAVING contests >= 5
        )
        SELECT 
            player_name,
            position,
            team,
            contests,
            ROUND(avg_salary, 0) as avg_salary,
            ROUND(avg_actual, 1) as avg_actual,
            ROUND(value, 2) as pts_per_1k
        FROM recent_performance
        WHERE avg_actual >= {min_avg_pts}
        ORDER BY value DESC
        LIMIT 20
        """
        
        return self.conn.execute(query).fetchdf()
    
    def get_salary_tier_efficiency(self, sport='NBA'):
        """Analyze value by salary tier"""
        
        query = f"""
        SELECT 
            CASE 
                WHEN salary >= 9000 THEN '$9K+'
                WHEN salary >= 8000 THEN '$8-9K'
                WHEN salary >= 7000 THEN '$7-8K'
                WHEN salary >= 6000 THEN '$6-7K'
                WHEN salary >= 5000 THEN '$5-6K'
                WHEN salary >= 4000 THEN '$4-5K'
                ELSE '<$4K'
            END as tier,
            COUNT(*) as contests,
            AVG(actual_fpts) as avg_actual,
            AVG(actual_fpts / (salary / 1000.0)) as avg_value,
            STDDEV(actual_fpts) as volatility
        FROM contest_results
        WHERE sport = '{sport}'
          AND salary IS NOT NULL
          AND contest_date >= CURRENT_DATE - INTERVAL '60 days'
        GROUP BY tier
        ORDER BY avg_value DESC
        """
        
        return self.conn.execute(query).fetchdf()
    
    # =========================================================================
    # PROJECTION ACCURACY QUERIES
    # =========================================================================
    
    def get_projection_accuracy_by_player(self, min_contests=5):
        """Find which players you project well/poorly"""
        
        query = f"""
        SELECT 
            player_name,
            position,
            COUNT(*) as contests,
            AVG(actual_fpts) as avg_actual,
            AVG(my_proj) as avg_my_proj,
            AVG(sabersim_proj) as avg_ss_proj,
            AVG(ABS(actual_fpts - my_proj)) as my_mae,
            AVG(ABS(actual_fpts - sabersim_proj)) as ss_mae,
            AVG(my_proj - actual_fpts) as my_bias
        FROM contest_results
        WHERE my_proj IS NOT NULL 
          AND sabersim_proj IS NOT NULL
        GROUP BY player_name, position
        HAVING contests >= {min_contests}
        ORDER BY my_mae ASC
        LIMIT 20
        """
        
        return self.conn.execute(query).fetchdf()
    
    def get_biggest_projection_misses(self, min_error=15):
        """Find games where projections were way off"""
        
        query = f"""
        SELECT 
            contest_date,
            player_name,
            position,
            team,
            opponent,
            salary,
            my_proj,
            sabersim_proj,
            actual_fpts,
            (actual_fpts - my_proj) as surprise,
            ABS(actual_fpts - my_proj) as abs_error
        FROM contest_results
        WHERE ABS(actual_fpts - my_proj) >= {min_error}
          AND my_proj IS NOT NULL
        ORDER BY abs_error DESC
        LIMIT 20
        """
        
        return self.conn.execute(query).fetchdf()
    
    # =========================================================================
    # SITUATIONAL QUERIES
    # =========================================================================
    
    def get_injury_beneficiaries(self, injured_player, min_games=3):
        """Find who benefits when a player is out"""
        
        # This requires injury data - placeholder for now
        query = f"""
        SELECT 
            'Feature requires injury tracking' as message
        """
        
        return self.conn.execute(query).fetchdf()
    
    def get_blowout_performance(self):
        """Analyze performance in blowouts vs close games"""
        
        query = """
        WITH game_scores AS (
            SELECT 
                g.game_id,
                ABS(g.home_score - g.away_score) as margin,
                l.player_name,
                l.dk_points
            FROM games g
            JOIN player_game_logs l ON g.game_id = l.game_id
            WHERE g.home_score IS NOT NULL 
              AND g.away_score IS NOT NULL
        )
        SELECT 
            CASE 
                WHEN margin <= 10 THEN 'Close game (<= 10)'
                WHEN margin <= 20 THEN 'Comfortable (11-20)'
                ELSE 'Blowout (>20)'
            END as game_type,
            COUNT(*) as performances,
            AVG(dk_points) as avg_dk_pts
        FROM game_scores
        GROUP BY game_type
        ORDER BY avg_dk_pts DESC
        """
        
        return self.conn.execute(query).fetchdf()
    
    # =========================================================================
    # VEGAS LINES QUERIES
    # =========================================================================
    
    def get_line_movement(self, days=7):
        """Track significant line movements"""
        
        query = f"""
        WITH line_changes AS (
            SELECT 
                game_id,
                MAX(total_movement) as total_move,
                MAX(spread_movement) as spread_move
            FROM vegas_odds
            WHERE timestamp >= CURRENT_TIMESTAMP - INTERVAL '{days} days'
            GROUP BY game_id
        )
        SELECT 
            v.game_id,
            v.date,
            l.total_move,
            l.spread_move,
            v.opening_total,
            v.current_total
        FROM vegas_odds v
        JOIN line_changes l ON v.game_id = l.game_id
        WHERE ABS(l.total_move) >= 3 OR ABS(l.spread_move) >= 2
        ORDER BY ABS(l.total_move) DESC
        """
        
        return self.conn.execute(query).fetchdf()
    
    # =========================================================================
    # PATTERN DISCOVERY
    # =========================================================================
    
    def discover_patterns(self):
        """Auto-discover patterns in the data"""
        
        patterns = []
        
        # Pattern 1: Position vs weak defenses
        weak_def = self.conn.execute("""
            WITH defense_ranks AS (
                SELECT team, position, rank
                FROM team_defense_by_position
                WHERE date = (SELECT MAX(date) FROM team_defense_by_position)
                  AND rank >= 25
            ),
            player_vs_weak AS (
                SELECT 
                    l.position,
                    AVG(l.dk_points) as avg_pts,
                    COUNT(*) as games
                FROM player_game_logs l
                JOIN defense_ranks d ON l.opponent = d.team AND l.position = d.position
                GROUP BY l.position
            )
            SELECT 
                position,
                ROUND(avg_pts, 1) as avg_vs_weak,
                games
            FROM player_vs_weak
            WHERE games >= 20
        """).fetchdf()
        
        patterns.append(('Position vs Weak Defense', weak_def))
        
        # Pattern 2: Rest advantage
        rest = self.get_rest_day_impact(min_games=50)
        patterns.append(('Rest Day Impact', rest))
        
        # Pattern 3: Salary tier value
        salary = self.get_salary_tier_efficiency()
        patterns.append(('Salary Tier Efficiency', salary))
        
        return patterns
    
    # =========================================================================
    # EXPORT FUNCTIONS
    # =========================================================================
    
    def export_all_patterns(self, output_dir='outputs/insights'):
        """Export all discovered patterns to files"""
        
        from pathlib import Path
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        print("\nDiscovering and exporting patterns...")
        
        patterns = self.discover_patterns()
        
        for name, df in patterns:
            filename = name.lower().replace(' ', '_') + '.csv'
            filepath = output_path / filename
            df.to_csv(filepath, index=False)
            print(f"  Exported: {filepath}")
        
        print(f"\n✅ All patterns exported to: {output_dir}")

# =============================================================================
# INTERACTIVE QUERY RUNNER
# =============================================================================

def run_interactive():
    """Interactive query runner"""
    
    print("="*80)
    print("QUERY LIBRARY - INTERACTIVE MODE")
    print("="*80)
    
    qlib = QueryLibrary()
    
    menu = """
    
AVAILABLE QUERIES:

1.  Players by Matchup
2.  Home/Away Splits
3.  Rest Day Impact
4.  Recent Form (Hot Players)
5.  Worst Defenses by Position
6.  High Total Games
7.  Value Plays
8.  Salary Tier Efficiency
9.  Projection Accuracy by Player
10. Biggest Projection Misses
11. Discover All Patterns
12. Export All Patterns
    
0. Exit
    """
    
    while True:
        print(menu)
        choice = input("Select query (0-12): ")
        
        if choice == '0':
            break
        
        elif choice == '1':
            opp = input("Enter opponent (e.g., ATL): ").upper()
            pos = input("Enter position (optional): ").upper() or None
            result = qlib.get_players_by_matchup(opp, pos)
            print("\n" + result.to_string(index=False))
        
        elif choice == '2':
            player = input("Enter player name: ")
            result = qlib.get_home_away_splits(player)
            print("\n" + result.to_string(index=False))
        
        elif choice == '3':
            result = qlib.get_rest_day_impact()
            print("\n" + result.to_string(index=False))
        
        elif choice == '4':
            result = qlib.get_recent_form()
            print("\n" + result.to_string(index=False))
        
        elif choice == '5':
            pos = input("Enter position (PG/SG/SF/PF/C): ").upper()
            result = qlib.get_worst_defenses_by_position(pos)
            print("\n" + result.to_string(index=False))
        
        elif choice == '6':
            result = qlib.get_high_total_games()
            print("\n" + result.to_string(index=False))
        
        elif choice == '7':
            result = qlib.get_value_plays()
            print("\n" + result.to_string(index=False))
        
        elif choice == '8':
            result = qlib.get_salary_tier_efficiency()
            print("\n" + result.to_string(index=False))
        
        elif choice == '9':
            result = qlib.get_projection_accuracy_by_player()
            print("\n" + result.to_string(index=False))
        
        elif choice == '10':
            result = qlib.get_biggest_projection_misses()
            print("\n" + result.to_string(index=False))
        
        elif choice == '11':
            patterns = qlib.discover_patterns()
            for name, df in patterns:
                print(f"\n{name}:")
                print(df.to_string(index=False))
        
        elif choice == '12':
            qlib.export_all_patterns()
        
        input("\nPress Enter to continue...")
    
    qlib.close()
    print("\nGoodbye!")

# =============================================================================
# MAIN
# =============================================================================

if __name__ == '__main__':
    run_interactive()
