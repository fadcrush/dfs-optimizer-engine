#!/usr/bin/env python3
"""
DFS Edge Pro — End-to-End Pipeline Smoke Test
==============================================

Exercises the full DB-first workflow:
  1. Upload FanDuel NBA projections CSV  →  /api/projections/upload-slate-to-db
  2. Upload ownership CSV                →  /api/ownership/upload-to-db
  3. Create optimizer run (inline)       →  POST /api/runs  (async_mode=false)
  4. Poll run status                     →  GET /api/runs/{run_id}/status
  5. Fetch lineups                       →  GET /api/results/{run_id}/lineups
  6. Fetch exposure                      →  GET /api/results/{run_id}/exposure
  7. Print summary metrics
  8. Exit non-zero on any failure

Usage:
    python scripts/verify_pipeline.py [--base-url http://localhost:8000] [--timeout 120]
"""
from __future__ import annotations

import argparse
import io
import json
import sys
import time
from typing import Any, Dict, Optional

# ---------------------------------------------------------------------------
# Optional dependency: try httpx, fall back to urllib
# ---------------------------------------------------------------------------
try:
    import httpx

    def _post_json(url: str, payload: dict, timeout: float = 30) -> Dict[str, Any]:
        r = httpx.post(url, json=payload, timeout=timeout)
        r.raise_for_status()
        return r.json()

    def _post_file(url: str, field: str, filename: str, content: bytes,
                   params: Optional[Dict] = None, timeout: float = 30) -> Dict[str, Any]:
        files = {field: (filename, io.BytesIO(content), "text/csv")}
        r = httpx.post(url, files=files, params=params or {}, timeout=timeout)
        r.raise_for_status()
        return r.json()

    def _get_json(url: str, timeout: float = 30) -> Dict[str, Any]:
        r = httpx.get(url, timeout=timeout)
        r.raise_for_status()
        return r.json()

except ImportError:
    import urllib.request
    import urllib.parse
    import urllib.error

    def _post_json(url: str, payload: dict, timeout: float = 30) -> Dict[str, Any]:  # type: ignore[misc]
        data = json.dumps(payload).encode()
        req = urllib.request.Request(
            url, data=data, headers={"Content-Type": "application/json"}, method="POST"
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read())

    def _post_file(url: str, field: str, filename: str, content: bytes,  # type: ignore[misc]
                   params: Optional[Dict] = None, timeout: float = 30) -> Dict[str, Any]:
        # minimal multipart/form-data
        boundary = "----VerifyPipelineBoundary"
        body = (
            f"--{boundary}\r\nContent-Disposition: form-data; "
            f'name="{field}"; filename="{filename}"\r\nContent-Type: text/csv\r\n\r\n'
        ).encode()
        body += content + f"\r\n--{boundary}--\r\n".encode()
        if params:
            url = f"{url}?{urllib.parse.urlencode(params)}"
        req = urllib.request.Request(
            url,
            data=body,
            headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read())

    def _get_json(url: str, timeout: float = 30) -> Dict[str, Any]:  # type: ignore[misc]
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            return json.loads(resp.read())


# ---------------------------------------------------------------------------
# Minimal FanDuel NBA slate CSV (8 players — enough for 1 lineup)
# ---------------------------------------------------------------------------

_FD_NBA_PROJECTIONS_CSV = b"""\
Nickname,Position,FPPG,Id,Salary,Team,Game,Opponent,Injury Indicator
LeBron James,SF,48.2,1001,9800,LAL,LAL@GSW,GSW,
Stephen Curry,PG,44.1,1002,9600,GSW,LAL@GSW,LAL,
Anthony Davis,C,42.7,1003,9400,LAL,LAL@GSW,GSW,
Klay Thompson,SG,33.5,1004,7200,GSW,LAL@GSW,LAL,
Draymond Green,PF,31.8,1005,7000,GSW,LAL@GSW,LAL,
Austin Reaves,SG,28.4,1006,6200,LAL,LAL@GSW,GSW,
D'Angelo Russell,PG,27.9,1007,6000,LAL,LAL@GSW,GSW,
Kevon Looney,C,22.1,1008,4800,GSW,LAL@GSW,LAL,
Rui Hachimura,PF,20.5,1009,4600,LAL,LAL@GSW,GSW,
Gui Santos,SF,18.3,1010,3500,GSW,LAL@GSW,LAL,
"""

_FD_NBA_OWNERSHIP_CSV = b"""\
Player,Own%
LeBron James,32.5
Stephen Curry,28.4
Anthony Davis,25.1
Klay Thompson,18.7
Draymond Green,15.3
Austin Reaves,12.8
D'Angelo Russell,11.4
Kevon Looney,8.2
Rui Hachimura,7.9
Gui Santos,5.1
"""


# ---------------------------------------------------------------------------
# ANSI colour helpers
# ---------------------------------------------------------------------------

GRN = "\033[92m"
RED = "\033[91m"
YLW = "\033[93m"
RST = "\033[0m"

def ok(msg: str) -> None:
    print(f"  {GRN}✓{RST}  {msg}")

def err(msg: str) -> None:
    print(f"  {RED}✗{RST}  {msg}", file=sys.stderr)

def hdr(msg: str) -> None:
    print(f"\n{YLW}▶ {msg}{RST}")


# ---------------------------------------------------------------------------
# Assertion helper
# ---------------------------------------------------------------------------

_failures: list[str] = []

def check(condition: bool, label: str, detail: str = "") -> bool:
    if condition:
        ok(label)
        return True
    msg = f"{label}" + (f": {detail}" if detail else "")
    err(msg)
    _failures.append(msg)
    return False


# ---------------------------------------------------------------------------
# Main pipeline steps
# ---------------------------------------------------------------------------

def step1_upload_projections(base: str, timeout: float) -> Optional[str]:
    hdr("Step 1 — Upload projections CSV")
    url = f"{base}/api/projections/upload-slate-to-db"
    try:
        resp = _post_file(url, "file", "verify_test_slate.csv", _FD_NBA_PROJECTIONS_CSV, timeout=timeout)
    except Exception as exc:
        check(False, "POST /projections/upload-slate-to-db", str(exc))
        return None

    slate_id = resp.get("slate_id")
    player_count = resp.get("player_count", 0)
    check(isinstance(slate_id, str) and len(slate_id) > 0, "Got slate_id", str(slate_id))
    check(player_count >= 8, f"player_count={player_count} (≥8)")
    print(f"     slate_id   = {slate_id}")
    print(f"     players    = {player_count}")
    print(f"     platform   = {resp.get('platform')}")
    print(f"     sport      = {resp.get('sport')}")
    return slate_id


def step2_upload_ownership(base: str, slate_id: str, timeout: float) -> bool:
    hdr("Step 2 — Upload ownership CSV")
    url = f"{base}/api/ownership/upload-to-db"
    try:
        resp = _post_file(
            url, "file", "verify_test_ownership.csv", _FD_NBA_OWNERSHIP_CSV,
            params={"slate_id": slate_id}, timeout=timeout,
        )
    except Exception as exc:
        check(False, "POST /ownership/upload-to-db", str(exc))
        return False

    matched = resp.get("matched", 0)
    check(matched >= 5, f"Ownership matched={matched} (≥5)")
    print(f"     matched    = {matched}")
    print(f"     unmatched  = {resp.get('unmatched', 0)}")
    return True


def step3_create_run(base: str, slate_id: str, timeout: float) -> Optional[str]:
    hdr("Step 3 — Create optimizer run (inline, 3 lineups)")
    url = f"{base}/api/runs"
    payload = {
        "slate_id": slate_id,
        "num_lineups": 3,
        "platform": "fanduel",
        "contest_type": "small_gpp",
        "max_exposure": 0.9,
        "min_salary": 49000,
        "max_salary": 60000,
        "async_mode": False,
    }
    try:
        resp = _post_json(url, payload, timeout=timeout)
    except Exception as exc:
        check(False, "POST /runs", str(exc))
        return None

    run_id = resp.get("run_id")
    status = resp.get("status", "")
    check(isinstance(run_id, str) and len(run_id) > 0, "Got run_id", str(run_id))
    check(status in ("queued", "running", "completed"), f"Initial status={status}")
    print(f"     run_id     = {run_id}")
    print(f"     status     = {status}")
    return run_id


def step4_poll_status(base: str, run_id: str, timeout: float) -> str:
    hdr("Step 4 — Poll run status until completion")
    deadline = time.time() + timeout
    last_status = "unknown"

    while time.time() < deadline:
        try:
            resp = _get_json(f"{base}/api/runs/{run_id}/status", timeout=10)
        except Exception as exc:
            print(f"     [warn] poll error: {exc}")
            time.sleep(2)
            continue

        last_status = resp.get("status", "unknown")
        num_lineups = resp.get("num_lineups", 0)
        print(f"     status={last_status}  lineups={num_lineups}", end="\r", flush=True)

        if last_status in ("completed", "failed"):
            print()  # newline after \r
            break
        time.sleep(2)

    check(last_status == "completed", f"Run completed (status={last_status})")
    return last_status


def step5_fetch_lineups(base: str, run_id: str, timeout: float) -> int:
    hdr("Step 5 — Fetch lineups")
    try:
        resp = _get_json(f"{base}/api/results/{run_id}/lineups", timeout=timeout)
    except Exception as exc:
        check(False, "GET /results/{run_id}/lineups", str(exc))
        return 0

    total = resp.get("total_lineups", 0)
    lineups = resp.get("lineups", [])
    check(total >= 1, f"total_lineups={total}")
    check(len(lineups) == total, f"lineups array length={len(lineups)} matches total")

    if lineups:
        sample = lineups[0]
        check("players" in sample, "Lineup has 'players' field")
        player_count = len(sample.get("players", []))
        check(player_count >= 5, f"Lineup 1 has {player_count} players")
        print(f"     total_lineups = {total}")
        print(f"     lineup[0] players = {player_count}")
        print(f"     lineup[0] salary  = {sample.get('total_salary')}")
        print(f"     lineup[0] proj    = {sample.get('total_projection')}")
    return total


def step6_fetch_exposure(base: str, run_id: str, total_lineups: int, timeout: float) -> bool:
    hdr("Step 6 — Fetch exposure")
    try:
        resp = _get_json(f"{base}/api/results/{run_id}/exposure", timeout=timeout)
    except Exception as exc:
        check(False, "GET /results/{run_id}/exposure", str(exc))
        return False

    players = resp.get("players", [])
    resp_total = resp.get("total_lineups", 0)

    check(len(players) >= 1, f"exposure has {len(players)} player rows")
    check(resp_total == total_lineups, f"exposure total_lineups={resp_total} matches run ({total_lineups})")

    if players:
        top = players[0]
        check("exposure_pct" in top, "Player row has exposure_pct")
        check("name" in top, "Player row has name")
        print(f"     top player     = {top.get('name')}  ({top.get('exposure_pct', 0)*100:.0f}%)")
    return True


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> int:
    parser = argparse.ArgumentParser(description="DFS Edge Pro pipeline smoke test")
    parser.add_argument("--base-url", default="http://localhost:8000", help="API base URL")
    parser.add_argument("--timeout", type=float, default=120.0, help="Per-step timeout (seconds)")
    args = parser.parse_args()

    base = args.base_url.rstrip("/")
    timeout = args.timeout

    print(f"\n{'='*60}")
    print("  DFS EDGE PRO — PIPELINE VERIFICATION")
    print(f"  Target: {base}")
    print(f"{'='*60}")

    # ── Pre-flight: check server is up ─────────────────────────────────────
    hdr("Pre-flight — Health check")
    try:
        health = _get_json(f"{base}/api/health", timeout=5)
        ok(f"Server responded: {health.get('status')}")
    except Exception as exc:
        err(f"Server not reachable at {base}: {exc}")
        print("\n  → Start the server first:  uvicorn main:app --port 8000\n")
        return 1

    # ── Pipeline steps ──────────────────────────────────────────────────────
    slate_id = step1_upload_projections(base, timeout)
    if not slate_id:
        _print_summary()
        return 1

    step2_upload_ownership(base, slate_id, timeout)

    run_id = step3_create_run(base, slate_id, timeout)
    if not run_id:
        _print_summary()
        return 1

    status = step4_poll_status(base, run_id, timeout)

    total_lineups = 0
    if status == "completed":
        total_lineups = step5_fetch_lineups(base, run_id, timeout)
        step6_fetch_exposure(base, run_id, total_lineups, timeout)
    else:
        check(False, f"Run did not complete (status={status}) — skipping lineups/exposure")

    return _print_summary()


def _print_summary() -> int:
    print(f"\n{'='*60}")
    if _failures:
        print(f"  {RED}FAILED{RST} — {len(_failures)} assertion(s) failed:")
        for f in _failures:
            print(f"    • {f}")
        print(f"{'='*60}\n")
        return 1
    else:
        print(f"  {GRN}ALL CHECKS PASSED{RST}")
        print(f"{'='*60}\n")
        return 0


if __name__ == "__main__":
    sys.exit(main())
