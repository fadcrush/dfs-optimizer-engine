#!/usr/bin/env python
"""
DEBUG_OPTIMIZER.py

Debug the lineup optimizer to see why it's failing.
Then generate lineups with more relaxed constraints.
"""

import pandas as pd
from pathlib import Path

print("="*80)
print("DEBUGGING LINEUP OPTIMIZER")
print("="*80)

# Find latest files
outputs_dir = Path('outputs')

# Find latest projections
proj_files = sorted(outputs_dir.glob('projections_today*.csv'), 
                   key=lambda p: p.stat().st_mtime, reverse=True)

if not proj_files:
    print("\n[ERROR] No projection files found!")
    exit(1)

proj_file = proj_files[0]
print(f"\nLoading projections: {proj_file.name}")

df = pd.read_csv(proj_file)

print(f"\nTotal players: {len(df)}")
print(f"\nColumns: {list(df.columns)}")

# Check salary distribution
print(f"\nSALARY DISTRIBUTION:")
print(df['Salary'].describe())

# Check position distribution
print(f"\nPOSITION DISTRIBUTION:")
print(df['Position'].value_counts())

# Check projections
print(f"\nPROJECTION DISTRIBUTION:")
if 'Projection' in df.columns:
    print(df['Projection'].describe())
elif 'FD_Projection' in df.columns:
    print(df['FD_Projection'].describe())

# Test a simple lineup
print(f"\n{'='*80}")
print("TESTING LINEUP FEASIBILITY")
print(f"{'='*80}")

# FanDuel requirements:
# - 2 PG
# - 2 SG  
# - 2 SF
# - 2 PF
# - 1 C
# - Salary: $60,000

# Check if we have enough players per position
for pos in ['PG', 'SG', 'SF', 'PF', 'C']:
    # Count players that have this position
    count = df[df['Position'].str.contains(pos, na=False)].shape[0]
    print(f"{pos}: {count} players available")

# Check multi-position flexibility
print(f"\nMULTI-POSITION PLAYERS:")
multi_pos = df[df['Position'].str.contains('/', na=False)]
print(f"Total: {len(multi_pos)}")
print(multi_pos[['Name', 'Position', 'Salary']].head(10))

# Try to build a simple lineup manually
print(f"\n{'='*80}")
print("ATTEMPTING MANUAL LINEUP BUILD")
print(f"{'='*80}")

def can_play_position(player_positions, target_position):
    """Check if player can play target position"""
    return target_position in player_positions.split('/')

# Sort by projection
proj_col = 'Projection' if 'Projection' in df.columns else 'FD_Projection'
df_sorted = df.sort_values(proj_col, ascending=False)

lineup = []
salary_used = 0
positions_needed = {'PG': 2, 'SG': 2, 'SF': 2, 'PF': 2, 'C': 1}

for _, player in df_sorted.iterrows():
    if salary_used >= 60000:
        break
    
    player_pos = player['Position']
    
    # Check if we need any position this player can fill
    for pos in positions_needed:
        if positions_needed[pos] > 0 and can_play_position(player_pos, pos):
            # Can we afford this player?
            if salary_used + player['Salary'] <= 60000:
                lineup.append({
                    'Name': player['Name'],
                    'Position': player_pos,
                    'FilledAs': pos,
                    'Salary': player['Salary'],
                    'Projection': player[proj_col]
                })
                salary_used += player['Salary']
                positions_needed[pos] -= 1
                break
    
    # Check if done
    if all(v == 0 for v in positions_needed.values()):
        break

print(f"\nLineup attempt:")
print(f"Players: {len(lineup)}/9")
print(f"Salary: ${salary_used:,}/60,000")
print(f"Positions still needed: {positions_needed}")

if len(lineup) == 9:
    print(f"\n[OK] Successfully built a lineup manually!")
    print(f"\nLineup:")
    for i, player in enumerate(lineup, 1):
        print(f"{i}. {player['Name']:20} {player['FilledAs']:2} ${player['Salary']:>6,} {player['Projection']:>5.1f} pts")
    print(f"\nTotal Salary: ${salary_used:,}")
    total_proj = sum(p['Projection'] for p in lineup)
    print(f"Total Projection: {total_proj:.1f} pts")
    
    print(f"\n[OK] Lineup optimizer SHOULD work!")
    print(f"\nPossible issues:")
    print(f"1. Optimizer min salary set too high ($49,000 default)")
    print(f"2. Exposure limits too restrictive")
    print(f"3. Leverage requirements filtering out valid players")
    
    print(f"\nTRY THIS:")
    print(f"  python scripts/optimization/nba_lineup_optimizer.py \\")
    print(f'    "slates\\nba\\FanDuel-NBA-2026 EST-01 EST-03 EST-125143-players-list.csv" \\')
    print(f"    --num-lineups 150 --strategy balanced --min-salary 40000")
    
else:
    print(f"\n[ERROR] Could not build valid lineup!")
    print(f"Missing positions: {[k for k,v in positions_needed.items() if v > 0]}")
    print(f"\nThis explains why the optimizer failed.")

print(f"\n{'='*80}")
