#!/usr/bin/env python
"""
INGEST_CONTEST_RESULTS.py

Ingests contest result files that contain:
- Actual fantasy points
- Your projections
- SaberSim projections
- Ownership data
- Predicted stats

This is GOLD for backtesting!
"""

import duckdb
import pandas as pd
from pathlib import Path
import re

print("="*80)
print("CONTEST RESULTS INGESTION - PRO LEVEL DATA")
print("="*80)

# Configuration
DB_PATH = 'data/dfs_warehouse.duckdb'

# Connect to DuckDB
print(f"\nConnecting to: {DB_PATH}")
conn = duckdb.connect(DB_PATH)

# Create enhanced schema for contest data
print("\nCreating enhanced schema...")

conn.execute("""
CREATE TABLE IF NOT EXISTS contest_results (
    result_id INTEGER PRIMARY KEY,
    
    -- Identifiers
    dfs_id VARCHAR,
    player_name VARCHAR NOT NULL,
    position VARCHAR,
    team VARCHAR,
    opponent VARCHAR,
    status VARCHAR,
    salary INTEGER,
    
    -- Contest info
    contest_date DATE,
    platform VARCHAR,  -- DK, FD, etc
    sport VARCHAR,     -- NBA, NFL
    slate_type VARCHAR, -- Main, Early, etc
    
    -- Performance
    actual_fpts FLOAT NOT NULL,
    
    -- Projections
    sabersim_proj FLOAT,
    live_proj FLOAT,
    my_proj FLOAT,
    
    -- Value metrics
    value_metric FLOAT,  -- actual / (salary / 1000)
    
    -- Ownership
    my_ownership FLOAT,
    adj_ownership FLOAT,
    min_exposure FLOAT,
    max_exposure FLOAT,
    
    -- Team totals
    saber_team_total FLOAT,
    saber_game_total FLOAT,
    
    -- Percentiles (DK)
    dk_25th FLOAT,
    dk_50th FLOAT,
    dk_75th FLOAT,
    dk_85th FLOAT,
    dk_95th FLOAT,
    dk_99th FLOAT,
    dk_std FLOAT,
    
    -- Percentiles (FD)
    fd_25th FLOAT,
    fd_50th FLOAT,
    fd_75th FLOAT,
    fd_85th FLOAT,
    fd_95th FLOAT,
    fd_99th FLOAT,
    fd_std FLOAT,
    
    -- Predicted stats (NBA)
    pred_pts FLOAT,
    pred_min FLOAT,
    pred_2pt FLOAT,
    pred_3pt FLOAT,
    pred_reb FLOAT,
    pred_off_reb FLOAT,
    pred_def_reb FLOAT,
    pred_ast FLOAT,
    pred_stl FLOAT,
    pred_blk FLOAT,
    pred_to FLOAT,
    
    -- Predicted stats (NFL)
    pred_pass_att FLOAT,
    pred_pass_comp FLOAT,
    pred_pass_yds FLOAT,
    pred_pass_td FLOAT,
    pred_pass_int FLOAT,
    pred_rec FLOAT,
    pred_rec_yds FLOAT,
    pred_rec_td FLOAT,
    pred_rush_att FLOAT,
    pred_rush_yds FLOAT,
    pred_rush_td FLOAT,
    
    -- Metadata
    loaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    source_file VARCHAR
);
""")

print("  [OK] Enhanced schema created")

# Ingestion function
def ingest_contest_file(file_path, platform, sport):
    """Ingest a single contest results file"""
    
    print(f"\n  Processing: {file_path.name}")
    
    # Read file
    if file_path.suffix == '.xlsx':
        df = pd.read_excel(file_path)
    else:
        df = pd.read_csv(file_path)
    
    print(f"    Loaded {len(df)} rows")
    print(f"    Columns: {len(df.columns)}")
    
    # Extract date from filename if possible
    # Format: NBA_2025-11-13-700pm_DK_Main.csv
    try:
        date_match = re.search(r'(\d{4}-\d{2}-\d{2})', file_path.name)
        if date_match:
            contest_date = date_match.group(1)
        else:
            contest_date = None
    except:
        contest_date = None
    
    # Extract slate type
    if 'Main' in file_path.name:
        slate_type = 'Main'
    elif 'Early' in file_path.name:
        slate_type = 'Early'
    elif 'Night' in file_path.name:
        slate_type = 'Night'
    elif 'SHOWDOWN' in file_path.name:
        slate_type = 'Showdown'
    else:
        slate_type = 'Unknown'
    
    # Standardize column names (handle variations)
    col_mapping = {
        'DFS ID': 'dfs_id',
        'Name': 'player_name',
        'Pos': 'position',
        'Team': 'team',
        'Opp': 'opponent',
        'Status': 'status',
        'Salary': 'salary',
        
        # Performance
        'Actual': 'actual_fpts',
        'actual fantasy points': 'actual_fpts',
        
        # Projections
        'SS Proj': 'sabersim_proj',
        'sabersim Fantasy projections': 'sabersim_proj',
        'Live Proj': 'live_proj',
        'live/actual fantasy points': 'live_proj',
        'My Proj': 'my_proj',
        'Fantasy projections': 'my_proj',
        
        # Value
        'Value': 'value_metric',
        
        # Ownership
        'My Own': 'my_ownership',
        'Ownership': 'my_ownership',
        'Adj Own': 'adj_ownership',
        'AdjustedOwnership': 'adj_ownership',
        'Min Exp': 'min_exposure',
        'Max Exp': 'max_exposure',
        
        # Team totals
        'Saber Team': 'saber_team_total',
        'Saber Total': 'saber_game_total',
        
        # DK percentiles
        'dk_25_percentile': 'dk_25th',
        'dk_50_percentile': 'dk_50th',
        'dk_75_percentile': 'dk_75th',
        'dk_85_percentile': 'dk_85th',
        'dk_95_percentile': 'dk_95th',
        'dk_99_percentile': 'dk_99th',
        'dk_std': 'dk_std',
        
        # FD percentiles
        'fd_25_percentile': 'fd_25th',
        'fd_50_percentile': 'fd_50th',
        'fd_75_percentile': 'fd_75th',
        'fd_85_percentile': 'fd_85th',
        'fd_95_percentile': 'fd_95th',
        'fd_99_percentile': 'fd_99th',
        'fd_std': 'fd_std',
    }
    
    # NBA stats
    if sport == 'NBA':
        col_mapping.update({
            'PTS': 'pred_pts',
            'Predicted Actual points': 'pred_pts',
            'Min': 'pred_min',
            'predicted actual minutes': 'pred_min',
            '2PT': 'pred_2pt',
            'predicted actual 2 point shots': 'pred_2pt',
            '3PT': 'pred_3pt',
            'predicted actual 3 point shots': 'pred_3pt',
            'RB': 'pred_reb',
            'predicted actual rebounds': 'pred_reb',
            'Off Reb': 'pred_off_reb',
            'predicted actual offensive rebounds': 'pred_off_reb',
            'Def Reb': 'pred_def_reb',
            'predicted actual defensive rebounds': 'pred_def_reb',
            'AST': 'pred_ast',
            'predicted actual assist': 'pred_ast',
            'STL': 'pred_stl',
            'predicted actual steals': 'pred_stl',
            'BLK': 'pred_blk',
            'predicted actual blocks': 'pred_blk',
            'TO': 'pred_to',
            'predicted actual turnovers': 'pred_to',
        })
    
    # NFL stats
    if sport == 'NFL':
        col_mapping.update({
            'Pass Att': 'pred_pass_att',
            'Predicted Actual pass attempts': 'pred_pass_att',
            'Completions': 'pred_pass_comp',
            'predicted actual pass completions': 'pred_pass_comp',
            'Pass Yds': 'pred_pass_yds',
            'predicted actual pass yards': 'pred_pass_yds',
            'Pass TD': 'pred_pass_td',
            'predicted actual pass td': 'pred_pass_td',
            'Pass Int': 'pred_pass_int',
            'predicted actual pass interception': 'pred_pass_int',
            'Rec': 'pred_rec',
            'predicted actual pass receptions': 'pred_rec',
            'Rec Yds': 'pred_rec_yds',
            'predicted actual pass receiving yards': 'pred_rec_yds',
            'Rec TD': 'pred_rec_td',
            'predicted actual pass receiving touchdowns': 'pred_rec_td',
            'Rush Att': 'pred_rush_att',
            'predicted actual rushing attempts': 'pred_rush_att',
            'Rush Yds': 'pred_rush_yds',
            'predicted actual rushing yards': 'pred_rush_yds',
            'Rush TD': 'pred_rush_td',
            'predicted actual rushing touchdowns': 'pred_rush_td',
        })
    
    # Rename columns
    df = df.rename(columns=col_mapping)
    
    # Add metadata
    df['contest_date'] = contest_date
    df['platform'] = platform
    df['sport'] = sport
    df['slate_type'] = slate_type
    df['source_file'] = file_path.name
    
    # Filter to only players with actual points
    df = df[df['actual_fpts'].notna()]
    
    if len(df) == 0:
        print("    [SKIP] No valid data")
        return 0
    
    # Insert into database
    conn.execute("""
        INSERT INTO contest_results 
        SELECT NULL as result_id, * FROM df
    """)
    
    print(f"    [OK] Inserted {len(df)} players")
    
    return len(df)

# Find contest result files
print("\n" + "="*80)
print("SEARCHING FOR CONTEST RESULT FILES")
print("="*80)

contest_files = {
    'NBA_DK': [],
    'NBA_FD': [],
    'NFL_DK': [],
    'NFL_FD': [],
}

# Search in current directory and subdirectories
for pattern in ['*.csv', '*.xlsx']:
    for file_path in Path('.').rglob(pattern):
        name = file_path.name.upper()
        
        # Skip if in specific data directories (already processed)
        if any(x in str(file_path) for x in ['DK_NBA_Past_Games', 'DK_NFL_Past_Games', 
                                               'FD_NBA_Past_Games', 'FD_NFL_Past_Games']):
            continue
        
        # Identify sport and platform
        if 'NBA' in name:
            if 'DK' in name or 'DRAFTKINGS' in name:
                contest_files['NBA_DK'].append(file_path)
            elif 'FD' in name or 'FANDUEL' in name:
                contest_files['NBA_FD'].append(file_path)
        elif 'NFL' in name:
            if 'DK' in name or 'DRAFTKINGS' in name:
                contest_files['NFL_DK'].append(file_path)
            elif 'FD' in name or 'FANDUEL' in name:
                contest_files['NFL_FD'].append(file_path)

# Display found files
for key, files in contest_files.items():
    if files:
        print(f"\n{key}: {len(files)} files")
        for f in files[:5]:
            print(f"  - {f}")
        if len(files) > 5:
            print(f"  ... and {len(files)-5} more")

# Ingest all files
print("\n" + "="*80)
print("INGESTING CONTEST RESULTS")
print("="*80)

total_ingested = 0

for key, files in contest_files.items():
    if not files:
        continue
    
    sport, platform = key.split('_')
    
    print(f"\n{platform} {sport}")
    print("-" * 40)
    
    for file_path in files:
        try:
            rows = ingest_contest_file(file_path, platform, sport)
            total_ingested += rows
        except Exception as e:
            print(f"  [ERROR] {file_path.name}: {str(e)[:100]}")

# Summary
print("\n" + "="*80)
print("INGESTION COMPLETE!")
print("="*80)

print(f"\nTotal players ingested: {total_ingested:,}")

if total_ingested > 0:
    summary = conn.execute("""
        SELECT 
            platform,
            sport,
            COUNT(*) as num_players,
            COUNT(DISTINCT player_name) as unique_players,
            COUNT(DISTINCT contest_date) as num_dates,
            ROUND(AVG(actual_fpts), 1) as avg_actual,
            ROUND(AVG(my_proj), 1) as avg_my_proj,
            ROUND(AVG(sabersim_proj), 1) as avg_ss_proj,
            ROUND(AVG(ABS(actual_fpts - my_proj)), 1) as my_mae,
            ROUND(AVG(ABS(actual_fpts - sabersim_proj)), 1) as ss_mae
        FROM contest_results
        WHERE my_proj IS NOT NULL
        GROUP BY platform, sport
    """).fetchdf()
    
    print("\nDatabase Summary:")
    print(summary.to_string(index=False))
    
    # Quick insights
    print("\n" + "="*80)
    print("QUICK INSIGHTS")
    print("="*80)
    
    # Overall accuracy
    overall = conn.execute("""
        SELECT 
            ROUND(AVG(ABS(actual_fpts - my_proj)), 2) as my_mae,
            ROUND(AVG(ABS(actual_fpts - sabersim_proj)), 2) as ss_mae,
            ROUND(AVG(my_proj - actual_fpts), 2) as my_bias,
            ROUND(AVG(sabersim_proj - actual_fpts), 2) as ss_bias
        FROM contest_results
        WHERE my_proj IS NOT NULL AND sabersim_proj IS NOT NULL
    """).fetchone()
    
    if overall:
        my_mae, ss_mae, my_bias, ss_bias = overall
        print(f"\nYour Projection Accuracy:")
        print(f"  MAE: {my_mae:.2f} points")
        print(f"  Bias: {my_bias:+.2f} points")
        
        print(f"\nSaberSim Accuracy:")
        print(f"  MAE: {ss_mae:.2f} points")
        print(f"  Bias: {ss_bias:+.2f} points")
        
        if my_mae < ss_mae:
            diff = ss_mae - my_mae
            print(f"\n🎉 YOU BEAT SABERSIM by {diff:.2f} points MAE!")
        else:
            diff = my_mae - ss_mae
            print(f"\n📊 SaberSim beat you by {diff:.2f} points MAE")
            print("     (But now you can learn why!)")

conn.close()

print("\n" + "="*80)
print("READY FOR PRO-LEVEL ANALYSIS!")
print("="*80)

print("\nYou can now:")
print("  1. Compare your projections vs SaberSim")
print("  2. Analyze ownership accuracy")
print("  3. Find mispriced players")
print("  4. Validate percentile distributions")
print("  5. Discover systematic biases")

print("\nNext: Create custom analysis queries!")

print("\n" + "="*80)
