"""
Generate player features for modeling
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from data_warehouse.features.player_features import PlayerFeatureEngineer
from data_warehouse.utils.logger import get_logger

logger = get_logger(__name__)


def main():
    """Generate features"""
    
    print("="*80)
    print("DFS DATA WAREHOUSE - FEATURE GENERATION")
    print("="*80)
    
    # Create feature engineer
    engineer = PlayerFeatureEngineer(db_type='duckdb')
    
    # Generate NBA features
    print("\nGenerating NBA features...")
    nba_features = engineer.generate_all_features('NBA')
    
    # Generate NFL features
    print("\nGenerating NFL features...")
    nfl_features = engineer.generate_all_features('NFL')
    
    print("\n" + "="*80)
    print("FEATURE GENERATION COMPLETE")
    print("="*80)
    print(f"\nNBA features: {len(nba_features)} players")
    print(f"NFL features: {len(nfl_features)} players")
    print("\nFeatures saved to data/features/")


if __name__ == '__main__':
    main()