#!/usr/bin/env python
"""
Quick Launcher: Automated Workflow
One command to run everything!
"""
import sys
from pathlib import Path

# Add scripts to path
sys.path.insert(0, str(Path(__file__).parent / 'scripts' / 'automation'))

# Import and run
from auto_injury_workflow import main

if __name__ == "__main__":
    main()
