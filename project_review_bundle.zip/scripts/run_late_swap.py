#!/usr/bin/env python
"""
Quick Launcher: Late Swap Assistant
Monitor and swap during games
"""
import sys
from pathlib import Path

# Add scripts to path
sys.path.insert(0, str(Path(__file__).parent / 'scripts' / 'gameday'))

# Import and run
from nba_late_swap_assistant import main

if __name__ == "__main__":
    main()
