# DFS Edge Pro — Deploy Checklist

Use this checklist every time you promote a new build to production or
a new environment. Check each item before marking the deployment complete.

---

## 1 — Prerequisites

- [ ] `SECRET_KEY` set to a random 64-char string (`openssl rand -hex 32`)
- [ ] `JWT_SECRET_KEY` set (same method)
- [ ] `DATABASE_URL` points to production PostgreSQL
- [ ] `REDIS_URL` points to production Redis
- [ ] `ALLOWED_ORIGINS` lists your frontend domain(s), comma-separated
- [ ] `DB_REQUIRED=true` is set in the backend service environment
- [ ] `.env` is **NOT** committed to source control

---

## 2 — Docker Build

```bash
# Build backend image
docker build -t dfs-backend:latest ./backend

# Build worker image (same Dockerfile)
docker build -t dfs-worker:latest ./backend

# (Optional) Build frontend image
docker build -t dfs-frontend:latest ./frontend
```

Verify image builds without errors before proceeding.

---

## 3 — Compose Stack Start

```bash
# Pull base images first
docker compose pull postgres redis

# Start infrastructure only first
docker compose up -d postgres redis

# Wait for readiness
docker compose exec backend bash scripts/wait_for_services.sh
# or on the host:
docker run --rm --network $(docker inspect -f '{{.Name}}' $(docker compose ps -q postgres) | cut -d/ -f2) \
  postgres:16-alpine pg_isready -h postgres -U dfs -d dfs_db
```

---

## 4 — Database Migration

```bash
# Run Alembic migrations (must succeed before starting backend)
docker compose run --rm backend alembic -c alembic.ini upgrade head

# Verify applied revision
docker compose run --rm backend alembic -c alembic.ini current
# Expected output: <revision_hash> (head)
```

If `alembic upgrade head` fails, **do not start the backend**. Fix the migration first.

---

## 5 — Start All Services

```bash
docker compose up -d
```

Expected container states after `docker compose ps`:
| Service | State |
|----------|-------|
| postgres | Up (healthy) |
| redis | Up (healthy) |
| backend | Up |
| worker | Up |
| frontend | Up (if using) |

---

## 6 — Health Checks

```bash
# Liveness
curl -sf http://localhost:8000/api/health | jq .

# DB schema health
curl -sf http://localhost:8000/api/health/db | jq .
# Expect: {"status":"ok", "missing_tables":[], "alembic_revision":"<hash>"}

# Metrics
curl -sf http://localhost:8000/api/health/metrics | jq .

# OpenAPI spec (proves all routers loaded)
curl -sf http://localhost:8000/api/openapi.json | jq .info.version
```

---

## 7 — Pipeline Smoke Test

```bash
# From the project root
python scripts/verify_pipeline.py --base-url http://localhost:8000

# Expected output: ALL CHECKS PASSED
# Exit code 0 = pass, non-zero = failure (do not consider deploy done)
```

---

## 8 — Worker Verification

```bash
# Confirm worker is processing (check logs for "run_optimizer_task completed")
docker compose logs --tail=50 worker

# Submit a test run and check it transitions to completed
curl -s -X POST http://localhost:8000/api/runs \
  -H 'Content-Type: application/json' \
  -d '{"slate_id":"<valid-slate-id>","num_lineups":3,"async_mode":true}' \
  | jq .run_id
# Then poll:
curl -s http://localhost:8000/api/runs/<run_id>/status | jq .
```

---

## 9 — CORS Verification

```bash
# Verify CORS headers are present and match ALLOWED_ORIGINS
curl -si -X OPTIONS http://localhost:8000/api/runs \
  -H 'Origin: https://your-frontend-domain.com' \
  -H 'Access-Control-Request-Method: POST' \
  | grep -i access-control
```

---

## 10 — Post-Deploy

- [ ] Monitor error rate for first 15 minutes via logs
- [ ] Confirm `runs_completed` counter is incrementing in `/api/health/metrics`
- [ ] Set up log rotation if running without a log aggregator
- [ ] Update `CHANGELOG.md` / deployment log with revision hash

---

## Rollback Procedure

```bash
# If migration caused schema breakage:
docker compose run --rm backend alembic -c alembic.ini downgrade -1

# Redeploy previous image:
docker compose down backend worker
docker compose up -d  # with previous TAG set in .env
```

---

## Environment Variable Reference

| Variable                    | Required    | Default        | Notes                   |
| --------------------------- | ----------- | -------------- | ----------------------- |
| `DATABASE_URL`              | Yes         | —              | PostgreSQL DSN          |
| `REDIS_URL`                 | Yes         | —              | Redis DSN               |
| `SECRET_KEY`                | Yes         | —              | Min 32 chars            |
| `JWT_SECRET_KEY`            | Yes         | —              | Min 32 chars            |
| `DB_REQUIRED`               | Recommended | `false`        | Set `true` in prod      |
| `ALLOWED_ORIGINS`           | Yes         | localhost:3000 | Comma-separated         |
| `ENVIRONMENT`               | No          | development    | Set `production`        |
| `LOG_LEVEL`                 | No          | INFO           | DEBUG/INFO/WARNING      |
| `UPLOAD_MAX_AGE_HOURS`      | No          | 24             | Purge old uploads       |
| `OPTIMIZER_TIMEOUT_SECONDS` | No          | 300            | Inline run timeout      |
| `INJURY_DATA_REQUIRED`      | No          | false          | Fail if enrichment down |
| `SPORTSDATA_API_KEY`        | No          | —              | Real-time injury data   |

See `config/env.template` for all variables.
