"""
Setup database schema
Run this first to initialize the warehouse
"""

import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from data_warehouse.core.database import WarehouseManager
from data_warehouse.utils.logger import get_logger

logger = get_logger(__name__)


def main():
    """Setup database"""
    
    print("="*80)
    print("DFS DATA WAREHOUSE - DATABASE SETUP")
    print("="*80)
    
    # Initialize warehouse (using DuckDB by default)
    warehouse = WarehouseManager(db_type='duckdb')
    
    # Create schema
    logger.info("Creating database schema...")
    warehouse.initialize_schema()
    
    # Verify tables
    logger.info("\nVerifying tables...")
    stats = warehouse.get_table_stats()
    
    for table, info in stats.items():
        status = "✓" if info['exists'] else "✗"
        print(f"  {status} {table}")
    
    print("\n" + "="*80)
    print("DATABASE SETUP COMPLETE")
    print("="*80)
    
    warehouse.close()


if __name__ == '__main__':
    main()