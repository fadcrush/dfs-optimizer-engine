import os
import zipfile
from pathlib import Path

# =============================
# CONFIG
# =============================

PROJECT_ROOT = Path(".").resolve()
OUTPUT_ZIP = PROJECT_ROOT / "project_review_bundle.zip"

# Folders to INCLUDE (if they exist)
INCLUDE_DIRS = [
    "backend",
    "frontend",
    "alembic",
    "scripts",
    "tests",
    "docs",
    ".github",
]

# Files to INCLUDE at root
INCLUDE_FILES = [
    "docker-compose.yml",
    "Dockerfile",
    "requirements.txt",
    "pyproject.toml",
    "README.md",
    "ARCHITECTURE.md",
    "ARCHITECTURE_PLAN.md",
    "DATABASE_SCHEMA.sql",
    ".env.example",
    "config.py",
]

# Patterns to EXCLUDE
EXCLUDE_DIRS = {
    ".venv",
    "venv",
    ".git",
    ".pytest_cache",
    "__pycache__",
    "node_modules",
    ".mypy_cache",
    ".ruff_cache",
    "dist",
    "build",
    ".idea",
    ".vscode",
}

EXCLUDE_EXTENSIONS = {
    ".pyc",
    ".pyo",
    ".log",
    ".sqlite",
    ".db",
    ".duckdb",
    ".zip",
}

MAX_FILE_SIZE_MB = 10  # Skip very large files


# =============================
# HELPERS
# =============================

def should_skip(path: Path) -> bool:
    """Determine if file should be skipped."""
    if any(part in EXCLUDE_DIRS for part in path.parts):
        return True

    if path.suffix.lower() in EXCLUDE_EXTENSIONS:
        return True

    if path.is_file():
        size_mb = path.stat().st_size / (1024 * 1024)
        if size_mb > MAX_FILE_SIZE_MB:
            return True

    return False


def add_path(zipf: zipfile.ZipFile, path: Path):
    """Add file to zip preserving relative path."""
    arcname = path.relative_to(PROJECT_ROOT)
    zipf.write(path, arcname)


# =============================
# ZIP CREATION
# =============================

def create_zip():
    if OUTPUT_ZIP.exists():
        OUTPUT_ZIP.unlink()

    with zipfile.ZipFile(OUTPUT_ZIP, "w", zipfile.ZIP_DEFLATED) as zipf:

        # Root files
        for file_name in INCLUDE_FILES:
            path = PROJECT_ROOT / file_name
            if path.exists() and path.is_file():
                add_path(zipf, path)

        # Included directories
        for folder in INCLUDE_DIRS:
            folder_path = PROJECT_ROOT / folder
            if not folder_path.exists():
                continue

            for root, dirs, files in os.walk(folder_path):

                root_path = Path(root)

                # Skip excluded directories
                dirs[:] = [
                    d for d in dirs
                    if not should_skip(root_path / d)
                ]

                for file in files:
                    file_path = root_path / file

                    if should_skip(file_path):
                        continue

                    add_path(zipf, file_path)

    print(f"\n✅ Zip created: {OUTPUT_ZIP}")
    print(f"Size: {OUTPUT_ZIP.stat().st_size / (1024*1024):.2f} MB")


# =============================
# RUN
# =============================

if __name__ == "__main__":
    create_zip()
