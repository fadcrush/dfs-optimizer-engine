#!/usr/bin/env python
"""
nba_late_swap_assistant.py

Real-time late swap tool for NBA DFS:
1. Shows which players are locked vs unlocked
2. Monitors early game performance
3. Suggests swap opportunities
4. Generates swap scenarios

Usage:
    python nba_late_swap_assistant.py "original_lineups.csv" "slate.csv"
"""

import argparse
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime, time
import re

print("="*80)
print("NBA LATE SWAP ASSISTANT")
print("="*80)

def parse_game_time(game_str: str) -> str:
    """
    Extract game time from FanDuel Game column
    Format: "ATL@BOS 7:00PM ET" -> "7:00 PM"
    """
    import re
    
    # Try to find time pattern
    match = re.search(r'(\d{1,2}):(\d{2})\s*(PM|AM)', str(game_str), re.IGNORECASE)
    if match:
        hour, minute, period = match.groups()
        return f"{hour}:{minute} {period.upper()}"
    
    return "Unknown"

def get_lock_status(game_time_str: str, current_time: datetime) -> dict:
    """
    Determine if game is locked based on time
    
    Returns:
        {
            'status': 'locked' | 'unlocked' | 'soon',
            'minutes_until_lock': int,
            'lock_time': str
        }
    """
    if game_time_str == "Unknown":
        return {'status': 'unknown', 'minutes_until_lock': 999, 'lock_time': 'Unknown'}
    
    try:
        # Parse game time
        game_time = datetime.strptime(game_time_str, "%I:%M %p").time()
        
        # Assume today's date
        game_datetime = datetime.combine(current_time.date(), game_time)
        
        # Calculate difference
        diff = (game_datetime - current_time).total_seconds() / 60
        
        if diff < 0:
            status = 'locked'
        elif diff < 15:  # Within 15 minutes
            status = 'soon'
        else:
            status = 'unlocked'
        
        return {
            'status': status,
            'minutes_until_lock': int(diff),
            'lock_time': game_time_str
        }
    except:
        return {'status': 'unknown', 'minutes_until_lock': 999, 'lock_time': game_time_str}

def load_original_lineups(csv_path: str) -> pd.DataFrame:
    """Load your submitted lineups"""
    df = pd.read_csv(csv_path)
    
    print(f"\n[OK] Loaded {len(df)} lineups")
    
    return df

def load_slate_with_times(csv_path: str) -> pd.DataFrame:
    """Load slate and parse game times"""
    df = pd.read_csv(csv_path)
    
    # Standardize name
    if "Nickname" in df.columns:
        df["Name"] = df["Nickname"].astype(str)
    elif "Name" not in df.columns:
        df["Name"] = (df.get("First Name", "").astype(str) + " " + df.get("Last Name", "").astype(str)).str.strip()
    
    df["Position"] = df["Position"].astype(str)
    df["Salary"] = pd.to_numeric(df["Salary"], errors="coerce")
    
    if "Game" in df.columns:
        df["GameTime"] = df["Game"].apply(parse_game_time)
    else:
        df["GameTime"] = "Unknown"
    
    return df

def analyze_lock_status(slate: pd.DataFrame, current_time: datetime = None) -> pd.DataFrame:
    """Add lock status to each player"""
    
    if current_time is None:
        current_time = datetime.now()
    
    print(f"\n Current time: {current_time.strftime('%I:%M %p')}")
    
    slate['LockStatus'] = slate['GameTime'].apply(
        lambda x: get_lock_status(x, current_time)
    )
    
    # Extract fields
    slate['Status'] = slate['LockStatus'].apply(lambda x: x['status'])
    slate['MinutesUntilLock'] = slate['LockStatus'].apply(lambda x: x['minutes_until_lock'])
    
    return slate

def show_lock_summary(slate: pd.DataFrame):
    """Display lock status summary"""
    
    print(f"\n LOCK STATUS SUMMARY")
    print("="*80)
    
    locked = slate[slate['Status'] == 'locked']
    soon = slate[slate['Status'] == 'soon']
    unlocked = slate[slate['Status'] == 'unlocked']
    
    print(f"\n LOCKED ({len(locked)} players)")
    if len(locked) > 0:
        for time in locked['GameTime'].unique():
            players = locked[locked['GameTime'] == time]
            print(f"  {time}: {len(players)} players")
    
    print(f"\n[WARNING]  LOCKING SOON ({len(soon)} players)")
    if len(soon) > 0:
        for time in soon['GameTime'].unique():
            players = soon[soon['GameTime'] == time]
            mins = players['MinutesUntilLock'].iloc[0]
            print(f"  {time} ({mins} mins): {len(players)} players")
    
    print(f"\n[OK] UNLOCKED ({len(unlocked)} players)")
    if len(unlocked) > 0:
        for time in sorted(unlocked['GameTime'].unique()):
            players = unlocked[unlocked['GameTime'] == time]
            if len(players) > 0:
                mins = players['MinutesUntilLock'].iloc[0]
                print(f"  {time} ({mins} mins): {len(players)} players")

def extract_players_from_lineups(lineups: pd.DataFrame) -> list:
    """Extract all unique players from lineups"""
    
    players = set()
    
    # Check all position columns
    for col in lineups.columns:
        if col in ['PG', 'SG', 'SF', 'PF', 'C', 'G', 'F', 'UTIL']:
            for entry in lineups[col]:
                if pd.notna(entry):
                    # Format: "12345:Player Name"
                    if ':' in str(entry):
                        name = str(entry).split(':')[1]
                        players.add(name)
                    else:
                        players.add(str(entry))
    
    return sorted(list(players))

def identify_swap_opportunities(lineups: pd.DataFrame, slate: pd.DataFrame, 
                               underperformers: dict = None) -> pd.DataFrame:
    """
    Identify which players can be swapped
    
    Args:
        underperformers: dict of {player_name: actual_score}
    """
    
    print(f"\n SWAP OPPORTUNITIES")
    print("="*80)
    
    # Get players in your lineups
    lineup_players = extract_players_from_lineups(lineups)
    
    # Filter slate to your players
    your_players = slate[slate['Name'].isin(lineup_players)].copy()
    
    # Separate locked vs unlocked
    locked_players = your_players[your_players['Status'] == 'locked']
    unlocked_players = your_players[your_players['Status'] == 'unlocked']
    
    print(f"\n LOCKED PLAYERS ({len(locked_players)}):")
    if len(locked_players) > 0:
        for _, p in locked_players.iterrows():
            print(f"  {p['Name']:<25} {p['Position']:>6} {p['GameTime']:>10}")
    
    print(f"\n[OK] SWAPPABLE PLAYERS ({len(unlocked_players)}):")
    if len(unlocked_players) > 0:
        for _, p in unlocked_players.iterrows():
            mins = p['MinutesUntilLock']
            print(f"  {p['Name']:<25} {p['Position']:>6} {p['GameTime']:>10} ({mins:>3} mins)")
    
    # If underperformers provided, show swap suggestions
    if underperformers:
        print(f"\n[WARNING]  UNDERPERFORMERS TO CONSIDER SWAPPING:")
        for player, actual in underperformers.items():
            player_info = slate[slate['Name'] == player]
            if not player_info.empty:
                p = player_info.iloc[0]
                if p['Status'] == 'locked':
                    print(f"  {player:<25} - LOCKED (can't swap)")
                else:
                    mins = p['MinutesUntilLock']
                    print(f"  {player:<25} - Can swap! ({mins} mins left)")
    
    return unlocked_players

def suggest_replacements(underperformer: str, slate: pd.DataFrame, 
                        salary_buffer: int = 500) -> pd.DataFrame:
    """
    Suggest replacement players
    
    Args:
        underperformer: Name of player to replace
        slate: Full slate with lock status
        salary_buffer: Max salary difference allowed
    """
    
    player = slate[slate['Name'] == underperformer]
    if player.empty:
        print(f"[ERROR] Player '{underperformer}' not found")
        return pd.DataFrame()
    
    player = player.iloc[0]
    
    # Only show unlocked players
    replacements = slate[
        (slate['Status'] == 'unlocked') &
        (slate['Position'].str.contains(player['Position'].split('/')[0])) &
        (slate['Salary'] <= player['Salary'] + salary_buffer)
    ].copy()
    
    # Sort by salary (descending)
    replacements = replacements.sort_values('Salary', ascending=False)
    
    print(f"\n REPLACEMENT OPTIONS FOR {underperformer}:")
    print(f"   Position: {player['Position']}, Salary: ${player['Salary']:,}")
    print(f"\n   Available replacements:")
    
    for _, r in replacements.head(10).iterrows():
        diff = r['Salary'] - player['Salary']
        sign = '+' if diff > 0 else ''
        mins = r['MinutesUntilLock']
        print(f"   {r['Name']:<25} ${r['Salary']:>5,} ({sign}${diff:,}) - {r['GameTime']:>10} ({mins:>3} mins)")
    
    return replacements

def create_swap_scenarios(lineups: pd.DataFrame, old_player: str, new_player: str, 
                         num_to_swap: int = None) -> pd.DataFrame:
    """
    Generate new lineups with swaps applied
    
    Args:
        lineups: Original lineups
        old_player: Player to remove
        new_player: Player to add
        num_to_swap: How many lineups to swap (default: all that contain old_player)
    """
    
    swapped = lineups.copy()
    swap_count = 0
    
    # Find all lineups containing old_player
    for idx, row in swapped.iterrows():
        contains_player = False
        
        for col in ['PG', 'SG', 'SF', 'PF', 'C', 'G', 'F', 'UTIL']:
            if col in row and old_player in str(row[col]):
                contains_player = True
                
                # Perform swap
                swapped.at[idx, col] = str(row[col]).replace(old_player, new_player)
                swap_count += 1
                break
        
        # If limiting number of swaps
        if num_to_swap and swap_count >= num_to_swap:
            break
    
    print(f"\n[OK] Swapped {old_player} -> {new_player} in {swap_count} lineups")
    
    return swapped

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("lineups_csv", help="Your submitted lineups CSV")
    ap.add_argument("slate_csv", help="FanDuel slate CSV")
    ap.add_argument("--time", default=None, help="Override current time (HH:MM PM)")
    ap.add_argument("--underperformers", default=None, 
                   help="Comma-separated list of underperforming players")
    args = ap.parse_args()
    
    # Parse current time
    if args.time:
        current_time = datetime.strptime(args.time, "%I:%M %p")
        current_time = current_time.replace(year=datetime.now().year, 
                                           month=datetime.now().month,
                                           day=datetime.now().day)
    else:
        current_time = datetime.now()
    
    # Load data
    lineups = load_original_lineups(args.lineups_csv)
    slate = load_slate_with_times(args.slate_csv)
    
    # Analyze lock status
    slate = analyze_lock_status(slate, current_time)
    show_lock_summary(slate)
    
    # Parse underperformers
    underperformers = {}
    if args.underperformers:
        for player in args.underperformers.split(','):
            underperformers[player.strip()] = 0  # Could add actual scores later
    
    # Show swap opportunities
    unlocked = identify_swap_opportunities(lineups, slate, underperformers)
    
    # Interactive mode
    print(f"\n{'='*80}")
    print("[TIP] LATE SWAP TIPS:")
    print("="*80)
    print("""
1. Monitor early games closely
2. If a player underperforms by 20%+, consider swapping
3. Focus on swapping your highest-exposure players
4. Don't panic swap - wait until halftime at least
5. Keep some lineups unchanged (hedge your bets)
    
DECISION RULES:
- Player scores <50% projection -> Swap in 80% of lineups
- Player scores 50-75% projection -> Swap in 50% of lineups  
- Player scores 75-90% projection -> Swap in 25% of lineups
- Player scores >90% projection -> Don't swap!
    """)

if __name__ == "__main__":
    main()
