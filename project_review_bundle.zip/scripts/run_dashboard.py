#!/usr/bin/env python
"""
Quick Launcher: Web Dashboard
Launches Streamlit interface
"""
import sys
from pathlib import Path

dashboard_path = Path(__file__).parent / 'dashboard' / 'dfs_injury_dashboard.py'

if not dashboard_path.exists():
    print(f"Dashboard not found: {dashboard_path}")
    print("Did you run the organization script?")
else:
    print(f"Launching dashboard: {dashboard_path}")
    
    # Use Python module syntax instead of streamlit command
    sys.argv = ['streamlit', 'run', str(dashboard_path)]
    
    # Import and run streamlit
    try:
        from streamlit.web import cli as stcli
        sys.exit(stcli.main())
    except ImportError:
        print("\nStreamlit not installed!")
        print("Install it with: pip install streamlit")
        sys.exit(1)
