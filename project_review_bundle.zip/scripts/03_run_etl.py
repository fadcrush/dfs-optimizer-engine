"""Run ETL pipeline with detailed output"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

print("="*80)
print("DFS DATA WAREHOUSE - ETL PIPELINE")
print("="*80)

try:
    # Import with feedback
    print("\n[STEP 1] Importing modules...")
    from data_warehouse.etl.extractors import FileExtractor
    from data_warehouse.etl.transformers import DataTransformer
    from data_warehouse.etl.loaders import DataLoader
    from data_warehouse.utils.logger import get_logger
    print("✓ Modules imported successfully")
    
    logger = get_logger(__name__)
    
    # EXTRACTION
    print("\n[STEP 2] EXTRACTION")
    print("-"*80)
    extractor = FileExtractor()
    raw_data = extractor.extract_all_directories()
    
    if not raw_data:
        print("❌ No data extracted! Check your source directories.")
        sys.exit(1)
    
    print(f"\n✓ Extracted data from {len(raw_data)} sources:")
    for source_key, df in raw_data.items():
        print(f"  - {source_key}: {len(df):,} records")
    
    total_records = sum(len(df) for df in raw_data.values())
    print(f"\nTotal records extracted: {total_records:,}")
    
    # TRANSFORMATION
    print("\n[STEP 3] TRANSFORMATION")
    print("-"*80)
    transformer = DataTransformer()
    transformed_data = transformer.transform_all(raw_data)
    
    print(f"\n✓ Transformed {len(transformed_data)} datasets")
    for source_key, df in transformed_data.items():
        print(f"  - {source_key}: {len(df):,} records")
        print(f"    Columns: {list(df.columns)[:8]}...")
    
    # LOADING
    print("\n[STEP 4] LOADING TO DATABASE")
    print("-"*80)
    loader = DataLoader(db_type='duckdb')
    
    # Load each dataset
    for source_key, df in transformed_data.items():
        print(f"\nLoading {source_key}...")
        try:
            loader.load_player_performance(df)
            print(f"  ✓ Loaded {len(df):,} records")
        except Exception as e:
            print(f"  ✗ Error: {e}")
    
    loader.close()
    
    # VERIFICATION
    print("\n[STEP 5] VERIFICATION")
    print("-"*80)
    import duckdb
    con = duckdb.connect('data/dfs_warehouse.duckdb')
    count = con.execute("SELECT COUNT(*) FROM fact_player_performance").fetchone()[0]
    con.close()
    
    print(f"✓ Database now contains: {count:,} records")
    
    print("\n" + "="*80)
    print("ETL PIPELINE COMPLETE!")
    print("="*80)

except Exception as e:
    print(f"\n❌ ERROR: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)