#!/usr/bin/env python
"""
SETUP_DATABASE.py

Initialize the master DFS database
- Creates all tables
- Loads existing contest results
- Sets up initial configuration
"""

import duckdb
import pandas as pd
from pathlib import Path
import sys

print("="*80)
print("MASTER DFS DATABASE - SETUP")
print("="*80)

# Database path
DB_PATH = 'data/dfs_master.duckdb'

# Ensure data directory exists
Path('data').mkdir(exist_ok=True)

# Connect to database
print(f"\nConnecting to: {DB_PATH}")
conn = duckdb.connect(DB_PATH)

# =============================================================================
# STEP 1: Create Schema
# =============================================================================

print("\nStep 1: Creating database schema...")

# Read schema file
schema_file = Path('DATABASE_SCHEMA.sql')

if not schema_file.exists():
    print(f"  [ERROR] Schema file not found: {schema_file}")
    print("  Make sure DATABASE_SCHEMA.sql is in the same directory")
    sys.exit(1)

with open(schema_file, 'r') as f:
    schema_sql = f.read()

# Execute schema (split by semicolon)
statements = [s.strip() for s in schema_sql.split(';') if s.strip()]

for i, statement in enumerate(statements):
    try:
        # Skip comments and summary query
        if statement.startswith('--') or 'row_count' in statement.lower():
            continue
        
        conn.execute(statement)
        
    except Exception as e:
        # Some statements might fail (like CREATE IF NOT EXISTS on existing tables)
        # That's okay
        pass

print("  [OK] Schema created")

# =============================================================================
# STEP 2: Load Existing Contest Results
# =============================================================================

print("\nStep 2: Loading existing contest results...")

# Check if contest_results table already has data
existing_count = conn.execute("SELECT COUNT(*) FROM contest_results").fetchone()[0]

if existing_count > 0:
    print(f"  Found {existing_count:,} existing contest results")
    response = input("  Do you want to keep existing data? (y/n): ")
    
    if response.lower() != 'y':
        print("  Clearing existing data...")
        conn.execute("DELETE FROM contest_results")
        existing_count = 0

if existing_count == 0:
    # Try to load from dfs_warehouse.duckdb
    old_db = Path('data/dfs_warehouse.duckdb')
    
    if old_db.exists():
        print(f"  Found existing database: {old_db}")
        print("  Importing contest results...")
        
        try:
            # Attach old database
            conn.execute(f"ATTACH '{old_db}' AS old_db")
            
            # Copy data
            conn.execute("""
                INSERT INTO contest_results 
                SELECT 
                    NULL as result_id,
                    contest_date,
                    NULL as player_id,
                    player_name,
                    platform,
                    sport,
                    NULL as slate_type,
                    position,
                    team,
                    opponent,
                    salary,
                    actual_fpts,
                    my_proj,
                    sabersim_proj,
                    NULL as platform_proj,
                    my_ownership,
                    NULL as actual_ownership,
                    source_file,
                    CURRENT_TIMESTAMP
                FROM old_db.contest_results
            """)
            
            imported = conn.execute("SELECT COUNT(*) FROM contest_results").fetchone()[0]
            print(f"    [OK] Imported {imported:,} contest results")
            
            # Detach
            conn.execute("DETACH old_db")
            
        except Exception as e:
            print(f"  [ERROR] Failed to import: {e}")

# =============================================================================
# STEP 3: Summary
# =============================================================================

print("\n" + "="*80)
print("DATABASE SUMMARY")
print("="*80)

summary = conn.execute("""
    SELECT 
        'players' as table_name, 
        COUNT(*) as row_count 
    FROM players
    
    UNION ALL
    SELECT 'player_game_logs', COUNT(*) FROM player_game_logs
    
    UNION ALL
    SELECT 'team_defense_by_position', COUNT(*) FROM team_defense_by_position
    
    UNION ALL
    SELECT 'games', COUNT(*) FROM games
    
    UNION ALL
    SELECT 'projections', COUNT(*) FROM projections
    
    UNION ALL
    SELECT 'injuries', COUNT(*) FROM injuries
    
    UNION ALL
    SELECT 'news', COUNT(*) FROM news
    
    UNION ALL
    SELECT 'contest_results', COUNT(*) FROM contest_results
    
    UNION ALL
    SELECT 'vegas_odds', COUNT(*) FROM vegas_odds
    
    UNION ALL
    SELECT 'player_props', COUNT(*) FROM player_props
    
    ORDER BY row_count DESC
""").fetchdf()

print("\n" + summary.to_string(index=False))

# Close connection
conn.close()

print("\n" + "="*80)
print("SETUP COMPLETE!")
print("="*80)

print("\nYour master database is ready at:")
print(f"  {DB_PATH}")

print("\nNext steps:")
print("  1. Set up API keys in config.py")
print("  2. Run: python update_data.py")
print("  3. Run: python query_library.py")

print("\n" + "="*80)
