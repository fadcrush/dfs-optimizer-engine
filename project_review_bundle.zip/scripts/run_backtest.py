#!/usr/bin/env python
"""
Quick Launcher: Backtest Analyzer
Analyze projection accuracy
"""
import sys
from pathlib import Path

# Add scripts to path
sys.path.insert(0, str(Path(__file__).parent / 'scripts' / 'analysis'))

# Import and run
from backtest_analyzer import main

if __name__ == "__main__":
    main()
