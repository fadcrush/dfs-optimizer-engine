<#
.SYNOPSIS
  Clean up N_B_A_AND_N_F_L root folder into a stable structure.
  Supports dry-run mode to preview moves without changing anything.

.USAGE
  # Preview only:
  powershell -ExecutionPolicy Bypass -File .\scripts\maintenance\cleanup_root.ps1 -Root "C:\Users\David\Documents\N_B_A_AND_N_F_L" -DryRun

  # Actually apply:
  powershell -ExecutionPolicy Bypass -File .\scripts\maintenance\cleanup_root.ps1 -Root "C:\Users\David\Documents\N_B_A_AND_N_F_L"
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$Root,

    [switch]$DryRun
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Write-Plan($msg) {
    if ($DryRun) { Write-Host "[DRYRUN] $msg" -ForegroundColor Yellow }
    else { Write-Host "[APPLY ] $msg" -ForegroundColor Green }
}

function Ensure-Dir($path) {
    if (!(Test-Path $path)) {
        Write-Plan "Create dir: $path"
        if (-not $DryRun) { New-Item -ItemType Directory -Path $path | Out-Null }
    }
}

function Safe-Move($src, $dstDir) {
    if (!(Test-Path $src)) { return }

    Ensure-Dir $dstDir
    $name = Split-Path $src -Leaf
    $dst = Join-Path $dstDir $name

    if (Test-Path $dst) {
        # Avoid overwriting: append timestamp
        $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
        $base = [System.IO.Path]::GetFileNameWithoutExtension($name)
        $ext = [System.IO.Path]::GetExtension($name)
        $dst = Join-Path $dstDir ("{0}__moved_{1}{2}" -f $base, $stamp, $ext)
    }

    Write-Plan "Move: $src  ->  $dst"
    if (-not $DryRun) { Move-Item -LiteralPath $src -Destination $dst }
}

# --- Destinations (create a stable structure) ---
$dataInboundFDNBA = Join-Path $Root "data\inbound\fanduel\nba"
$dataInboundFDNFL = Join-Path $Root "data\inbound\fanduel\nfl"
$dataInboundOther = Join-Path $Root "data\inbound\misc"
$dataUser = Join-Path $Root "data\inbound\user"
$dataCache = Join-Path $Root "data\cache"
$archives = Join-Path $Root "scripts\archive"
$archivesFixers = Join-Path $archives "fixers"
$archivesVersions = Join-Path $archives "versions"
$archivesTests = Join-Path $archives "tests"
$archivesDocs = Join-Path $archives "scratch_docs"
$archivesTrees = Join-Path $archives "tree_dumps"

Ensure-Dir (Join-Path $Root "data")
Ensure-Dir (Join-Path $Root "scripts\maintenance")
Ensure-Dir $dataCache
Ensure-Dir $archives

# --- 1) Move FanDuel CSV downloads off ROOT ---
Get-ChildItem -LiteralPath $Root -File -Filter "FanDuel-*.csv" | ForEach-Object {
    $name = $_.Name.ToLowerInvariant()
    if ($name -match "nba") { Safe-Move $_.FullName $dataInboundFDNBA }
    elseif ($name -match "nfl") { Safe-Move $_.FullName $dataInboundFDNFL }
    else { Safe-Move $_.FullName $dataInboundOther }
}

# --- 2) Move personal lineup inputs (keep them out of root clutter) ---
$myLineups = Join-Path $Root "my_lineups.csv"
Safe-Move $myLineups $dataUser

# --- 3) Archive “fix_*” scripts (keep them, but not in root) ---
Get-ChildItem -LiteralPath $Root -File -Filter "fix_*.py" | ForEach-Object {
    Safe-Move $_.FullName $archivesFixers
}

# --- 4) Archive version-sprawl scripts: *_fixed*, *_v2*, *_v3*, *(2) etc ---
# Keeps your history, but removes noise from ROOT.
$versionPatterns = @(
    "*_fixed*.py",
    "*_FIXED*.py",
    "*_v2*.py",
    "*_v3*.py",
    "*(2).py",
    "*(3).py"
)

foreach ($pat in $versionPatterns) {
    Get-ChildItem -LiteralPath $Root -File -Filter $pat | ForEach-Object {
        Safe-Move $_.FullName $archivesVersions
    }
}

# --- 5) Archive tests that are living in ROOT ---
Get-ChildItem -LiteralPath $Root -File -Filter "test_*.py" | ForEach-Object {
    Safe-Move $_.FullName $archivesTests
}

# --- 6) Archive scratch/tree dumps ---
@("modTree.txt", "tree_sub.txt", "treemf.txt", "hit.txt") | ForEach-Object {
    Safe-Move (Join-Path $Root $_) $archivesTrees
}

# --- 7) OPTIONAL: relocate raw response folders into data\cache (if they exist) ---
# (We won’t delete anything; just move.)
$raw1 = Join-Path $Root "api_integrations\raw_responses"
$raw2 = Join-Path $Root "data_cache"
Safe-Move $raw1 $dataCache
Safe-Move $raw2 $dataCache

Write-Host ""
Write-Host "Done." -ForegroundColor Cyan
if ($DryRun) {
    Write-Host "Nothing was changed because -DryRun was used." -ForegroundColor Yellow
}
