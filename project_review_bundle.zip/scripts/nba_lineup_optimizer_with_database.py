#!/usr/bin/env python
"""
nba_lineup_optimizer_with_database.py

Enhanced NBA Lineup Optimizer with Master Database Integration!

Combines:
1. Your existing optimizer (projections + ownership + leverage)
2. Master database insights (matchups, defense, hot players, patterns)
3. Automatic projection adjustments based on discovered edges

Usage:
    python nba_lineup_optimizer_with_database.py "slate.csv" --num-lineups 150
"""

import argparse
import re
from pathlib import Path
from datetime import datetime
from collections import defaultdict
import pandas as pd
import numpy as np
import duckdb

print("="*80)
print("NBA LINEUP OPTIMIZER - WITH DATABASE INSIGHTS")
print("="*80)

# =============================================================================
# DATABASE INTEGRATION
# =============================================================================

class DatabaseInsights:
    """Pull insights from master database"""
    
    def __init__(self, db_path='data/dfs_master.duckdb'):
        self.db_path = db_path
        self.conn = None
        
        # Try to connect
        if Path(db_path).exists():
            try:
                self.conn = duckdb.connect(db_path, read_only=True)
                print(f"\n[OK] Connected to master database")
            except Exception as e:
                print(f"\n[WARNING] Could not connect to database: {e}")
                print("          Will run without database insights")
        else:
            print(f"\n[INFO] Master database not found at: {db_path}")
            print("       Run: python setup_database_fixed.py")
            print("       Will run without database insights")
    
    def get_value_plays(self, min_games=5):
        """Get underpriced players"""
        if not self.conn:
            return {}
        
        try:
            query = f"""
            SELECT 
                player_name,
                AVG(actual_fpts / (salary / 1000.0)) as value,
                COUNT(*) as games
            FROM contest_results
            WHERE sport = 'NBA'
              AND contest_date >= CURRENT_DATE - INTERVAL '30 days'
              AND salary < 7000
            GROUP BY player_name
            HAVING games >= {min_games}
              AND value > 4.5
            ORDER BY value DESC
            LIMIT 20
            """
            
            result = self.conn.execute(query).fetchdf()
            
            # Return as dict: {player_name: boost_multiplier}
            boosts = {}
            for _, row in result.iterrows():
                # Value over 5.0 = 5% boost, over 5.5 = 7% boost
                if row['value'] > 5.5:
                    boosts[row['player_name']] = 1.07
                elif row['value'] > 5.0:
                    boosts[row['player_name']] = 1.05
                else:
                    boosts[row['player_name']] = 1.03
            
            print(f"[OK] Found {len(boosts)} value plays")
            return boosts
        
        except Exception as e:
            print(f"[WARNING] Could not get value plays: {e}")
            return {}
    
    def get_weak_defenses(self):
        """Get teams with weak defense by position"""
        if not self.conn:
            return {}
        
        try:
            query = """
            WITH latest AS (
                SELECT MAX(date) as max_date 
                FROM team_defense_by_position
                WHERE sport = 'NBA'
            )
            SELECT 
                d.team,
                d.position,
                d.avg_fpts_allowed,
                d.rank
            FROM team_defense_by_position d
            JOIN latest l ON d.date = l.max_date
            WHERE d.rank >= 25
            ORDER BY d.avg_fpts_allowed DESC
            """
            
            result = self.conn.execute(query).fetchdf()
            
            # Return as dict: {(team, position): boost}
            weak_def = {}
            for _, row in result.iterrows():
                key = (row['team'], row['position'])
                # Bottom 5 = 8% boost, bottom 10 = 5% boost
                if row['rank'] >= 28:
                    weak_def[key] = 1.08
                else:
                    weak_def[key] = 1.05
            
            print(f"[OK] Found {len(weak_def)} weak defense matchups")
            return weak_def
        
        except Exception as e:
            print(f"[WARNING] Could not get defense rankings: {e}")
            return {}
    
    def get_hot_players(self, num_games=10):
        """Get players with hot recent form"""
        if not self.conn:
            return {}
        
        try:
            query = f"""
            WITH recent_games AS (
                SELECT 
                    player_name,
                    actual_fpts,
                    contest_date,
                    ROW_NUMBER() OVER (PARTITION BY player_name ORDER BY contest_date DESC) as game_num
                FROM contest_results
                WHERE sport = 'NBA'
                  AND contest_date >= CURRENT_DATE - INTERVAL '30 days'
            )
            SELECT 
                player_name,
                AVG(actual_fpts) as avg_recent,
                COUNT(*) as games
            FROM recent_games
            WHERE game_num <= {num_games}
            GROUP BY player_name
            HAVING games >= {num_games - 2}
              AND avg_recent > 30
            ORDER BY avg_recent DESC
            LIMIT 20
            """
            
            result = self.conn.execute(query).fetchdf()
            
            hot_players = {}
            for _, row in result.iterrows():
                # Over 40 pts = 5% boost, over 35 = 3% boost
                if row['avg_recent'] > 40:
                    hot_players[row['player_name']] = 1.05
                else:
                    hot_players[row['player_name']] = 1.03
            
            print(f"[OK] Found {len(hot_players)} hot players")
            return hot_players
        
        except Exception as e:
            print(f"[WARNING] Could not get hot players: {e}")
            return {}
    
    def get_matchup_crushers(self, min_games=5):
        """Get player-opponent pairs with strong history"""
        if not self.conn:
            return {}
        
        try:
            query = f"""
            SELECT 
                player_name,
                opponent,
                AVG(actual_fpts) as avg_vs_opp,
                COUNT(*) as games
            FROM contest_results
            WHERE sport = 'NBA'
              AND contest_date >= CURRENT_DATE - INTERVAL '90 days'
            GROUP BY player_name, opponent
            HAVING games >= {min_games}
              AND avg_vs_opp > 35
            ORDER BY avg_vs_opp DESC
            LIMIT 30
            """
            
            result = self.conn.execute(query).fetchdf()
            
            crushers = {}
            for _, row in result.iterrows():
                key = (row['player_name'], row['opponent'])
                # Over 45 pts = 8% boost, over 40 = 5% boost
                if row['avg_vs_opp'] > 45:
                    crushers[key] = 1.08
                else:
                    crushers[key] = 1.05
            
            print(f"[OK] Found {len(crushers)} matchup crushers")
            return crushers
        
        except Exception as e:
            print(f"[WARNING] Could not get matchup crushers: {e}")
            return {}
    
    def apply_insights(self, pool: pd.DataFrame) -> pd.DataFrame:
        """Apply all database insights to player pool"""
        
        print(f"\n Applying database insights...")
        
        if not self.conn:
            print("[INFO] No database connection - using base projections")
            return pool
        
        # Get insights
        value_plays = self.get_value_plays()
        weak_defenses = self.get_weak_defenses()
        hot_players = self.get_hot_players()
        matchup_crushers = self.get_matchup_crushers()
        
        # Track adjustments
        adjustments_made = 0
        
        # Apply boosts
        for idx, row in pool.iterrows():
            player = row['Name']
            opponent = row.get('Opponent', '')
            position = row['PosBucket']
            base_proj = row['Projection']
            
            total_boost = 1.0
            reasons = []
            
            # Value play boost
            if player in value_plays:
                total_boost *= value_plays[player]
                reasons.append(f"Value:{value_plays[player]:.2f}")
            
            # Weak defense boost
            def_key = (opponent, position)
            if def_key in weak_defenses:
                total_boost *= weak_defenses[def_key]
                reasons.append(f"WeakDef:{weak_defenses[def_key]:.2f}")
            
            # Hot player boost
            if player in hot_players:
                total_boost *= hot_players[player]
                reasons.append(f"Hot:{hot_players[player]:.2f}")
            
            # Matchup crusher boost
            matchup_key = (player, opponent)
            if matchup_key in matchup_crushers:
                total_boost *= matchup_crushers[matchup_key]
                reasons.append(f"Matchup:{matchup_crushers[matchup_key]:.2f}")
            
            # Apply total boost
            if total_boost > 1.0:
                new_proj = base_proj * total_boost
                pool.at[idx, 'Projection'] = new_proj
                pool.at[idx, 'DB_Boost'] = total_boost
                pool.at[idx, 'DB_Reasons'] = ', '.join(reasons)
                adjustments_made += 1
        
        print(f"[OK] Applied {adjustments_made} database adjustments")
        
        # Show top boosts
        if adjustments_made > 0:
            boosted = pool[pool.get('DB_Boost', 1.0) > 1.0].nlargest(10, 'DB_Boost')
            if not boosted.empty:
                print(f"\n TOP 10 DATABASE BOOSTS:")
                for _, p in boosted.iterrows():
                    print(f"  {p['Name']:<25} {p.get('DB_Boost', 1.0):.2%} - {p.get('DB_Reasons', '')}")
        
        return pool
    
    def close(self):
        if self.conn:
            self.conn.close()

# =============================================================================
# ORIGINAL OPTIMIZER CODE (with enhancements)
# =============================================================================

def norm_name(s: str) -> str:
    """Normalize name for matching"""
    s = (s or "").strip().lower()
    s = re.sub(r"[^a-z\s\-\.']", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s

def latest_file(pattern: str) -> Path:
    """Get most recent file matching pattern"""
    files = sorted(Path("outputs").glob(pattern), key=lambda p: p.stat().st_mtime, reverse=True)
    if not files:
        return None
    return files[0]

def load_slate(csv_path: str) -> pd.DataFrame:
    """Load FanDuel slate CSV"""
    df = pd.read_csv(csv_path)
    
    # Standardize columns
    if "Id" in df.columns:
        df["ID"] = df["Id"].astype(str)
    elif "ID" not in df.columns:
        raise ValueError("Need Id or ID column")
    
    if "Nickname" in df.columns:
        df["Name"] = df["Nickname"].astype(str)
    elif "Name" not in df.columns:
        df["Name"] = (df.get("First Name", "").astype(str) + " " + df.get("Last Name", "").astype(str)).str.strip()
    
    df["Name_norm"] = df["Name"].map(norm_name)
    df["Position"] = df["Position"].astype(str)
    df["Salary"] = pd.to_numeric(df["Salary"], errors="coerce").fillna(0).astype(int)
    
    # Extract opponent if available
    if "Opponent" in df.columns:
        df["Opponent"] = df["Opponent"].astype(str)
    elif "Opp" in df.columns:
        df["Opponent"] = df["Opp"].astype(str)
    else:
        df["Opponent"] = ""
    
    # Primary position bucket
    def primary_pos(pos: str) -> str:
        pos = (pos or "").upper()
        for bucket in ["PG", "SG", "SF", "PF", "C"]:
            if bucket in pos:
                return bucket
        return ""
    
    df["PosBucket"] = df["Position"].map(primary_pos)
    
    return df

def load_projections() -> pd.DataFrame:
    """Load latest projections"""
    proj_file = latest_file("projections_today*.csv")
    if not proj_file:
        print("\n[ERROR] No projections found!")
        print("   Run: python nba_today_projections_v3_dvp_posmap.py \"slate.csv\" --season 2024-25")
        return None
    
    print(f"\n[OK] Loading projections: {proj_file.name}")
    proj = pd.read_csv(proj_file)
    
    if "Name" in proj.columns:
        proj["Name_norm"] = proj["Name"].astype(str).map(norm_name)
    
    if "Projection" not in proj.columns:
        print("[ERROR] Projections file missing 'Projection' column!")
        return None
    
    proj["Projection"] = pd.to_numeric(proj["Projection"], errors="coerce")
    
    return proj

def load_ownership() -> pd.DataFrame:
    """Load latest ownership simulation"""
    own_file = latest_file("ownership_study_nba*.csv")
    if not own_file:
        print("\n[WARNING] No ownership data found")
        print("   Run: python ownership_simulator_nba_FIXED.py \"slate.csv\" --num 10000")
        return None
    
    print(f"[OK] Loading ownership: {own_file.name}")
    own = pd.read_csv(own_file)
    
    if "Name" in own.columns:
        own["Name_norm"] = own["Name"].astype(str).map(norm_name)
    
    if "SimOwnership" in own.columns:
        own["Ownership"] = pd.to_numeric(own["SimOwnership"], errors="coerce")
    elif "Ownership" in own.columns:
        own["Ownership"] = pd.to_numeric(own["Ownership"], errors="coerce")
    else:
        print("[ERROR] Ownership file missing ownership column!")
        return None
    
    return own[["Name_norm", "Ownership"]]

def build_player_pool(slate: pd.DataFrame, projections: pd.DataFrame, ownership: pd.DataFrame) -> pd.DataFrame:
    """Merge slate + projections + ownership"""
    
    # Merge projections
    pool = slate.merge(
        projections[["Name_norm", "Projection"]],
        on="Name_norm",
        how="left"
    )
    
    pool["Projection"] = pool["Projection"].fillna(0.0)
    
    # Merge ownership
    if ownership is not None:
        pool = pool.merge(ownership, on="Name_norm", how="left")
        pool["Ownership"] = pool["Ownership"].fillna(0.50)
    else:
        pool["Ownership"] = 0.50
    
    # Calculate leverage
    pool["Leverage"] = pool["Projection"] / (pool["Ownership"] + 0.01)
    
    # Calculate value
    pool["Value"] = pool["Projection"] / (pool["Salary"] / 1000)
    
    # Clean up
    pool["Leverage"] = pool["Leverage"].replace([np.inf, -np.inf], 0.0).fillna(0.0)
    pool["Value"] = pool["Value"].replace([np.inf, -np.inf], 0.0).fillna(0.0)
    pool["Projection"] = pool["Projection"].fillna(0.0)
    pool["Ownership"] = pool["Ownership"].fillna(0.5)
    
    return pool

def can_fill_slot(position: str, slot: str) -> bool:
    """Check if position can fill FanDuel slot"""
    positions = [p.strip() for p in str(position).split('/')]
    
    if slot == 'PG': return 'PG' in positions
    elif slot == 'SG': return 'SG' in positions
    elif slot == 'SF': return 'SF' in positions
    elif slot == 'PF': return 'PF' in positions
    elif slot == 'C': return 'C' in positions
    return False

def build_lineup(pool: pd.DataFrame, used_count: dict, config: dict, strategy: str = 'balanced') -> list:
    """Build single lineup"""
    
    available = pool.copy()
    
    # Filter over-exposed
    max_uses = int(config['num_lineups'] * config['max_exposure'])
    available = available[available['Name'].map(lambda x: used_count.get(x, 0) < max_uses)]
    
    if len(available) < 9:
        return None
    
    lineup = []
    salary_used = 0
    
    needed = {'PG': 2, 'SG': 2, 'SF': 2, 'PF': 2, 'C': 1}
    
    # Sort by strategy with randomization
    if strategy == 'gpp':
        available['Score'] = available['Leverage']
    elif strategy == 'cash':
        available['Score'] = available['Projection']
    else:
        available['Score'] = available['Leverage'] * 0.6 + available['Value'] * 0.4

    # Add randomness to avoid greedy failures
    available['Random'] = np.random.random(len(available))
    available['FinalScore'] = available['Score'] + available['Random'] * available['Score'].std() * 0.3
    available = available.sort_values('FinalScore', ascending=False)
    
    
    # Build lineup
    for slot in ['PG', 'SG', 'SF', 'PF', 'C']:
        while needed[slot] > 0:
            eligible = available[
                available['Name'].map(lambda n: n not in [p['Name'] for p in lineup])
            ]
            eligible = eligible[eligible['PosBucket'] == slot]
            
            if eligible.empty:
                return None
            
            # Try to find affordable player
            player_added = False
            for _, player in eligible.iterrows():
                if salary_used + player['Salary'] <= config['max_salary']:
                    lineup.append(player.to_dict())
                    salary_used += player['Salary']
                    needed[slot] -= 1
                    player_added = True
                    break
            
            # If couldn't afford any player, lineup fails
            if not player_added:
                return None
        
        if len(lineup) == 9 and config['min_salary'] <= salary_used <= config['max_salary']:
            return lineup
        return None

def generate_lineups(pool: pd.DataFrame, config: dict, strategy: str = 'balanced'):
    """Generate multiple lineups"""
    
    print(f"\n Generating {config['num_lineups']} lineups ({strategy} strategy)...")
    
    lineups = []
    used_count = defaultdict(int)
    
    attempts = 0
    max_attempts = config['num_lineups'] * 20
    
    while len(lineups) < config['num_lineups'] and attempts < max_attempts:
        attempts += 1
        
        lineup = build_lineup(pool, used_count, config, strategy)
        
        if lineup:
            lineups.append(lineup)
            for p in lineup:
                used_count[p['Name']] += 1
            
            if len(lineups) % 25 == 0:
                print(f"  Progress: {len(lineups)}/{config['num_lineups']}")
    
    print(f"[OK] Generated {len(lineups)} lineups in {attempts} attempts")
    
    return lineups, used_count

def export_lineups(lineups: list, output_file: Path):
    """Export to FanDuel CSV format"""
    
    print(f"\n Exporting to FanDuel format...")
    
    with open(output_file, 'w') as f:
        f.write("PG,PG,SG,SG,SF,SF,PF,PF,C\n")
        
        for lineup in lineups:
            sorted_lu = []
            used = set()
            
            for slot in ['PG', 'PG', 'SG', 'SG', 'SF', 'SF', 'PF', 'PF', 'C']:
                for p in lineup:
                    if p['Name'] not in used and can_fill_slot(p['PosBucket'], slot):
                        sorted_lu.append(p)
                        used.add(p['Name'])
                        break
            
            row = [f"{p['ID']}:{p['Name']}" for p in sorted_lu]
            f.write(','.join(row) + '\n')
    
    print(f"[OK] Saved to: {output_file}")

def show_analytics(lineups: list, pool: pd.DataFrame):
    """Show lineup analytics"""
    
    print(f"\n LINEUP ANALYTICS")
    print("="*80)
    
    all_proj = [sum(p['Projection'] for p in lu) for lu in lineups]
    all_sal = [sum(p['Salary'] for p in lu) for lu in lineups]
    all_own = [np.mean([p['Ownership'] for p in lu]) for lu in lineups]
    
    print(f"Avg Projection: {np.mean(all_proj):.1f} pts")
    print(f"Projection Range: {np.min(all_proj):.1f} - {np.max(all_proj):.1f}")
    print(f"Avg Ownership: {np.mean(all_own)*100:.1f}%")
    print(f"Ownership Range: {np.min(all_own)*100:.1f}% - {np.max(all_own)*100:.1f}%")
    print(f"Avg Salary: ${np.mean(all_sal):,.0f}")
    print(f"Salary Range: ${np.min(all_sal):,} - ${np.max(all_sal):,}")
    
    # Player exposures
    exposure = defaultdict(int)
    for lu in lineups:
        for p in lu:
            exposure[p['Name']] += 1
    
    print(f"\n TOP 10 EXPOSURES:")
    top_exp = sorted(exposure.items(), key=lambda x: x[1], reverse=True)[:10]
    
    for name, count in top_exp:
        pct = (count / len(lineups)) * 100
        player = pool[pool['Name'] == name].iloc[0]
        own_pct = player['Ownership'] * 100
        proj = player['Projection']
        db_boost = player.get('DB_Boost', 1.0)
        
        boost_str = f"DB:{db_boost:.0%}" if db_boost > 1.0 else ""
        print(f"  {name:<25} {count:>3} ({pct:>4.1f}%) | Proj:{proj:>5.1f} Own:{own_pct:>4.1f}% {boost_str}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("slate_csv", help="FanDuel NBA slate CSV")
    ap.add_argument("--num-lineups", type=int, default=150)
    ap.add_argument("--max-exposure", type=float, default=0.35)
    ap.add_argument("--min-salary", type=int, default=44000)
    ap.add_argument("--max-salary", type=int, default=60000)
    ap.add_argument("--strategy", choices=['balanced', 'gpp', 'cash'], default='balanced')
    ap.add_argument("--no-database", action='store_true', help="Skip database insights")
    args = ap.parse_args()
    
    # Load data
    print(f"\n Loading slate: {Path(args.slate_csv).name}")
    slate = load_slate(args.slate_csv)
    print(f"[OK] Loaded {len(slate)} players")
    
    projections = load_projections()
    if projections is None:
        return
    
    ownership = load_ownership()
    
    # Build player pool
    print(f"\n Building player pool...")
    pool = build_player_pool(slate, projections, ownership)
    print(f"[OK] Pool ready: {len(pool)} players")
    
    # Apply database insights
    if not args.no_database:
        db = DatabaseInsights()
        pool = db.apply_insights(pool)
        db.close()
    else:
        print("[INFO] Skipping database insights (--no-database flag)")
    
    # Recalculate leverage/value after DB boosts
    pool["Leverage"] = pool["Projection"] / (pool["Ownership"] + 0.01)
    pool["Value"] = pool["Projection"] / (pool["Salary"] / 1000)
    
    print(f"\n   Avg Ownership: {pool['Ownership'].mean()*100:.1f}%")
    print(f"   Avg Projection: {pool['Projection'].mean():.1f} pts")
    print(f"   Avg Leverage: {pool['Leverage'].mean():.2f}")
    
    # Generate lineups
    config = {
        'num_lineups': args.num_lineups,
        'max_exposure': args.max_exposure,
        'min_salary': args.min_salary,
        'max_salary': args.max_salary
    }
    
    lineups, used_count = generate_lineups(pool, config, args.strategy)
    
    if not lineups:
        print("\n[ERROR] Failed to generate lineups")
        return
    
    # Analytics
    show_analytics(lineups, pool)
    
    # Export
    outdir = Path("outputs")
    outdir.mkdir(exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = outdir / f"nba_lineups_db_{args.strategy}_{ts}.csv"
    
    export_lineups(lineups, output_file)
    
    print(f"\n{'='*80}")
    print("[OK] LINEUP GENERATION COMPLETE!")
    print(f"{'='*80}")
    print(f"\n Upload to FanDuel: {output_file}")
    
    # Show database impact
    if not args.no_database:
        boosted_count = len(pool[pool.get('DB_Boost', 1.0) > 1.0])
        print(f"\n Database Impact: {boosted_count} players received boosts")

if __name__ == "__main__":
    main()
