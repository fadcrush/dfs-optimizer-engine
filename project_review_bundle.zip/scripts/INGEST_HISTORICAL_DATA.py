#!/usr/bin/env python
"""
INGEST_HISTORICAL_DATA.py

Comprehensive script to ingest all historical DFS data:
- DK_NBA_Past_Games
- DK_NFL_Past_Games  
- FD_NBA_Past_Games
- FD_NFL_Past_Games

Creates unified database for backtesting and analysis.
"""

import duckdb
import pandas as pd
from pathlib import Path
from datetime import datetime
import re

print("="*80)
print("HISTORICAL DATA INGESTION SYSTEM")
print("="*80)

# Configuration
DB_PATH = 'data/dfs_warehouse.duckdb'
DATA_DIRS = {
    'DK_NBA': Path('DK_NBA_Past_Games'),
    'DK_NFL': Path('DK_NFL_Past_Games'),
    'FD_NBA': Path('FD_NBA_Past_Games'),
    'FD_NFL': Path('FD_NFL_Past_Games'),
}

# Connect to DuckDB
print(f"\nConnecting to: {DB_PATH}")
conn = duckdb.connect(DB_PATH)

# =============================================================================
# CREATE SCHEMA
# =============================================================================

print("\nCreating database schema...")

# Main historical results table
conn.execute("""
CREATE TABLE IF NOT EXISTS historical_results (
    -- Identifiers
    result_id INTEGER PRIMARY KEY,
    game_date DATE NOT NULL,
    player_name VARCHAR NOT NULL,
    player_id VARCHAR,
    
    -- Game context
    platform VARCHAR NOT NULL,  -- 'DraftKings' or 'FanDuel'
    sport VARCHAR NOT NULL,     -- 'NBA' or 'NFL'
    team VARCHAR,
    opponent VARCHAR,
    home_away VARCHAR,
    
    -- Salary & Position
    salary INTEGER,
    position VARCHAR,
    
    -- Performance
    fantasy_points FLOAT NOT NULL,
    minutes_played FLOAT,
    
    -- Stats (NBA)
    points INTEGER,
    rebounds INTEGER,
    assists INTEGER,
    steals INTEGER,
    blocks INTEGER,
    turnovers INTEGER,
    
    -- Stats (NFL)
    passing_yards FLOAT,
    passing_tds INTEGER,
    rushing_yards FLOAT,
    rushing_tds INTEGER,
    receptions INTEGER,
    receiving_yards FLOAT,
    receiving_tds INTEGER,
    
    -- Metadata
    loaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    source_file VARCHAR
);
""")

# Projection tracking table
conn.execute("""
CREATE TABLE IF NOT EXISTS projection_tracking (
    tracking_id INTEGER PRIMARY KEY,
    game_date DATE NOT NULL,
    player_name VARCHAR NOT NULL,
    platform VARCHAR NOT NULL,
    sport VARCHAR NOT NULL,
    
    -- Projections
    your_projection FLOAT,
    platform_projection FLOAT,
    
    -- Actual result
    actual_points FLOAT NOT NULL,
    
    -- Errors
    your_error FLOAT,
    your_abs_error FLOAT,
    your_pct_error FLOAT,
    
    platform_error FLOAT,
    platform_abs_error FLOAT,
    
    -- Context
    salary INTEGER,
    ownership_actual FLOAT,
    ownership_predicted FLOAT,
    
    -- Metadata
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
""")

# Slate performance tracking
conn.execute("""
CREATE TABLE IF NOT EXISTS slate_performance (
    slate_id INTEGER PRIMARY KEY,
    game_date DATE NOT NULL,
    platform VARCHAR NOT NULL,
    sport VARCHAR NOT NULL,
    
    -- Projection accuracy
    num_players INTEGER,
    avg_mae FLOAT,
    avg_rmse FLOAT,
    r_squared FLOAT,
    
    -- Top performers
    best_projection_player VARCHAR,
    best_projection_error FLOAT,
    worst_projection_player VARCHAR,
    worst_projection_error FLOAT,
    
    -- Your performance (if tracked)
    lineups_entered INTEGER,
    total_winnings FLOAT,
    total_fees FLOAT,
    net_profit FLOAT,
    roi FLOAT,
    
    -- Metadata
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
""")

# Pattern discovery table
conn.execute("""
CREATE TABLE IF NOT EXISTS discovered_patterns (
    pattern_id INTEGER PRIMARY KEY,
    pattern_name VARCHAR NOT NULL,
    pattern_type VARCHAR,  -- 'rest', 'matchup', 'injury', 'streak', etc.
    
    -- Pattern details
    condition_description TEXT,
    avg_boost FLOAT,
    sample_size INTEGER,
    confidence_level VARCHAR,
    
    -- Statistical significance
    p_value FLOAT,
    t_statistic FLOAT,
    
    -- Actionable insight
    recommendation TEXT,
    
    -- Metadata
    discovered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    sport VARCHAR,
    platform VARCHAR
);
""")

print("  [OK] Schema created")

# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def detect_csv_type(file_path):
    """Detect what type of CSV this is by examining headers"""
    df = pd.read_csv(file_path, nrows=1)
    cols = set(df.columns)
    
    # DraftKings slate
    if 'Name' in cols and 'AvgPointsPerGame' in cols:
        return 'DK_SLATE'
    
    # FanDuel slate  
    if 'Nickname' in cols and 'FPPG' in cols:
        return 'FD_SLATE'
    
    # Contest results (entries/lineups)
    if 'Entry ID' in cols or 'Entry Name' in cols:
        return 'CONTEST_RESULTS'
    
    # Could be raw stats export
    if 'FP' in cols or 'FPTS' in cols or 'Fantasy Points' in cols:
        return 'STATS_EXPORT'
    
    return 'UNKNOWN'

def standardize_dk_nba(df, source_file):
    """Standardize DraftKings NBA data"""
    
    # Map columns to standard format
    standard = pd.DataFrame()
    
    standard['game_date'] = pd.to_datetime(df.get('Date', df.get('GameDate', None)))
    standard['player_name'] = df.get('Name', df.get('Player', None))
    standard['player_id'] = df.get('ID', df.get('PlayerId', None))
    standard['team'] = df.get('TeamAbbrev', df.get('Team', None))
    standard['opponent'] = df.get('OpponentAbbrev', df.get('Opp', None))
    standard['salary'] = df.get('Salary', None)
    standard['position'] = df.get('Position', df.get('Pos', None))
    
    # Fantasy points
    standard['fantasy_points'] = df.get('FPTS', df.get('FantasyPoints', 
                                        df.get('DraftKings points', None)))
    
    # Stats
    standard['minutes_played'] = df.get('Minutes', df.get('MIN', None))
    standard['points'] = df.get('Points', df.get('PTS', None))
    standard['rebounds'] = df.get('Rebounds', df.get('REB', None))
    standard['assists'] = df.get('Assists', df.get('AST', None))
    standard['steals'] = df.get('Steals', df.get('STL', None))
    standard['blocks'] = df.get('Blocks', df.get('BLK', None))
    standard['turnovers'] = df.get('Turnovers', df.get('TO', None))
    
    # Metadata
    standard['platform'] = 'DraftKings'
    standard['sport'] = 'NBA'
    standard['source_file'] = source_file
    
    return standard

def standardize_fd_nba(df, source_file):
    """Standardize FanDuel NBA data"""
    
    standard = pd.DataFrame()
    
    standard['game_date'] = pd.to_datetime(df.get('Date', df.get('GameDate', None)))
    standard['player_name'] = df.get('Nickname', df.get('Player', df.get('Name', None)))
    standard['player_id'] = df.get('Id', df.get('ID', None))
    standard['team'] = df.get('Team', None)
    standard['opponent'] = df.get('Opponent', df.get('Opp', None))
    standard['salary'] = df.get('Salary', None)
    standard['position'] = df.get('Position', df.get('Pos', None))
    
    # Fantasy points
    standard['fantasy_points'] = df.get('FPTS', df.get('FD points', 
                                        df.get('FantasyPoints', None)))
    
    # Stats
    standard['minutes_played'] = df.get('Minutes', df.get('MIN', None))
    standard['points'] = df.get('Points', df.get('PTS', None))
    standard['rebounds'] = df.get('Rebounds', df.get('REB', None))
    standard['assists'] = df.get('Assists', df.get('AST', None))
    standard['steals'] = df.get('Steals', df.get('STL', None))
    standard['blocks'] = df.get('Blocks', df.get('BLK', None))
    standard['turnovers'] = df.get('Turnovers', df.get('TO', None))
    
    # Metadata
    standard['platform'] = 'FanDuel'
    standard['sport'] = 'NBA'
    standard['source_file'] = source_file
    
    return standard

def standardize_nfl(df, source_file, platform):
    """Standardize NFL data (DK or FD)"""
    
    standard = pd.DataFrame()
    
    standard['game_date'] = pd.to_datetime(df.get('Date', df.get('GameDate', None)))
    
    if platform == 'DraftKings':
        standard['player_name'] = df.get('Name', None)
    else:  # FanDuel
        standard['player_name'] = df.get('Nickname', df.get('Name', None))
    
    standard['player_id'] = df.get('Id', df.get('ID', None))
    standard['team'] = df.get('Team', df.get('TeamAbbrev', None))
    standard['opponent'] = df.get('Opponent', df.get('OpponentAbbrev', None))
    standard['salary'] = df.get('Salary', None)
    standard['position'] = df.get('Position', df.get('Pos', None))
    
    # Fantasy points
    standard['fantasy_points'] = df.get('FPTS', df.get('FantasyPoints', 
                                        df.get('DraftKings points',
                                        df.get('FD points', None))))
    
    # NFL stats
    standard['passing_yards'] = df.get('PassYds', df.get('Passing Yards', None))
    standard['passing_tds'] = df.get('PassTD', df.get('Passing TDs', None))
    standard['rushing_yards'] = df.get('RushYds', df.get('Rushing Yards', None))
    standard['rushing_tds'] = df.get('RushTD', df.get('Rushing TDs', None))
    standard['receptions'] = df.get('Rec', df.get('Receptions', None))
    standard['receiving_yards'] = df.get('RecYds', df.get('Receiving Yards', None))
    standard['receiving_tds'] = df.get('RecTD', df.get('Receiving TDs', None))
    
    # Metadata
    standard['platform'] = platform
    standard['sport'] = 'NFL'
    standard['source_file'] = source_file
    
    return standard

# =============================================================================
# INGESTION
# =============================================================================

def ingest_directory(directory, platform, sport):
    """Ingest all CSVs from a directory"""
    
    if not directory.exists():
        print(f"\n  [WARNING] Directory not found: {directory}")
        return 0
    
    csv_files = list(directory.glob('*.csv'))
    
    if not csv_files:
        print(f"\n  [WARNING] No CSV files in: {directory}")
        return 0
    
    print(f"\n  Processing {len(csv_files)} files from {directory.name}...")
    
    total_rows = 0
    
    for csv_file in csv_files:
        try:
            print(f"    - {csv_file.name}...", end=' ')
            
            # Read CSV
            df = pd.read_csv(csv_file)
            
            # Standardize based on platform and sport
            if platform == 'DraftKings' and sport == 'NBA':
                standard = standardize_dk_nba(df, csv_file.name)
            elif platform == 'FanDuel' and sport == 'NBA':
                standard = standardize_fd_nba(df, csv_file.name)
            elif sport == 'NFL':
                standard = standardize_nfl(df, csv_file.name, platform)
            else:
                print("SKIPPED (unknown format)")
                continue
            
            # Remove rows with no fantasy points (likely headers or invalid data)
            standard = standard[standard['fantasy_points'].notna()]
            
            if len(standard) == 0:
                print("SKIPPED (no valid data)")
                continue
            
            # Insert into DuckDB
            conn.execute("""
                INSERT INTO historical_results 
                SELECT NULL as result_id, * FROM standard
            """)
            
            total_rows += len(standard)
            print(f"OK ({len(standard)} rows)")
            
        except Exception as e:
            print(f"ERROR: {e}")
            continue
    
    return total_rows

# =============================================================================
# MAIN INGESTION
# =============================================================================

print("\n" + "="*80)
print("INGESTING HISTORICAL DATA")
print("="*80)

total_ingested = 0

for key, directory in DATA_DIRS.items():
    platform, sport = key.split('_')
    
    if platform == 'DK':
        platform = 'DraftKings'
    else:
        platform = 'FanDuel'
    
    print(f"\n{platform} {sport}")
    print("-" * 40)
    
    rows = ingest_directory(directory, platform, sport)
    total_ingested += rows
    
    print(f"  Total rows ingested: {rows:,}")

# =============================================================================
# SUMMARY
# =============================================================================

print("\n" + "="*80)
print("INGESTION COMPLETE!")
print("="*80)

print(f"\nTotal rows ingested: {total_ingested:,}")

# Get summary stats
summary = conn.execute("""
    SELECT 
        platform,
        sport,
        COUNT(*) as num_rows,
        COUNT(DISTINCT player_name) as num_players,
        COUNT(DISTINCT game_date) as num_dates,
        MIN(game_date) as earliest_date,
        MAX(game_date) as latest_date,
        AVG(fantasy_points) as avg_fpts
    FROM historical_results
    GROUP BY platform, sport
    ORDER BY platform, sport
""").fetchdf()

print("\nDatabase Summary:")
print(summary.to_string(index=False))

# Close connection
conn.close()

print(f"\n{'='*80}")
print("DATA READY FOR ANALYSIS!")
print(f"{'='*80}")

print("\nNext steps:")
print("  1. Run: python analyze_projection_accuracy.py")
print("  2. Run: python discover_patterns.py")
print("  3. Run: python backtest_strategy.py")

print(f"\n{'='*80}")
