#!/usr/bin/env python
"""
LOG_SLATE_RESULTS.py

After each slate completes, run this to log your projections vs actual results.
This builds your accuracy tracking database for continuous improvement.

Usage:
    python log_slate_results.py --date 2026-01-03 --platform FanDuel --sport NBA
"""

import duckdb
import pandas as pd
import numpy as np
from pathlib import Path
import argparse
from datetime import datetime, timedelta

print("="*80)
print("SLATE RESULTS LOGGER")
print("="*80)

# Parse arguments
parser = argparse.ArgumentParser(description='Log slate results for accuracy tracking')
parser.add_argument('--date', required=True, help='Slate date (YYYY-MM-DD)')
parser.add_argument('--platform', default='FanDuel', choices=['FanDuel', 'DraftKings'])
parser.add_argument('--sport', default='NBA', choices=['NBA', 'NFL'])
parser.add_argument('--projections', help='Path to your projections CSV (optional - will auto-detect)')
parser.add_argument('--ownership', help='Path to ownership data CSV (optional)')

args = parser.parse_args()

# Connect to database
DB_PATH = 'data/dfs_warehouse.duckdb'
conn = duckdb.connect(DB_PATH)

slate_date = args.date
platform = args.platform
sport = args.sport

print(f"\nProcessing slate: {slate_date} ({platform} {sport})")

# =============================================================================
# STEP 1: Find your projections file
# =============================================================================

print("\nStep 1: Loading your projections...")

if args.projections:
    proj_file = Path(args.projections)
else:
    # Auto-detect from outputs folder
    outputs_dir = Path('outputs')
    
    # Look for projections from this date
    date_str = slate_date.replace('-', '')  # 20260103
    proj_files = list(outputs_dir.glob(f'projections_*{date_str}*.csv'))
    
    if not proj_files:
        # Try with different date format
        proj_files = list(outputs_dir.glob(f'projections_today*.csv'))
        if proj_files:
            # Use most recent
            proj_files.sort(key=lambda x: x.stat().st_mtime, reverse=True)
    
    if not proj_files:
        print("[ERROR] Could not find projections file!")
        print("Please specify with --projections flag")
        exit(1)
    
    proj_file = proj_files[0]

print(f"  Found: {proj_file.name}")

projections = pd.read_csv(proj_file)

print(f"  Loaded {len(projections)} player projections")

# Identify projection column
proj_col = None
for col in ['Projection', 'FD_Projection', 'DK_Projection', 'projection']:
    if col in projections.columns:
        proj_col = col
        break

if not proj_col:
    print("[ERROR] Could not find projection column!")
    print(f"Available columns: {list(projections.columns)}")
    exit(1)

print(f"  Using projection column: {proj_col}")

# =============================================================================
# STEP 2: Get actual results
# =============================================================================

print("\nStep 2: Getting actual results from database...")

actuals = conn.execute("""
    SELECT 
        player_name,
        fantasy_points,
        salary,
        position,
        team,
        opponent
    FROM historical_results
    WHERE game_date = ?
      AND platform = ?
      AND sport = ?
""", [slate_date, platform, sport]).fetchdf()

if len(actuals) == 0:
    print(f"[ERROR] No actual results found for {slate_date}!")
    print(f"\nMake sure you've run: python INGEST_HISTORICAL_DATA.py")
    print(f"And that you have data for {slate_date}")
    exit(1)

print(f"  Found {len(actuals)} actual results")

# =============================================================================
# STEP 3: Merge projections with actuals
# =============================================================================

print("\nStep 3: Merging projections with actuals...")

# Prepare projection data
proj_data = projections[['Name', proj_col]].copy()
proj_data.columns = ['player_name', 'your_projection']

# Merge
merged = actuals.merge(proj_data, on='player_name', how='inner')

print(f"  Matched {len(merged)} players")

if len(merged) == 0:
    print("[ERROR] No players matched!")
    print("This usually means player names don't match between files")
    print("\nSample projection names:")
    print(projections['Name'].head())
    print("\nSample actual names:")
    print(actuals['player_name'].head())
    exit(1)

# Calculate errors
merged['your_error'] = merged['your_projection'] - merged['fantasy_points']
merged['your_abs_error'] = abs(merged['your_error'])
merged['your_pct_error'] = (merged['your_error'] / merged['fantasy_points']) * 100

# Platform projection if available
if 'FieldProjection' in projections.columns:
    platform_proj = projections[['Name', 'FieldProjection']].copy()
    platform_proj.columns = ['player_name', 'platform_projection']
    merged = merged.merge(platform_proj, on='player_name', how='left')
    
    merged['platform_error'] = merged['platform_projection'] - merged['fantasy_points']
    merged['platform_abs_error'] = abs(merged['platform_error'])
else:
    merged['platform_projection'] = None
    merged['platform_error'] = None
    merged['platform_abs_error'] = None

# =============================================================================
# STEP 4: Insert into tracking database
# =============================================================================

print("\nStep 4: Saving to tracking database...")

for _, row in merged.iterrows():
    conn.execute("""
        INSERT INTO projection_tracking (
            tracking_id, game_date, player_name, platform, sport,
            your_projection, platform_projection,
            actual_points,
            your_error, your_abs_error, your_pct_error,
            platform_error, platform_abs_error,
            salary, ownership_actual, ownership_predicted
        ) VALUES (
            NULL, ?, ?, ?, ?,
            ?, ?,
            ?,
            ?, ?, ?,
            ?, ?,
            ?, NULL, NULL
        )
    """, [
        slate_date, row['player_name'], platform, sport,
        row['your_projection'], row['platform_projection'],
        row['fantasy_points'],
        row['your_error'], row['your_abs_error'], row['your_pct_error'],
        row['platform_error'], row['platform_abs_error'],
        row['salary']
    ])

print(f"  [OK] Saved {len(merged)} player results")

# =============================================================================
# STEP 5: Calculate slate-level metrics
# =============================================================================

print("\nStep 5: Calculating slate-level accuracy...")

# Your accuracy
your_mae = merged['your_abs_error'].mean()
your_rmse = np.sqrt((merged['your_error'] ** 2).mean())
correlation = merged['your_projection'].corr(merged['fantasy_points'])
r_squared = correlation ** 2

print(f"\n  Your Accuracy:")
print(f"    MAE:  {your_mae:.2f} points")
print(f"    RMSE: {your_rmse:.2f} points")
print(f"    R²:   {r_squared:.3f}")

# Best and worst projections
best_idx = merged['your_abs_error'].idxmin()
worst_idx = merged['your_abs_error'].idxmax()

best = merged.iloc[best_idx]
worst = merged.iloc[worst_idx]

print(f"\n  Best projection: {best['player_name']}")
print(f"    Projected: {best['your_projection']:.1f}, Actual: {best['fantasy_points']:.1f}, Error: {best['your_error']:+.1f}")

print(f"\n  Worst projection: {worst['player_name']}")
print(f"    Projected: {worst['your_projection']:.1f}, Actual: {worst['fantasy_points']:.1f}, Error: {worst['your_error']:+.1f}")

# Platform comparison (if available)
if merged['platform_projection'].notna().any():
    platform_mae = merged['platform_abs_error'].mean()
    print(f"\n  {platform} Accuracy:")
    print(f"    MAE:  {platform_mae:.2f} points")
    
    diff = your_mae - platform_mae
    if diff < 0:
        print(f"\n  [SUCCESS] You beat {platform} by {abs(diff):.2f} points!")
    else:
        print(f"\n  [INFO] {platform} beat you by {diff:.2f} points")

# Save slate-level stats
conn.execute("""
    INSERT INTO slate_performance (
        slate_id, game_date, platform, sport,
        num_players, avg_mae, avg_rmse, r_squared,
        best_projection_player, best_projection_error,
        worst_projection_player, worst_projection_error,
        lineups_entered, total_winnings, total_fees, net_profit, roi
    ) VALUES (
        NULL, ?, ?, ?,
        ?, ?, ?, ?,
        ?, ?,
        ?, ?,
        NULL, NULL, NULL, NULL, NULL
    )
""", [
    slate_date, platform, sport,
    len(merged), your_mae, your_rmse, r_squared,
    best['player_name'], best['your_error'],
    worst['player_name'], worst['your_error']
])

# =============================================================================
# STEP 6: Generate insights
# =============================================================================

print("\n" + "="*80)
print("INSIGHTS")
print("="*80)

# Find systematic biases
overproj = merged[merged['your_error'] > 5]
underproj = merged[merged['your_error'] < -5]

if len(overproj) > 0:
    print(f"\nOverprojected (by 5+ points): {len(overproj)} players")
    print(overproj[['player_name', 'your_projection', 'fantasy_points', 'your_error']].head(10).to_string(index=False))

if len(underproj) > 0:
    print(f"\nUnderprojected (by 5+ points): {len(underproj)} players")
    print(underproj[['player_name', 'your_projection', 'fantasy_points', 'your_error']].head(10).to_string(index=False))

# Position analysis
print("\nAccuracy by position:")
pos_accuracy = merged.groupby('position').agg({
    'your_abs_error': 'mean',
    'player_name': 'count'
}).rename(columns={'player_name': 'count', 'your_abs_error': 'mae'})
print(pos_accuracy.to_string())

# Team analysis
print("\nAccuracy by team:")
team_accuracy = merged.groupby('team').agg({
    'your_abs_error': 'mean',
    'your_error': 'mean',
    'player_name': 'count'
}).rename(columns={'player_name': 'count', 'your_abs_error': 'mae', 'your_error': 'bias'})
print(team_accuracy.sort_values('mae', ascending=False).head(10).to_string())

# Close connection
conn.close()

print("\n" + "="*80)
print("RESULTS LOGGED SUCCESSFULLY!")
print("="*80)

print(f"\nYou now have projection tracking data!")
print(f"Run: python ANALYZE_PROJECTION_ACCURACY.py")
print(f"     to see trends over multiple slates")

print("\n" + "="*80)
