#!/usr/bin/env python
"""
NBA_STATS_API.py

Connector for official NBA Stats API (FREE)
Gets player game logs, team stats, advanced metrics, etc.

Documentation: https://github.com/swar/nba_api
"""

import requests
import pandas as pd
import time
from datetime import datetime, timedelta
import json

class NBAStatsAPI:
    """Wrapper for NBA Stats API"""
    
    BASE_URL = 'https://stats.nba.com/stats'
    
    HEADERS = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Referer': 'https://stats.nba.com/',
        'Origin': 'https://stats.nba.com',
        'Accept': 'application/json',
    }
    
    def __init__(self, delay=3):
        """
        Initialize API wrapper
        
        Args:
            delay: Seconds to wait between requests (default: 3)
        """
        self.delay = delay
        self.last_request_time = 0
    
    def _make_request(self, endpoint, params):
        """Make API request with rate limiting"""
        
        # Rate limiting
        time_since_last = time.time() - self.last_request_time
        if time_since_last < self.delay:
            time.sleep(self.delay - time_since_last)
        
        # Make request
        url = f"{self.BASE_URL}/{endpoint}"
        
        try:
            response = requests.get(url, headers=self.HEADERS, params=params, timeout=30)
            response.raise_for_status()
            self.last_request_time = time.time()
            return response.json()
        
        except requests.exceptions.RequestException as e:
            print(f"  [ERROR] API request failed: {e}")
            return None
    
    def get_player_game_logs(self, season='2024-25', player_id=None):
        """
        Get player game logs for a season
        
        Args:
            season: Season (e.g., '2024-25')
            player_id: Specific player ID (optional)
        
        Returns:
            DataFrame with game logs
        """
        
        endpoint = 'playergamelogs'
        
        params = {
            'Season': season,
            'SeasonType': 'Regular Season',
        }
        
        if player_id:
            params['PlayerID'] = player_id
        
        print(f"  Fetching player game logs for {season}...")
        
        data = self._make_request(endpoint, params)
        
        if not data:
            return pd.DataFrame()
        
        try:
            # Parse response
            result_sets = data.get('resultSets', [])
            if not result_sets:
                return pd.DataFrame()
            
            headers = result_sets[0]['headers']
            rows = result_sets[0]['rowSet']
            
            df = pd.DataFrame(rows, columns=headers)
            
            print(f"    [OK] Got {len(df)} game logs")
            
            return df
        
        except Exception as e:
            print(f"  [ERROR] Failed to parse response: {e}")
            return pd.DataFrame()
    
    def get_player_info(self, player_id):
        """Get detailed player information"""
        
        endpoint = 'commonplayerinfo'
        params = {'PlayerID': player_id}
        
        data = self._make_request(endpoint, params)
        
        if not data:
            return None
        
        try:
            result_sets = data.get('resultSets', [])
            if not result_sets:
                return None
            
            headers = result_sets[0]['headers']
            row = result_sets[0]['rowSet'][0]
            
            info = dict(zip(headers, row))
            return info
        
        except Exception as e:
            print(f"  [ERROR] Failed to get player info: {e}")
            return None
    
    def get_team_game_logs(self, season='2024-25', team_id=None):
        """Get team game logs"""
        
        endpoint = 'teamgamelogs'
        
        params = {
            'Season': season,
            'SeasonType': 'Regular Season',
        }
        
        if team_id:
            params['TeamID'] = team_id
        
        print(f"  Fetching team game logs for {season}...")
        
        data = self._make_request(endpoint, params)
        
        if not data:
            return pd.DataFrame()
        
        try:
            result_sets = data.get('resultSets', [])
            if not result_sets:
                return pd.DataFrame()
            
            headers = result_sets[0]['headers']
            rows = result_sets[0]['rowSet']
            
            df = pd.DataFrame(rows, columns=headers)
            
            print(f"    [OK] Got {len(df)} team game logs")
            
            return df
        
        except Exception as e:
            print(f"  [ERROR] Failed to parse response: {e}")
            return pd.DataFrame()
    
    def get_todays_scoreboard(self):
        """Get today's games"""
        
        endpoint = 'scoreboardv2'
        
        today = datetime.now().strftime('%m/%d/%Y')
        
        params = {
            'GameDate': today,
            'LeagueID': '00',
            'DayOffset': '0'
        }
        
        print(f"  Fetching scoreboard for {today}...")
        
        data = self._make_request(endpoint, params)
        
        if not data:
            return pd.DataFrame()
        
        try:
            # Get game header
            result_sets = data.get('resultSets', [])
            
            for rs in result_sets:
                if rs['name'] == 'GameHeader':
                    headers = rs['headers']
                    rows = rs['rowSet']
                    df = pd.DataFrame(rows, columns=headers)
                    print(f"    [OK] Got {len(df)} games")
                    return df
            
            return pd.DataFrame()
        
        except Exception as e:
            print(f"  [ERROR] Failed to parse scoreboard: {e}")
            return pd.DataFrame()
    
    def get_injury_report(self):
        """Get current injury report"""
        
        # Note: NBA API doesn't have a dedicated injury endpoint
        # Injuries are typically in player info or box scores
        # For real-time injuries, scrape from official NBA injury report page
        # or use Twitter/news sources
        
        print("  [INFO] NBA API doesn't have injury endpoint")
        print("        Use official NBA injury report or news sources")
        
        return pd.DataFrame()
    
    def calculate_fantasy_points(self, game_log_row, scoring='DraftKings'):
        """
        Calculate fantasy points from box score
        
        Args:
            game_log_row: Row from game log DataFrame
            scoring: 'DraftKings' or 'FanDuel'
        
        Returns:
            Fantasy points (float)
        """
        
        try:
            pts = float(game_log_row.get('PTS', 0))
            reb = float(game_log_row.get('REB', 0))
            ast = float(game_log_row.get('AST', 0))
            stl = float(game_log_row.get('STL', 0))
            blk = float(game_log_row.get('BLK', 0))
            to = float(game_log_row.get('TOV', 0))
            
            if scoring == 'DraftKings':
                # DK scoring
                fpts = (pts * 1.0 + reb * 1.25 + ast * 1.5 + 
                       stl * 2.0 + blk * 2.0 - to * 0.5)
                
                # Double-double bonus
                stats = [pts >= 10, reb >= 10, ast >= 10, stl >= 10, blk >= 10]
                if sum(stats) >= 2:
                    fpts += 1.5
                
                # Triple-double bonus
                if sum(stats) >= 3:
                    fpts += 3.0
            
            elif scoring == 'FanDuel':
                # FD scoring
                fpts = (pts * 1.0 + reb * 1.2 + ast * 1.5 + 
                       stl * 3.0 + blk * 3.0 - to * 1.0)
            
            else:
                raise ValueError(f"Unknown scoring: {scoring}")
            
            return round(fpts, 1)
        
        except Exception as e:
            print(f"  [ERROR] Failed to calculate fantasy points: {e}")
            return 0.0

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def get_current_season():
    """Get current NBA season string (e.g., '2024-25')"""
    now = datetime.now()
    
    # NBA season runs Oct-June
    if now.month >= 10:
        # New season started
        year = now.year
    else:
        # Still in previous season
        year = now.year - 1
    
    return f"{year}-{str(year + 1)[-2:]}"

def standardize_game_log(df):
    """Standardize NBA game log columns for database"""
    
    standardized = pd.DataFrame()
    
    # Player info
    standardized['player_id'] = df.get('PLAYER_ID')
    standardized['player_name'] = df.get('PLAYER_NAME')
    standardized['team'] = df.get('TEAM_ABBREVIATION')
    
    # Game info
    standardized['game_id'] = df.get('GAME_ID')
    standardized['date'] = pd.to_datetime(df.get('GAME_DATE'))
    standardized['opponent'] = df.get('MATCHUP').str.split(' ').str[-1]  # Extract opp
    standardized['home_away'] = df.get('MATCHUP').apply(
        lambda x: 'Home' if 'vs.' in str(x) else 'Away'
    )
    
    # Stats
    standardized['minutes_played'] = df.get('MIN')
    standardized['points'] = df.get('PTS')
    standardized['rebounds'] = df.get('REB')
    standardized['assists'] = df.get('AST')
    standardized['steals'] = df.get('STL')
    standardized['blocks'] = df.get('BLK')
    standardized['turnovers'] = df.get('TOV')
    standardized['fgm'] = df.get('FGM')
    standardized['fga'] = df.get('FGA')
    standardized['fg3m'] = df.get('FG3M')
    standardized['fg3a'] = df.get('FG3A')
    standardized['ftm'] = df.get('FTM')
    standardized['fta'] = df.get('FTA')
    standardized['offensive_rebounds'] = df.get('OREB')
    standardized['defensive_rebounds'] = df.get('DREB')
    standardized['plus_minus'] = df.get('PLUS_MINUS')
    
    return standardized

# ============================================================================
# USAGE EXAMPLE
# ============================================================================

if __name__ == '__main__':
    
    print("="*80)
    print("NBA STATS API - TEST")
    print("="*80)
    
    # Initialize API
    api = NBAStatsAPI(delay=3)
    
    # Get current season
    season = get_current_season()
    print(f"\nCurrent season: {season}")
    
    # Test: Get recent game logs
    print("\nTesting: Get player game logs...")
    game_logs = api.get_player_game_logs(season=season)
    
    if not game_logs.empty:
        print(f"\n✅ Success! Got {len(game_logs)} game logs")
        print(f"\nSample data:")
        print(game_logs[['PLAYER_NAME', 'GAME_DATE', 'PTS', 'REB', 'AST']].head(10))
        
        # Calculate fantasy points
        print("\nCalculating fantasy points...")
        for idx, row in game_logs.head(5).iterrows():
            dk_pts = api.calculate_fantasy_points(row, 'DraftKings')
            fd_pts = api.calculate_fantasy_points(row, 'FanDuel')
            print(f"  {row['PLAYER_NAME']}: DK={dk_pts}, FD={fd_pts}")
    
    # Test: Today's games
    print("\nTesting: Today's scoreboard...")
    scoreboard = api.get_todays_scoreboard()
    
    if not scoreboard.empty:
        print(f"\n✅ Found {len(scoreboard)} games today")
    else:
        print("\n  No games today")
    
    print("\n" + "="*80)
    print("TEST COMPLETE!")
    print("="*80)
