#!/usr/bin/env python
"""
ownership_insights_analyzer.py

Deep analysis of 10K ownership simulation to find edges:
1. Ownership tier analysis (chalk, balanced, contrarian)
2. Salary-adjusted ownership ($/own ratio)
3. Projection vs ownership gaps (leverage spots)
4. Position-specific ownership patterns
5. Correlation analysis (which players appear together)
6. Value detection (high proj, low own, low salary)

Usage:
    python ownership_insights_analyzer.py "outputs/ownership_study_nba_*.csv" "outputs/projections_today*.csv"
"""

import argparse
import pandas as pd
import numpy as np
from pathlib import Path
import matplotlib.pyplot as plt
import seaborn as sns
from collections import defaultdict

print("="*80)
print("OWNERSHIP INSIGHTS ANALYZER")
print("="*80)

def load_latest_file(pattern: str) -> Path:
    """Get most recent file matching pattern"""
    files = sorted(Path(".").glob(pattern), key=lambda p: p.stat().st_mtime, reverse=True)
    return files[0] if files else None

def categorize_ownership(own: float) -> str:
    """Categorize player by ownership tier"""
    if own >= 0.30:
        return "Chalk"
    elif own >= 0.15:
        return "Balanced"
    elif own >= 0.05:
        return "Contrarian"
    else:
        return "Punt"

def analyze_ownership_distribution(ownership: pd.DataFrame, projections: pd.DataFrame):
    """Analyze overall ownership patterns"""
    
    # Merge data
    df = ownership.merge(projections[['Name', 'Salary', 'Projection', 'Position']], 
                        on='Name', how='left')
    
    # Add ownership category
    df['OwnCategory'] = df['SimOwnership'].apply(categorize_ownership)
    
    # Calculate leverage
    df['Leverage'] = df['Projection'] / (df['SimOwnership'] + 0.01)
    
    # Calculate value ($/ownership point)
    df['DollarsPerOwnPct'] = df['Salary'] / (df['SimOwnership'] * 100 + 0.01)
    
    print("\n" + "="*80)
    print("OWNERSHIP DISTRIBUTION ANALYSIS")
    print("="*80)
    
    # Overall stats
    print(f"\nTotal players analyzed: {len(df)}")
    print(f"Average ownership: {df['SimOwnership'].mean()*100:.1f}%")
    print(f"Median ownership: {df['SimOwnership'].median()*100:.1f}%")
    print(f"Ownership std dev: {df['SimOwnership'].std()*100:.1f}%")
    
    # By tier
    print(f"\n OWNERSHIP TIERS:")
    tier_counts = df['OwnCategory'].value_counts()
    for tier in ['Chalk', 'Balanced', 'Contrarian', 'Punt']:
        count = tier_counts.get(tier, 0)
        pct = (count / len(df)) * 100
        avg_own = df[df['OwnCategory'] == tier]['SimOwnership'].mean() * 100
        print(f"  {tier:12s}: {count:3d} players ({pct:4.1f}%) | Avg own: {avg_own:5.1f}%")
    
    return df

def find_leverage_plays(df: pd.DataFrame, min_proj: float = 25, max_own: float = 0.15):
    """Find high leverage opportunities"""
    
    print("\n" + "="*80)
    print(" HIGH LEVERAGE PLAYS (High Proj, Low Own)")
    print("="*80)
    print(f"Criteria: Projection >= {min_proj} pts, Ownership <= {max_own*100}%\n")
    
    leverage = df[
        (df['Projection'] >= min_proj) &
        (df['SimOwnership'] <= max_own)
    ].sort_values('Leverage', ascending=False)
    
    if len(leverage) == 0:
        print("No players meet criteria")
        return leverage
    
    print(f"{'Name':<25} {'Pos':>6} {'Proj':>6} {'Own':>6} {'Salary':>8} {'Leverage':>9}")
    print("-"*80)
    
    for _, p in leverage.head(20).iterrows():
        print(f"{p['Name']:<25} {str(p.get('Position', 'N/A')):>6} "
              f"{p['Projection']:>6.1f} {p['SimOwnership']*100:>5.1f}% "
              f"${p['Salary']:>6,.0f} {p['Leverage']:>9.2f}")
    
    return leverage

def find_value_plays(df: pd.DataFrame, max_salary: int = 5500, min_proj: float = 20):
    """Find value plays - low salary, solid projection"""
    
    print("\n" + "="*80)
    print(" VALUE PLAYS (Low Salary, Solid Projection)")
    print("="*80)
    print(f"Criteria: Salary <= ${max_salary:,}, Projection >= {min_proj} pts\n")
    
    value = df[
        (df['Salary'] <= max_salary) &
        (df['Projection'] >= min_proj)
    ].sort_values('Projection', ascending=False)
    
    if len(value) == 0:
        print("No players meet criteria")
        return value
    
    print(f"{'Name':<25} {'Pos':>6} {'Salary':>8} {'Proj':>6} {'Own':>6} {'Pts/$K':>8}")
    print("-"*80)
    
    for _, p in value.head(20).iterrows():
        pts_per_k = (p['Projection'] / p['Salary']) * 1000
        print(f"{p['Name']:<25} {str(p.get('Position', 'N/A')):>6} "
              f"${p['Salary']:>6,.0f} {p['Projection']:>6.1f} "
              f"{p['SimOwnership']*100:>5.1f}% {pts_per_k:>8.2f}")
    
    return value

def find_chalky_busts(df: pd.DataFrame, min_own: float = 0.30, max_proj: float = 35):
    """Find potentially overowned players (fade candidates)"""
    
    print("\n" + "="*80)
    print("[WARNING]  POTENTIAL CHALK BUSTS (High Own, Mediocre Proj)")
    print("="*80)
    print(f"Criteria: Ownership >= {min_own*100}%, Projection <= {max_proj} pts\n")
    
    chalk = df[
        (df['SimOwnership'] >= min_own) &
        (df['Projection'] <= max_proj)
    ].sort_values('SimOwnership', ascending=False)
    
    if len(chalk) == 0:
        print("No players meet criteria")
        return chalk
    
    print(f"{'Name':<25} {'Pos':>6} {'Own':>6} {'Proj':>6} {'Salary':>8} {'Value':>7}")
    print("-"*80)
    
    for _, p in chalk.head(15).iterrows():
        pts_per_k = (p['Projection'] / p['Salary']) * 1000
        print(f"{p['Name']:<25} {str(p.get('Position', 'N/A')):>6} "
              f"{p['SimOwnership']*100:>5.1f}% {p['Projection']:>6.1f} "
              f"${p['Salary']:>6,.0f} {pts_per_k:>7.2f}")
    
    return chalk

def position_ownership_analysis(df: pd.DataFrame):
    """Analyze ownership patterns by position"""
    
    print("\n" + "="*80)
    print(" POSITION-LEVEL OWNERSHIP ANALYSIS")
    print("="*80)
    
    if 'Position' not in df.columns or df['Position'].isna().all():
        print("Position data not available")
        return
    
    # Extract primary position
    df['PrimaryPos'] = df['Position'].str.split('/').str[0]
    
    pos_stats = df.groupby('PrimaryPos').agg({
        'SimOwnership': ['mean', 'std', 'min', 'max'],
        'Projection': 'mean',
        'Salary': 'mean',
        'Name': 'count'
    }).round(3)
    
    print(f"\n{'Pos':>4} {'Count':>6} {'AvgOwn':>8} {'StdOwn':>8} {'MinOwn':>8} {'MaxOwn':>8} {'AvgProj':>9} {'AvgSal':>9}")
    print("-"*80)
    
    for pos in ['PG', 'SG', 'SF', 'PF', 'C']:
        if pos in pos_stats.index:
            row = pos_stats.loc[pos]
            print(f"{pos:>4} {row[('Name', 'count')]:>6.0f} "
                  f"{row[('SimOwnership', 'mean')]*100:>7.1f}% "
                  f"{row[('SimOwnership', 'std')]*100:>7.1f}% "
                  f"{row[('SimOwnership', 'min')]*100:>7.1f}% "
                  f"{row[('SimOwnership', 'max')]*100:>7.1f}% "
                  f"{row[('Projection', 'mean')]:>9.1f} "
                  f"${row[('Salary', 'mean')]:>7,.0f}")

def salary_tier_analysis(df: pd.DataFrame):
    """Analyze ownership by salary tier"""
    
    print("\n" + "="*80)
    print(" SALARY TIER ANALYSIS")
    print("="*80)
    
    # Define tiers
    df['SalaryTier'] = pd.cut(df['Salary'], 
                              bins=[0, 4000, 5500, 7000, 9000, 15000],
                              labels=['Punt (<$4K)', 'Value ($4-5.5K)', 
                                     'Mid ($5.5-7K)', 'Premium ($7-9K)', 
                                     'Elite ($9K+)'])
    
    tier_stats = df.groupby('SalaryTier').agg({
        'SimOwnership': ['mean', 'std'],
        'Projection': 'mean',
        'Name': 'count'
    }).round(3)
    
    print(f"\n{'Tier':<20} {'Count':>6} {'AvgOwn':>8} {'StdOwn':>8} {'AvgProj':>9}")
    print("-"*80)
    
    for tier in tier_stats.index:
        row = tier_stats.loc[tier]
        print(f"{tier:<20} {row[('Name', 'count')]:>6.0f} "
              f"{row[('SimOwnership', 'mean')]*100:>7.1f}% "
              f"{row[('SimOwnership', 'std')]*100:>7.1f}% "
              f"{row[('Projection', 'mean')]:>9.1f}")

def export_insights(leverage: pd.DataFrame, value: pd.DataFrame, 
                   chalk: pd.DataFrame, output_dir: Path):
    """Export findings to CSV files"""
    
    output_dir.mkdir(exist_ok=True, parents=True)
    
    if not leverage.empty:
        leverage.to_csv(output_dir / "leverage_plays.csv", index=False)
        print(f"\n[OK] Leverage plays: {output_dir / 'leverage_plays.csv'}")
    
    if not value.empty:
        value.to_csv(output_dir / "value_plays.csv", index=False)
        print(f"[OK] Value plays: {output_dir / 'value_plays.csv'}")
    
    if not chalk.empty:
        chalk.to_csv(output_dir / "chalk_fade_candidates.csv", index=False)
        print(f"[OK] Chalk fades: {output_dir / 'chalk_fade_candidates.csv'}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("ownership_csv", nargs='?', default=None, 
                   help="Ownership simulation CSV")
    ap.add_argument("projections_csv", nargs='?', default=None,
                   help="Projections CSV")
    ap.add_argument("--min-leverage-proj", type=float, default=25)
    ap.add_argument("--max-leverage-own", type=float, default=0.15)
    ap.add_argument("--max-value-salary", type=int, default=5500)
    ap.add_argument("--min-value-proj", type=float, default=20)
    args = ap.parse_args()
    
    # Load files
    if args.ownership_csv:
        own_file = Path(args.ownership_csv)
    else:
        own_file = load_latest_file("outputs/ownership_study_nba*.csv")
    
    if args.projections_csv:
        proj_file = Path(args.projections_csv)
    else:
        proj_file = load_latest_file("outputs/projections_today*.csv")
    
    if not own_file or not own_file.exists():
        print("[ERROR] Ownership file not found")
        return
    
    if not proj_file or not proj_file.exists():
        print("[ERROR] Projections file not found")
        return
    
    print(f"\n Loading data...")
    print(f"   Ownership: {own_file.name}")
    print(f"   Projections: {proj_file.name}")
    
    ownership = pd.read_csv(own_file)
    projections = pd.read_csv(proj_file)
    
    # Run analyses
    df = analyze_ownership_distribution(ownership, projections)
    
    leverage = find_leverage_plays(df, 
                                   min_proj=args.min_leverage_proj,
                                   max_own=args.max_leverage_own)
    
    value = find_value_plays(df,
                            max_salary=args.max_value_salary,
                            min_proj=args.min_value_proj)
    
    chalk = find_chalky_busts(df)
    
    position_ownership_analysis(df)
    
    salary_tier_analysis(df)
    
    # Export
    export_insights(leverage, value, chalk, Path("outputs/insights"))
    
    print("\n" + "="*80)
    print(" KEY TAKEAWAYS:")
    print("="*80)
    print("""
1. LEVERAGE PLAYS = Your GPP targets (high proj, low own)
2. VALUE PLAYS = Your salary savers (low price, solid proj)
3. CHALK FADES = Consider avoiding (high own, mediocre proj)
4. Position patterns = Where is ownership concentrated?
5. Salary tiers = Are elites or punts more popular?

[TIP] STRATEGY:
- GPPs: Stack leverage + value plays, fade chalk
- Cash: Use balanced ownership (15-30%), avoid extremes
- Differentiation: Find your 3-4 leverage plays, build around them
    """)
    
    print("="*80)
    print("[OK] ANALYSIS COMPLETE!")
    print("="*80)

if __name__ == "__main__":
    main()
