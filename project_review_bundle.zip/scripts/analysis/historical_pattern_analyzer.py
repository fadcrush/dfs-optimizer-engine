#!/usr/bin/env python
"""
historical_pattern_analyzer.py

Mine your DuckDB game logs for predictive patterns:
1. Player performance after rest days
2. Home vs away splits
3. Opponent-specific performance
4. Back-to-back game impact
5. Usage rate changes when teammates out
6. Blowout vs close game patterns
7. Time-of-season trends

Usage:
    python historical_pattern_analyzer.py --season 2024-25 --db "data/dfs_warehouse.duckdb"
"""

import argparse
import duckdb
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime, timedelta

print("="*80)
print("HISTORICAL PATTERN ANALYZER")
print("="*80)

def analyze_rest_impact(con: duckdb.DuckDBPyConnection, season: str):
    """Analyze how rest days affect performance"""
    
    print("\n" + "="*80)
    print(" REST DAYS IMPACT ANALYSIS")
    print("="*80)
    
    q = """
    WITH games AS (
        SELECT 
            player_id,
            player_name,
            game_date,
            fd_points,
            LAG(game_date) OVER (PARTITION BY player_id ORDER BY game_date) as prev_game,
            AVG(fd_points) OVER (PARTITION BY player_id) as season_avg
        FROM nba_player_game_logs
        WHERE season = ?
          AND fd_points IS NOT NULL
          AND minutes > 15
    ),
    with_rest AS (
        SELECT 
            player_id,
            player_name,
            CASE 
                WHEN prev_game IS NULL THEN 'First game'
                WHEN DATEDIFF('day', prev_game, game_date) = 1 THEN 'Back-to-back'
                WHEN DATEDIFF('day', prev_game, game_date) = 2 THEN '1 day rest'
                WHEN DATEDIFF('day', prev_game, game_date) >= 3 THEN '2+ days rest'
            END as rest_category,
            fd_points,
            season_avg
        FROM games
        WHERE prev_game IS NOT NULL
    )
    SELECT 
        rest_category,
        COUNT(*) as games,
        AVG(fd_points) as avg_performance,
        AVG(fd_points / season_avg) as pct_of_season_avg,
        STDDEV(fd_points) as std_dev
    FROM with_rest
    GROUP BY rest_category
    ORDER BY 
        CASE rest_category
            WHEN 'Back-to-back' THEN 1
            WHEN '1 day rest' THEN 2
            WHEN '2+ days rest' THEN 3
        END
    """
    
    result = con.execute(q, [season]).df()
    
    if result.empty:
        print("No data available")
        return result
    
    print(f"\n{'Rest Category':<20} {'Games':>8} {'Avg FD Pts':>12} {'vs Season':>10} {'Std Dev':>10}")
    print("-"*80)
    
    for _, row in result.iterrows():
        pct = (row['pct_of_season_avg'] - 1) * 100
        sign = '+' if pct > 0 else ''
        print(f"{row['rest_category']:<20} {row['games']:>8.0f} "
              f"{row['avg_performance']:>12.1f} {sign}{pct:>9.1f}% "
              f"{row['std_dev']:>10.1f}")
    
    print("\n[TIP] INSIGHTS:")
    b2b = result[result['rest_category'] == 'Back-to-back']
    rested = result[result['rest_category'] == '2+ days rest']
    
    if not b2b.empty and not rested.empty:
        b2b_impact = (b2b['pct_of_season_avg'].iloc[0] - 1) * 100
        rest_impact = (rested['pct_of_season_avg'].iloc[0] - 1) * 100
        
        print(f"   B2B Impact: {b2b_impact:+.1f}% vs season average")
        print(f"   Well-rested: {rest_impact:+.1f}% vs season average")
    
    return result

def analyze_home_away_splits(con: duckdb.DuckDBPyConnection, season: str, min_games: int = 10):
    """Find players with significant home/away splits"""
    
    print("\n" + "="*80)
    print(" HOME vs AWAY SPLITS")
    print("="*80)
    
    q = """
    WITH splits AS (
        SELECT 
            player_id,
            player_name,
            is_home,
            COUNT(*) as games,
            AVG(fd_points) as avg_fd,
            STDDEV(fd_points) as std_dev
        FROM nba_player_game_logs
        WHERE season = ?
          AND fd_points IS NOT NULL
          AND minutes > 15
        GROUP BY player_id, player_name, is_home
        HAVING COUNT(*) >= ?
    ),
    pivoted AS (
        SELECT 
            player_name,
            MAX(CASE WHEN is_home THEN avg_fd END) as home_avg,
            MAX(CASE WHEN NOT is_home THEN avg_fd END) as away_avg,
            MAX(CASE WHEN is_home THEN games END) as home_games,
            MAX(CASE WHEN NOT is_home THEN games END) as away_games
        FROM splits
        GROUP BY player_name
        HAVING home_avg IS NOT NULL AND away_avg IS NOT NULL
    )
    SELECT 
        player_name,
        home_avg,
        away_avg,
        home_avg - away_avg as diff,
        ABS(home_avg - away_avg) / ((home_avg + away_avg) / 2) as pct_diff,
        home_games,
        away_games
    FROM pivoted
    WHERE ABS(home_avg - away_avg) > 3
    ORDER BY ABS(diff) DESC
    LIMIT 30
    """
    
    result = con.execute(q, [season, min_games]).df()
    
    if result.empty:
        print("No significant splits found")
        return result
    
    print(f"\nPlayers with >3 pt home/away difference (min {min_games} games each):\n")
    print(f"{'Player':<25} {'Home':>8} {'Away':>8} {'Diff':>8} {'% Diff':>8}")
    print("-"*80)
    
    for _, row in result.head(20).iterrows():
        print(f"{row['player_name']:<25} {row['home_avg']:>8.1f} "
              f"{row['away_avg']:>8.1f} {row['diff']:>+8.1f} "
              f"{row['pct_diff']*100:>7.1f}%")
    
    return result

def analyze_blowout_performance(con: duckdb.DuckDBPyConnection, season: str):
    """Analyze performance in blowouts vs close games"""
    
    print("\n" + "="*80)
    print(" BLOWOUT vs CLOSE GAME PERFORMANCE")
    print("="*80)
    
    q = """
    WITH game_margins AS (
        SELECT 
            game_date,
            team_abbr,
            opp_abbr,
            SUM(fd_points) as team_fd,
            -- Get opponent total via self-join later
            team_abbr || '|' || opp_abbr || '|' || game_date as game_key
        FROM nba_player_game_logs
        WHERE season = ?
          AND fd_points IS NOT NULL
        GROUP BY game_date, team_abbr, opp_abbr
    ),
    margins AS (
        SELECT 
            a.game_date,
            a.team_abbr,
            a.team_fd,
            b.team_fd as opp_fd,
            ABS(a.team_fd - b.team_fd) as margin
        FROM game_margins a
        JOIN game_margins b
          ON a.game_date = b.game_date
         AND a.team_abbr = b.opp_abbr
         AND a.opp_abbr = b.team_abbr
    ),
    player_games AS (
        SELECT 
            p.player_id,
            p.player_name,
            p.game_date,
            p.team_abbr,
            p.fd_points,
            p.minutes,
            m.margin,
            CASE 
                WHEN m.margin >= 25 THEN 'Blowout (25+)'
                WHEN m.margin >= 15 THEN 'Big lead (15-24)'
                WHEN m.margin < 15 THEN 'Close game (<15)'
            END as game_type
        FROM nba_player_game_logs p
        JOIN margins m
          ON p.game_date = m.game_date
         AND p.team_abbr = m.team_abbr
        WHERE p.season = ?
          AND p.fd_points IS NOT NULL
          AND p.minutes > 15
    )
    SELECT 
        game_type,
        COUNT(*) as games,
        AVG(fd_points) as avg_fd,
        AVG(minutes) as avg_min,
        STDDEV(fd_points) as std_dev
    FROM player_games
    GROUP BY game_type
    ORDER BY 
        CASE game_type
            WHEN 'Close game (<15)' THEN 1
            WHEN 'Big lead (15-24)' THEN 2
            WHEN 'Blowout (25+)' THEN 3
        END
    """
    
    result = con.execute(q, [season, season]).df()
    
    if result.empty:
        print("No data available")
        return result
    
    print(f"\n{'Game Type':<20} {'Games':>8} {'Avg FD':>10} {'Avg Min':>10} {'Std Dev':>10}")
    print("-"*80)
    
    for _, row in result.iterrows():
        print(f"{row['game_type']:<20} {row['games']:>8.0f} "
              f"{row['avg_fd']:>10.1f} {row['avg_min']:>10.1f} "
              f"{row['std_dev']:>10.1f}")
    
    print("\n[TIP] INSIGHTS:")
    print("   Blowouts = Starters sit, bench gets minutes")
    print("   Close games = Starters play full minutes")
    print("   -> Monitor Vegas spreads for blowout risk!")
    
    return result

def find_opponent_crushers(con: duckdb.DuckDBPyConnection, season: str, min_games: int = 3):
    """Find players who consistently crush specific opponents"""
    
    print("\n" + "="*80)
    print(" OPPONENT-SPECIFIC DOMINANCE")
    print("="*80)
    
    q = """
    WITH opp_performance AS (
        SELECT 
            player_name,
            opp_abbr,
            COUNT(*) as games,
            AVG(fd_points) as avg_vs_opp,
            AVG(AVG(fd_points)) OVER (PARTITION BY player_name) as season_avg
        FROM nba_player_game_logs
        WHERE season = ?
          AND fd_points IS NOT NULL
          AND minutes > 15
        GROUP BY player_name, opp_abbr
        HAVING COUNT(*) >= ?
    )
    SELECT 
        player_name,
        opp_abbr,
        games,
        avg_vs_opp,
        season_avg,
        avg_vs_opp - season_avg as diff,
        (avg_vs_opp / season_avg - 1) * 100 as pct_above_avg
    FROM opp_performance
    WHERE avg_vs_opp > season_avg + 5
    ORDER BY pct_above_avg DESC
    LIMIT 25
    """
    
    result = con.execute(q, [season, min_games]).df()
    
    if result.empty:
        print(f"No players with {min_games}+ games vs same opponent")
        return result
    
    print(f"\nPlayers who dominate specific opponents (min {min_games} games):\n")
    print(f"{'Player':<25} {'vs':>4} {'Games':>6} {'AvgVs':>7} {'Season':>7} {'Above':>7}")
    print("-"*80)
    
    for _, row in result.head(20).iterrows():
        print(f"{row['player_name']:<25} {row['opp_abbr']:>4} "
              f"{row['games']:>6.0f} {row['avg_vs_opp']:>7.1f} "
              f"{row['season_avg']:>7.1f} {row['pct_above_avg']:>+6.1f}%")
    
    return result

def analyze_usage_bump_injuries(con: duckdb.DuckDBPyConnection, season: str):
    """Identify players who benefit when teammates are out"""
    
    print("\n" + "="*80)
    print(" INJURY BENEFICIARIES (Usage Bump Analysis)")
    print("="*80)
    print("\nThis requires teammate injury data - showing methodology:\n")
    
    print("""
METHODOLOGY:
1. Identify team's top 3 usage players
2. For games when Star A is OUT:
   - Measure Star B and Star C usage increase
   - Track FD points increase
3. Build "Injury Impact Matrix"

EXAMPLE PATTERNS:
Team: DAL
- When Luka OUT -> Kyrie gets +8% usage, +12 FD pts
- When Kyrie OUT -> Luka gets +5% usage, +8 FD pts

Team: PHI  
- When Embiid OUT -> Maxey gets +12% usage, +15 FD pts
- When Maxey OUT -> Embiid gets +3% usage, +5 FD pts

[TIP] ACTION ITEM:
Create injury tracking system (see injury_monitor.py)
Then cross-reference with DuckDB to find beneficiaries
    """)
    
    # Sample query structure (requires injury data)
    print("\nSAMPLE QUERY STRUCTURE:")
    print("""
    WITH team_leaders AS (
        SELECT team_abbr, player_name, AVG(usage_pct) as avg_usage
        FROM player_advanced_stats
        WHERE season = ?
        GROUP BY team_abbr, player_name
        HAVING AVG(usage_pct) > 25
    )
    SELECT 
        a.player_name as beneficiary,
        b.player_name as absent_star,
        AVG(a.fd_points) as avg_with_star_out,
        AVG(c.fd_points) as avg_normally,
        AVG(a.fd_points) - AVG(c.fd_points) as bump
    FROM games_when_teammate_out a
    JOIN team_leaders b ON ...
    JOIN normal_games c ON ...
    GROUP BY a.player_name, b.player_name
    HAVING bump > 5
    ORDER BY bump DESC
    """)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--season", default="2024-25")
    ap.add_argument("--db", default="data/dfs_warehouse.duckdb")
    ap.add_argument("--min-games", type=int, default=10)
    args = ap.parse_args()
    
    db_path = Path(args.db)
    if not db_path.exists():
        print(f"[ERROR] Database not found: {db_path}")
        return
    
    print(f"\n Database: {db_path}")
    print(f" Season: {args.season}\n")
    
    con = duckdb.connect(str(db_path), read_only=True)
    
    # Run analyses
    rest = analyze_rest_impact(con, args.season)
    
    splits = analyze_home_away_splits(con, args.season, args.min_games)
    
    blowouts = analyze_blowout_performance(con, args.season)
    
    crushers = find_opponent_crushers(con, args.season, min_games=3)
    
    analyze_usage_bump_injuries(con, args.season)
    
    # Export results
    outdir = Path("outputs/historical_insights")
    outdir.mkdir(exist_ok=True, parents=True)
    
    if not rest.empty:
        rest.to_csv(outdir / "rest_impact.csv", index=False)
    if not splits.empty:
        splits.to_csv(outdir / "home_away_splits.csv", index=False)
    if not blowouts.empty:
        blowouts.to_csv(outdir / "blowout_patterns.csv", index=False)
    if not crushers.empty:
        crushers.to_csv(outdir / "opponent_crushers.csv", index=False)
    
    print("\n" + "="*80)
    print(" ACTIONABLE INSIGHTS:")
    print("="*80)
    print("""
1. REST DAYS:
   -> Check tonight's slate for B2B teams
   -> Fade stars on B2B, target well-rested players

2. HOME/AWAY:
   -> Use splits for today's matchups
   -> Player X at home = boost, away = fade

3. BLOWOUTS:
   -> Check Vegas spreads (large favorites/underdogs)
   -> Fade starters in potential blowouts
   -> Target bench in garbage time

4. OPPONENT MATCHUPS:
   -> Player Y crushes Team Z every time
   -> If Y vs Z tonight -> leverage play!

5. INJURY BENEFICIARIES:
   -> Monitor injury reports 30 min before lock
   -> If Star OUT -> his backup/teammates get usage bump
   -> Value explosion opportunity!
    """)
    
    con.close()
    
    print("\n[OK] Files saved to: outputs/historical_insights/")
    print("="*80)

if __name__ == "__main__":
    main()
