#!/usr/bin/env python
"""
boom_bust_analysis_nba.py

Adds ceiling/floor projections for GPP optimization:
- Floor (10th percentile) - Worst case scenario
- Median (50th percentile) - Expected outcome  
- Ceiling (90th percentile) - Best case scenario
- Boom% - Probability of 1.5x+ projection
- Bust% - Probability of <50% projection

Uses StdDev + usage patterns + variance factors
"""

import pandas as pd
import numpy as np
from scipy import stats
from typing import Optional

class BoomBustConfig:
    """Configuration for ceiling/floor calculations"""
    def __init__(self):
        # Percentiles
        self.floor_pct = 10     # 10th percentile
        self.median_pct = 50    # 50th percentile  
        self.ceiling_pct = 90   # 90th percentile
        
        # Boom/Bust thresholds
        self.boom_threshold = 1.5   # 1.5x projection = boom
        self.bust_threshold = 0.5   # 0.5x projection = bust
        
        # Variance multipliers by position
        self.pos_variance = {
            'PG': 1.1,  # Guards more volatile (usage dependent)
            'SG': 1.15,
            'SF': 1.05,
            'PF': 1.0,
            'C': 0.95   # Centers most consistent
        }
        
        # Salary tier variance
        self.elite_variance = 0.9   # $9K+ more consistent
        self.mid_variance = 1.0     # $6-9K baseline
        self.value_variance = 1.2   # <$6K more volatile

def get_position_variance(position: str, cfg: BoomBustConfig) -> float:
    """Get variance multiplier based on position"""
    pos = (position or '').upper()
    for bucket in ['PG', 'SG', 'SF', 'PF', 'C']:
        if bucket in pos:
            return cfg.pos_variance.get(bucket, 1.0)
    return 1.0

def get_salary_variance(salary: float, cfg: BoomBustConfig) -> float:
    """Get variance multiplier based on salary tier"""
    if salary >= 9000:
        return cfg.elite_variance
    elif salary >= 6000:
        return cfg.mid_variance
    else:
        return cfg.value_variance

def compute_adjusted_stddev(row: pd.Series, cfg: BoomBustConfig) -> float:
    """
    Compute adjusted standard deviation accounting for:
    - Base StdDev from historical data
    - Position variance
    - Salary tier variance
    - Minutes volatility
    """
    base_std = row.get('StdDev', 0)
    if pd.isna(base_std) or base_std <= 0:
        # Fallback: 20% of projection
        proj = row.get('Projection', 0)
        base_std = 0.20 * proj
    
    # Adjust for position
    pos_mult = get_position_variance(row.get('Position', ''), cfg)
    
    # Adjust for salary
    sal_mult = get_salary_variance(row.get('Salary', 0), cfg)
    
    # Combine
    adjusted_std = base_std * pos_mult * sal_mult
    
    return float(adjusted_std)

def compute_ceiling_floor(df: pd.DataFrame, cfg: Optional[BoomBustConfig] = None) -> pd.DataFrame:
    """
    Add ceiling/floor/median projections
    
    Assumes normal distribution around Projection with adjusted StdDev
    """
    if cfg is None:
        cfg = BoomBustConfig()
    
    df = df.copy()
    
    # Compute adjusted StdDev
    df['AdjStdDev'] = df.apply(lambda r: compute_adjusted_stddev(r, cfg), axis=1)
    
    # For each row, compute percentiles
    def compute_percentile(proj, std, pct):
        if pd.isna(proj) or pd.isna(std) or std <= 0:
            return proj
        z_score = stats.norm.ppf(pct / 100.0)
        value = proj + z_score * std
        return max(value, 0.0)  # Can't be negative
    
    df['Floor'] = df.apply(
        lambda r: compute_percentile(r['Projection'], r['AdjStdDev'], cfg.floor_pct),
        axis=1
    )
    
    df['Median'] = df['Projection']  # 50th percentile = projection
    
    df['Ceiling'] = df.apply(
        lambda r: compute_percentile(r['Projection'], r['AdjStdDev'], cfg.ceiling_pct),
        axis=1
    )
    
    # Boom/Bust probabilities
    def boom_probability(proj, std, threshold):
        if pd.isna(proj) or pd.isna(std) or std <= 0:
            return 0.0
        target = proj * threshold
        z = (target - proj) / std
        return float(1.0 - stats.norm.cdf(z))  # P(X > target)
    
    def bust_probability(proj, std, threshold):
        if pd.isna(proj) or pd.isna(std) or std <= 0:
            return 0.0
        target = proj * threshold
        z = (target - proj) / std
        return float(stats.norm.cdf(z))  # P(X < target)
    
    df['BoomPct'] = df.apply(
        lambda r: boom_probability(r['Projection'], r['AdjStdDev'], cfg.boom_threshold) * 100,
        axis=1
    )
    
    df['BustPct'] = df.apply(
        lambda r: bust_probability(r['Projection'], r['AdjStdDev'], cfg.bust_threshold) * 100,
        axis=1
    )
    
    # Upside metric: (Ceiling - Floor) / Salary
    df['UpsidePerDollar'] = (df['Ceiling'] - df['Floor']) / (df['Salary'] / 1000)
    
    return df

def identify_gpp_targets(df: pd.DataFrame, min_boom=15, max_bust=30) -> pd.DataFrame:
    """
    Identify ideal GPP targets:
    - High boom% (upside)
    - Moderate bust% (not too risky)
    - Good upside per dollar
    """
    df = df.copy()
    
    df['GPP_Score'] = (
        df['BoomPct'] * 2.0           # Boom% weighted heavily
        - df['BustPct'] * 0.5          # Bust% penalty
        + df['UpsidePerDollar'] * 10   # Upside matters
    )
    
    # Flag GPP targets
    df['GPP_Target'] = (
        (df['BoomPct'] >= min_boom) &
        (df['BustPct'] <= max_bust)
    )
    
    return df.sort_values('GPP_Score', ascending=False)

def identify_cash_targets(df: pd.DataFrame, min_floor=15) -> pd.DataFrame:
    """
    Identify ideal cash game targets:
    - High floor (consistent)
    - Low bust%
    - Good median projection
    """
    df = df.copy()
    
    df['Cash_Score'] = (
        df['Floor'] * 2.0              # Floor weighted heavily
        + df['Median']                 # Median projection
        - df['BustPct'] * 0.5          # Bust% penalty
        - df['AdjStdDev'] * 0.3        # Prefer consistency
    )
    
    # Flag cash targets
    df['Cash_Target'] = (
        (df['Floor'] >= min_floor) &
        (df['BustPct'] <= 20)
    )
    
    return df.sort_values('Cash_Score', ascending=False)

# Example usage
if __name__ == "__main__":
    # Sample data
    sample_df = pd.DataFrame({
        'Name': ['Nikola Jokic', 'Jayson Tatum', 'De\'Aaron Fox', 'Value Guard', 'Punt Play'],
        'Position': ['C', 'SF', 'PG', 'SG', 'PF'],
        'Salary': [12000, 9500, 8200, 5500, 3800],
        'Projection': [58.0, 45.0, 38.0, 22.0, 12.0],
        'StdDev': [8.5, 11.0, 12.5, 8.0, 6.0]
    })
    
    print("Sample projections:")
    print(sample_df[['Name', 'Position', 'Salary', 'Projection', 'StdDev']])
    
    # Add ceiling/floor
    result = compute_ceiling_floor(sample_df)
    
    print("\nWith Ceiling/Floor:")
    print(result[['Name', 'Floor', 'Median', 'Ceiling', 'BoomPct', 'BustPct', 'UpsidePerDollar']])
    
    # Identify targets
    gpp_targets = identify_gpp_targets(result)
    
    print("\nTop GPP Targets:")
    print(gpp_targets[gpp_targets['GPP_Target']][['Name', 'Ceiling', 'BoomPct', 'BustPct', 'GPP_Score']].head())
    
    cash_targets = identify_cash_targets(result)
    
    print("\nTop Cash Targets:")
    print(cash_targets[cash_targets['Cash_Target']][['Name', 'Floor', 'BustPct', 'Cash_Score']].head())
    
    print("\nℹ  Key insights:")
    print("   - Centers (Jokic) have lower variance = better cash plays")
    print("   - Guards (Fox) have higher variance = better GPP upside")
    print("   - Value plays have highest bust% = risky but high ceiling")
