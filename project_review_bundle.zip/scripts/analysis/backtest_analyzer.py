#!/usr/bin/env python
"""
backtest_analyzer.py

Compare your projections vs actual results to identify systematic errors:
1. Load projections from slate
2. Load actual results from DuckDB
3. Calculate accuracy metrics (MAE, RMSE, R²)
4. Identify which players you consistently miss on
5. Generate improvement recommendations

Usage:
    python backtest_analyzer.py --date 2026-01-15 --projections "outputs/projections_today*.csv" --db "data/dfs_warehouse.duckdb"
"""

import argparse
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime
import duckdb
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

print("="*80)
print("BACKTEST ANALYZER - Learn From Your Projections")
print("="*80)

def load_projections(proj_file: Path) -> pd.DataFrame:
    """Load your projections"""
    df = pd.read_csv(proj_file)
    
    # Normalize player name
    if 'Name' in df.columns:
        df['name_norm'] = df['Name'].str.lower().str.strip()
    
    if 'Projection' not in df.columns:
        raise ValueError("Projections file missing 'Projection' column")
    
    return df

def load_actual_results(con: duckdb.DuckDBPyConnection, game_date: str, season: str) -> pd.DataFrame:
    """Load actual FD points from game logs"""
    
    q = """
    SELECT 
        player_name,
        LOWER(player_name) as name_norm,
        fd_points as ActualPoints,
        minutes,
        team_abbr as Team,
        opp_abbr as Opponent
    FROM nba_player_game_logs
    WHERE season = ?
      AND game_date = CAST(? AS DATE)
      AND fd_points IS NOT NULL
    """
    
    result = con.execute(q, [season, game_date]).df()
    
    return result

def calculate_accuracy_metrics(df: pd.DataFrame):
    """Calculate projection accuracy metrics"""
    
    # Remove any rows with NaN
    df = df.dropna(subset=['Projection', 'ActualPoints'])
    
    if len(df) == 0:
        print("[ERROR] No matching data found")
        return None
    
    y_true = df['ActualPoints'].values
    y_pred = df['Projection'].values
    
    mae = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    r2 = r2_score(y_true, y_pred)
    
    # Calculate error distribution
    df['Error'] = df['Projection'] - df['ActualPoints']
    df['AbsError'] = df['Error'].abs()
    df['PctError'] = (df['Error'] / df['ActualPoints']).replace([np.inf, -np.inf], np.nan)
    
    return {
        'mae': mae,
        'rmse': rmse,
        'r2': r2,
        'mean_error': df['Error'].mean(),
        'median_error': df['Error'].median(),
        'std_error': df['Error'].std()
    }

def analyze_systematic_errors(df: pd.DataFrame):
    """Find patterns in projection errors"""
    
    print("\n" + "="*80)
    print(" SYSTEMATIC ERROR ANALYSIS")
    print("="*80)
    
    # 1. Biggest misses
    print("\n[ERROR] TOP 10 BIGGEST MISSES (Over-projected):")
    print(f"{'Player':<25} {'Projected':>10} {'Actual':>10} {'Error':>10}")
    print("-"*80)
    
    biggest_misses = df.nlargest(10, 'Error')
    for _, p in biggest_misses.iterrows():
        print(f"{p['Name']:<25} {p['Projection']:>10.1f} "
              f"{p['ActualPoints']:>10.1f} {p['Error']:>+10.1f}")
    
    # 2. Biggest surprises
    print("\n[OK] TOP 10 BIGGEST SURPRISES (Under-projected):")
    print(f"{'Player':<25} {'Projected':>10} {'Actual':>10} {'Error':>10}")
    print("-"*80)
    
    surprises = df.nsmallest(10, 'Error')
    for _, p in surprises.iterrows():
        print(f"{p['Name']:<25} {p['Projection']:>10.1f} "
              f"{p['ActualPoints']:>10.1f} {p['Error']:>+10.1f}")
    
    # 3. Most accurate
    print("\n TOP 10 MOST ACCURATE:")
    print(f"{'Player':<25} {'Projected':>10} {'Actual':>10} {'Error':>10}")
    print("-"*80)
    
    accurate = df.nsmallest(10, 'AbsError')
    for _, p in accurate.iterrows():
        print(f"{p['Name']:<25} {p['Projection']:>10.1f} "
              f"{p['ActualPoints']:>10.1f} {p['Error']:>+10.1f}")

def salary_tier_accuracy(df: pd.DataFrame):
    """Analyze accuracy by salary tier"""
    
    if 'Salary' not in df.columns:
        return
    
    print("\n" + "="*80)
    print(" ACCURACY BY SALARY TIER")
    print("="*80)
    
    # Define tiers
    df['SalaryTier'] = pd.cut(df['Salary'], 
                              bins=[0, 4000, 5500, 7000, 9000, 15000],
                              labels=['Punt (<$4K)', 'Value ($4-5.5K)', 
                                     'Mid ($5.5-7K)', 'Premium ($7-9K)', 
                                     'Elite ($9K+)'])
    
    tier_acc = df.groupby('SalaryTier').agg({
        'Error': ['mean', 'std'],
        'AbsError': 'mean',
        'Name': 'count'
    }).round(2)
    
    print(f"\n{'Tier':<20} {'Count':>6} {'MeanErr':>9} {'StdErr':>9} {'MAE':>9}")
    print("-"*80)
    
    for tier in tier_acc.index:
        row = tier_acc.loc[tier]
        print(f"{tier:<20} {row[('Name', 'count')]:>6.0f} "
              f"{row[('Error', 'mean')]:>+9.2f} "
              f"{row[('Error', 'std')]:>9.2f} "
              f"{row[('AbsError', 'mean')]:>9.2f}")
    
    print("\n[TIP] INSIGHTS:")
    if tier_acc.loc['Elite ($9K+)', ('Error', 'mean')] > 2:
        print("   [WARNING]  You're OVER-projecting elite players")
        print("   -> Reduce elite projections by 5-10%")
    elif tier_acc.loc['Elite ($9K+)', ('Error', 'mean')] < -2:
        print("   [WARNING]  You're UNDER-projecting elite players")
        print("   -> Increase elite projections by 5-10%")
    
    if tier_acc.loc['Punt (<$4K)', ('Error', 'mean')] > 2:
        print("   [WARNING]  You're OVER-projecting punt plays")
        print("   -> Be more conservative on value")
    elif tier_acc.loc['Punt (<$4K)', ('Error', 'mean')] < -2:
        print("   [WARNING]  You're UNDER-projecting punt plays")
        print("   -> Value plays have more upside than you think")

def generate_improvement_plan(metrics: dict, df: pd.DataFrame):
    """Generate actionable improvement recommendations"""
    
    print("\n" + "="*80)
    print(" IMPROVEMENT RECOMMENDATIONS")
    print("="*80)
    
    print(f"\n CURRENT ACCURACY:")
    print(f"   MAE: {metrics['mae']:.2f} pts")
    print(f"   RMSE: {metrics['rmse']:.2f} pts")
    print(f"   R²: {metrics['r2']:.3f}")
    print(f"   Mean Error: {metrics['mean_error']:+.2f} pts")
    
    # Diagnose issues
    print(f"\n DIAGNOSIS:")
    
    if abs(metrics['mean_error']) > 1:
        if metrics['mean_error'] > 0:
            print("   [WARNING]  SYSTEMATIC OVER-PROJECTION")
            print("   -> You're too optimistic overall")
            print(f"   -> Reduce all projections by {metrics['mean_error']:.1f} pts")
        else:
            print("   [WARNING]  SYSTEMATIC UNDER-PROJECTION")
            print("   -> You're too conservative overall")
            print(f"   -> Increase all projections by {abs(metrics['mean_error']):.1f} pts")
    else:
        print("   [OK] No systematic bias")
    
    if metrics['mae'] > 7:
        print("   [WARNING]  HIGH ERROR RATE")
        print("   -> Review your projection methodology")
        print("   -> Consider adding more contextual factors")
    elif metrics['mae'] < 5.5:
        print("   [OK] EXCELLENT ACCURACY")
        print("   -> Your projections are elite!")
    else:
        print("   [OK] GOOD ACCURACY")
        print("   -> Room for improvement")
    
    if metrics['r2'] < 0.65:
        print("   [WARNING]  LOW CORRELATION")
        print("   -> Your projections don't capture variance well")
        print("   -> Add more factors: injuries, rest, matchups")
    elif metrics['r2'] > 0.75:
        print("   [OK] STRONG CORRELATION")
        print("   -> Your model captures patterns well")
    
    # Specific actions
    print(f"\n ACTION ITEMS:")
    
    actions = []
    
    # Check for specific patterns
    high_error_players = df[df['AbsError'] > 10]
    if len(high_error_players) > 0:
        actions.append(f"Investigate {len(high_error_players)} players with >10pt errors")
    
    if 'Salary' in df.columns:
        elite = df[df['Salary'] >= 9000]
        if len(elite) > 0 and abs(elite['Error'].mean()) > 3:
            actions.append(f"Adjust elite player projections (currently off by {elite['Error'].mean():+.1f} pts)")
    
    if metrics['std_error'] > 8:
        actions.append("High variance in errors - add stability factors (home/away, rest)")
    
    if not actions:
        actions.append("Continue current methodology - it's working!")
    
    for i, action in enumerate(actions, 1):
        print(f"   {i}. {action}")
    
    # Save recommendations
    outdir = Path("outputs/backtest")
    outdir.mkdir(exist_ok=True, parents=True)
    
    with open(outdir / "improvement_plan.txt", 'w') as f:
        f.write("PROJECTION IMPROVEMENT PLAN\n")
        f.write("="*80 + "\n\n")
        f.write(f"Analysis Date: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n\n")
        f.write(f"MAE: {metrics['mae']:.2f}\n")
        f.write(f"RMSE: {metrics['rmse']:.2f}\n")
        f.write(f"R²: {metrics['r2']:.3f}\n\n")
        f.write("Action Items:\n")
        for i, action in enumerate(actions, 1):
            f.write(f"{i}. {action}\n")
    
    print(f"\n[OK] Saved to: {outdir / 'improvement_plan.txt'}")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--date", required=True, help="Game date YYYY-MM-DD")
    ap.add_argument("--projections", default=None, help="Projections CSV")
    ap.add_argument("--season", default="2024-25")
    ap.add_argument("--db", default="data/dfs_warehouse.duckdb")
    args = ap.parse_args()
    
    # Find projections file
    if args.projections:
        proj_file = Path(args.projections)
    else:
        # Find file from that date
        files = sorted(Path("outputs").glob("projections_today*.csv"))
        if not files:
            print("[ERROR] No projection files found")
            return
        proj_file = files[-1]  # Most recent
    
    if not proj_file.exists():
        print(f"[ERROR] Projection file not found: {proj_file}")
        return
    
    print(f"\n Loading projections: {proj_file.name}")
    projections = load_projections(proj_file)
    print(f"[OK] Loaded {len(projections)} projections")
    
    # Load actual results
    db_path = Path(args.db)
    if not db_path.exists():
        print(f"[ERROR] Database not found: {db_path}")
        return
    
    print(f"\n Loading actual results for {args.date}")
    con = duckdb.connect(str(db_path), read_only=True)
    actuals = load_actual_results(con, args.date, args.season)
    con.close()
    
    if actuals.empty:
        print(f"[ERROR] No game results found for {args.date}")
        print("   Either games haven't been played yet or data not loaded")
        return
    
    print(f"[OK] Loaded {len(actuals)} actual results")
    
    # Merge
    print(f"\n Matching projections to actuals...")
    merged = projections.merge(actuals, on='name_norm', how='inner', suffixes=('', '_actual'))
    
    if merged.empty:
        print("[ERROR] No matches found between projections and actuals")
        print("   Check player name formatting")
        return
    
    print(f"[OK] Matched {len(merged)} players")
    
    # Calculate metrics
    print(f"\n Calculating accuracy metrics...")
    metrics = calculate_accuracy_metrics(merged)
    
    if metrics is None:
        return
    
    print(f"\n" + "="*80)
    print("ACCURACY METRICS")
    print("="*80)
    print(f"\nMean Absolute Error (MAE): {metrics['mae']:.2f} pts")
    print(f"Root Mean Squared Error (RMSE): {metrics['rmse']:.2f} pts")
    print(f"R² Score: {metrics['r2']:.3f}")
    print(f"\nMean Error: {metrics['mean_error']:+.2f} pts")
    print(f"Median Error: {metrics['median_error']:+.2f} pts")
    print(f"Std Dev of Error: {metrics['std_error']:.2f} pts")
    
    # Benchmarks
    print(f"\n BENCHMARKS:")
    if metrics['mae'] < 5.5:
        print("    Elite accuracy (MAE < 5.5)")
    elif metrics['mae'] < 6.5:
        print("   [OK] Very good accuracy (MAE < 6.5)")
    elif metrics['mae'] < 7.5:
        print("   [OK] Good accuracy (MAE < 7.5)")
    else:
        print("   [WARNING]  Needs improvement (MAE > 7.5)")
    
    # Detailed analysis
    analyze_systematic_errors(merged)
    
    salary_tier_accuracy(merged)
    
    generate_improvement_plan(metrics, merged)
    
    # Export results
    outdir = Path("outputs/backtest")
    outdir.mkdir(exist_ok=True, parents=True)
    
    merged_export = merged[['Name', 'Projection', 'ActualPoints', 'Error', 
                           'AbsError', 'Salary', 'Team', 'Opponent']].copy()
    merged_export = merged_export.sort_values('AbsError', ascending=False)
    
    output_file = outdir / f"backtest_{args.date}.csv"
    merged_export.to_csv(output_file, index=False)
    
    print(f"\n[OK] Full results saved to: {output_file}")
    
    print("\n" + "="*80)
    print("[OK] BACKTEST COMPLETE!")
    print("="*80)

if __name__ == "__main__":
    main()
