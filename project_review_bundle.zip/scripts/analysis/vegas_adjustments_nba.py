#!/usr/bin/env python
"""
vegas_adjustments_nba.py

Adds Vegas line adjustments to NBA projections:
- Game total (O/U) -> Pace boost
- Spread -> Blowout risk adjustment  
- Implied team total -> Volume boost

Usage:
    from vegas_adjustments_nba import add_vegas_adjustments
    
    df = add_vegas_adjustments(df, vegas_lines)
"""

import pandas as pd
import numpy as np
from typing import Dict, Optional

class VegasConfig:
    """Configuration for Vegas adjustments"""
    def __init__(self):
        # League averages (2024-25 season)
        self.league_avg_total = 225.0  # NBA avg game total
        self.league_avg_spread = 0.0    # Neutral
        
        # Adjustment weights
        self.total_weight = 0.25   # How much game total affects projection
        self.spread_weight = 0.15  # How much spread affects projection
        self.blowout_threshold = 12.0  # Points where blowout risk kicks in
        
        # Caps
        self.max_total_boost = 1.15   # Max 15% boost from high total
        self.min_total_penalty = 0.90  # Max 10% penalty from low total
        self.max_blowout_penalty = 0.85  # Max 15% penalty in blowout

def parse_game_total(game_str: str) -> Optional[float]:
    """
    Extract game total from various formats:
    - "ATL@BOS O/U 230.5"
    - "ATL@BOS (230.5)"
    - "230.5"
    """
    import re
    
    # Try to find a number that looks like game total (200-260 range)
    matches = re.findall(r'(\d{3}\.?\d?)', str(game_str))
    for m in matches:
        total = float(m)
        if 200 <= total <= 260:
            return total
    return None

def parse_spread(game_str: str, team: str) -> Optional[float]:
    """
    Extract spread for a specific team:
    - "ATL -3.5 @BOS" -> ATL = -3.5, BOS = +3.5
    - "BOS +7.5" -> BOS = +7.5
    """
    import re
    
    # Look for patterns like "ATL -3.5" or "+7.5"
    pattern = rf'{team}\s*([+-]?\d+\.?\d?)'
    match = re.search(pattern, str(game_str), re.IGNORECASE)
    if match:
        return float(match.group(1))
    
    # If not found, look for generic spread
    matches = re.findall(r'([+-]\d+\.?\d?)', str(game_str))
    if matches:
        # Assume first is home team spread
        return float(matches[0])
    
    return None

def compute_total_multiplier(game_total: float, cfg: VegasConfig) -> float:
    """
    High total -> More possessions -> Boost projection
    Low total -> Fewer possessions -> Lower projection
    """
    if pd.isna(game_total) or game_total <= 0:
        return 1.0
    
    ratio = game_total / cfg.league_avg_total
    
    # Apply weight
    multiplier = 1.0 + cfg.total_weight * (ratio - 1.0)
    
    # Clamp
    multiplier = np.clip(multiplier, cfg.min_total_penalty, cfg.max_total_boost)
    
    return float(multiplier)

def compute_spread_multiplier(spread: float, is_star: bool, cfg: VegasConfig) -> float:
    """
    Large favorite -> Likely blowout -> Starters sit
    Large underdog -> Likely blowout -> Garbage time for bench
    
    Stars get penalized more in blowouts (sit in 4th)
    Bench players get boost (garbage time)
    """
    if pd.isna(spread):
        return 1.0
    
    # Absolute value of spread
    abs_spread = abs(float(spread))
    
    if abs_spread < cfg.blowout_threshold:
        # Competitive game, no adjustment
        return 1.0
    
    # Blowout risk
    blowout_factor = (abs_spread - cfg.blowout_threshold) / 10.0
    blowout_factor = min(blowout_factor, 1.0)  # Cap at 1.0
    
    if is_star:
        # Stars sit in blowouts
        penalty = 1.0 - cfg.spread_weight * blowout_factor
        multiplier = max(penalty, cfg.max_blowout_penalty)
    else:
        # Bench gets garbage time
        boost = 1.0 + (cfg.spread_weight * 0.5) * blowout_factor
        multiplier = min(boost, 1.10)  # Max 10% boost
    
    return float(multiplier)

def is_star_player(row: pd.Series) -> bool:
    """
    Determine if player is a star (simplistic):
    - Salary > $8,500
    - Or Projection > 40 pts
    """
    salary = row.get('Salary', 0)
    proj = row.get('Projection', 0)
    
    return salary >= 8500 or proj >= 40

def add_vegas_adjustments(df: pd.DataFrame, vegas_lines: Optional[Dict] = None, cfg: Optional[VegasConfig] = None) -> pd.DataFrame:
    """
    Add Vegas-based adjustments to projections
    
    Args:
        df: DataFrame with Team, Opponent, Projection columns
        vegas_lines: Optional dict of {game: {'total': X, 'spread': Y}}
        cfg: VegasConfig instance
    
    Returns:
        DataFrame with VegasTotalMult, VegasSpreadMult, VegasMultiplier columns
    """
    if cfg is None:
        cfg = VegasConfig()
    
    df = df.copy()
    
    # If no vegas_lines provided, try to parse from Game column
    if vegas_lines is None:
        print("ℹ  No Vegas lines provided, attempting to parse from Game column")
        df['GameTotal'] = df.get('Game', '').apply(parse_game_total)
        df['Spread'] = df.apply(lambda r: parse_spread(r.get('Game', ''), r.get('Team', '')), axis=1)
    else:
        # Use provided vegas_lines
        def get_total(row):
            game = row.get('Game', '')
            return vegas_lines.get(game, {}).get('total')
        
        def get_spread(row):
            game = row.get('Game', '')
            team = row.get('Team', '')
            spread_data = vegas_lines.get(game, {}).get('spread', {})
            return spread_data.get(team)
        
        df['GameTotal'] = df.apply(get_total, axis=1)
        df['Spread'] = df.apply(get_spread, axis=1)
    
    # Compute multipliers
    df['VegasTotalMult'] = df['GameTotal'].apply(lambda x: compute_total_multiplier(x, cfg))
    
    df['IsStar'] = df.apply(is_star_player, axis=1)
    df['VegasSpreadMult'] = df.apply(
        lambda r: compute_spread_multiplier(r.get('Spread'), r.get('IsStar', False), cfg),
        axis=1
    )
    
    # Combined Vegas multiplier
    df['VegasMultiplier'] = df['VegasTotalMult'] * df['VegasSpreadMult']
    
    # Apply to projection if exists
    if 'Projection' in df.columns:
        df['ProjectionPreVegas'] = df['Projection']
        df['Projection'] = df['Projection'] * df['VegasMultiplier']
    
    return df

def manual_vegas_lines_example():
    """
    Example of manually providing Vegas lines
    """
    return {
        'ATL@BOS': {
            'total': 235.5,
            'spread': {'ATL': -3.5, 'BOS': 3.5}
        },
        'LAL@GSW': {
            'total': 228.0,
            'spread': {'LAL': 2.5, 'GSW': -2.5}
        }
    }

# Example usage
if __name__ == "__main__":
    # Create sample data
    sample_df = pd.DataFrame({
        'Name': ['Jayson Tatum', 'Derrick White', 'Trae Young'],
        'Team': ['BOS', 'BOS', 'ATL'],
        'Opponent': ['ATL', 'ATL', 'BOS'],
        'Game': ['ATL@BOS O/U 235.5', 'ATL@BOS O/U 235.5', 'ATL@BOS O/U 235.5'],
        'Salary': [9500, 6800, 9200],
        'Projection': [45.0, 32.0, 42.0]
    })
    
    print("Sample projections BEFORE Vegas adjustments:")
    print(sample_df[['Name', 'Projection']])
    
    # Apply Vegas adjustments
    result = add_vegas_adjustments(sample_df)
    
    print("\nSample projections AFTER Vegas adjustments:")
    print(result[['Name', 'Projection', 'VegasTotalMult', 'VegasSpreadMult', 'VegasMultiplier']])
    
    print("\nℹ  High game total (235.5) boosted all players")
    print("ℹ  To use manual Vegas lines:")
    print("""
    vegas_lines = {
        'ATL@BOS': {'total': 235.5, 'spread': {'ATL': -3.5, 'BOS': 3.5}}
    }
    result = add_vegas_adjustments(df, vegas_lines=vegas_lines)
    """)
