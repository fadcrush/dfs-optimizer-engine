#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# wait_for_services.sh — block until PostgreSQL and Redis are accepting
#                         connections in the Docker Compose stack.
#
# Usage:
#   scripts/wait_for_services.sh [--timeout 60]
#
# Intended to run inside the backend container before `alembic upgrade head`
# and before starting Uvicorn.
# ---------------------------------------------------------------------------
set -euo pipefail

TIMEOUT=${WAIT_TIMEOUT:-60}
ELAPSED=0
SLEEP=2

PG_HOST=${POSTGRES_HOST:-postgres}
PG_PORT=${POSTGRES_PORT:-5432}
PG_USER=${POSTGRES_USER:-dfs}
PG_DB=${POSTGRES_DB:-dfs_db}

REDIS_HOST=${REDIS_HOST:-redis}
REDIS_PORT=${REDIS_PORT:-6379}

echo "Waiting for PostgreSQL at ${PG_HOST}:${PG_PORT} ..."
until pg_isready -h "${PG_HOST}" -p "${PG_PORT}" -U "${PG_USER}" -d "${PG_DB}" -q; do
  if [ "${ELAPSED}" -ge "${TIMEOUT}" ]; then
    echo "ERROR: PostgreSQL not ready after ${TIMEOUT}s"
    exit 1
  fi
  sleep "${SLEEP}"
  ELAPSED=$((ELAPSED + SLEEP))
done
echo "  OK — PostgreSQL ready (${ELAPSED}s)"

echo "Waiting for Redis at ${REDIS_HOST}:${REDIS_PORT} ..."
ELAPSED=0
until redis-cli -h "${REDIS_HOST}" -p "${REDIS_PORT}" ping > /dev/null 2>&1; do
  if [ "${ELAPSED}" -ge "${TIMEOUT}" ]; then
    echo "ERROR: Redis not ready after ${TIMEOUT}s"
    exit 1
  fi
  sleep "${SLEEP}"
  ELAPSED=$((ELAPSED + SLEEP))
done
echo "  OK — Redis ready (${ELAPSED}s)"

echo "All services ready."
