#!/usr/bin/env python
"""Field-bias model for ownership.

Goal:
- Keep your TRUE projection (best estimate of fantasy points)
- Create a FIELD projection (what the field is likely to overweight)

This FIELD projection should be used ONLY in ownership simulation.

Bias signals (all optional; safely fall back if missing):
- Value (Projection per $1k)
- Salary drop (not available in FD CSV -> skipped)
- Recent overperformance: last game fd_points vs last10 average (from DuckDB)
- Name/price anchoring: higher salary attracts ownership
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import duckdb
import numpy as np
import pandas as pd


@dataclass(frozen=True)
class FieldBiasConfig:
    season: str
    w_value: float = 0.10
    w_salary: float = 0.06
    w_recent: float = 0.10
    clamp_low: float = 0.85
    clamp_high: float = 1.25


def recent_overperformance_index(
    con: duckdb.DuckDBPyConnection,
    season: str,
    player_ids: pd.Series,
    as_of_date: Optional[str] = None,
) -> pd.DataFrame:
    """Return per-player recent overperformance index.

    overperf = (last_game_fd - avg_fd_last10) / max(1, avg_fd_last10)
    """
    ids = [int(x) for x in player_ids.dropna().unique().tolist() if str(x).isdigit()]
    if not ids:
        return pd.DataFrame(columns=["player_id", "overperf"])

    date_filter = ""
    params = [season]
    if as_of_date:
        date_filter = "AND game_date < CAST(? AS DATE)"
        params.append(as_of_date)

    # DuckDB doesn't allow parameterizing IN list directly in a standard way across drivers,
    # so we build a VALUES table.
    values_sql = ", ".join([f"({i})" for i in ids])
    q = f"""
    WITH want(player_id) AS (VALUES {values_sql}),
    logs AS (
      SELECT
        l.player_id,
        l.game_date,
        l.fd_points,
        ROW_NUMBER() OVER (PARTITION BY l.player_id ORDER BY l.game_date DESC) AS rn
      FROM nba_player_game_logs l
      JOIN want w USING(player_id)
      WHERE l.season = ?
        {date_filter}
        AND l.fd_points IS NOT NULL
    )
    SELECT
      player_id,
      MAX(CASE WHEN rn = 1 THEN fd_points END) AS last_fd,
      AVG(CASE WHEN rn <= 10 THEN fd_points END) AS avg_fd_10
    FROM logs
    GROUP BY player_id;
    """
    df = con.execute(q, params).df()
    df["avg_fd_10"] = pd.to_numeric(df["avg_fd_10"], errors="coerce")
    df["last_fd"] = pd.to_numeric(df["last_fd"], errors="coerce")
    df["overperf"] = (df["last_fd"] - df["avg_fd_10"]) / df["avg_fd_10"].clip(lower=1.0)
    df["overperf"] = df["overperf"].replace([np.inf, -np.inf], np.nan).fillna(0.0).clip(-1.0, 2.0)
    return df[["player_id", "overperf"]]


def add_field_projection(
    df: pd.DataFrame,
    cfg: FieldBiasConfig,
    con: Optional[duckdb.DuckDBPyConnection] = None,
    as_of_date: Optional[str] = None,
) -> pd.DataFrame:
    """Add FieldProjection to a dataframe that already has Projection, Salary, player_id (optional)."""
    out = df.copy()
    out["Projection"] = pd.to_numeric(out["Projection"], errors="coerce")
    out["Salary"] = pd.to_numeric(out["Salary"], errors="coerce")

    # Base index signals
    value = out["Projection"] / (out["Salary"] / 1000.0)
    value = value.replace([np.inf, -np.inf], np.nan).fillna(value.median())
    # Normalize value & salary into z-scores
    value_z = (value - value.mean()) / (value.std(ddof=0) + 1e-9)
    salary_z = (out["Salary"] - out["Salary"].mean()) / (out["Salary"].std(ddof=0) + 1e-9)

    recent = pd.Series(0.0, index=out.index)
    if con is not None and "player_id" in out.columns:
        r = recent_overperformance_index(con, cfg.season, out["player_id"], as_of_date=as_of_date)
        if len(r):
            mapper = dict(zip(r["player_id"].astype(int), r["overperf"].astype(float)))
            recent = out["player_id"].apply(lambda x: mapper.get(int(x), 0.0) if pd.notna(x) and str(x).isdigit() else 0.0)
            recent = recent.clip(-1.0, 2.0)

    # Combine into multiplicative bias
    bias = 1.0 + cfg.w_value * value_z + cfg.w_salary * salary_z + cfg.w_recent * recent
    bias = bias.clip(cfg.clamp_low, cfg.clamp_high)

    out["FieldProjection"] = (out["Projection"] * bias).astype(float)
    out["FieldBias"] = bias.astype(float)
    return out
