
#!/usr/bin/env python
"""
nba_today_projections_v3_dvp_posmap.py

Drop-in replacement for nba_today_projections_v3_dvp.py:
- Still uses slate Team/Opponent for matchup multipliers.
- If logs don't have positions, DvP uses nba_player_position_map.

Prereq:
  Run build_player_position_map_duckdb.py at least once.

Run:
  python nba_today_projections_v3_dvp_posmap.py "<FD slate csv>" --season 2024-25 --db "C:\path\dfs_warehouse.duckdb"
"""
import argparse
import re
from datetime import datetime
from pathlib import Path

import duckdb
import numpy as np
import pandas as pd

from minutes_model_nba import MinutesModelConfig, compute_minutes_features, project_minutes
from field_bias_nba import FieldBiasConfig, add_field_projection
from opponent_adjustments_nba_v3_posmap import OpponentAdjV3Config, compute_team_environment_tables_v3, compute_matchup_multiplier_v3


def _norm_name(s: str) -> str:
    s = (s or "").strip().lower()
    s = re.sub(r"[^a-z\s\-\.']", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def _fd_name(row: pd.Series) -> str:
    if pd.notna(row.get("Nickname")) and str(row.get("Nickname")).strip():
        return str(row["Nickname"]).strip()
    fn = str(row.get("First Name", "")).strip()
    ln = str(row.get("Last Name", "")).strip()
    name = (fn + " " + ln).strip()
    if name:
        return name
    return str(row.get("Name", "")).strip()


def _primary_pos_bucket(pos_str: str) -> str:
    s = (pos_str or "").upper()
    for bucket in ["PG", "SG", "SF", "PF", "C"]:
        if bucket in s:
            return bucket
    return ""


def load_slate(fd_csv: str) -> pd.DataFrame:
    raw = pd.read_csv(fd_csv)

    df = pd.DataFrame()
    if "Id" in raw.columns:
        df["ID"] = raw["Id"].astype(str)
    elif "ID" in raw.columns:
        df["ID"] = raw["ID"].astype(str)
    else:
        raise ValueError("Slate CSV missing Id/ID column.")

    df["Name"] = raw.apply(_fd_name, axis=1)
    df["Name_norm"] = df["Name"].apply(_norm_name)

    df["Position"] = raw["Position"].astype(str) if "Position" in raw.columns else ""
    df["PosBucket"] = df["Position"].map(_primary_pos_bucket)

    df["Salary"] = pd.to_numeric(raw["Salary"], errors="coerce") if "Salary" in raw.columns else np.nan
    df["FPPG"] = pd.to_numeric(raw["FPPG"], errors="coerce") if "FPPG" in raw.columns else np.nan

    df["Team"] = raw["Team"].astype(str) if "Team" in raw.columns else ""
    df["Opponent"] = raw["Opponent"].astype(str) if "Opponent" in raw.columns else ""
    df["Game"] = raw["Game"].astype(str) if "Game" in raw.columns else ""

    return df


def compute_fppm_features(con: duckdb.DuckDBPyConnection, season: str, as_of_date: str | None = None) -> pd.DataFrame:
    date_filter = ""
    params = [season]
    if as_of_date:
        date_filter = "AND game_date < CAST(? AS DATE)"
        params.append(as_of_date)

    q = f"""
    WITH logs AS (
      SELECT
        player_id,
        player_name,
        LOWER(player_name) AS name_norm,
        game_date,
        minutes,
        fd_points,
        CASE WHEN minutes > 0 THEN fd_points / minutes ELSE NULL END AS fppm,
        ROW_NUMBER() OVER (PARTITION BY player_id ORDER BY game_date DESC) AS rn
      FROM nba_player_game_logs
      WHERE season = ?
        {date_filter}
        AND fd_points IS NOT NULL
        AND minutes IS NOT NULL
        AND minutes > 0
    )
    SELECT
      player_id,
      ANY_VALUE(player_name) AS player_name,
      ANY_VALUE(name_norm) AS name_norm,
      AVG(CASE WHEN rn <= 5  THEN fppm END)  AS fppm_last5,
      AVG(CASE WHEN rn <= 10 THEN fppm END)  AS fppm_last10,
      AVG(fppm) AS fppm_season,
      STDDEV_POP(CASE WHEN rn <= 10 THEN fd_points END) AS stdev_last10_fd
    FROM logs
    GROUP BY player_id;
    """
    return con.execute(q, params).df()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("slate_csv", help="FanDuel NBA players-list CSV")
    ap.add_argument("--season", default="2024-25")
    ap.add_argument("--db", default=str(Path("data") / "dfs_warehouse.duckdb"))
    ap.add_argument("--asof", default=None, help="Optional as-of date YYYY-MM-DD (for backtesting). Uses games before this date.")
    args = ap.parse_args()

    slate = load_slate(args.slate_csv)
    con = duckdb.connect(args.db, read_only=True)

    mins_feat = compute_minutes_features(con, args.season, as_of_date=args.asof)
    fppm_feat = compute_fppm_features(con, args.season, as_of_date=args.asof)

    if "name_norm" not in fppm_feat.columns or fppm_feat["name_norm"].isna().all():
        fppm_feat["name_norm"] = fppm_feat["player_name"].astype(str).map(_norm_name)

    feats = fppm_feat.merge(mins_feat.drop(columns=["player_name"], errors="ignore"), on="player_id", how="left")
    merged = slate.merge(feats, left_on="Name_norm", right_on="name_norm", how="left")

    mcfg = MinutesModelConfig(season=args.season)
    merged["MinProj"] = project_minutes(merged, mcfg)

    for c in ["fppm_last10", "fppm_last5", "fppm_season"]:
        merged[c] = pd.to_numeric(merged.get(c, np.nan), errors="coerce")

    merged["FPPM_blend"] = (
        0.55 * merged["fppm_last10"].fillna(merged["fppm_season"])
        + 0.30 * merged["fppm_last5"].fillna(merged["fppm_last10"])
        + 0.15 * merged["fppm_season"].fillna(merged["fppm_last10"])
    )
    merged["ProjectionRaw"] = merged["MinProj"] * merged["FPPM_blend"]

    env = compute_team_environment_tables_v3(con, args.season, as_of_date=args.asof)
    cfg = OpponentAdjV3Config(season=args.season)

    def _mult(row):
        team = str(row.get("Team", "")).strip()
        opp = str(row.get("Opponent", "")).strip()
        pb = str(row.get("PosBucket", "")).strip()
        if not team or not opp:
            return 1.0
        return compute_matchup_multiplier_v3(env, team, opp, pb if pb else None, cfg)

    merged["OppMultiplier"] = merged.apply(_mult, axis=1).astype(float)
    merged["Projection"] = (merged["ProjectionRaw"] * merged["OppMultiplier"]).astype(float)

    merged["StdDev"] = pd.to_numeric(merged.get("stdev_last10_fd", np.nan), errors="coerce")
    merged.loc[merged["StdDev"].isna(), "StdDev"] = 0.20 * merged["Projection"]
    merged["StdDev"] = merged["StdDev"].clip(lower=3.0)

    bcfg = FieldBiasConfig(season=args.season)
    merged = add_field_projection(merged, bcfg, con=con, as_of_date=args.asof)
    con.close()

    outdir = Path("outputs")
    outdir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_path = outdir / f"projections_today_v3_posmap_{ts}.csv"

    out_cols = [
        "ID", "Name", "Position", "PosBucket", "Salary",
        "Team", "Opponent", "Game",
        "player_id", "MinProj", "FPPM_blend",
        "ProjectionRaw", "OppMultiplier", "Projection", "StdDev",
        "FieldProjection", "FieldBias"
    ]
    merged[out_cols].to_csv(out_path, index=False)

    print(f"[OK] Wrote projections for {len(merged)} slate players: {out_path}")
    print(f"[OK] DvP source: {env.get('dvp_source')}")
    print("\nOppMultiplier quick-check:")
    print(merged["OppMultiplier"].describe().to_string())


if __name__ == "__main__":
    main()
