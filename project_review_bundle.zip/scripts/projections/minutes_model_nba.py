#!/usr/bin/env python
"""Minutes projection model using DuckDB nba_player_game_logs.

This module is designed to be imported by nba_today_projections_v2.py and the backtester.

Model (simple but strong for DFS):
- Drop "injury/early-exit" games from minutes baseline (minutes < min_floor)
- Weighted minutes:
    min_last3_w = avg(minutes of last 3, excluding low-minute games)      weight 0.45
    min_last10_w = avg(minutes of last 10, excluding low-minute games)    weight 0.35
    min_season_w = avg(minutes season, excluding low-minute games)        weight 0.20
- Clamp to [min_cap_low, min_cap_high]

You can tune weights without changing any other pipeline code.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import duckdb
import pandas as pd


@dataclass(frozen=True)
class MinutesModelConfig:
    season: str
    min_floor: float = 8.0           # treat <8 minutes as likely injury/garbage; exclude from baseline
    min_cap_low: float = 10.0
    min_cap_high: float = 40.0
    w_last3: float = 0.45
    w_last10: float = 0.35
    w_season: float = 0.20


def compute_minutes_features(
    con: duckdb.DuckDBPyConnection,
    season: str,
    as_of_date: Optional[str] = None,
) -> pd.DataFrame:
    """Return per-player minutes features using games strictly before as_of_date (if provided)."""
    date_filter = ""
    if as_of_date:
        date_filter = "AND game_date < CAST(? AS DATE)"

    q = f"""
    WITH logs AS (
      SELECT
        player_id,
        player_name,
        game_date,
        minutes
      FROM nba_player_game_logs
      WHERE season = ?
        AND minutes IS NOT NULL
        {date_filter}
    ),
    logs2 AS (
      SELECT
        player_id,
        player_name,
        game_date,
        minutes,
        CASE WHEN minutes >= 8 THEN 1 ELSE 0 END AS good_min
      FROM logs
    ),
    ranked AS (
      SELECT
        player_id,
        player_name,
        game_date,
        minutes,
        good_min,
        ROW_NUMBER() OVER (PARTITION BY player_id ORDER BY game_date DESC) AS rn
      FROM logs2
    )
    SELECT
      player_id,
      ANY_VALUE(player_name) AS player_name,
      AVG(CASE WHEN good_min=1 THEN minutes END) AS min_season_good,
      AVG(CASE WHEN rn <= 10 AND good_min=1 THEN minutes END) AS min_last10_good,
      AVG(CASE WHEN rn <= 3  AND good_min=1 THEN minutes END) AS min_last3_good,
      AVG(CASE WHEN rn <= 10 THEN minutes END) AS min_last10_any,
      AVG(CASE WHEN rn <= 3  THEN minutes END) AS min_last3_any,
      SUM(CASE WHEN rn <= 10 AND good_min=0 THEN 1 ELSE 0 END) AS low_min_games_last10
    FROM ranked
    GROUP BY player_id;
    """

    if as_of_date:
        return con.execute(q, [season, as_of_date]).df()
    return con.execute(q, [season]).df()


def project_minutes(features: pd.DataFrame, cfg: MinutesModelConfig) -> pd.Series:
    """Compute MinProj for each row in features dataframe."""
    # Prefer "good" mins, but fall back to any mins if good mins missing
    min_last3 = features["min_last3_good"].fillna(features["min_last3_any"])
    min_last10 = features["min_last10_good"].fillna(features["min_last10_any"])
    min_season = features["min_season_good"].fillna(min_last10).fillna(min_last3)

    min_proj = (
        cfg.w_last3 * min_last3.fillna(min_last10).fillna(min_season)
        + cfg.w_last10 * min_last10.fillna(min_season).fillna(min_last3)
        + cfg.w_season * min_season.fillna(min_last10).fillna(min_last3)
    )

    # Clamp
    min_proj = min_proj.clip(lower=cfg.min_cap_low, upper=cfg.min_cap_high)
    return min_proj
