
#!/usr/bin/env python
"""
opponent_adjustments_nba_v3_posmap.py

Same as v2 (team env + optional DvP), but if nba_player_game_logs lacks a position column,
it will compute DvP using nba_player_position_map (built from FanDuel slate CSVs).

CTEs avoid reserved words. Works in DuckDB.

Exported:
- OpponentAdjV3Config
- compute_team_environment_tables_v3
- compute_matchup_multiplier_v3
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional
import duckdb
import numpy as np
import pandas as pd


@dataclass
class OpponentAdjV3Config:
    season: str
    pace_weight: float = 0.55
    defense_weight: float = 0.45

    dvp_weight: float = 0.55
    dvp_min_samples: int = 60
    clamp_low: float = 0.90
    clamp_high: float = 1.10


def _detect_col(cols, candidates):
    lower = {c.lower(): c for c in cols}
    for cand in candidates:
        if cand.lower() in lower:
            return lower[cand.lower()]
    return None


def compute_team_environment_tables_v3(
    con: duckdb.DuckDBPyConnection,
    season: str,
    as_of_date: Optional[str] = None
) -> dict:
    date_filter = ""
    params = [season]
    if as_of_date:
        date_filter = "AND game_date < CAST(? AS DATE)"
        params.append(as_of_date)

    # --- Team defense proxy: FD allowed per game ---
    q_allowed = f"""
    WITH team_games AS (
      SELECT season, game_date, team_abbr, opp_abbr,
             SUM(fd_points) AS team_fd
      FROM nba_player_game_logs
      WHERE season = ?
        {date_filter}
        AND fd_points IS NOT NULL
      GROUP BY season, game_date, team_abbr, opp_abbr
    ),
    allowed AS (
      SELECT opp_abbr AS team, AVG(team_fd) AS fd_allowed_per_game
      FROM team_games
      GROUP BY opp_abbr
    )
    SELECT * FROM allowed;
    """
    allowed_df = con.execute(q_allowed, params).df()

    # --- Matchup environment proxy: total FD in game (both teams) ---
    q_total = f"""
    WITH team_games AS (
      SELECT season, game_date, team_abbr, opp_abbr,
             SUM(fd_points) AS team_fd
      FROM nba_player_game_logs
      WHERE season = ?
        {date_filter}
        AND fd_points IS NOT NULL
      GROUP BY season, game_date, team_abbr, opp_abbr
    ),
    paired AS (
      SELECT tg1.team_abbr AS team, tg1.opp_abbr AS opp,
             (tg1.team_fd + tg2.team_fd) AS total_fd
      FROM team_games tg1
      JOIN team_games tg2
        ON tg1.season = tg2.season
       AND tg1.game_date = tg2.game_date
       AND tg1.team_abbr = tg2.opp_abbr
       AND tg1.opp_abbr = tg2.team_abbr
    )
    SELECT team, opp, AVG(total_fd) AS total_fd_avg
    FROM paired
    GROUP BY team, opp;
    """
    total_df = con.execute(q_total, params).df()

    league_avg_allowed = float(allowed_df["fd_allowed_per_game"].mean()) if not allowed_df.empty else 0.0
    league_avg_total = float(total_df["total_fd_avg"].mean()) if not total_df.empty else 0.0

    team_allowed = {str(r["team"]): float(r["fd_allowed_per_game"]) for _, r in allowed_df.iterrows()}
    matchup_total = {(str(r["team"]), str(r["opp"])): float(r["total_fd_avg"]) for _, r in total_df.iterrows()}

    # --- DvP ---
    cols = con.execute("DESCRIBE nba_player_game_logs").df()["column_name"].tolist()
    pos_col = _detect_col(cols, ["roster_position", "position", "pos", "lineup_position", "positions"])

    dvp_allowed = {}
    dvp_league_avg = {}
    dvp_samples = {}
    dvp_source = None

    if pos_col:
        dvp_source = f"logs:{pos_col}"
        q_dvp = f"""
        WITH base AS (
          SELECT
            opp_abbr AS opp,
            {pos_col} AS pos_raw,
            fd_points
          FROM nba_player_game_logs
          WHERE season = ?
            {date_filter}
            AND fd_points IS NOT NULL
            AND {pos_col} IS NOT NULL
            AND TRIM(CAST({pos_col} AS VARCHAR)) <> ''
        ),
        bucketed AS (
          SELECT
            opp,
            CASE
              WHEN UPPER(pos_raw) LIKE '%PG%' THEN 'PG'
              WHEN UPPER(pos_raw) LIKE '%SG%' THEN 'SG'
              WHEN UPPER(pos_raw) LIKE '%SF%' THEN 'SF'
              WHEN UPPER(pos_raw) LIKE '%PF%' THEN 'PF'
              WHEN UPPER(pos_raw) LIKE '%C%'  THEN 'C'
              ELSE NULL
            END AS pos_bucket,
            fd_points
          FROM base
        )
        SELECT opp, pos_bucket,
               COUNT(*) AS n,
               AVG(fd_points) AS fd_allowed_per_player
        FROM bucketed
        WHERE pos_bucket IS NOT NULL
        GROUP BY opp, pos_bucket;
        """
        dvp_df = con.execute(q_dvp, params).df()

        if not dvp_df.empty:
            q_league = f"""
            WITH base AS (
              SELECT
                {pos_col} AS pos_raw,
                fd_points
              FROM nba_player_game_logs
              WHERE season = ?
                {date_filter}
                AND fd_points IS NOT NULL
                AND {pos_col} IS NOT NULL
                AND TRIM(CAST({pos_col} AS VARCHAR)) <> ''
            ),
            bucketed AS (
              SELECT
                CASE
                  WHEN UPPER(pos_raw) LIKE '%PG%' THEN 'PG'
                  WHEN UPPER(pos_raw) LIKE '%SG%' THEN 'SG'
                  WHEN UPPER(pos_raw) LIKE '%SF%' THEN 'SF'
                  WHEN UPPER(pos_raw) LIKE '%PF%' THEN 'PF'
                  WHEN UPPER(pos_raw) LIKE '%C%'  THEN 'C'
                  ELSE NULL
                END AS pos_bucket,
                fd_points
              FROM base
            )
            SELECT pos_bucket, AVG(fd_points) AS league_avg
            FROM bucketed
            WHERE pos_bucket IS NOT NULL
            GROUP BY pos_bucket;
            """
            league_df = con.execute(q_league, params).df()
            dvp_league_avg = {str(r["pos_bucket"]): float(r["league_avg"]) for _, r in league_df.iterrows()}

            for _, r in dvp_df.iterrows():
                key = (str(r["opp"]), str(r["pos_bucket"]))
                dvp_allowed[key] = float(r["fd_allowed_per_player"])
                dvp_samples[key] = int(r["n"])

    else:
        # Try pos map table from FD slates
        # Requires nba_player_position_map(player_id, pos_bucket)
        try:
            con.execute("SELECT 1 FROM nba_player_position_map LIMIT 1").df()
            dvp_source = "posmap:nba_player_position_map"
            q_dvp = f"""
            WITH base AS (
              SELECT
                l.opp_abbr AS opp,
                m.pos_bucket AS pos_bucket,
                l.fd_points AS fd_points
              FROM nba_player_game_logs l
              JOIN nba_player_position_map m
                ON CAST(l.player_id AS VARCHAR) = m.player_id
              WHERE l.season = ?
                {date_filter.replace("game_date", "l.game_date")}
                AND l.fd_points IS NOT NULL
                AND m.pos_bucket IS NOT NULL
                AND TRIM(CAST(m.pos_bucket AS VARCHAR)) <> ''
            )
            SELECT opp, pos_bucket,
                   COUNT(*) AS n,
                   AVG(fd_points) AS fd_allowed_per_player
            FROM base
            GROUP BY opp, pos_bucket;
            """
            dvp_df = con.execute(q_dvp, params).df()

            if not dvp_df.empty:
                q_league = f"""
                WITH base AS (
                  SELECT
                    m.pos_bucket AS pos_bucket,
                    l.fd_points AS fd_points
                  FROM nba_player_game_logs l
                  JOIN nba_player_position_map m
                    ON CAST(l.player_id AS VARCHAR) = m.player_id
                  WHERE l.season = ?
                    {date_filter.replace("game_date", "l.game_date")}
                    AND l.fd_points IS NOT NULL
                    AND m.pos_bucket IS NOT NULL
                    AND TRIM(CAST(m.pos_bucket AS VARCHAR)) <> ''
                )
                SELECT pos_bucket, AVG(fd_points) AS league_avg
                FROM base
                GROUP BY pos_bucket;
                """
                league_df = con.execute(q_league, params).df()
                dvp_league_avg = {str(r["pos_bucket"]): float(r["league_avg"]) for _, r in league_df.iterrows()}

                for _, r in dvp_df.iterrows():
                    key = (str(r["opp"]), str(r["pos_bucket"]))
                    dvp_allowed[key] = float(r["fd_allowed_per_player"])
                    dvp_samples[key] = int(r["n"])
        except Exception:
            dvp_source = None

    return {
        "team_allowed": team_allowed,
        "matchup_total": matchup_total,
        "league_avg_allowed": league_avg_allowed,
        "league_avg_total": league_avg_total,
        "dvp_allowed": dvp_allowed,
        "dvp_league_avg": dvp_league_avg,
        "dvp_samples": dvp_samples,
        "dvp_source": dvp_source,
    }


def compute_matchup_multiplier_v3(env: dict, team: str, opp: str, pos_bucket: Optional[str], cfg: OpponentAdjV3Config) -> float:
    team = (team or "").strip().upper()
    opp = (opp or "").strip().upper()
    if not team or not opp:
        return 1.0

    total = env["matchup_total"].get((team, opp))
    pace_mult = 1.0 if (total is None or env["league_avg_total"] <= 0) else float(total / env["league_avg_total"])

    allowed = env["team_allowed"].get(opp)
    def_mult = 1.0 if (allowed is None or env["league_avg_allowed"] <= 0) else float(allowed / env["league_avg_allowed"])

    base = (pace_mult ** cfg.pace_weight) * (def_mult ** cfg.defense_weight)

    dvp_mult = 1.0
    if pos_bucket:
        pb = pos_bucket.strip().upper()
        league_pb = env["dvp_league_avg"].get(pb)
        allowed_pb = env["dvp_allowed"].get((opp, pb))
        n = env["dvp_samples"].get((opp, pb), 0)
        if league_pb and allowed_pb and league_pb > 0 and n >= cfg.dvp_min_samples:
            raw = allowed_pb / league_pb
            dvp_mult = 1.0 + cfg.dvp_weight * (raw - 1.0)

    out = base * dvp_mult
    return float(np.clip(out, cfg.clamp_low, cfg.clamp_high))
