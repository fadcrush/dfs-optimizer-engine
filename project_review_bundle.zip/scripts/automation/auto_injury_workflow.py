#!/usr/bin/env python
"""
auto_injury_workflow.py

MASTER AUTOMATION WORKFLOW - One command does everything!

This is the main entry point for the automated injury analysis system.
Orchestrates all components with correct paths after reorganization.

Usage:
    python auto_injury_workflow.py SLATE.csv --num-lineups 150
    
Or use the launcher:
    python run_automation.py SLATE.csv --num-lineups 150
"""

import sys
import subprocess
from pathlib import Path
import argparse

print("="*80)
print("[AI] AUTOMATED INJURY WORKFLOW")
print("="*80)

def get_script_path(category: str, script_name: str) -> Path:
    """Get absolute path to a script in the new structure"""
    base = Path(__file__).parent.parent  # scripts/
    return base / category / script_name

def run_script(category: str, script_name: str, args: list) -> subprocess.CompletedProcess:
    """Run a script with arguments"""
    script_path = get_script_path(category, script_name)
    
    if not script_path.exists():
        print(f"\n[ERROR] Script not found: {script_path}")
        sys.exit(1)
    
    cmd = [sys.executable, str(script_path)] + args
    return subprocess.run(cmd, capture_output=True, text=True, check=True)

def main():
    parser = argparse.ArgumentParser(description='Automated DFS Injury Workflow')
    parser.add_argument('slate', help='Path to FanDuel slate CSV')
    parser.add_argument('--num-lineups', type=int, default=150, help='Number of lineups to generate')
    parser.add_argument('--db', default='data/dfs_warehouse.duckdb', help='Path to DuckDB database')
    parser.add_argument('--season', default='2024-25', help='NBA season')
    parser.add_argument('--min-salary', type=int, default=8000, help='Min salary for star players')
    parser.add_argument('--min-uplift', type=float, default=5.0, help='Min FD uplift for beneficiaries')
    
    args = parser.parse_args()
    
    slate_path = Path(args.slate)
    if not slate_path.exists():
        print(f"\n[ERROR] Slate file not found: {slate_path}")
        sys.exit(1)
    
    print(f"\n Slate: {slate_path.name}")
    print(f" Lineups: {args.num_lineups}")
    print(f" Database: {args.db}")
    
    try:
        # STEP 1: Auto-detect injuries
        print(f"\n{'='*80}")
        print("STEP 1: Auto-Detect Injuries from Slate")
        print(f"{'='*80}")
        
        result = run_script('detection', 'auto_injury_scanner.py', [
            str(slate_path),
            '--min-salary', str(args.min_salary)
        ])
        
        print(result.stdout)
        
        # Extract injury string from output
        injury_string = None
        for line in result.stdout.split('\n'):
            if line.strip() and ':' in line and ';' in line:
                # This looks like injury string format
                injury_string = line.strip()
                break
        
        if not injury_string:
            print("\n[WARNING]  No star injuries detected - proceeding with normal workflow")
            injury_string = ""
        
        # STEP 2: AI Beneficiary Analysis (if injuries found)
        if injury_string:
            print(f"\n{'='*80}")
            print("STEP 2: AI Beneficiary Analysis")
            print(f"{'='*80}")
            
            result = run_script('detection', 'injury_beneficiary_analyzer.py', [
                '--injuries', injury_string,
                '--db', args.db,
                '--season', args.season,
                '--min-uplift', str(args.min_uplift),
                '--output', 'outputs/auto_injury_rules.py'
            ])
            
            print(result.stdout)
        
        # STEP 3: Generate base projections
        print(f"\n{'='*80}")
        print("STEP 3: Generate Base Projections")
        print(f"{'='*80}")
        
        result = run_script('projections', 'nba_today_projections_v3_dvp_posmap.py', [
            str(slate_path),
            '--season', args.season
        ])
        
        print(result.stdout)
        
        # STEP 4: Apply injury boosts (if injuries found)
        if injury_string:
            print(f"\n{'='*80}")
            print("STEP 4: Apply Injury Boosts")
            print(f"{'='*80}")
            
            result = run_script('detection', 'injury_value_detector.py', [
                str(slate_path),
                '--injuries', injury_string
            ])
            
            print(result.stdout)
        
        # STEP 5: Run ownership simulation
        print(f"\n{'='*80}")
        print("STEP 5: Ownership Simulation (10K lineups)")
        print(f"{'='*80}")
        
        result = run_script('optimization', 'ownership_simulator_nba_FIXED_for_one_command.py', [
            str(slate_path),
            '--num', '10000'
        ])
        
        print(result.stdout)
        
        # STEP 6: Analyze ownership insights
        print(f"\n{'='*80}")
        print("STEP 6: Ownership Insights Analysis")
        print(f"{'='*80}")
        
        result = run_script('analysis', 'ownership_insights_analyzer.py', [])
        
        print(result.stdout)
        
        # STEP 7: Generate optimized lineups
        print(f"\n{'='*80}")
        print(f"STEP 7: Generate {args.num_lineups} Optimized Lineups")
        print(f"{'='*80}")
        
        result = run_script('optimization', 'nba_lineup_optimizer.py', [
            str(slate_path),
            '--num-lineups', str(args.num_lineups),
            '--strategy', 'balanced',
            '--min-salary', '49000'
        ])
        
        print(result.stdout)
        
        # DONE
        print(f"\n{'='*80}")
        print("[OK] WORKFLOW COMPLETE!")
        print(f"{'='*80}")
        
        print(f"\n Check outputs/ folder for:")
        print(f"   - Projections (with injury boosts)")
        print(f"   - Ownership simulation results")
        print(f"   - Leverage insights")
        print(f"   - Optimized lineups (FanDuel CSV)")
        
        if injury_string:
            print(f"\n[TIP] Auto-generated injury rules saved to:")
            print(f"   outputs/auto_injury_rules.py")
        
        print(f"\n Upload lineups to FanDuel and dominate!")
        print(f"{'='*80}")
        
    except subprocess.CalledProcessError as e:
        print(f"\n[ERROR] Error running script:")
        print(e.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"\n[ERROR] Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
