#!/usr/bin/env python
"""
nba_dfs_master_workflow.py

Complete NBA DFS workflow:
1. Generate projections (minutes + FPPM + DvP)
2. Run ownership simulation (10K lineups)
3. Generate optimized lineups using both projections and ownership
4. Export FanDuel-ready CSV

Usage:
    python nba_dfs_master_workflow.py "FanDuel-NBA-Main.csv" --num-lineups 50
"""

import argparse
import random
import subprocess
import sys
from collections import defaultdict
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd


def _banner():
    print("=" * 80)
    print("NBA DFS MASTER WORKFLOW")
    print("=" * 80)


def run_step(description: str, command: str | list[str], shell: bool = True) -> None:
    """
    Run a subprocess step and hard-fail on non-zero exit.
    command:
      - str  (shell=True default)
      - list (shell=False recommended)
    """
    print(f"\n{'=' * 80}")
    print(f"STEP: {description}")
    print(f"{'=' * 80}")

    if isinstance(command, list):
        # safer invocation
        result = subprocess.run(command, shell=False)
    else:
        result = subprocess.run(command, shell=shell)

    if result.returncode != 0:
        raise RuntimeError(f"FAILED step: {description} (code={result.returncode})")

    print(f"[OK] COMPLETED: {description}")


def load_latest_file(pattern):
    """Get most recent file matching pattern"""
    files = sorted(Path("outputs").glob(pattern), key=lambda p: p.stat().st_mtime, reverse=True)
    return files[0] if files else None

def can_fill_slot(position, slot):
    """Check if position can fill FanDuel slot"""
    positions = [p.strip() for p in str(position).split('/')]
    
    if slot == 'PG': return 'PG' in positions
    elif slot == 'SG': return 'SG' in positions
    elif slot == 'SF': return 'SF' in positions
    elif slot == 'PF': return 'PF' in positions
    elif slot == 'C': return 'C' in positions
    return False

def build_lineup_with_ownership(pool, ownership, used_count, config):
    """Build single lineup using projections and ownership data"""
    
    available = pool.copy()
    
    # Filter over-exposed players
    max_uses = int(config['num_lineups'] * config['max_exposure'])
    available = available[available['Name'].map(lambda x: used_count.get(x, 0) < max_uses)]
    
    if len(available) < 9:
        return None
    
    # Merge ownership data
    if ownership is not None:
        own_dict = dict(zip(ownership['Name'], ownership['SimOwnership']))
        available['Ownership'] = available['Name'].map(own_dict).fillna(0.5)
    else:
        available['Ownership'] = 0.5
    
    # Calculate leverage score
    # High projection + Low ownership = High leverage
    available['Leverage'] = available['Projection'] / (available['Ownership'] + 0.01)
    
    # Clean up any NaN or inf values
    available['Leverage'] = available['Leverage'].replace([np.inf, -np.inf], 0.0).fillna(0.0)
    available['Projection'] = available['Projection'].fillna(0.0)
    available['Ownership'] = available['Ownership'].fillna(0.5)
    
    lineup = []
    salary_used = 0
    
    # FanDuel slots: PG, PG, SG, SG, SF, SF, PF, PF, C
    needed = {'PG': 2, 'SG': 2, 'SF': 2, 'PF': 2, 'C': 1}
    
    # Strategy: Mix high leverage with some chalk
    # 3 high leverage (contrarian)
    # 3 medium leverage (balanced)
    # 3 chalk (safe)
    
    leverage_sorted = available.sort_values('Leverage', ascending=False)
    
    # Pick players by leverage tiers
    for slot in ['PG', 'SG', 'SF', 'PF', 'C']:
        while needed[slot] > 0:
            # Get eligible players for this slot
            eligible = leverage_sorted[
                leverage_sorted['Name'].map(lambda x: x not in [p['Name'] for p in lineup])
            ]
            eligible = eligible[eligible.apply(lambda x: can_fill_slot(x['PosBucket'], slot), axis=1)]
            
            if eligible.empty:
                return None
            
            # Pick weighted by leverage
            leverage_values = eligible['Leverage'].fillna(0.1).values
            weights = np.maximum(leverage_values, 0.1)
            
            # Safety check for NaN/invalid weights
            if np.isnan(weights).any() or weights.sum() <= 0:
                # Fallback to first eligible player
                player = eligible.iloc[0]
            else:
                weights = weights / weights.sum()
                idx = np.random.choice(len(eligible), p=weights)
                player = eligible.iloc[int(idx)]
            
            if salary_used + player['Salary'] > config['max_salary']:
                # Try cheapest option
                eligible = eligible.sort_values('Salary')
                if eligible.empty:
                    return None
                player = eligible.iloc[0]
                if salary_used + player['Salary'] > config['max_salary']:
                    return None
            
            lineup.append(player.to_dict())
            salary_used += player['Salary']
            needed[slot] -= 1
    
    # Validate
    if len(lineup) == 9 and config['min_salary'] <= salary_used <= config['max_salary']:
        return lineup
    return None

def generate_lineups_with_ownership(pool, ownership, config):
    """Generate lineups using projections and ownership"""
    
    print(f"\n Generating {config['num_lineups']} NBA lineups...")
    print(f"   Strategy: Leverage-based (High Proj / Low Own)")
    
    lineups = []
    used_count = defaultdict(int)
    
    attempts = 0
    max_attempts = config['num_lineups'] * 20
    
    while len(lineups) < config['num_lineups'] and attempts < max_attempts:
        attempts += 1
        
        lineup = build_lineup_with_ownership(pool, ownership, used_count, config)
        
        if lineup:
            lineups.append(lineup)
            for p in lineup:
                used_count[p['Name']] += 1
            
            if len(lineups) % 10 == 0:
                print(f"  Progress: {len(lineups)}/{config['num_lineups']}")
    
    print(f"\n[OK] Generated {len(lineups)} lineups in {attempts} attempts")
    
    return lineups, used_count

def export_fanduel_csv(lineups, output_file):
    """Export to FanDuel format"""
    
    with open(output_file, 'w') as f:
        f.write("Lineup,PG,PG,SG,SG,SF,SF,PF,PF,C,Salary,Projection\n")
        
        for i, lineup in enumerate(lineups):
            row = [f'Lineup_{i+1}']
            
            # Sort by slots
            sorted_lu = []
            used = set()
            
            for slot in ['PG', 'PG', 'SG', 'SG', 'SF', 'SF', 'PF', 'PF', 'C']:
                for p in lineup:
                    if p['Name'] not in used and can_fill_slot(p['PosBucket'], slot):
                        sorted_lu.append(p)
                        used.add(p['Name'])
                        break
            
            # Add player IDs
            for p in sorted_lu:
                row.append(f"{p['ID']}:{p['Name']}")
            
            row.append(str(sum(p['Salary'] for p in lineup)))
            row.append(f"{sum(p['Projection'] for p in lineup):.1f}")
            
            f.write(','.join(row) + '\n')
    
    print(f"[OK] Saved to: {output_file}")

def run_nba_dfs_pipeline(
    slate_csv: str,
    season: str = "2024-25",
    num_lineups: int = 50,
    max_exposure: float = 0.35,
    min_salary: int = 44000,
    max_salary: int = 60000,
    db: str = "data/dfs_warehouse.duckdb",
    ownership_sims: int = 10000,
    skip_projections: bool = False,
    skip_ownership: bool = False,
    verbose: bool = True,
) -> dict:
    """
    Programmatic API for NBA DFS workflow.
    - Safe for Django views + Celery tasks (no sys.exit, no argparse)
    - Returns paths to generated files and summary metrics

    Returns:
      {
        "projection_file": "...",
        "ownership_file": "... or None",
        "lineups_file": "...",
        "num_lineups": int,
        "avg_projection": float,
        "avg_salary": float,
        "avg_ownership": float | None
      }
    """
    slate_path = Path(slate_csv)
    if not slate_path.exists():
        raise FileNotFoundError(f"Slate file not found: {slate_path}")

    def vprint(msg: str):
        if verbose:
            print(msg)

    if verbose:
        _banner()

    # STEP 1: Projections
    if not skip_projections:
        cmd = (
            f'python nba_today_projections_v3_dvp_posmap.py '
            f'"{slate_csv}" --season {season} --db "{db}"'
        )
        run_step("Generate Advanced Projections", cmd)
    else:
        vprint("\n⏭  Skipping projections (using existing)")

    # STEP 2: Ownership Simulation
    if not skip_ownership:
        cmd = f'python ownership_simulator_nba_FIXED_for_one_command.py "{slate_csv}" --num {ownership_sims}'
        run_step(f"Run {ownership_sims:,} Ownership Simulation", cmd)
    else:
        vprint("\n⏭  Skipping ownership (using existing)")

    # STEP 3: Load outputs
    vprint(f"\n{'='*80}")
    vprint("STEP: Load Projections & Ownership")
    vprint(f"{'='*80}")

    proj_file = load_latest_file("projections_today*.csv")
    own_file = load_latest_file("ownership_study_nba*.csv")

    if not proj_file:
        raise RuntimeError("No projection file found! (expected outputs/projections_today*.csv)")

    projections = pd.read_csv(proj_file)
    vprint(f"[OK] Loaded projections: {proj_file.name}")

    ownership = None
    if not own_file:
        vprint("[WARNING]  No ownership file found, proceeding without ownership data")
    else:
        ownership = pd.read_csv(own_file)
        vprint(f"[OK] Loaded ownership: {own_file.name}")

    # STEP 4: Generate optimized lineups
    vprint(f"\n{'='*80}")
    vprint("STEP: Generate Optimized Lineups")
    vprint(f"{'='*80}")

    config = {
        "num_lineups": int(num_lineups),
        "max_exposure": float(max_exposure),
        "min_salary": int(min_salary),
        "max_salary": int(max_salary),
    }

    lineups, used_count = generate_lineups_with_ownership(projections, ownership, config)

    if not lineups:
        raise RuntimeError("Failed to generate lineups")

    # STEP 5: Analytics (for return payload)
    all_proj = [sum(p["Projection"] for p in lu) for lu in lineups]
    all_sal = [sum(p["Salary"] for p in lu) for lu in lineups]

    avg_proj = float(np.mean(all_proj)) if all_proj else 0.0
    avg_sal = float(np.mean(all_sal)) if all_sal else 0.0

    avg_own = None
    if ownership is not None:
        # Handle both variants: SimOwn or SimOwnership
        own_col = "SimOwn" if "SimOwn" in ownership.columns else ("SimOwnership" if "SimOwnership" in ownership.columns else None)
        if own_col and "Name" in ownership.columns:
            own_dict = dict(zip(ownership["Name"], ownership[own_col]))
            all_own = []
            for lu in lineups:
                all_own.append(float(np.mean([own_dict.get(p["Name"], 0.0) for p in lu])))
            avg_own = float(np.mean(all_own)) if all_own else 0.0

    # STEP 6: Export
    vprint(f"\n{'='*80}")
    vprint("STEP: Export FanDuel CSV")
    vprint(f"{'='*80}")

    outdir = Path("outputs")
    outdir.mkdir(exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = outdir / f"nba_lineups_master_{ts}.csv"

    export_fanduel_csv(lineups, output_file)
    vprint(f"[OK] Saved to: {output_file}")

    return {
        "projection_file": str(proj_file),
        "ownership_file": str(own_file) if own_file else None,
        "lineups_file": str(output_file),
        "num_lineups": len(lineups),
        "avg_projection": avg_proj,
        "avg_salary": avg_sal,
        "avg_ownership": avg_own,
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("slate_csv", help="FanDuel NBA players-list CSV")
    ap.add_argument("--num-lineups", type=int, default=50)
    ap.add_argument("--max-exposure", type=float, default=0.35)
    ap.add_argument("--min-salary", type=int, default=44000)
    ap.add_argument("--max-salary", type=int, default=60000)
    ap.add_argument("--season", default="2024-25")
    ap.add_argument("--db", default="data/dfs_warehouse.duckdb")
    ap.add_argument("--skip-projections", action="store_true")
    ap.add_argument("--skip-ownership", action="store_true")
    args = ap.parse_args()

    result = run_nba_dfs_pipeline(
        slate_csv=args.slate_csv,
        season=args.season,
        num_lineups=args.num_lineups,
        max_exposure=args.max_exposure,
        min_salary=args.min_salary,
        max_salary=args.max_salary,
        db=args.db,
        skip_projections=args.skip_projections,
        skip_ownership=args.skip_ownership,
        verbose=True,
    )

    print("\n Output:", result["lineups_file"])

    

if __name__ == "__main__":
    main()
