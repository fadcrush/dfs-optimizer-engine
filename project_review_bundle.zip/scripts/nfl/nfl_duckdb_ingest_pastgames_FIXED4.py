#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# NFL DuckDB ingestion (FanDuel past games) - WEEK FILES ONLY
#
# Fixes included:
# - Windows-safe (no backslash docstrings)
# - Correct week filename regex
# - Robust CSV reading (comma OR tab-delimited; utf-8-sig)
# - Robust DFS ID detection (handles BOM/hidden chars/alternate headers)
# - Coalesces duplicate columns after normalization
#
# Creates / upserts:
#   nfl_player_games
#   nfl_field_ownership
#   nfl_projection_inputs

import argparse
import re
from pathlib import Path
from typing import Optional, Tuple, Dict, List

import duckdb
import pandas as pd
import numpy as np

WEEK_FILE_RE = re.compile(r"nfl_(\d{4}-\d{2}-\d{2})_week(\d+)\.csv$", re.IGNORECASE)


def infer_date_week(path: Path) -> Tuple[Optional[str], Optional[int]]:
    m = WEEK_FILE_RE.search(path.name)
    if not m:
        return None, None
    return m.group(1), int(m.group(2))


def clean_header(h: str) -> str:
    if h is None:
        return ""
    # Remove BOM and weird unicode spaces
    return str(h).replace("\ufeff", "").replace("\u200b", "").strip()


def snake(s: str) -> str:
    s = clean_header(s).lower()
    s = re.sub(r"[^a-z0-9]+", "_", s)
    s = re.sub(r"_+", "_", s).strip("_")
    return s


CANON_MAP: Dict[str, str] = {
    "dfs_id": "dfs_id",
    "dfs id": "dfs_id",
    "dfsid": "dfs_id",
    "id": "dfs_id",
    "player_id": "dfs_id",
    "player id": "dfs_id",

    "name": "name",
    "player": "name",
    "pos": "pos",
    "position": "pos",
    "team": "team",
    "opp": "opp",
    "opponent": "opp",
    "status": "status",
    "salary": "salary",

    "actual": "actual_fd_points",
    "fd_points": "actual_fd_points",
    "fd points": "actual_fd_points",

    "ss_proj": "ss_proj",
    "ss proj": "ss_proj",
    "live_proj": "live_proj",
    "live proj": "live_proj",
    "my_proj": "my_proj",
    "my proj": "my_proj",

    "ownership": "ownership",
    "adjusted_ownership": "adjusted_ownership",
    "adjusted ownership": "adjusted_ownership",
    "my_own": "my_own",
    "min_exp": "min_exp",
    "max_exp": "max_exp",

    "pass_att": "pass_att",
    "pass att": "pass_att",
    "pass_attempts": "pass_att",
    "pass attempts": "pass_att",
    "completions": "pass_completions",
    "pass_completions": "pass_completions",
    "pass completions": "pass_completions",
    "pass_yds": "pass_yds",
    "pass yds": "pass_yds",
    "pass_yards": "pass_yds",
    "pass yards": "pass_yds",
    "pass_td": "pass_td",
    "pass td": "pass_td",
    "pass_touchdowns": "pass_td",
    "pass touchdowns": "pass_td",
    "pass_int": "pass_int",
    "pass int": "pass_int",
    "interceptions": "pass_int",
    "pass interceptions": "pass_int",

    "rec": "rec",
    "receptions": "rec",
    "rec_yds": "rec_yds",
    "rec yds": "rec_yds",
    "receiving_yards": "rec_yds",
    "receiving yards": "rec_yds",
    "rec_td": "rec_td",
    "rec td": "rec_td",
    "receiving_touchdowns": "rec_td",
    "receiving touchdowns": "rec_td",

    "rush_att": "rush_att",
    "rush att": "rush_att",
    "rushing_attempts": "rush_att",
    "rushing attempts": "rush_att",
    "rush_yds": "rush_yds",
    "rush yds": "rush_yds",
    "rushing_yards": "rush_yds",
    "rushing yards": "rush_yds",
    "rush_td": "rush_td",
    "rush td": "rush_td",
    "rushing_touchdowns": "rush_td",
    "rushing touchdowns": "rush_td",
}


def read_csv_robust(path: Path) -> pd.DataFrame:
    # Try UTF-8 with BOM handling
    df = pd.read_csv(path, encoding="utf-8-sig")
    # If it looks tab-delimited (single big column with tabs), retry
    if df.shape[1] == 1:
        col0 = str(df.columns[0])
        if "\t" in col0:
            df = pd.read_csv(path, sep="\t", encoding="utf-8-sig")
        else:
            # also check first row values for tabs
            first_val = str(df.iloc[0, 0]) if len(df) else ""
            if "\t" in first_val:
                df = pd.read_csv(path, sep="\t", encoding="utf-8-sig")
    # Clean headers
    df.columns = [clean_header(c) for c in df.columns]
    return df


def _coalesce_duplicate_columns(df: pd.DataFrame) -> pd.DataFrame:
    if df.columns.is_unique:
        return df
    out = df.copy()
    for col in pd.Index(out.columns).unique():
        if (out.columns == col).sum() > 1:
            block = out.loc[:, col]
            combined = block.bfill(axis=1).iloc[:, 0]
            out = out.drop(columns=[col])
            out[col] = combined
    return out


def find_dfs_id_column(columns: List[str]) -> Optional[str]:
    # Direct hits after cleaning
    for c in columns:
        c_clean = clean_header(c).lower()
        if c_clean in ("dfs id", "dfs_id", "dfsid", "id", "player id", "player_id"):
            return c
    # Fuzzy contains
    for c in columns:
        c_clean = clean_header(c).lower()
        if "dfs" in c_clean and "id" in c_clean:
            return c
    return None


def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    # First, force-detect DFS id header if present
    dfs_col = find_dfs_id_column(list(df.columns))
    rename = {}

    for c in df.columns:
        key = clean_header(c)
        key_l = key.lower()

        # If this is the detected DFS column, map it
        if dfs_col is not None and c == dfs_col:
            rename[c] = "dfs_id"
            continue

        # Special-cases frequently seen
        if key_l == "adjusted ownership":
            rename[c] = "adjusted_ownership"
            continue
        if key_l == "ss proj":
            rename[c] = "ss_proj"
            continue
        if key_l == "live proj":
            rename[c] = "live_proj"
            continue
        if key_l == "my proj":
            rename[c] = "my_proj"
            continue

        k = key_l.replace("/", " ").replace("_", " ")
        k = re.sub(r"\s+", " ", k).strip()
        if k in CANON_MAP:
            rename[c] = CANON_MAP[k]
        else:
            sk = snake(key)
            rename[c] = CANON_MAP.get(sk, sk)

    out = df.rename(columns=rename).copy()
    out = _coalesce_duplicate_columns(out)

    # Ensure dfs_id exists; if not, attempt last-chance detect on normalized columns
    if "dfs_id" not in out.columns:
        last = find_dfs_id_column(list(out.columns))
        if last and last in out.columns:
            out = out.rename(columns={last: "dfs_id"})
        else:
            raise ValueError("Could not find dfs_id column after normalization. Headers seen: " + ", ".join(list(df.columns)[:25]))

    out["dfs_id"] = out["dfs_id"].astype(str)

    for col in ["name", "pos", "team", "opp", "status"]:
        if col not in out.columns:
            out[col] = ""
        out[col] = out[col].astype(str)

    num_cols = [
        "salary", "actual_fd_points", "ss_proj", "live_proj", "my_proj",
        "ownership", "adjusted_ownership", "my_own", "min_exp", "max_exp",
        "pass_att", "pass_completions", "pass_yds", "pass_td", "pass_int",
        "rec", "rec_yds", "rec_td",
        "rush_att", "rush_yds", "rush_td",
    ]
    for c in num_cols:
        if c in out.columns:
            if isinstance(out[c], pd.DataFrame):
                out[c] = out[c].bfill(axis=1).iloc[:, 0]
            out[c] = pd.to_numeric(out[c], errors="coerce")

    return out


def ensure_tables(con: duckdb.DuckDBPyConnection) -> None:
    con.execute("""
    CREATE TABLE IF NOT EXISTS nfl_player_games (
        season INTEGER,
        week INTEGER,
        slate_date VARCHAR,
        dfs_id VARCHAR,
        name VARCHAR,
        pos VARCHAR,
        team VARCHAR,
        opp VARCHAR,
        status VARCHAR,
        salary INTEGER,
        actual_fd_points DOUBLE,
        pass_att DOUBLE,
        pass_completions DOUBLE,
        pass_yds DOUBLE,
        pass_td DOUBLE,
        pass_int DOUBLE,
        rec DOUBLE,
        rec_yds DOUBLE,
        rec_td DOUBLE,
        rush_att DOUBLE,
        rush_yds DOUBLE,
        rush_td DOUBLE,
        source_file VARCHAR,
        ingested_at TIMESTAMP DEFAULT now()
    );
    """)
    con.execute("""
    CREATE TABLE IF NOT EXISTS nfl_field_ownership (
        season INTEGER,
        week INTEGER,
        slate_date VARCHAR,
        dfs_id VARCHAR,
        name VARCHAR,
        pos VARCHAR,
        team VARCHAR,
        opp VARCHAR,
        salary INTEGER,
        ownership DOUBLE,
        adjusted_ownership DOUBLE,
        my_own DOUBLE,
        min_exp DOUBLE,
        max_exp DOUBLE,
        source_file VARCHAR,
        ingested_at TIMESTAMP DEFAULT now()
    );
    """)
    con.execute("""
    CREATE TABLE IF NOT EXISTS nfl_projection_inputs (
        season INTEGER,
        week INTEGER,
        slate_date VARCHAR,
        dfs_id VARCHAR,
        name VARCHAR,
        pos VARCHAR,
        team VARCHAR,
        opp VARCHAR,
        status VARCHAR,
        salary INTEGER,
        ss_proj DOUBLE,
        live_proj DOUBLE,
        my_proj DOUBLE,
        source_file VARCHAR,
        ingested_at TIMESTAMP DEFAULT now()
    );
    """)


def upsert(con: duckdb.DuckDBPyConnection, table: str, df: pd.DataFrame, cols: list[str]) -> int:
    stage = f"stg_{table}"
    con.register(stage, df[cols])

    con.execute(f"""
        DELETE FROM {table}
        USING {stage}
        WHERE {table}.season = {stage}.season
          AND {table}.week = {stage}.week
          AND {table}.slate_date = {stage}.slate_date
          AND {table}.dfs_id = {stage}.dfs_id;
    """)
    con.execute(f"INSERT INTO {table} ({', '.join(cols)}) SELECT {', '.join(cols)} FROM {stage};")
    n = con.execute(f"SELECT COUNT(*) FROM {stage}").fetchone()[0]
    con.unregister(stage)
    return int(n)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--past_nfl", required=True, help="Folder containing NFL_YYYY-MM-DD_weekN.csv files")
    ap.add_argument("--db", required=True, help="DuckDB database path")
    ap.add_argument("--season", required=True, type=int, help="Season year (e.g., 2025)")
    args = ap.parse_args()

    folder = Path(args.past_nfl)
    files = sorted([p for p in folder.glob("*.csv") if WEEK_FILE_RE.search(p.name)])
    print(f" Found {len(files)} week files in: {folder}")
    if not files:
        raise RuntimeError("No week files found. Expected NFL_YYYY-MM-DD_weekN.csv")

    frames = []
    for p in files:
        slate_date, week = infer_date_week(p)
        if slate_date is None:
            continue

        df_raw = read_csv_robust(p)
        df = normalize_columns(df_raw)

        df["slate_date"] = slate_date
        df["week"] = week
        df["season"] = args.season
        df["source_file"] = p.name
        frames.append(df)

    if not frames:
        raise RuntimeError("Parsed 0 rows from week files (unexpected).")

    all_df = pd.concat(frames, ignore_index=True)
    all_df = all_df[all_df["dfs_id"].notna()].copy()

    all_df["salary"] = pd.to_numeric(all_df.get("salary", 0), errors="coerce").fillna(0).astype(int)

    con = duckdb.connect(args.db)
    ensure_tables(con)

    pg_cols = [
        "season","week","slate_date","dfs_id","name","pos","team","opp","status","salary",
        "actual_fd_points","pass_att","pass_completions","pass_yds","pass_td","pass_int",
        "rec","rec_yds","rec_td","rush_att","rush_yds","rush_td","source_file"
    ]
    for c in pg_cols:
        if c not in all_df.columns:
            all_df[c] = np.nan
    pg_n = upsert(con, "nfl_player_games", all_df, pg_cols)

    own_cols = [
        "season","week","slate_date","dfs_id","name","pos","team","opp","salary",
        "ownership","adjusted_ownership","my_own","min_exp","max_exp","source_file"
    ]
    for c in own_cols:
        if c not in all_df.columns:
            all_df[c] = np.nan
    own_n = upsert(con, "nfl_field_ownership", all_df, own_cols)

    pi_cols = [
        "season","week","slate_date","dfs_id","name","pos","team","opp","status","salary",
        "ss_proj","live_proj","my_proj","source_file"
    ]
    for c in pi_cols:
        if c not in all_df.columns:
            all_df[c] = np.nan
    pi_n = upsert(con, "nfl_projection_inputs", all_df, pi_cols)

    con.close()

    print("[OK] DuckDB ingestion complete")
    print(f"   nfl_player_games:      upserted {pg_n:,} rows")
    print(f"   nfl_field_ownership:   upserted {own_n:,} rows")
    print(f"   nfl_projection_inputs: upserted {pi_n:,} rows")


if __name__ == "__main__":
    main()
