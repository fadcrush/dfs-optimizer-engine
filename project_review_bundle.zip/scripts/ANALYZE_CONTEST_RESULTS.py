#!/usr/bin/env python
"""
ANALYZE_CONTEST_RESULTS.py

Pro-level analysis of contest results with projections and ownership.
Compares YOUR projections vs SaberSim and finds your edge.
"""

import duckdb
import pandas as pd
import numpy as np

print("="*80)
print("CONTEST RESULTS ANALYSIS - FIND YOUR EDGE")
print("="*80)

# Connect to database
DB_PATH = 'data/dfs_warehouse.duckdb'
conn = duckdb.connect(DB_PATH)

# Check data
data_check = conn.execute("""
    SELECT COUNT(*) as count FROM contest_results
""").fetchone()[0]

if data_check == 0:
    print("\n[ERROR] No contest results found!")
    print("Run: python INGEST_CONTEST_RESULTS.py first")
    exit(1)

print(f"\nAnalyzing {data_check:,} contest performances")

# =============================================================================
# ANALYSIS 1: YOU VS SABERSIM
# =============================================================================

print("\n" + "="*80)
print("YOU VS SABERSIM - HEAD TO HEAD")
print("="*80)

comparison = conn.execute("""
    SELECT 
        sport,
        COUNT(*) as num_players,
        
        -- Your accuracy
        ROUND(AVG(ABS(actual_fpts - my_proj)), 2) as your_mae,
        ROUND(AVG(my_proj - actual_fpts), 2) as your_bias,
        ROUND(CORR(my_proj, actual_fpts), 3) as your_r,
        
        -- SaberSim accuracy
        ROUND(AVG(ABS(actual_fpts - sabersim_proj)), 2) as ss_mae,
        ROUND(AVG(sabersim_proj - actual_fpts), 2) as ss_bias,
        ROUND(CORR(sabersim_proj, actual_fpts), 3) as ss_r,
        
        -- Head to head wins
        SUM(CASE WHEN ABS(actual_fpts - my_proj) < ABS(actual_fpts - sabersim_proj) 
            THEN 1 ELSE 0 END) as your_wins,
        SUM(CASE WHEN ABS(actual_fpts - my_proj) > ABS(actual_fpts - sabersim_proj) 
            THEN 1 ELSE 0 END) as ss_wins
        
    FROM contest_results
    WHERE my_proj IS NOT NULL 
      AND sabersim_proj IS NOT NULL
      AND actual_fpts IS NOT NULL
    GROUP BY sport
""").fetchdf()

print("\n" + comparison.to_string(index=False))

# Calculate R²
for idx, row in comparison.iterrows():
    your_r2 = row['your_r'] ** 2
    ss_r2 = row['ss_r'] ** 2
    print(f"\n{row['sport']}:")
    print(f"  Your R²: {your_r2:.3f}")
    print(f"  SaberSim R²: {ss_r2:.3f}")
    
    if your_r2 > ss_r2:
        print(f"  🎉 You beat SaberSim!")
    
    win_pct = (row['your_wins'] / (row['your_wins'] + row['ss_wins'])) * 100
    print(f"  Win Rate: {win_pct:.1f}% ({row['your_wins']}/{row['your_wins'] + row['ss_wins']})")

# =============================================================================
# ANALYSIS 2: WHERE YOU BEAT SABERSIM
# =============================================================================

print("\n" + "="*80)
print("POSITIONS WHERE YOU BEAT SABERSIM")
print("="*80)

by_position = conn.execute("""
    SELECT 
        sport,
        position,
        COUNT(*) as n,
        ROUND(AVG(ABS(actual_fpts - my_proj)), 2) as your_mae,
        ROUND(AVG(ABS(actual_fpts - sabersim_proj)), 2) as ss_mae,
        ROUND(AVG(ABS(actual_fpts - my_proj)) - AVG(ABS(actual_fpts - sabersim_proj)), 2) as advantage
    FROM contest_results
    WHERE my_proj IS NOT NULL AND sabersim_proj IS NOT NULL
    GROUP BY sport, position
    HAVING n >= 10
    ORDER BY advantage ASC
""").fetchdf()

print("\nYour Advantage by Position (negative = you're better):")
print(by_position.to_string(index=False))

# =============================================================================
# ANALYSIS 3: PLAYERS YOU CONSISTENTLY BEAT SS ON
# =============================================================================

print("\n" + "="*80)
print("PLAYERS YOU PROJECT BETTER THAN SABERSIM")
print("="*80)

better_players = conn.execute("""
    SELECT 
        player_name,
        COUNT(*) as contests,
        ROUND(AVG(actual_fpts), 1) as avg_actual,
        ROUND(AVG(ABS(actual_fpts - my_proj)), 2) as your_mae,
        ROUND(AVG(ABS(actual_fpts - sabersim_proj)), 2) as ss_mae,
        ROUND(AVG(ABS(actual_fpts - sabersim_proj)) - AVG(ABS(actual_fpts - my_proj)), 2) as your_edge
    FROM contest_results
    WHERE my_proj IS NOT NULL AND sabersim_proj IS NOT NULL
    GROUP BY player_name
    HAVING contests >= 3
    ORDER BY your_edge DESC
    LIMIT 20
""").fetchdf()

print("\nTop 20 Players You Project Better:")
print(better_players.to_string(index=False))

# =============================================================================
# ANALYSIS 4: PLAYERS YOU STRUGGLE WITH
# =============================================================================

print("\n" + "="*80)
print("PLAYERS YOU STRUGGLE TO PROJECT")
print("="*80)

struggle_players = conn.execute("""
    SELECT 
        player_name,
        COUNT(*) as contests,
        ROUND(AVG(actual_fpts), 1) as avg_actual,
        ROUND(AVG(ABS(actual_fpts - my_proj)), 2) as your_mae,
        ROUND(AVG(ABS(actual_fpts - sabersim_proj)), 2) as ss_mae,
        ROUND(AVG(ABS(actual_fpts - my_proj)) - AVG(ABS(actual_fpts - sabersim_proj)), 2) as your_deficit
    FROM contest_results
    WHERE my_proj IS NOT NULL AND sabersim_proj IS NOT NULL
    GROUP BY player_name
    HAVING contests >= 3
    ORDER BY your_deficit DESC
    LIMIT 20
""").fetchdf()

print("\nTop 20 Players SaberSim Projects Better:")
print(struggle_players.to_string(index=False))

# =============================================================================
# ANALYSIS 5: OWNERSHIP ACCURACY
# =============================================================================

print("\n" + "="*80)
print("OWNERSHIP PREDICTION ACCURACY")
print("="*80)

# Note: This assumes actual ownership is tracked somewhere
# If not available, skip this section
ownership_check = conn.execute("""
    SELECT COUNT(*) FROM contest_results 
    WHERE my_ownership IS NOT NULL
""").fetchone()[0]

if ownership_check > 0:
    print(f"\nAnalyzing {ownership_check} players with ownership data...")
    
    own_accuracy = conn.execute("""
        SELECT 
            sport,
            COUNT(*) as n,
            ROUND(AVG(my_ownership), 1) as avg_predicted,
            ROUND(AVG(adj_ownership), 1) as avg_adjusted
        FROM contest_results
        WHERE my_ownership IS NOT NULL
        GROUP BY sport
    """).fetchdf()
    
    print("\n" + own_accuracy.to_string(index=False))
else:
    print("\nNo ownership data available")

# =============================================================================
# ANALYSIS 6: VALUE PLAYS YOU MISSED
# =============================================================================

print("\n" + "="*80)
print("VALUE PLAYS YOU UNDERESTIMATED")
print("="*80)

missed_value = conn.execute("""
    SELECT 
        player_name,
        contest_date,
        salary,
        ROUND(actual_fpts, 1) as actual,
        ROUND(my_proj, 1) as my_proj,
        ROUND(actual_fpts - my_proj, 1) as surprise,
        ROUND(actual_fpts / (salary / 1000.0), 2) as actual_value,
        ROUND(my_ownership, 1) as ownership
    FROM contest_results
    WHERE my_proj IS NOT NULL
      AND actual_fpts - my_proj > 15  -- Surprised by 15+ pts
    ORDER BY surprise DESC
    LIMIT 20
""").fetchdf()

print("\nTop 20 Players You Underestimated:")
print(missed_value.to_string(index=False))

print("\n[INSIGHT] These were chalk-busting performances you missed!")
print("  -> Study what these players had in common")

# =============================================================================
# ANALYSIS 7: PROJECTION DISTRIBUTION VALIDATION
# =============================================================================

print("\n" + "="*80)
print("PERCENTILE DISTRIBUTION VALIDATION")
print("="*80)

percentile_check = conn.execute("""
    SELECT 
        sport,
        SUM(CASE WHEN actual_fpts <= dk_25th THEN 1 ELSE 0 END) * 100.0 / COUNT(*) as pct_below_25th,
        SUM(CASE WHEN actual_fpts <= dk_50th THEN 1 ELSE 0 END) * 100.0 / COUNT(*) as pct_below_50th,
        SUM(CASE WHEN actual_fpts <= dk_75th THEN 1 ELSE 0 END) * 100.0 / COUNT(*) as pct_below_75th,
        SUM(CASE WHEN actual_fpts >= dk_75th THEN 1 ELSE 0 END) * 100.0 / COUNT(*) as pct_ceiling
    FROM contest_results
    WHERE dk_25th IS NOT NULL AND dk_50th IS NOT NULL AND dk_75th IS NOT NULL
    GROUP BY sport
""").fetchdf()

print("\nActual Results vs Predicted Percentiles:")
print(percentile_check.to_string(index=False))

print("\n[INSIGHT] If distributions are calibrated:")
print("  - ~25% should be below 25th percentile")
print("  - ~50% should be below 50th percentile")
print("  - ~25% should hit ceiling (>75th percentile)")

# =============================================================================
# ANALYSIS 8: SYSTEMATIC BIASES
# =============================================================================

print("\n" + "="*80)
print("SYSTEMATIC BIASES IN YOUR PROJECTIONS")
print("="*80)

# By salary tier
salary_bias = conn.execute("""
    SELECT 
        CASE 
            WHEN salary >= 9000 THEN 'Elite ($9K+)'
            WHEN salary >= 7000 THEN 'Premium ($7-9K)'
            WHEN salary >= 5500 THEN 'Mid ($5.5-7K)'
            WHEN salary >= 4000 THEN 'Value ($4-5.5K)'
            ELSE 'Punt (<$4K)'
        END as tier,
        COUNT(*) as n,
        ROUND(AVG(my_proj - actual_fpts), 2) as bias,
        ROUND(AVG(ABS(my_proj - actual_fpts)), 2) as mae
    FROM contest_results
    WHERE my_proj IS NOT NULL AND salary IS NOT NULL
    GROUP BY tier
    ORDER BY 
        CASE tier
            WHEN 'Elite ($9K+)' THEN 1
            WHEN 'Premium ($7-9K)' THEN 2
            WHEN 'Mid ($5.5-7K)' THEN 3
            WHEN 'Value ($4-5.5K)' THEN 4
            ELSE 5
        END
""").fetchdf()

print("\nBias by Salary Tier (positive = overproject, negative = underproject):")
print(salary_bias.to_string(index=False))

# By team
team_bias = conn.execute("""
    SELECT 
        team,
        COUNT(*) as n,
        ROUND(AVG(my_proj - actual_fpts), 2) as bias,
        ROUND(AVG(ABS(my_proj - actual_fpts)), 2) as mae
    FROM contest_results
    WHERE my_proj IS NOT NULL AND team IS NOT NULL
    GROUP BY team
    HAVING n >= 20
    ORDER BY ABS(bias) DESC
    LIMIT 10
""").fetchdf()

print("\nTeams with Biggest Projection Bias:")
print(team_bias.to_string(index=False))

# =============================================================================
# SUMMARY & RECOMMENDATIONS
# =============================================================================

print("\n" + "="*80)
print("ACTIONABLE RECOMMENDATIONS")
print("="*80)

# Get overall stats
overall = conn.execute("""
    SELECT 
        ROUND(AVG(ABS(actual_fpts - my_proj)), 2) as your_mae,
        ROUND(AVG(ABS(actual_fpts - sabersim_proj)), 2) as ss_mae,
        ROUND(AVG(my_proj - actual_fpts), 2) as your_bias
    FROM contest_results
    WHERE my_proj IS NOT NULL AND sabersim_proj IS NOT NULL
""").fetchone()

your_mae, ss_mae, your_bias = overall

print(f"\nYour Overall Performance:")
print(f"  MAE: {your_mae:.2f} points")
print(f"  Bias: {your_bias:+.2f} points")

if your_mae < ss_mae:
    diff = ss_mae - your_mae
    print(f"\n✅ YOU'RE BEATING SABERSIM by {diff:.2f} points!")
    print("   Keep doing what you're doing!")
else:
    diff = your_mae - ss_mae
    print(f"\n📊 SaberSim is {diff:.2f} points better")

print("\nKey Actions:")

# Bias correction
if abs(your_bias) > 1:
    if your_bias > 0:
        print(f"  1. You OVERPROJECT by {your_bias:.1f} pts on average")
        print(f"     -> Reduce all projections by ~{your_bias:.1f} points")
    else:
        print(f"  1. You UNDERPROJECT by {abs(your_bias):.1f} pts on average")
        print(f"     -> Increase all projections by ~{abs(your_bias):.1f} points")

# Position focus
best_pos = by_position.iloc[0]
worst_pos = by_position.iloc[-1]
print(f"\n  2. Focus on improving {worst_pos['position']} projections")
print(f"     Current MAE: {worst_pos['your_mae']:.2f} (SS: {worst_pos['ss_mae']:.2f})")

# Player-specific
if len(struggle_players) > 0:
    worst_player = struggle_players.iloc[0]
    print(f"\n  3. Avoid or be conservative with: {worst_player['player_name']}")
    print(f"     Your MAE: {worst_player['your_mae']:.2f} (SS: {worst_player['ss_mae']:.2f})")

conn.close()

print("\n" + "="*80)
print("ANALYSIS COMPLETE!")
print("="*80)

print("\nYou now know:")
print("  ✓ Where you beat SaberSim")
print("  ✓ Where you struggle")
print("  ✓ Your systematic biases")
print("  ✓ Which players to avoid")
print("  ✓ Value plays you're missing")

print("\nApply these insights to improve your edge!")

print("\n" + "="*80)
