#!/usr/bin/env python
"""
DISCOVER_PATTERNS.py

Discovers actionable patterns from historical DFS data.
Uses statistical analysis to find edges in matchups, rest, streaks, etc.
"""

import duckdb
import pandas as pd
import numpy as np
from scipy import stats
from pathlib import Path

print("="*80)
print("PATTERN DISCOVERY ENGINE")
print("="*80)

# Connect to database
DB_PATH = 'data/dfs_warehouse.duckdb'
conn = duckdb.connect(DB_PATH)

# Check data availability
data_check = conn.execute("""
    SELECT 
        COUNT(*) as total_rows,
        COUNT(DISTINCT game_date) as num_dates,
        MIN(game_date) as earliest,
        MAX(game_date) as latest
    FROM historical_results
    WHERE sport = 'NBA'
""").fetchone()

total_rows, num_dates, earliest, latest = data_check

print(f"\nAnalyzing {total_rows:,} performances across {num_dates} dates")
print(f"Date range: {earliest} to {latest}")

if total_rows < 100:
    print("\n[WARNING] Limited data - patterns may not be statistically significant")
    print("Recommendation: Ingest more historical data for better insights")

# =============================================================================
# PATTERN 1: Performance by Team
# =============================================================================

print("\n" + "="*80)
print("PATTERN 1: HIGH-SCORING TEAMS")
print("="*80)

team_scoring = conn.execute("""
    SELECT 
        team,
        COUNT(*) as num_performances,
        AVG(fantasy_points) as avg_team_fpts,
        AVG(salary) as avg_salary,
        AVG(fantasy_points / (salary / 1000.0)) as avg_value
    FROM historical_results
    WHERE sport = 'NBA'
      AND platform = 'FanDuel'
      AND salary IS NOT NULL
      AND team IS NOT NULL
    GROUP BY team
    HAVING num_performances >= 50
    ORDER BY avg_team_fpts DESC
    LIMIT 10
""").fetchdf()

print("\nTop Scoring Teams (FanDuel NBA):")
print(team_scoring.to_string(index=False))

# Statistical significance test
if len(team_scoring) >= 2:
    top_team = team_scoring.iloc[0]['team']
    top_avg = team_scoring.iloc[0]['avg_team_fpts']
    
    # Compare to league average
    league_avg = conn.execute("""
        SELECT AVG(fantasy_points) as avg
        FROM historical_results
        WHERE sport = 'NBA' AND platform = 'FanDuel'
    """).fetchone()[0]
    
    boost = top_avg - league_avg
    print(f"\n[INSIGHT] {top_team} players average {boost:+.1f} pts vs league average")
    print(f"  -> Consider boosting {top_team} projections by {boost:.1f} points")

# =============================================================================
# PATTERN 2: Defensive Matchups
# =============================================================================

print("\n" + "="*80)
print("PATTERN 2: OPPONENT DEFENSIVE IMPACT")
print("="*80)

# Best matchups (teams to target)
best_matchups = conn.execute("""
    SELECT 
        opponent as defense,
        COUNT(*) as num_performances,
        AVG(fantasy_points) as avg_fpts_allowed,
        AVG(salary) as avg_salary,
        AVG(fantasy_points / (salary / 1000.0)) as avg_value
    FROM historical_results
    WHERE sport = 'NBA'
      AND platform = 'FanDuel'
      AND opponent IS NOT NULL
      AND salary IS NOT NULL
    GROUP BY opponent
    HAVING num_performances >= 50
    ORDER BY avg_fpts_allowed DESC
    LIMIT 10
""").fetchdf()

print("\nWorst Defenses (Best Matchups):")
print(best_matchups.to_string(index=False))

# Toughest matchups (teams to avoid)
worst_matchups = conn.execute("""
    SELECT 
        opponent as defense,
        COUNT(*) as num_performances,
        AVG(fantasy_points) as avg_fpts_allowed
    FROM historical_results
    WHERE sport = 'NBA'
      AND platform = 'FanDuel'
      AND opponent IS NOT NULL
      AND salary IS NOT NULL
    GROUP BY opponent
    HAVING num_performances >= 50
    ORDER BY avg_fpts_allowed ASC
    LIMIT 10
""").fetchdf()

print("\nBest Defenses (Tough Matchups):")
print(worst_matchups.to_string(index=False))

# =============================================================================
# PATTERN 3: Position-Specific Matchups
# =============================================================================

print("\n" + "="*80)
print("PATTERN 3: POSITION-SPECIFIC MATCHUPS")
print("="*80)

# Find best matchups for each position
print("\nBest matchups by position:")

for pos in ['PG', 'SG', 'SF', 'PF', 'C']:
    pos_matchup = conn.execute(f"""
        SELECT 
            opponent,
            COUNT(*) as games,
            AVG(fantasy_points) as avg_fpts
        FROM historical_results
        WHERE sport = 'NBA'
          AND platform = 'FanDuel'
          AND position = '{pos}'
          AND opponent IS NOT NULL
        GROUP BY opponent
        HAVING games >= 20
        ORDER BY avg_fpts DESC
        LIMIT 3
    """).fetchdf()
    
    if len(pos_matchup) > 0:
        print(f"\n{pos} vs:")
        for _, row in pos_matchup.iterrows():
            print(f"  {row['opponent']:3} - {row['avg_fpts']:.1f} pts (n={int(row['games'])})")

# =============================================================================
# PATTERN 4: Salary Tier Efficiency
# =============================================================================

print("\n" + "="*80)
print("PATTERN 4: SALARY EFFICIENCY BY TIER")
print("="*80)

efficiency = conn.execute("""
    SELECT 
        CASE 
            WHEN salary >= 9000 THEN '$9K+'
            WHEN salary >= 8000 THEN '$8-9K'
            WHEN salary >= 7000 THEN '$7-8K'
            WHEN salary >= 6000 THEN '$6-7K'
            WHEN salary >= 5000 THEN '$5-6K'
            WHEN salary >= 4000 THEN '$4-5K'
            ELSE '<$4K'
        END as tier,
        COUNT(*) as num_performances,
        AVG(fantasy_points) as avg_fpts,
        AVG(fantasy_points / (salary / 1000.0)) as value,
        STDDEV(fantasy_points) as volatility
    FROM historical_results
    WHERE sport = 'NBA'
      AND platform = 'FanDuel'
      AND salary IS NOT NULL
    GROUP BY tier
    ORDER BY value DESC
""").fetchdf()

print("\nValue by Salary Tier:")
print(efficiency.to_string(index=False))

# Find the sweet spot
best_tier = efficiency.iloc[0]
print(f"\n[INSIGHT] Best value tier: {best_tier['tier']}")
print(f"  - {best_tier['value']:.2f} points per $1K")
print(f"  -> Focus lineup construction in this salary range")

# =============================================================================
# PATTERN 5: Consistency Streaks
# =============================================================================

print("\n" + "="*80)
print("PATTERN 5: MOST CONSISTENT PERFORMERS")
print("="*80)

consistency = conn.execute("""
    WITH player_games AS (
        SELECT 
            player_name,
            COUNT(*) as games,
            AVG(fantasy_points) as avg_fpts,
            STDDEV(fantasy_points) as std_dev,
            MIN(fantasy_points) as min_fpts,
            MAX(fantasy_points) as max_fpts
        FROM historical_results
        WHERE sport = 'NBA'
          AND platform = 'FanDuel'
          AND salary >= 6000
        GROUP BY player_name
        HAVING games >= 15
    )
    SELECT 
        player_name,
        games,
        ROUND(avg_fpts, 1) as avg_fpts,
        ROUND(std_dev, 1) as std_dev,
        ROUND((std_dev / avg_fpts) * 100, 1) as cv_pct,
        ROUND(min_fpts, 1) as min_fpts,
        ROUND(max_fpts, 1) as max_fpts
    FROM player_games
    WHERE avg_fpts >= 30
    ORDER BY cv_pct ASC
    LIMIT 15
""").fetchdf()

print("\nMost Consistent High Performers (Low CV = Less Volatile):")
print(consistency.to_string(index=False))

print("\n[INSIGHT] These players have the highest floor")
print("  -> Great for cash games and core GPP builds")

# =============================================================================
# PATTERN 6: Ceiling Plays
# =============================================================================

print("\n" + "="*80)
print("PATTERN 6: HIGHEST CEILING PLAYS")
print("="*80)

ceiling = conn.execute("""
    WITH player_games AS (
        SELECT 
            player_name,
            COUNT(*) as games,
            AVG(fantasy_points) as avg_fpts,
            MAX(fantasy_points) as max_fpts,
            PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY fantasy_points) as p90_fpts
        FROM historical_results
        WHERE sport = 'NBA'
          AND platform = 'FanDuel'
          AND salary >= 6000
        GROUP BY player_name
        HAVING games >= 10
    )
    SELECT 
        player_name,
        games,
        ROUND(avg_fpts, 1) as avg_fpts,
        ROUND(p90_fpts, 1) as p90_fpts,
        ROUND(max_fpts, 1) as max_fpts,
        ROUND(max_fpts - avg_fpts, 1) as ceiling_boost
    FROM player_games
    ORDER BY max_fpts DESC
    LIMIT 15
""").fetchdf()

print("\nHighest Ceiling Performers:")
print(ceiling.to_string(index=False))

print("\n[INSIGHT] These players can win you tournaments")
print("  -> Use in GPP builds when you need upside")

# =============================================================================
# SAVE PATTERNS TO DATABASE
# =============================================================================

print("\n" + "="*80)
print("SAVING DISCOVERED PATTERNS")
print("="*80)

# Clear old patterns
conn.execute("DELETE FROM discovered_patterns")

# Example: Save top team pattern
if len(team_scoring) > 0:
    top_team = team_scoring.iloc[0]
    
    conn.execute("""
        INSERT INTO discovered_patterns VALUES (
            NULL,
            ?,
            'team_scoring',
            ?,
            ?,
            ?,
            'HIGH',
            NULL,
            NULL,
            ?,
            CURRENT_TIMESTAMP,
            'NBA',
            'FanDuel'
        )
    """, [
        f"{top_team['team']} High Scoring Team",
        f"Players on {top_team['team']} average {top_team['avg_team_fpts']:.1f} FD points",
        top_team['avg_team_fpts'] - league_avg,
        int(top_team['num_performances']),
        f"Boost {top_team['team']} player projections by {(top_team['avg_team_fpts'] - league_avg):.1f} points"
    ])

print("\n[OK] Patterns saved to database")

# =============================================================================
# EXPORT PATTERNS
# =============================================================================

# Create patterns summary file
output_dir = Path('outputs/insights')
output_dir.mkdir(parents=True, exist_ok=True)

patterns_file = output_dir / 'discovered_patterns.txt'

with open(patterns_file, 'w') as f:
    f.write("="*80 + "\n")
    f.write("DISCOVERED PATTERNS - ACTIONABLE INSIGHTS\n")
    f.write("="*80 + "\n\n")
    
    f.write("TOP SCORING TEAMS:\n")
    f.write("-" * 40 + "\n")
    f.write(team_scoring.to_string(index=False))
    f.write("\n\n")
    
    f.write("BEST MATCHUPS (Target These Defenses):\n")
    f.write("-" * 40 + "\n")
    f.write(best_matchups.to_string(index=False))
    f.write("\n\n")
    
    f.write("MOST CONSISTENT PLAYERS:\n")
    f.write("-" * 40 + "\n")
    f.write(consistency.to_string(index=False))
    f.write("\n\n")
    
    f.write("HIGHEST CEILING PLAYS:\n")
    f.write("-" * 40 + "\n")
    f.write(ceiling.to_string(index=False))
    f.write("\n")

print(f"\n[OK] Patterns exported to: {patterns_file}")

# Close connection
conn.close()

print("\n" + "="*80)
print("PATTERN DISCOVERY COMPLETE!")
print("="*80)

print("\nNext steps:")
print("  1. Review insights in outputs/insights/discovered_patterns.txt")
print("  2. Apply boosts to your projection system")
print("  3. Track results to validate patterns")

print("\n" + "="*80)
