#!/usr/bin/env bash
# scripts/deploy_validate.sh
# ============================================================
# Full deployment validation sequence.
#
# Runs:
#   1. wait_for_services.sh  — wait for postgres + redis
#   2. alembic upgrade head  — apply migrations
#   3. verify_pipeline.py    — end-to-end pipeline smoke test
#   4. health checks         — verify all critical endpoints
#
# Exit codes:
#   0 — all steps passed
#   1 — at least one step failed
#
# Environment variables:
#   BASE_URL                Defaults to http://localhost:8000
#   ALEMBIC_DIR             Defaults to ./backend
#   SKIP_WAIT               Set to "true" to skip wait_for_services.sh
#   SKIP_MIGRATION          Set to "true" to skip alembic migration
#   VERIFY_TIMEOUT          Timeout for verify_pipeline.py (default 120)
# ============================================================

set -euo pipefail

BASE_URL="${BASE_URL:-http://localhost:8000}"
ALEMBIC_DIR="${ALEMBIC_DIR:-./backend}"
SKIP_WAIT="${SKIP_WAIT:-false}"
SKIP_MIGRATION="${SKIP_MIGRATION:-false}"
VERIFY_TIMEOUT="${VERIFY_TIMEOUT:-120}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

RED='\033[0;31m'
GRN='\033[0;32m'
YLW='\033[0;33m'
NC='\033[0m'

STEPS_PASSED=0
STEPS_FAILED=0

pass() { echo -e "${GRN}✓ $*${NC}"; STEPS_PASSED=$((STEPS_PASSED+1)); }
fail() { echo -e "${RED}✗ $*${NC}"; STEPS_FAILED=$((STEPS_FAILED+1)); }
hdr()  { echo -e "\n${YLW}── $* ──${NC}"; }

# ─────────────────────────────────────────────────────────────
# Step 1: Service readiness
# ─────────────────────────────────────────────────────────────
hdr "Step 1 — Service readiness"
if [ "$SKIP_WAIT" = "true" ]; then
    echo "  Skipped (SKIP_WAIT=true)"
    STEPS_PASSED=$((STEPS_PASSED+1))
elif [ -f "$SCRIPT_DIR/wait_for_services.sh" ]; then
    if bash "$SCRIPT_DIR/wait_for_services.sh"; then
        pass "All services ready"
    else
        fail "Services not ready (postgres/redis)"
    fi
else
    echo "  wait_for_services.sh not found — skipping"
    STEPS_PASSED=$((STEPS_PASSED+1))
fi

# ─────────────────────────────────────────────────────────────
# Step 2: Alembic migration
# ─────────────────────────────────────────────────────────────
hdr "Step 2 — Alembic migration"
if [ "$SKIP_MIGRATION" = "true" ]; then
    echo "  Skipped (SKIP_MIGRATION=true)"
    STEPS_PASSED=$((STEPS_PASSED+1))
else
    cd "$ALEMBIC_DIR"
    if python -m alembic upgrade head 2>&1; then
        pass "alembic upgrade head succeeded"
    else
        fail "alembic upgrade head failed"
    fi
    cd "$ROOT_DIR"
fi

# ─────────────────────────────────────────────────────────────
# Step 3: Pipeline smoke test
# ─────────────────────────────────────────────────────────────
hdr "Step 3 — Pipeline smoke test (verify_pipeline.py)"
if python "$SCRIPT_DIR/verify_pipeline.py" \
       --base-url "$BASE_URL" \
       --timeout "$VERIFY_TIMEOUT"; then
    pass "verify_pipeline.py passed"
else
    fail "verify_pipeline.py FAILED"
fi

# ─────────────────────────────────────────────────────────────
# Step 4: Endpoint health checks
# ─────────────────────────────────────────────────────────────
hdr "Step 4 — Endpoint health checks"

_check_endpoint() {
    local url="$1"
    local label="$2"
    local expected_status="${3:-200}"
    local http_code
    http_code=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 "$url" 2>/dev/null || echo "000")
    if [ "$http_code" = "$expected_status" ]; then
        pass "$label → HTTP $http_code"
    else
        fail "$label → HTTP $http_code (expected $expected_status)"
    fi
}

_check_endpoint "$BASE_URL/api/health"          "GET /api/health"
_check_endpoint "$BASE_URL/api/health/db"        "GET /api/health/db"
_check_endpoint "$BASE_URL/api/health/metrics"   "GET /api/health/metrics"
_check_endpoint "$BASE_URL/api/metrics"          "GET /api/metrics"
_check_endpoint "$BASE_URL/api/openapi.json"     "GET /api/openapi.json"
_check_endpoint "$BASE_URL/api/docs"             "GET /api/docs"

# ─────────────────────────────────────────────────────────────
# Summary
# ─────────────────────────────────────────────────────────────
echo ""
echo "════════════════════════════════════════════════"
echo "  DEPLOYMENT VALIDATION SUMMARY"
echo "  Passed: $STEPS_PASSED"
echo "  Failed: $STEPS_FAILED"
echo "════════════════════════════════════════════════"

if [ "$STEPS_FAILED" -eq 0 ]; then
    echo -e "${GRN}  ✓  DEPLOYMENT VALIDATED SUCCESSFULLY${NC}"
    exit 0
else
    echo -e "${RED}  ✗  $STEPS_FAILED step(s) failed — DO NOT promote to production${NC}"
    exit 1
fi
