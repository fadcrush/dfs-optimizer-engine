# Scripts Directory

Utility and maintenance scripts for the DFS projection system.

## Running Scripts

All scripts should be run from the repository root:

```bash
python scripts/<script_name>.py [arguments]
```

## Directory Structure

### Root-Level Scripts

| Script | Purpose |
|--------|---------|
| `setup_database.py` | Initialize DuckDB database |
| `setup_database_fixed.py` | Database setup with fixes |
| `run_automation.py` | Run full automation workflow |
| `run_backtest.py` | Run backtesting analysis |
| `run_dashboard.py` | Launch Streamlit dashboard |
| `run_late_swap.py` | Late swap assistant |
| `query_library.py` | Database query utilities |
| `nba_lineup_optimizer_with_database.py` | Standalone lineup optimizer |
| `nba_stats_api.py` | NBA stats API client |
| `odds_api.py` | Odds API client |

### Data Ingestion

| Script | Purpose |
|--------|---------|
| `INGEST_HISTORICAL_DATA.py` | Import historical game data |
| `INGEST_HISTORICAL_DATA_UPDATED.py` | Updated historical import |
| `INGEST_CONTEST_RESULTS.py` | Import contest results |
| `INGEST_CONTEST_RESULTS_FIXED.py` | Fixed contest import |
| `LOG_SLATE_RESULTS.py` | Log slate results to database |

### Analysis

| Script | Purpose |
|--------|---------|
| `ANALYZE_PROJECTION_ACCURACY.py` | Measure projection accuracy |
| `ANALYZE_CONTEST_RESULTS.py` | Analyze contest performance |
| `DISCOVER_PATTERNS.py` | Find patterns in historical data |

### Maintenance

| Script | Purpose |
|--------|---------|
| `DEBUG_OPTIMIZER.py` | Debug optimizer issues |
| `FIX_DASHBOARD_PATHS.py` | Fix dashboard file paths |
| `QUICK_FIX_SCANNER.py` | Scan for common issues |

### Numbered Pipeline Scripts

Run in sequence for initial setup:

```bash
python scripts/01_setup_database.py
python scripts/02_run_audit.py
python scripts/03_run_etl.py
python scripts/04_generate_features.py
```

## Subdirectories

| Directory | Contents |
|-----------|----------|
| `analysis/` | Backtest, ownership, and pattern analyzers |
| `automation/` | Automated workflow scripts |
| `detection/` | Injury detection and parsing |
| `gameday/` | Live game tools and late swap |
| `maintenance/` | Database maintenance utilities |
| `nfl/` | NFL-specific scripts |
| `optimization/` | Lineup optimization utilities |
| `projections/` | Projection generation scripts |
| `utilities/` | General helper scripts |
