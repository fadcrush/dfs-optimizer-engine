#!/usr/bin/env python
"""
QUICK_FIX_SCANNER.py

Quick fix for auto_injury_scanner.py Unicode encoding issue.
Replaces the problematic ≥ character with >=
"""

from pathlib import Path

print("="*80)
print("FIXING AUTO_INJURY_SCANNER.PY")
print("="*80)

scanner_path = Path('scripts/detection/auto_injury_scanner.py')

if not scanner_path.exists():
    print(f"\nERROR: File not found: {scanner_path}")
    print("Make sure you're in the project root directory")
    exit(1)

print(f"\nReading: {scanner_path}")

# Read the file
with open(scanner_path, 'r', encoding='utf-8') as f:
    content = f.read()

# Replace problematic characters
replacements = {
    '\u2265': '>=',  # ≥ symbol
    '≥': '>=',
    '≤': '<=',
    '→': '->',
    '←': '<-',
}

original = content
for unicode_char, ascii_char in replacements.items():
    content = content.replace(unicode_char, ascii_char)

# Write back
with open(scanner_path, 'w', encoding='utf-8') as f:
    f.write(content)

if content != original:
    print("  -> Fixed Unicode characters")
else:
    print("  -> No changes needed")

print("\n" + "="*80)
print("COMPLETE!")
print("="*80)

print("\nThe auto_injury_scanner.py file has been fixed.")
print("Now try running your automation again:")
print('  python run_automation.py "slates\\nba\\YOUR_SLATE.csv" --num-lineups 150')

print("\n" + "="*80)
