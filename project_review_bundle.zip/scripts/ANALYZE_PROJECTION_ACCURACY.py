#!/usr/bin/env python
"""
ANALYZE_PROJECTION_ACCURACY.py

Analyzes projection accuracy using historical data.
Identifies systematic biases and areas for improvement.
"""

import duckdb
import pandas as pd
import numpy as np
from pathlib import Path
from scipy import stats
import matplotlib.pyplot as plt

print("="*80)
print("PROJECTION ACCURACY ANALYZER")
print("="*80)

# Connect to database
DB_PATH = 'data/dfs_warehouse.duckdb'
conn = duckdb.connect(DB_PATH)

# Check if we have projection tracking data
has_tracking = conn.execute("""
    SELECT COUNT(*) as count FROM projection_tracking
""").fetchone()[0]

if has_tracking == 0:
    print("\n[WARNING] No projection tracking data found!")
    print("This analysis requires you to log your projections vs actual results.")
    print("\nFor now, we'll analyze historical data patterns...")
    use_tracking = False
else:
    print(f"\nFound {has_tracking:,} tracked projections")
    use_tracking = True

# =============================================================================
# ANALYSIS 1: Overall Projection Accuracy (if tracking exists)
# =============================================================================

if use_tracking:
    print("\n" + "="*80)
    print("OVERALL PROJECTION ACCURACY")
    print("="*80)
    
    accuracy = conn.execute("""
        SELECT 
            platform,
            sport,
            COUNT(*) as num_projections,
            AVG(your_abs_error) as mae,
            SQRT(AVG(your_error * your_error)) as rmse,
            CORR(your_projection, actual_points) as correlation,
            AVG(your_error) as bias,
            STDDEV(your_error) as std_error
        FROM projection_tracking
        GROUP BY platform, sport
    """).fetchdf()
    
    print("\n" + accuracy.to_string(index=False))
    
    # Calculate R²
    for idx, row in accuracy.iterrows():
        r = row['correlation']
        r_squared = r ** 2 if pd.notna(r) else None
        print(f"\n{row['platform']} {row['sport']} R²: {r_squared:.3f}")

# =============================================================================
# ANALYSIS 2: Accuracy by Player
# =============================================================================

if use_tracking:
    print("\n" + "="*80)
    print("ACCURACY BY PLAYER (Top 20 Most Projected)")
    print("="*80)
    
    by_player = conn.execute("""
        SELECT 
            player_name,
            platform,
            COUNT(*) as times_projected,
            AVG(actual_points) as avg_actual,
            AVG(your_projection) as avg_projected,
            AVG(your_abs_error) as mae,
            AVG(your_error) as bias
        FROM projection_tracking
        GROUP BY player_name, platform
        HAVING times_projected >= 5
        ORDER BY times_projected DESC
        LIMIT 20
    """).fetchdf()
    
    print("\n" + by_player.to_string(index=False))
    
    # Find worst projections
    print("\n" + "="*80)
    print("WORST PROJECTIONS (Highest MAE)")
    print("="*80)
    
    worst = conn.execute("""
        SELECT 
            player_name,
            platform,
            COUNT(*) as times_projected,
            AVG(your_abs_error) as mae,
            AVG(your_error) as bias
        FROM projection_tracking
        GROUP BY player_name, platform
        HAVING times_projected >= 5
        ORDER BY mae DESC
        LIMIT 10
    """).fetchdf()
    
    print("\n" + worst.to_string(index=False))

# =============================================================================
# ANALYSIS 3: Historical Performance Patterns
# =============================================================================

print("\n" + "="*80)
print("HISTORICAL PERFORMANCE PATTERNS")
print("="*80)

# NBA patterns
print("\nNBA Analysis:")
print("-" * 40)

nba_stats = conn.execute("""
    SELECT 
        platform,
        COUNT(DISTINCT player_name) as unique_players,
        COUNT(DISTINCT game_date) as unique_dates,
        COUNT(*) as total_performances,
        AVG(fantasy_points) as avg_fpts,
        STDDEV(fantasy_points) as std_fpts,
        MIN(game_date) as earliest,
        MAX(game_date) as latest
    FROM historical_results
    WHERE sport = 'NBA'
    GROUP BY platform
""").fetchdf()

print(nba_stats.to_string(index=False))

# NFL patterns
print("\nNFL Analysis:")
print("-" * 40)

nfl_stats = conn.execute("""
    SELECT 
        platform,
        COUNT(DISTINCT player_name) as unique_players,
        COUNT(DISTINCT game_date) as unique_dates,
        COUNT(*) as total_performances,
        AVG(fantasy_points) as avg_fpts,
        STDDEV(fantasy_points) as std_fpts,
        MIN(game_date) as earliest,
        MAX(game_date) as latest
    FROM historical_results
    WHERE sport = 'NFL'
    GROUP BY platform
""").fetchdf()

if len(nfl_stats) > 0:
    print(nfl_stats.to_string(index=False))
else:
    print("No NFL data found")

# =============================================================================
# ANALYSIS 4: Salary Tier Analysis
# =============================================================================

print("\n" + "="*80)
print("PERFORMANCE BY SALARY TIER (NBA)")
print("="*80)

salary_tiers = conn.execute("""
    SELECT 
        platform,
        CASE 
            WHEN salary >= 9000 THEN 'Elite ($9K+)'
            WHEN salary >= 7000 THEN 'Premium ($7-9K)'
            WHEN salary >= 5500 THEN 'Mid ($5.5-7K)'
            WHEN salary >= 4000 THEN 'Value ($4-5.5K)'
            ELSE 'Punt (<$4K)'
        END as salary_tier,
        COUNT(*) as num_performances,
        AVG(fantasy_points) as avg_fpts,
        AVG(fantasy_points / (salary / 1000.0)) as avg_value,
        STDDEV(fantasy_points) as volatility
    FROM historical_results
    WHERE sport = 'NBA' AND salary IS NOT NULL
    GROUP BY platform, salary_tier
    ORDER BY platform, 
             CASE salary_tier
                 WHEN 'Elite ($9K+)' THEN 1
                 WHEN 'Premium ($7-9K)' THEN 2
                 WHEN 'Mid ($5.5-7K)' THEN 3
                 WHEN 'Value ($4-5.5K)' THEN 4
                 ELSE 5
             END
""").fetchdf()

print("\n" + salary_tiers.to_string(index=False))

# =============================================================================
# ANALYSIS 5: Top Performers by Position
# =============================================================================

print("\n" + "="*80)
print("TOP PERFORMERS BY POSITION (NBA, FanDuel)")
print("="*80)

top_by_pos = conn.execute("""
    WITH avg_by_player AS (
        SELECT 
            player_name,
            position,
            COUNT(*) as games,
            AVG(fantasy_points) as avg_fpts,
            AVG(salary) as avg_salary
        FROM historical_results
        WHERE sport = 'NBA' 
          AND platform = 'FanDuel'
          AND position IS NOT NULL
          AND salary IS NOT NULL
        GROUP BY player_name, position
        HAVING games >= 10
    )
    SELECT 
        position,
        player_name,
        games,
        ROUND(avg_fpts, 1) as avg_fpts,
        ROUND(avg_salary, 0) as avg_salary,
        ROUND(avg_fpts / (avg_salary / 1000.0), 2) as value
    FROM avg_by_player
    WHERE position IN ('PG', 'SG', 'SF', 'PF', 'C')
    QUALIFY ROW_NUMBER() OVER (PARTITION BY position ORDER BY avg_fpts DESC) <= 5
    ORDER BY position, avg_fpts DESC
""").fetchdf()

print("\n" + top_by_pos.to_string(index=False))

# =============================================================================
# ANALYSIS 6: Consistency Analysis
# =============================================================================

print("\n" + "="*80)
print("CONSISTENCY ANALYSIS (Coefficient of Variation)")
print("="*80)

consistency = conn.execute("""
    WITH player_stats AS (
        SELECT 
            player_name,
            COUNT(*) as games,
            AVG(fantasy_points) as avg_fpts,
            STDDEV(fantasy_points) as std_fpts
        FROM historical_results
        WHERE sport = 'NBA' 
          AND platform = 'FanDuel'
          AND salary >= 6000  -- Focus on playable salary range
        GROUP BY player_name
        HAVING games >= 15
    )
    SELECT 
        player_name,
        games,
        ROUND(avg_fpts, 1) as avg_fpts,
        ROUND(std_fpts, 1) as std_fpts,
        ROUND((std_fpts / avg_fpts) * 100, 1) as cv_pct
    FROM player_stats
    WHERE avg_fpts >= 25  -- Focus on productive players
    ORDER BY cv_pct ASC
    LIMIT 20
""").fetchdf()

print("\nMost Consistent Players (Low CV = More Predictable):")
print(consistency.to_string(index=False))

# =============================================================================
# ANALYSIS 7: Value Finder
# =============================================================================

print("\n" + "="*80)
print("BEST VALUE PLAYS (Historical)")
print("="*80)

value_plays = conn.execute("""
    WITH player_avg AS (
        SELECT 
            player_name,
            position,
            COUNT(*) as games,
            AVG(fantasy_points) as avg_fpts,
            AVG(salary) as avg_salary,
            AVG(fantasy_points / (salary / 1000.0)) as avg_value
        FROM historical_results
        WHERE sport = 'NBA'
          AND platform = 'FanDuel'
          AND salary IS NOT NULL
          AND position IS NOT NULL
        GROUP BY player_name, position
        HAVING games >= 10
    )
    SELECT 
        player_name,
        position,
        games,
        ROUND(avg_fpts, 1) as avg_fpts,
        ROUND(avg_salary, 0) as avg_salary,
        ROUND(avg_value, 2) as pts_per_1K
    FROM player_avg
    WHERE avg_salary <= 7000  -- Focus on value tier
    ORDER BY avg_value DESC
    LIMIT 20
""").fetchdf()

print("\n" + value_plays.to_string(index=False))

# =============================================================================
# SUMMARY & RECOMMENDATIONS
# =============================================================================

print("\n" + "="*80)
print("RECOMMENDATIONS")
print("="*80)

if use_tracking:
    # Get overall stats
    overall = conn.execute("""
        SELECT 
            AVG(your_abs_error) as mae,
            AVG(your_error) as bias
        FROM projection_tracking
        WHERE sport = 'NBA'
    """).fetchone()
    
    mae, bias = overall
    
    print(f"\nYour NBA projection accuracy:")
    print(f"  - MAE: {mae:.2f} points")
    print(f"  - Bias: {bias:+.2f} points", end='')
    
    if bias > 1:
        print(" (You tend to OVERPROJECT)")
        print("    -> Consider reducing projections by ~2 points across the board")
    elif bias < -1:
        print(" (You tend to UNDERPROJECT)")
        print("    -> Consider increasing projections by ~2 points across the board")
    else:
        print(" (Well calibrated!)")
    
    # Get worst players
    worst_player = conn.execute("""
        SELECT player_name, AVG(your_abs_error) as mae
        FROM projection_tracking
        GROUP BY player_name
        HAVING COUNT(*) >= 5
        ORDER BY mae DESC
        LIMIT 1
    """).fetchone()
    
    if worst_player:
        player, player_mae = worst_player
        print(f"\nWorst projection: {player} (MAE: {player_mae:.1f} points)")
        print(f"    -> Consider avoiding or using conservative projections")

else:
    print("\nTo enable projection accuracy tracking:")
    print("  1. After each slate, run: python log_results.py")
    print("  2. This will compare your projections to actual results")
    print("  3. After 20+ slates, patterns will emerge")

print("\n" + "="*80)
print("ANALYSIS COMPLETE!")
print("="*80)

print("\nHistorical data ready for:")
print("  - Pattern discovery (python discover_patterns.py)")
print("  - Backtesting strategies (python backtest_strategy.py)")
print("  - Custom queries in DuckDB")

# Close connection
conn.close()

print("\n" + "="*80)
