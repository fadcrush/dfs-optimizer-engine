#!/usr/bin/env python
"""
INGEST_CONTEST_RESULTS_FIXED.py

Fixed version with explicit column handling.
"""

import duckdb
import pandas as pd
from pathlib import Path
import re

print("="*80)
print("CONTEST RESULTS INGESTION - FIXED VERSION")
print("="*80)

DB_PATH = 'data/dfs_warehouse.duckdb'
conn = duckdb.connect(DB_PATH)

# Create simpler schema
print("\nCreating schema...")

conn.execute("DROP TABLE IF EXISTS contest_results")

conn.execute("""
CREATE TABLE contest_results (
    dfs_id VARCHAR,
    player_name VARCHAR,
    position VARCHAR,
    team VARCHAR,
    opponent VARCHAR,
    salary INTEGER,
    
    contest_date DATE,
    platform VARCHAR,
    sport VARCHAR,
    
    actual_fpts FLOAT,
    my_proj FLOAT,
    sabersim_proj FLOAT,
    
    my_ownership FLOAT,
    
    source_file VARCHAR
)
""")

print("  [OK] Schema created")

def ingest_contest_file(file_path, platform, sport):
    """Ingest contest file with explicit column selection"""
    
    print(f"\n  {file_path.name}...", end=' ')
    
    try:
        # Read file
        if file_path.suffix == '.xlsx':
            df = pd.read_excel(file_path)
        else:
            df = pd.read_csv(file_path)
        
        # Check if this is contest results (has Actual column)
        if 'Actual' not in df.columns and 'actual fantasy points' not in df.columns:
            print("SKIP (no actual results)")
            return 0
        
        # Extract date from filename
        date_match = re.search(r'(\d{4}-\d{2}-\d{2})', file_path.name)
        contest_date = date_match.group(1) if date_match else None
        
        # Create simple DataFrame with only columns we need
        result = pd.DataFrame()
        
        result['dfs_id'] = df.get('DFS ID', None)
        result['player_name'] = df.get('Name', None)
        result['position'] = df.get('Pos', None)
        result['team'] = df.get('Team', None)
        result['opponent'] = df.get('Opp', None)
        result['salary'] = df.get('Salary', None)
        
        result['contest_date'] = contest_date
        result['platform'] = platform
        result['sport'] = sport
        
        # Get actual points
        result['actual_fpts'] = df.get('Actual', df.get('actual fantasy points', None))
        
        # Get projections
        result['my_proj'] = df.get('My Proj', df.get('Fantasy projections', None))
        result['sabersim_proj'] = df.get('SS Proj', df.get('sabersim Fantasy projections', None))
        
        # Get ownership
        result['my_ownership'] = df.get('My Own', df.get('Ownership', None))
        
        result['source_file'] = file_path.name
        
        # Filter to only rows with actual points
        result = result[result['actual_fpts'].notna()]
        result = result[result['player_name'].notna()]
        
        if len(result) == 0:
            print("SKIP (no valid data)")
            return 0
        
        # Insert
        conn.execute("INSERT INTO contest_results SELECT * FROM result")
        
        print(f"OK ({len(result)} players)")
        return len(result)
        
    except Exception as e:
        print(f"ERROR: {str(e)[:60]}")
        return 0

# Find files
print("\n" + "="*80)
print("SEARCHING FOR CONTEST FILES")
print("="*80)

contest_files = []

# Search in data directories
for dir_name in ['DK_NBA_Past_Games', 'DK_NFL_Past_Games', 
                  'FD_NBA_Past_Games', 'FD_NFL_Past_Games']:
    dir_path = Path(dir_name)
    if dir_path.exists():
        for file_path in dir_path.glob('*.csv'):
            contest_files.append(file_path)
        for file_path in dir_path.glob('*.xlsx'):
            contest_files.append(file_path)

print(f"\nFound {len(contest_files)} potential contest files")

# Ingest
print("\n" + "="*80)
print("INGESTING")
print("="*80)

total = 0
success = 0

nba_dk = []
nba_fd = []
nfl_dk = []
nfl_fd = []

for file_path in contest_files:
    name_upper = file_path.name.upper()
    
    # Determine sport and platform
    if 'NBA' in name_upper:
        sport = 'NBA'
        if 'DK' in name_upper or file_path.parent.name.startswith('DK'):
            platform = 'DraftKings'
            nba_dk.append(file_path)
        else:
            platform = 'FanDuel'
            nba_fd.append(file_path)
    elif 'NFL' in name_upper:
        sport = 'NFL'
        if 'DK' in name_upper or file_path.parent.name.startswith('DK'):
            platform = 'DraftKings'
            nfl_dk.append(file_path)
        else:
            platform = 'FanDuel'
            nfl_fd.append(file_path)
    else:
        continue

# Process each category
for category, files in [('NBA DK', nba_dk), ('NBA FD', nba_fd), 
                         ('NFL DK', nfl_dk), ('NFL FD', nfl_fd)]:
    if not files:
        continue
    
    print(f"\n{category}")
    print("-" * 40)
    
    sport, platform = category.split()
    if platform == 'DK':
        platform = 'DraftKings'
    else:
        platform = 'FanDuel'
    
    for file_path in files[:20]:  # Limit to first 20 per category for testing
        rows = ingest_contest_file(file_path, platform, sport)
        if rows > 0:
            total += rows
            success += 1

# Summary
print("\n" + "="*80)
print("INGESTION COMPLETE!")
print("="*80)

print(f"\nTotal players: {total:,}")
print(f"Successful files: {success}")

if total > 0:
    summary = conn.execute("""
        SELECT 
            platform,
            sport,
            COUNT(*) as players,
            COUNT(DISTINCT player_name) as unique_players,
            COUNT(DISTINCT contest_date) as dates,
            ROUND(AVG(actual_fpts), 1) as avg_actual,
            ROUND(AVG(my_proj), 1) as avg_my_proj,
            ROUND(AVG(sabersim_proj), 1) as avg_ss_proj
        FROM contest_results
        WHERE my_proj IS NOT NULL AND sabersim_proj IS NOT NULL
        GROUP BY platform, sport
    """).fetchdf()
    
    print("\n" + summary.to_string(index=False))
    
    # Quick accuracy check
    print("\n" + "="*80)
    print("QUICK ACCURACY CHECK")
    print("="*80)
    
    accuracy = conn.execute("""
        SELECT 
            sport,
            ROUND(AVG(ABS(actual_fpts - my_proj)), 2) as your_mae,
            ROUND(AVG(ABS(actual_fpts - sabersim_proj)), 2) as ss_mae
        FROM contest_results
        WHERE my_proj IS NOT NULL AND sabersim_proj IS NOT NULL
        GROUP BY sport
    """).fetchdf()
    
    print("\n" + accuracy.to_string(index=False))
    
    for _, row in accuracy.iterrows():
        if row['your_mae'] < row['ss_mae']:
            diff = row['ss_mae'] - row['your_mae']
            print(f"\n🎉 {row['sport']}: YOU BEAT SABERSIM by {diff:.2f} points!")
        else:
            diff = row['your_mae'] - row['ss_mae']
            print(f"\n📊 {row['sport']}: SaberSim ahead by {diff:.2f} points")

conn.close()

print("\n" + "="*80)
print("READY FOR ANALYSIS!")
print("="*80)

print("\nRun: python ANALYZE_CONTEST_RESULTS.py")

print("\n" + "="*80)
