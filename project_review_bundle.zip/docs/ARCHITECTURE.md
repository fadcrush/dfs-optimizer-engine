# DFS Edge Pro — Architecture

## System Overview

DFS Edge Pro is a database-first SaaS optimizer for Daily Fantasy Sports.
The core invariant is:

> **Files are ingestion-only. The optimizer runtime reads exclusively from the database.**

---

## Request Flow

```
Upload CSV  →  /projections/upload-slate-to-db
                    │
                    ▼
             projection_ingestion.py
             writes: Slate, Player, Projection rows
                    │
                    ▼
Upload Ownership  →  /ownership/upload-to-db?slate_id=...
                    │
                    ▼
             ownership_ingestion.py
             writes: OwnershipData rows
             mirrors ownership_pct → Projection.ownership_pct
                    │
                    ▼
POST /runs (slate_id, params)
                    │
                    ├── async_mode=true  ──▶  Dramatiq task → Redis queue
                    │                              │
                    └── async_mode=false ──────────┤
                                                   │
                                          run_optimizer_task()
                                                   │
                                         player_pool_loader.py
                                         loads Player+Projection from DB
                                                   │
                                         optimizer_service.py
                                         LP solver (PuLP/CBC)
                                                   │
                                         run_service.persist_lineups()
                                         writes: Lineup, LineupEntry rows
                                                   │
                                                   ▼
GET /results/{run_id}/lineups  ←——  DB query
GET /results/{run_id}/exposure ←——  DB aggregation
```

---

## Database Schema

Seven tables constitute the DFS SaaS schema (all share `DFSBase`):

| Table            | Purpose                                             |
| ---------------- | --------------------------------------------------- |
| `slates`         | One row per contest slate (platform + sport + date) |
| `slate_players`  | One row per player per slate (salary, position)     |
| `projections`    | Fantasy-point projections for each player           |
| `ownership_data` | Projected ownership percentages                     |
| `runs`           | One optimizer run record (status lifecycle)         |
| `lineups`        | One lineup per run iteration                        |
| `lineup_entries` | Player↔lineup membership (roster slot, position)    |

### Relationships

```
Slate ─── 1:N ──▶ Player
Slate ─── 1:N ──▶ Projection
Slate ─── 1:N ──▶ OwnershipData
Slate ─── 1:N ──▶ Run
Run   ─── 1:N ──▶ Lineup
Lineup ── 1:N ──▶ LineupEntry
LineupEntry ─▶ Player (FK)
```

### Naming Convention

All constraint names follow SQLAlchemy's naming convention for Alembic
autogenerate compatibility:

```python
"ix": "ix_%(table_name)s_%(column_0_name)s"
"uq": "uq_%(table_name)s_%(column_0_name)s"
"fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s"
"pk": "pk_%(table_name)s"
```

---

## Service Layer

| Module                             | Responsibility                                     |
| ---------------------------------- | -------------------------------------------------- |
| `services/projection_ingestion.py` | Parse CSV → upsert Slate/Player/Projection         |
| `services/ownership_ingestion.py`  | Parse ownership CSV → upsert OwnershipData         |
| `services/player_pool_loader.py`   | Load DB rows → optimizer DataFrame                 |
| `services/run_service.py`          | Run lifecycle (create/start/complete/fail/persist) |
| `services/optimizer_service.py`    | LP optimizer (PuLP/CBC)                            |
| `tasks/optimizer_tasks.py`         | Dramatiq task wrapper                              |
| `tasks/cleanup_tasks.py`           | Periodic upload file purge                         |

---

## API Routers

| Router           | Prefix             | Key endpoints                                                             |
| ---------------- | ------------------ | ------------------------------------------------------------------------- |
| `health.py`      | `/api/health`      | `/db`, `/metrics`                                                         |
| `slates.py`      | `/api/slates`      | `GET /`, `/{id}`, `/{id}/players`, `/{id}/projections`, `/{id}/ownership` |
| `projections.py` | `/api/projections` | `POST /upload-slate-to-db` (DB-first), `POST /upload-slate` (legacy)      |
| `ownership.py`   | `/api/ownership`   | `POST /upload-to-db` (DB-first)                                           |
| `runs.py`        | `/api/runs`        | `POST /`, `GET /{run_id}`, `GET /{run_id}/status`                         |
| `results.py`     | `/api/results`     | `GET /{run_id}/status`, `GET /{run_id}/exposure`, `GET /{run_id}/lineups` |

---

## Middleware Stack (applied in order)

1. `RequestContextMiddleware` — request-id + structured JSON logging
2. `RateLimitMiddleware` — per-IP rate limiting
3. `LimitMiddleware` — payload size enforcement
4. `APIKeyMiddleware` — optional bearer auth
5. `CORSMiddleware` — env-driven allowed origins

---

## Async Task Flow

```
FastAPI  →  run_optimizer_task.send(...)   [non-blocking]
                │
                ▼
         Redis queue  "optimizer"
                │
                ▼
         Dramatiq worker process
         (separate container)
                │
                ▼
         run_optimizer_task(run_id, ...)
         time_limit = OPTIMIZER_TIMEOUT_SECONDS × 1000 ms
```

---

## Configuration (core settings)

Settings are Pydantic `BaseSettings` loaded from environment variables.
See `backend/src/core/config.py` for the full schema.

Key safety flags:

- `DB_REQUIRED=true` — startup fails if Alembic migration not applied
- `OPTIMIZER_TIMEOUT_SECONDS=300` — inline run hard timeout
- `UPLOAD_MAX_AGE_HOURS=24` — startup upload cleanup age
- `DB_REQUIRED` also disables `DFSBase.metadata.create_all()` fallback

---

## Technology Stack

| Component     | Technology              |
| ------------- | ----------------------- |
| API server    | FastAPI + Uvicorn       |
| ORM           | SQLAlchemy 2.0          |
| Migrations    | Alembic                 |
| Async workers | Dramatiq + Redis        |
| Dev database  | DuckDB (file-based)     |
| Prod database | PostgreSQL 16           |
| LP solver     | PuLP / CBC              |
| Frontend      | Next.js 14 + TypeScript |
| Container     | Docker + Docker Compose |
| CI            | GitHub Actions          |
