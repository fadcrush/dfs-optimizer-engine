# Migration Baseline Runbook

## Purpose

This document captures the **pre-migration baseline** for the monorepo transition, so each migration step can be executed and verified with minimal risk and no scope creep.

## Guardrails (Operator Rules)

1. One migration step at a time.
2. One commit per approved step.
3. Move-only + minimal import/path fixes until contracts phase.
4. No algorithm/logic changes unless a step explicitly says to fix logic.
5. Never commit generated/local artifacts (virtual envs, caches, build outputs, node modules, coverage output).

## Baseline Repository Shape (Top Level)

Primary directories observed at repo root:

- `backend/`
- `frontend/`
- `analysis/`
- `docs/`
- `scripts/`
- plus additional data/archive/audit/output directories and reports.

## Baseline Runtime Commands

### Backend

- From repo docs:
  - `uvicorn main:app --reload` (from `backend/`)
  - `python main.py` (from `backend/`)

### Frontend

- From `frontend/package.json`:
  - `npm run dev`
  - `npm run dev:frontend`
  - `npm run dev:backend`
  - `npm run dev:all`
  - `npm run build`
  - `npm run test`

### Analysis / Misc

- `python -m analysis.entrypoints.workflow`

## Baseline VCS Status

At migration start, working tree is **already dirty** with substantial tracked modifications and many untracked files.

Implications:

- Migration commits must be narrowly scoped to the step being executed.
- Validation should include explicit diff inspection before each commit.

## Smoke Verification Convention (Per Step)

For each step, run:

1. `git diff --stat`
2. targeted smoke command(s) relevant to that step
3. pause for approval before committing

## Planned Migration Sequence

The execution order follows the approved 30-step plan (docs baseline → smoke scripts → gitignore hardening → untrack artifacts → packaging/src layout → entrypoints → contracts/normalization → domain extraction → worker mode → determinism/regression → frontend API client + contract wiring → CI gates → fixtures → architecture docs).
