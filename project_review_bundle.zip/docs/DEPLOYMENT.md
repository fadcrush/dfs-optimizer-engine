# DFS Edge Pro — Deployment Guide

This document covers deploying DFS Edge Pro in production using Docker Compose.
For local development, see [README.md](../README.md).

---

## Architecture Overview

```
                  ┌─────────────────────────────────────────┐
                  │          Docker Compose Stack            │
                  │                                          │
  Browser  ──────>│  frontend (Next.js :3000)                │
                  │      │                                   │
  API calls ─────>│  backend (FastAPI :8000)  ──> postgres   │
                  │       │                       :5432      │
                  │       └──> worker (Dramatiq)             │
                  │               └──> redis :6379           │
                  └─────────────────────────────────────────┘
```

---

## Prerequisites

- Docker 24+ and Docker Compose v2
- `make` (optional, for convenience targets)
- A Linux/macOS host (Windows via WSL2)

---

## Quick Start

```bash
# 1. Copy env template
cp config/env.template .env

# 2. Edit .env — fill in SECRET_KEY, JWT_SECRET_KEY, DATABASE_URL, REDIS_URL, ALLOWED_ORIGINS

# 3. Build images
docker compose build

# 4. Start infrastructure
docker compose up -d postgres redis

# 5. Run migrations
docker compose run --rm backend alembic -c alembic.ini upgrade head

# 6. Start all services
docker compose up -d

# 7. Run smoke test
python scripts/verify_pipeline.py

# 8. Open docs
open http://localhost:8000/api/docs
```

---

## Environment Variables

See [scripts/deploy_checklist.md](../scripts/deploy_checklist.md) for the full
variable reference table.

Critical variables that **must** be set before starting:

| Variable          | Example                                                 |
| ----------------- | ------------------------------------------------------- |
| `SECRET_KEY`      | `$(openssl rand -hex 32)`                               |
| `JWT_SECRET_KEY`  | `$(openssl rand -hex 32)`                               |
| `DATABASE_URL`    | `postgresql+psycopg2://dfs:secret@postgres:5432/dfs_db` |
| `REDIS_URL`       | `redis://redis:6379/0`                                  |
| `ALLOWED_ORIGINS` | `https://app.yourdomain.com`                            |
| `DB_REQUIRED`     | `true`                                                  |

---

## Migrations

Migrations are managed by **Alembic**.

```bash
# Apply all pending migrations
docker compose run --rm backend alembic -c alembic.ini upgrade head

# Show current revision
docker compose run --rm backend alembic -c alembic.ini current

# Generate a new auto-migration after model changes
docker compose run --rm backend alembic -c alembic.ini revision --autogenerate -m "description"
```

`DB_REQUIRED=true` causes the backend to **fail on startup** if `alembic_version`
is absent or empty. Always run migrations before starting the backend service.

---

## Worker Concurrency

The optimizer worker is a **Dramatiq** process reading from Redis.

```yaml
# docker-compose.yml worker section
command: >
  python -m dramatiq tasks.optimizer_tasks
  --processes 2 --threads 1
```

Rules:

- **DuckDB** (local dev): `--processes 1 --threads 1` only. DuckDB uses
  an exclusive file lock — multiple workers will crash with `DUCKDB_FILE_LOCK`.
- **PostgreSQL** (production): `--processes 2+` is safe.
- Each process uses one DB connection. Size the connection pool accordingly.

---

## DuckDB vs PostgreSQL

| Feature                   | DuckDB (dev)        | PostgreSQL (prod)      |
| ------------------------- | ------------------- | ---------------------- |
| Setup                     | Zero-config         | Requires server        |
| Concurrency               | Single-process only | Multi-process safe     |
| Performance               | Fast for analytics  | Better for OLTP writes |
| `DB_REQUIRED`             | Leave `false`       | Set `true`             |
| Alembic `render_as_batch` | Required            | Optional               |

Switch between them by changing `DATABASE_URL` only.

---

## Scaling

**Horizontal scaling** (multiple backend replicas):

- Use a PostgreSQL connection pooler (PgBouncer) in transaction mode.
- Set `WEB_CONCURRENCY=1` per backend container to avoid DuckDB lock issues.
- Add a load balancer (nginx / AWS ALB) in front.

**Worker scaling**:

- Add more worker containers via `docker compose up --scale worker=N`.
- Each worker process consumes one DB connection.

---

## Monitoring

```bash
# Health check (for load balancer)
GET /api/health
# → {"status": "healthy"}

# DB schema health
GET /api/health/db
# → {"status": "ok", "alembic_revision": "...", "missing_tables": []}

# Runtime counters
GET /api/health/metrics
# → {"uptime_seconds": 3600, "counts": {"runs_completed": 42, ...}}
```

Add `/api/health` as the ALB target group health check path.

---

## Log Aggregation

The backend emits structured JSON logs to stdout:

```json
{
  "ts": "2026-02-19T14:35:01",
  "level": "INFO",
  "evt": "request_complete",
  "request_id": "a3f2b1c4",
  "method": "POST",
  "path": "/api/runs",
  "status": 200,
  "duration_ms": 42
}
```

Forward to your log aggregator (CloudWatch, Datadog, Loki, etc.) by
collecting container stdout. Set `LOG_LEVEL=DEBUG` for verbose output.

---

## Backup and Recovery

```bash
# Backup PostgreSQL
docker compose exec postgres pg_dump -U dfs dfs_db > backup_$(date +%Y%m%d).sql

# Restore
docker compose exec -T postgres psql -U dfs dfs_db < backup_20260219.sql
```

---

## SSL / TLS

Terminate TLS at the load balancer (nginx/ALB) — the backend listens on plain HTTP.
Set `ALLOWED_ORIGINS` to your HTTPS frontend domain.

---

## Troubleshooting

| Symptom                                                         | Likely cause                          | Fix                                  |
| --------------------------------------------------------------- | ------------------------------------- | ------------------------------------ |
| `RuntimeError: DB_REQUIRED=true but alembic_version is missing` | Migration not run                     | `alembic upgrade head`               |
| Worker `DUCKDB_FILE_LOCK` error                                 | Multiple workers on file DuckDB       | Set `--processes 1`                  |
| `CORS blocked`                                                  | `ALLOWED_ORIGINS` missing your domain | Add domain to `ALLOWED_ORIGINS`      |
| `503 Database unavailable`                                      | PostgreSQL not healthy                | Check `docker compose ps postgres`   |
| Runs stuck in `queued`                                          | Worker not running or Redis down      | `docker compose up -d worker redis`  |
| `504 Optimizer timed out`                                       | Large slate / slow hardware           | Increase `OPTIMIZER_TIMEOUT_SECONDS` |
