# docs/LAUNCH_CHECKLIST.md

# DFS Edge Pro — Production Launch Checklist

This document is the authoritative go/no-go checklist before promoting the system to production.
Every item must be ✓ before launch.

---

## 1. Infrastructure Readiness

| # | Check | Command / Verification | Status |
|---|-------|------------------------|--------|
| 1.1 | PostgreSQL accessible from backend | `psql $DATABASE_URL -c "SELECT 1"` | ⬜ |
| 1.2 | Redis accessible from backend + worker | `redis-cli -u $REDIS_URL PING` | ⬜ |
| 1.3 | `.env` values set for production | Review `config/env.template` | ⬜ |
| 1.4 | `SECRET_KEY` is a random 32+ char string | `python -c "import secrets; print(secrets.token_hex(32))"` | ⬜ |
| 1.5 | `ALLOWED_ORIGINS` set to production domain | `export ALLOWED_ORIGINS=https://yourdomain.com` | ⬜ |

---

## 2. Database Migration

| # | Check | Command | Status |
|---|-------|---------|--------|
| 2.1 | Alembic head applied | `cd backend && alembic upgrade head` | ⬜ |
| 2.2 | Schema version confirmed | `GET /api/health/db` → `alembic_revision` not null | ⬜ |
| 2.3 | No missing tables | `GET /api/health/db` → `missing_tables: []` | ⬜ |
| 2.4 | Required indexes present | `python scripts/check_indexes.py` | ⬜ |

---

## 3. Backend Service

| # | Check | Command | Status |
|---|-------|---------|--------|
| 3.1 | Backend starts without errors | `uvicorn main:app --port 8000` | ⬜ |
| 3.2 | Health check passes | `curl http://localhost:8000/api/health` | ⬜ |
| 3.3 | OpenAPI schema loads | `curl http://localhost:8000/api/openapi.json` | ⬜ |
| 3.4 | DB_REQUIRED=true set | `export DB_REQUIRED=true` | ⬜ |
| 3.5 | Stale run recovery runs on startup | Check startup logs for "Stale run recovery" | ⬜ |

---

## 4. Worker Service

| # | Check | Command | Status |
|---|-------|---------|--------|
| 4.1 | Dramatiq worker starts | `cd backend && python -m dramatiq tasks.optimizer_tasks` | ⬜ |
| 4.2 | Worker processes test job | Create run with `async_mode=true`, verify completion | ⬜ |
| 4.3 | Optimizer timeout configured | `export OPTIMIZER_TIMEOUT_SECONDS=300` | ⬜ |

---

## 5. End-to-End Pipeline

| # | Check | Command | Status |
|---|-------|---------|--------|
| 5.1 | Pipeline smoke test passes | `python scripts/verify_pipeline.py --base-url $BASE_URL` | ⬜ |
| 5.2 | Projection upload works | Verify `slate_id` returned | ⬜ |
| 5.3 | Ownership upload works | Verify `matched >= 5` | ⬜ |
| 5.4 | Optimizer run completes | Verify `status=completed` | ⬜ |
| 5.5 | Lineups retrievable from DB | `GET /api/results/{run_id}/lineups` | ⬜ |
| 5.6 | Exposure retrievable from DB | `GET /api/results/{run_id}/exposure` | ⬜ |

---

## 6. Observability

| # | Check | Command | Status |
|---|-------|---------|--------|
| 6.1 | Structured JSON logging enabled | `export LOG_LEVEL=INFO` and tail logs | ⬜ |
| 6.2 | Health metrics endpoint works | `GET /api/health/metrics` | ⬜ |
| 6.3 | Prometheus metrics endpoint works | `GET /api/metrics` | ⬜ |
| 6.4 | Request IDs in response headers | Check `X-Request-ID` header | ⬜ |

---

## 7. Security

| # | Check | Command | Status |
|---|-------|---------|--------|
| 7.1 | CORS restricted to production origins | `ALLOWED_ORIGINS=https://yourdomain.com` | ⬜ |
| 7.2 | HTTPS enforced at load balancer | Nginx/Caddy SSL termination configured | ⬜ |
| 7.3 | No debug endpoints exposed | `DB_REQUIRED=true`, no dev mocks | ⬜ |
| 7.4 | Upload file retention configured | `UPLOAD_MAX_AGE_HOURS=24` | ⬜ |

---

## 8. Tests

| # | Check | Command | Status |
|---|-------|---------|--------|
| 8.1 | All tests pass | `pytest tests/ --ignore=tests/test_simulation_engine.py -q` | ⬜ |
| 8.2 | No test warnings ignored | Review `pytest.ini` | ⬜ |
| 8.3 | CI pipeline green | Check GitHub Actions / CI status | ⬜ |

---

## 9. Deployment Validation

| # | Check | Command | Status |
|---|-------|---------|--------|
| 9.1 | Full deploy validation passes | `bash scripts/deploy_validate.sh` | ⬜ |
| 9.2 | Performance within thresholds | `python scripts/performance_check.py` | ⬜ |
| 9.3 | Worker recovery tested | Simulate crash + restart, verify stale run marked failed | ⬜ |

---

## 10. Environment Variables Reference

```bash
# Database
DATABASE_URL=postgresql://user:pass@host:5432/dfs_edge

# Redis / Worker
REDIS_URL=redis://:pass@host:6379/0

# Security
SECRET_KEY=<random 64 hex chars>
ALLOWED_ORIGINS=https://yourdomain.com
DB_REQUIRED=true

# Logging
LOG_LEVEL=INFO
ENVIRONMENT=production

# Optimizer
OPTIMIZER_TIMEOUT_SECONDS=300
UPLOAD_MAX_AGE_HOURS=24
STALE_RUN_THRESHOLD_MINUTES=15

# Optional
USE_DUCKDB_FALLBACK=false
```

---

## Pre-Launch Sign-Off

| Role | Name | Date | Signature |
|------|------|------|-----------|
| Engineering Lead | | | |
| DevOps | | | |
| QA | | | |
