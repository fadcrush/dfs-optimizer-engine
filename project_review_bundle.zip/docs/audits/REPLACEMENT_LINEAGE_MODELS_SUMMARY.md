# Replacement Lineage Models - Implementation Summary

## ✅ Implementation Complete

All requirements met with **33/33 tests passing**.

---

## Models Implemented

### 1. ReplacementCandidate (Immutable Dataclass)

**Location:** `backend/signals/models.py` (lines 279-373)

**Fields:**

- `player_name` (str) - Name of replacement player
- `team` (str) - Team abbreviation (e.g., "MIL", "BOS")
- `pos` (str) - Position (e.g., "PG", "SF", "C")
- `score` (float) - Composite opportunity score (0.0-100.0)
- `minutes_delta` (float) - Expected change in minutes per game
- `usage_delta` (float) - Expected change in usage rate (percentage points)
- `starting_likelihood` (float) - Probability of moving to starting lineup (0.0-1.0)
- `reason_codes` (List[str]) - List of reason codes for explainability

**Validation:**

- ✅ Frozen (immutable) - `@dataclass(frozen=True)`
- ✅ `score` must be 0.0-100.0
- ✅ `starting_likelihood` must be 0.0-1.0
- ✅ `reason_codes` must be non-empty
- ✅ All string fields must be non-empty
- ✅ Negative deltas allowed (penalty scenarios)

**Methods:**

- `to_dict()` - JSON serialization
- `from_dict(data)` - JSON deserialization

**Example:**

```python
from backend.signals.models import ReplacementCandidate

candidate = ReplacementCandidate(
    player_name="AJ Green",
    team="MIL",
    pos="PG",
    score=85.5,
    minutes_delta=12.0,
    usage_delta=6.0,
    starting_likelihood=0.95,
    reason_codes=["BACKUP_PG", "STARTER_REPLACEMENT"],
)

# Serialize
data = candidate.to_dict()

# Deserialize
restored = ReplacementCandidate.from_dict(data)
```

---

### 2. ReplacementLineage (Immutable Dataclass)

**Location:** `backend/signals/models.py` (lines 376-649)

**Fields:**

- `out_player_name` (str) - Name of injured player
- `out_team` (str) - Team abbreviation
- `out_pos` (str) - Position of injured player
- `status` (str) - Injury status (OUT/DOUBTFUL/QUESTIONABLE/ACTIVE)
- `confidence` (float) - Overall confidence in lineage (0.0-1.0)
- `candidates` (List[ReplacementCandidate]) - Ordered list (highest score first)
- `created_at` (datetime) - UTC timestamp (timezone-aware required)
- `sources` (List[str]) - Source identifiers for auditability
- `selected` (Optional[ReplacementCandidate]) - Top replacement candidate (optional)

**Validation:**

- ✅ Frozen (immutable) - `@dataclass(frozen=True)`
- ✅ `status` normalized to uppercase, must be valid InjuryStatus
- ✅ `confidence` must be 0.0-1.0
- ✅ `candidates` must be non-empty
- ✅ `sources` must be non-empty (auditability requirement)
- ✅ `created_at` must be timezone-aware
- ✅ `selected` must be in `candidates` list if provided
- ✅ All `candidates` must be `ReplacementCandidate` instances

**Methods:**

- `to_dict()` - JSON serialization (with nested candidates)
- `from_dict(data)` - JSON deserialization
- `@property top_candidate` - Get highest-scoring candidate
- `@property total_minutes_absorbed` - Sum of positive minutes deltas
- `get_candidates_above_score(threshold)` - Filter by score
- `get_starters()` - Get candidates with starting_likelihood >= 0.75

**Example:**

```python
from backend.signals.models import ReplacementCandidate, ReplacementLineage
from datetime import datetime, timezone

candidates = [
    ReplacementCandidate(
        player_name="AJ Green",
        team="MIL",
        pos="PG",
        score=85.5,
        minutes_delta=12.0,
        usage_delta=6.0,
        starting_likelihood=0.95,
        reason_codes=["BACKUP_PG", "STARTER_REPLACEMENT"],
    ),
    ReplacementCandidate(
        player_name="Andre Jackson",
        team="MIL",
        pos="SG",
        score=65.0,
        minutes_delta=5.0,
        usage_delta=2.0,
        starting_likelihood=0.30,
        reason_codes=["ROTATION", "USAGE_BUMP"],
    ),
]

lineage = ReplacementLineage(
    out_player_name="Damian Lillard",
    out_team="MIL",
    out_pos="PG",
    status="OUT",  # Auto-normalized to uppercase
    confidence=0.85,
    candidates=candidates,
    created_at=datetime.now(timezone.utc),
    sources=["beat_writer:shams", "depth_chart:nba_official"],
    selected=candidates[0],  # Optional
)

# Access properties
print(lineage.top_candidate.player_name)  # "AJ Green"
print(lineage.total_minutes_absorbed)     # 17.0 (12.0 + 5.0)

# Filter candidates
high_score = lineage.get_candidates_above_score(70.0)  # Only AJ Green
starters = lineage.get_starters()                      # Only AJ Green

# Serialize
data = lineage.to_dict()

# Deserialize
restored = ReplacementLineage.from_dict(data)
```

---

## Test Coverage

**Test File:** `tests/test_replacement_lineage_models.py` (33 tests)

### ReplacementCandidate Tests (15 tests)

- ✅ Valid creation
- ✅ Frozen behavior (immutability)
- ✅ Score validation (too low, too high)
- ✅ Starting likelihood validation (too low, too high)
- ✅ Empty reason_codes validation
- ✅ Empty string field validation (player_name, team, pos)
- ✅ Negative deltas allowed
- ✅ to_dict serialization
- ✅ from_dict deserialization
- ✅ Round-trip serialization

### ReplacementLineage Tests (18 tests)

- ✅ Valid creation
- ✅ Frozen behavior (immutability)
- ✅ Status normalization to uppercase
- ✅ Invalid status validation
- ✅ Confidence validation (too low, too high)
- ✅ Empty candidates validation
- ✅ Empty sources validation
- ✅ Naive datetime validation
- ✅ Selected not in candidates validation
- ✅ Selected in candidates (valid)
- ✅ to_dict serialization
- ✅ from_dict deserialization
- ✅ Round-trip serialization
- ✅ top_candidate property
- ✅ total_minutes_absorbed property
- ✅ get_candidates_above_score method
- ✅ get_starters method

---

## Key Features

### ✅ Deterministic

- Frozen dataclasses prevent mutation
- All timestamps are timezone-aware UTC
- Status normalized to uppercase (OUT, DOUBTFUL, etc.)
- Validation in `__post_init__` ensures data integrity

### ✅ JSON-Serializable

- `to_dict()` converts to plain Python dicts
- `from_dict(data)` reconstructs from dicts
- Nested objects handled correctly
- Datetimes serialized to ISO format
- Round-trip serialization validated by tests

### ✅ Explainable

- `reason_codes` list for replacement logic
- `sources` list for audit trail
- `confidence` and `score` for transparency
- Human-readable docstrings

### ✅ Production-Ready

- 33/33 tests passing
- Comprehensive validation
- Type hints throughout
- Edge cases handled

---

## Integration Points

These models are designed to integrate with:

- Signal ingestion pipeline (`backend/signals/`)
- Injury tracking services (`backend/services/models.py`)
- Lineup adjustment logic (`backend/services/lineup_adjustments.py`)
- Ownership leverage scoring (`backend/services/replacement_leverage.py`)

---

## Files Modified

1. ✅ **backend/signals/models.py**
   - Updated `ReplacementCandidate` dataclass (lines 279-373)
   - Updated `ReplacementLineage` dataclass (lines 376-649)
   - Added validation, serialization, and utility methods

2. ✅ **tests/test_replacement_lineage_models.py** (NEW)
   - 33 comprehensive tests
   - 100% coverage of validation logic
   - Round-trip serialization tests
   - Edge case validation

---

## Usage in Production

```python
from backend.signals.models import ReplacementCandidate, ReplacementLineage
from datetime import datetime, timezone

# When player is OUT, create lineage
lineage = ReplacementLineage(
    out_player_name="Damian Lillard",
    out_team="MIL",
    out_pos="PG",
    status="OUT",
    confidence=0.85,
    candidates=[
        ReplacementCandidate(
            player_name="AJ Green",
            team="MIL",
            pos="PG",
            score=85.5,
            minutes_delta=12.0,
            usage_delta=6.0,
            starting_likelihood=0.95,
            reason_codes=["BACKUP_PG", "STARTER_REPLACEMENT"],
        ),
    ],
    created_at=datetime.now(timezone.utc),
    sources=["beat_writer:shams", "depth_chart:nba_official"],
)

# Store as JSON
import json
with open("lineages.json", "w") as f:
    json.dump(lineage.to_dict(), f)

# Load from JSON
with open("lineages.json", "r") as f:
    data = json.load(f)
    restored_lineage = ReplacementLineage.from_dict(data)
```

---

## Summary

✅ **All requirements met:**

- Immutable dataclasses (`frozen=True`)
- Deterministic behavior (validation, normalization)
- JSON-serializable (`to_dict()`, `from_dict()`)
- Comprehensive unit tests (33/33 passing)
- Production-ready with full validation
- Clear explainability (reason_codes, sources, confidence)

The models are ready for integration into the injury replacement lineage pipeline.
