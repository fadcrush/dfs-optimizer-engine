# FORENSIC AUDIT: DFS Backend Implementation vs. Architecture Intent

**Audit Date**: 2026-01-22  
**Scope**: Verify 4-tier architecture, signal enforcement, temporal logic, starter opportunity modeling, self-correction loop  
**Result**: Mixed — Core structures present but critical enforcement gaps and missing logic flows

---

## EXECUTIVE SUMMARY

The codebase has **strong structural foundations** but suffers from **incomplete enforcement** of critical temporal and decision logic:

- ✅ **4-tier schema** correctly partitioned (RAW/DERIVED/OPERATIONAL/EVALUATION)
- ✅ **Signal specifications** properly defined with decay/validity
- ⚠️ **Signal enforcement** incomplete (signals stored but not enforced in projection building)
- ❌ **Temporal projection building** not fully implemented (no `as_of_time` query logic)
- ⚠️ **Starter logic** partially correct but mixed with efficiency (should be OPPORTUNITY ONLY)
- ❌ **Self-correction loop** incomplete (evaluation computed but not wired back to source weighting)
- ⚠️ **Decision snapshots** schema exists but not populated during projection builds

---

## STEP 1: ARCHITECTURAL VERIFICATION

### A. 4-Tier Data Model

#### RAW TIER (Immutable Ingest)

**Status**: ✅ Correctly Implemented

- `raw_fd_slate_csv`, `raw_dk_slate_csv` — append-only, file_hash dedup
- `raw_actual_results` — immutable game truth
- `raw_contest_results` — immutable entry results
- JSON payloads preserved for forensic audit
- All have `UNIQUE` constraints preventing re-ingestion of identical payloads

**Verified**:

```sql
raw_fd_slate_csv:   file_hash dedup ✓
raw_dk_slate_csv:   file_hash dedup ✓
raw_actual_results: UNIQUE(game_id, player_id, league) ✓
```

---

#### DERIVED TIER (Canonicalized, Versioned)

**Status**: ✅ Schema Correct, ⚠️ Logic Partially Implemented

**Schema**:

- `dim_players` — canonical player master (✓)
- `dim_teams` — canonical team master (✓)
- `dim_games` — game metadata with UTC times (✓)
- `dim_slates` — slate definitions (✓)
- `fact_site_players` — site-to-canonical mapping (✓)
- `fact_actual_player_results` — immutable truth (✓)

**Issues**:

1. **⚠️ NO VERSIONING IN DIMENSION TABLES**
   - `dim_players.updated_at` exists but NOT used to track canonical name changes
   - If "LeBron James" gets renamed, historical references become ambiguous
   - **Risk**: Retroactive analysis uses wrong canonical names
   - **Action**: Need SCD (Slowly Changing Dimension) Type 2 or versioned lookup

2. **✅ Feature Storage Absent From Schema**
   - Expected: `fact_feature_snapshots(feature_id, player_id, game_id, season, minutes_floor, minutes_ceiling, ...)`
   - **Current**: Features computed on-the-fly in `FeatureBuilder` class
   - **Impact**: Features are NOT stored, so can't audit which features were used at decision time
   - **Risk**: Projection building is not fully reproducible (features recomputed = potential variance)

---

#### OPERATIONAL TIER (Decision Points)

**Status**: ⚠️ Schema Correct, ❌ Decision Logic Not Fully Wired

**Schema**:

- `operational_signals` — signal specs with decay/validity (✓)
- `operational_lineups` — starter status (✓)
- `operational_projections` — distributions + inputs_hash (✓)
- `decision_snapshots` schema defined but **NEVER POPULATED**

**Critical Issues**:

1. **❌ `decision_snapshots` Table NOT Used**
   - **Location**: Defined in `migrations.py` (004)
   - **Usage**: Zero—no code populates this table
   - **Intent**: Should record which signals were active at projection build time
   - **Impact**: Cannot audit "why was this projection 45 FPPG and not 40?"
   - **Action**: Must wire signal application into projection builder

2. **❌ Temporal Projection Building NOT Implemented**
   - **Current Logic**:
     ```python
     # api/projections.py, GET /projections/slate/{slate_id}
     query = """
     SELECT ... FROM operational_projections
     WHERE slate_id = :slate_id
       AND version = :version
       AND as_of_time <= :as_of_time  # This clause exists...
     ORDER BY player_id, created_at DESC
     """
     ```
   - **Problem**: Clause is there but `as_of_time` comes from parameter, NOT from actual decision time
   - **Intent**: Should fetch projections built AT specific time T, using signals valid AT time T
   - **Action**: Need explicit temporal query logic in `ProjectionStore`

3. **⚠️ `operational_lineups` Partially Used**
   - Schema has `announced_at`, `valid_until`, `minutes_ceiling_adjustment`
   - BUT: `OpportunityModifier.apply_modifiers()` checks for `ConfirmedStarterSignal` objects, NOT the `operational_lineups` table
   - **Risk**: Two sources of starter truth (signals vs. table) can diverge
   - **Action**: Consolidate starter logic to use one source

---

#### EVALUATION TIER (Feedback Loops)

**Status**: ✅ Schema Correct, ⚠️ Loop Not Connected

**Schema**:

- `evaluation_projection_accuracy` — projection vs. actual (✓)
- `evaluation_source_reliability` — source hit rates (✓)
- `evaluation_bias` — bias by dimension (✓)

**Issues**:

1. **⚠️ Evaluation Computed But Not Looped Back**
   - **Current**: `AccuracyMetricsComputer` computes RMSE, MAE, hit_rate
   - **Current**: `SourceReliabilityTracker` has `upweight()` and `downweight()` methods
   - **Missing**: No code that:
     - Runs post-slate evaluation
     - Fetches source reliability scores
     - Applies weighting to next projection build
   - **Location**: Should be in a "feedback loop" orchestrator (doesn't exist)
   - **Action**: Create evaluation → source weight update → projection rebuild pipeline

2. **⚠️ Source Reliability NOT Used In Projection Building**
   - **Current**: `SourceReliabilityTracker` tracks scores in memory
   - **Missing**: Projection builder doesn't fetch/apply these weights
   - **Intent**: Next slate should weight FanDuel differently if last slate showed poor reliability
   - **Action**: Thread source weights through projection builder

3. **⚠️ `evaluation_bias` Table Defined But Population Logic Unclear**
   - **Intent**: Track bias by position, team, salary tier, etc.
   - **Current**: No code populates this table in evaluator
   - **Action**: Implement dimension-level bias computation

---

### B. Signal Engine Audit

**Status**: ✅ Specification Correct, ⚠️ Enforcement Incomplete

#### Signal Specification

**File**: `backend/signals/spec.py`

**Verification**:

```python
@dataclass
class SignalSpec:
    signal_type: str                  ✓
    entity_type: str                  ✓
    entity_id: str                    ✓
    league: str                       ✓

    timestamp_utc: datetime           ✓
    decay_profile: str                ✓
    validity_start: datetime          ✓
    validity_end: Optional[datetime]  ✓

    source: str                       ✓
    source_confidence: float (0-1)    ✓

    applies_to: List[str]             ✓
    cannot_apply_to: List[str]        ✓

    payload: Dict                     ✓
```

**Correct Methods**:

- `get_effective_confidence(as_of)` — applies decay ✓
- `is_valid_at(at_time)` — checks validity window ✓
- `applies_to_domain(domain)` — checks scope ✓

**Templates**:

- `InjuryOutSignal` — decay=NONE, applies_to=[minutes, usage], cannot_apply_to=[efficiency] ✓
- `ConfirmedStarterSignal` — applies_to=[minutes, usage, opportunity, ownership] ✓
- Others defined correctly ✓

---

#### Signal Enforcement

**Status**: ⚠️ Signals Stored, But Not Enforced In Projections

**Critical Gap**:

1. **Signals Are Stored Correctly**
   - `operational_signals` table has all required fields
   - Decay profiles exist (FAST/MEDIUM/SLOW/NONE)
   - Validity windows enforced in `SignalSpec.is_valid_at()`

2. **BUT: Signals Not Fetched During Projection Building**
   - **Location**: `projection/store.py` — projection build logic
   - **Current**: No method fetches active signals for a player at time T
   - **Missing Code**:
     ```python
     # This doesn't exist:
     def get_signals_for_player_at_time(player_id, game_id, as_of_time):
         """Fetch signals active at specific time with decay applied."""
         # Should query operational_signals
         # Should filter by is_valid_at(as_of_time)
         # Should filter by applies_to_domain(domain)
         # Should compute effective_confidence(as_of_time)
     ```
   - **Impact**: Projections built without signal influence

3. **Starter Logic Uses Signals (Partially)**
   - `OpportunityModifier.apply_modifiers()` accepts `signals: List[SignalSpec]`
   - Checks for `InjuryOutSignal` → hard override ✓
   - Checks for `ConfirmedStarterSignal` → +4 minutes ceiling ✓
   - BUT: Signals are passed as parameter, not fetched from database
   - **Question**: Where are signals loaded before calling this method?
   - **Answer**: Not found in codebase—signals are NOT being wired in

---

### C. Starting Lineup Logic Verification

**Status**: ⚠️ Schema Correct, ⚠️ Logic Partially Correct But Mixed

#### Intended Design (from ARCHITECTURE_PLAN.md)

```
Starter Status is OPPORTUNITY ACCESS, NOT EFFICIENCY BOOST:
  - Expands minutes CEILING (more opportunity)
  - Expands usage CEILING (more touches)
  - Increases volatility (wider distribution)
  - DOES NOT change per-minute efficiency (fppm)
```

#### Current Implementation

**File**: `backend/derive/modifiers.py`

```python
class OpportunityModifier:
    def apply_modifiers(self, ..., signals: List[SignalSpec]) -> OpportunityModifiers:

        # Check for injury OUT
        for signal in signals:
            if isinstance(signal, InjuryOutSignal):
                modifiers.minutes_floor_final = 0     ✓
                modifiers.minutes_ceiling_final = 0   ✓
                return modifiers                       ✓

        # Check for confirmed starter
        for signal in signals:
            if isinstance(signal, ConfirmedStarterSignal):
                modifiers.starter_minutes_adjustment = 4  # Add 4 min to ceiling ✓
                modifiers.confidence = signal.source_confidence
                break

        # Apply adjustments
        modifiers.minutes_floor_final = baseline + (adjustment * 0.3)     ✓
        modifiers.minutes_ceiling_final = baseline + (adjustment * 0.7)   ✓

        # Usage scales with opportunity ✓
        modifiers.usage_ceiling_final = baseline_usage * (ceiling_ratio)
```

**Verification**:

✅ Starter **increases minutes ceiling** (opportunity expansion)
✅ Starter **increases usage ceiling** (scaled by minutes)
✅ Starter **does NOT boost efficiency** (no fppm multiplier)
✅ Injury OUT **hard override** (minutes = 0)

**BUT ISSUE**: This logic is **never called** in projection building because signals are never fetched.

---

#### Remaining Concern: NBA vs. NFL Differences

**File**: `backend/derive/features.py`

**Issue**: No position-specific starter handling visible

- NBA: Starter status affects PG, SG, SF, PF, C differently
- NFL: Starter status affects QB, RB, WR, TE differently
- Defensive-only starters (DEF position) should NOT be boosted

**Current Code**: No mention of position-specific logic
**Action**: Verify position checks are in place before applying starter boost

---

### D. Temporal Intelligence Check

**Status**: ❌ Not Fully Implemented

#### Intended Design

```
Projections should be buildable "as_of a time T":
  - Fetch signals valid at time T (with decay applied)
  - Fetch features valid at time T
  - Compute distribution using T-time data
  - Store inputs_hash for reproducibility
```

#### Current Implementation

**Location**: `backend/projection/models.py` and `store.py`

```python
@dataclass
class ProjectionDistribution:
    as_of_time: datetime  ✓ (field exists)
    inputs_hash: str      ✓ (field exists)
```

**Issue 1: As-Of Time Not Used Functionally**

- Field stored but **no code computes projections as_of a historical time**
- Only stores when projection was created, not when it was meant to apply

**Issue 2: No Inputs Hash Computation**

- `inputs_hash` field exists but never populated
- **Missing Code**:
  ```python
  def compute_inputs_hash(player_id, game_id, signals, features, baselines, as_of_time):
      """Create deterministic hash of all inputs."""
      # Should include: player_id, game_id, signal_ids, feature versions, baseline versions
      # Should be deterministic: same inputs → same hash
  ```
- **Impact**: Cannot verify reproducibility

**Issue 3: Decision Snapshots Not Used**

- Table exists, never populated
- Should record:
  - Which signals were active
  - Which features were used
  - Which baseline versions applied
  - Timestamp of decision
- **Action**: Must populate during projection build

**Issue 4: Feature Storage Missing**

- Features computed on-the-fly in `FeatureBuilder`
- Not stored with version/timestamp
- **Impact**: Cannot replay historical feature state
- **Action**: Store features as snapshots in database

---

### E. Self-Correction Loop Verification

**Status**: ⚠️ Components Exist, Loop Not Connected

#### Intended Design

```
1. Build projections at time T
2. Ingest results after game
3. Compute accuracy metrics
4. Update source reliability
5. Next projection build uses updated weights
6. Loop improves accuracy over time
```

#### Current Implementation

**Step 1: Build Projections** ✓

- Code exists: `ProjectionBuilder` (but not fully wired)

**Step 2: Ingest Results** ✓

- Code exists: `ingest_results` endpoint

**Step 3: Compute Accuracy** ✅

- `AccuracyMetricsComputer` correctly computes RMSE, MAE, hit_rate, bias, correlation

**Step 4: Update Source Reliability** ⚠️

- `SourceReliabilityTracker` has methods but:
  - Tracks in **memory only** (dictionary)
  - NOT persisted to database
  - NOT loaded on next run
- Missing code:

  ```python
  # Store reliability to database
  def persist_reliability(self, connection):
      # Update evaluation_source_reliability table
      pass

  # Load reliability from database
  def load_reliability(self, connection):
      # Read from evaluation_source_reliability table
      pass
  ```

**Step 5: Use Weights In Next Build** ❌

- **Missing Code**: Projection builder doesn't fetch source reliability scores
- No weighting applied to baselines based on source performance
- **Example Missing**:
  ```python
  # This doesn't happen:
  def apply_source_weights(baseline_minutes, source_reliability):
      # If minutes baseline has reliability 0.88, weight it differently
      # If minutes baseline has reliability 0.65, reduce its influence
      pass
  ```

**Step 6: Iterative Improvement** ❌

- Loop is not wired → no self-correction

---

## STEP 2: SIGNAL ENGINE DETAILED AUDIT

**File Locations**:

- Spec: `backend/signals/spec.py`
- Store: `backend/signals/store.py`
- Overrides: `backend/signals/overrides.py`
- Snapshot: `backend/signals/snapshot.py`

### Signal Specification: ✅ Correct

All required fields present and validated:

- timestamp_utc, source, source_confidence
- decay_profile, validity_start, validity_end
- applies_to, cannot_apply_to
- payload for signal-specific data

### Signal Storage: ✅ Correct

Schema supports temporal queries:

```sql
CREATE TABLE operational_signals (
    signal_id BIGINT PRIMARY KEY,
    signal_type VARCHAR,
    entity_type VARCHAR,
    entity_id VARCHAR,
    league VARCHAR,
    slate_id VARCHAR,
    timestamp_utc TIMESTAMP WITH TIME ZONE,
    source VARCHAR,
    source_confidence DECIMAL(3, 2),
    decay_profile VARCHAR,
    validity_start TIMESTAMP WITH TIME ZONE,
    validity_end TIMESTAMP WITH TIME ZONE,
    applies_to JSON,
    cannot_apply_to JSON,
    signal_payload JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ingested_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
```

All columns necessary for temporal + decay logic. ✓

### Signal Retrieval: ⚠️ Incomplete

**File**: `backend/signals/store.py`

**Issue 1: No Time-Range Query**

```python
# This method is missing:
def get_signals_for_player_at_time(self, player_id: str, as_of_time: datetime) -> List[SignalSpec]:
    """
    Get all signals active for player at specific time.
    Should:
    1. Filter by entity_id = player_id
    2. Filter by is_valid_at(as_of_time)
    3. Compute effective_confidence(as_of_time)
    4. Return ordered by signal_type priority
    """
    pass
```

**Issue 2: No Decay Application**

- Signals stored with decay_profile
- But no code applies decay when retrieving
- `SignalSpec.get_effective_confidence()` computes decay, but is never called during retrieval

**Issue 3: No Priority Ordering**

- Override priority hierarchy (Injury OUT > Injury IN > Starter > Fatigue) exists in concept
- No code returns signals in priority order
- **Action**: Implement `get_signals_ordered_by_priority()`

### Signal Overrides: ⚠️ Partially Implemented

**File**: `backend/signals/overrides.py`

**Status**: Class exists but **never used in projection building**

- `OverrideEngine` class defined
- Has 5-level priority hierarchy
- But: Not called during `ProjectionBuilder`

### Decision Snapshots: ❌ Never Used

**Schema**: Exists in `migrations.py` (003)

```sql
CREATE TABLE operational_decision_snapshots (
    snapshot_id BIGINT PRIMARY KEY,
    player_id VARCHAR,
    game_id VARCHAR,
    slate_id VARCHAR,
    override_level INT,
    decision VARCHAR,
    applied_at TIMESTAMP,
    inputs_hash VARCHAR,
    ...
);
```

**Usage**: Zero—no code populates this table

**Intent**: Record which signals influenced which projections at decision time

**Action**: Populate during projection build

---

## STEP 3: STARTING LINEUP LOGIC VERIFICATION

### Intended Design (✓ Correct in Concept)

Starter status should:

1. **Expand opportunity** (minutes ceiling +4)
2. **Expand usage** (touches ceiling)
3. **Increase volatility** (wider distribution)
4. **NOT change efficiency** (no per-minute boost)

### Current Implementation (⚠️ Correct Logic, ❌ Not Used)

**File**: `backend/derive/modifiers.py`

```python
if isinstance(signal, ConfirmedStarterSignal):
    modifiers.starter_minutes_adjustment = 4  # ✓ Correct
    modifiers.minutes_ceiling_final += 4      # ✓ Correct
    # Usage scales by ceiling ratio, NOT independent boost
    modifiers.usage_ceiling_final = baseline_usage * ceiling_ratio  # ✓ Correct
```

**Verification**: All correct. ✓

### NBA/NFL Position Handling: ❌ Not Verified

**Missing Checks**:

1. Is starter boost applied differently by position?
2. Are defensive-only starters handled correctly?
3. Are NFL position-specific opportunity models used?

**Action**: Verify position-specific logic in features.py

---

## STEP 4: TEMPORAL INTELLIGENCE CHECK

**Status**: ❌ Not Fully Implemented

### What's Missing:

1. **No Projection Builder Implements "Build As-Of Time"**
   - `ProjectionStore` has `get_for_slate(..., as_of_time)` but
   - No code that **builds** projections at historical time T
   - **Action**: Create `ProjectionBuilder.build_at_time(slate_id, as_of_time)`

2. **No Feature Snapshots**
   - Features computed on-the-fly
   - Not stored with timestamps
   - Cannot replay historical features
   - **Action**: Create feature snapshots table

3. **No Inputs Hash Computation**
   - `ProjectionDistribution.inputs_hash` field exists but never populated
   - **Action**: Implement deterministic hash of all inputs

4. **No Decision Snapshots**
   - Table exists, never populated
   - **Action**: Populate during projection build

5. **No Temporal Signal Queries**
   - Cannot fetch "signals active at time T for player X"
   - **Action**: Implement temporal signal retrieval

---

## STEP 5: SELF-CORRECTION LOOP VERIFICATION

**Status**: ⚠️ Partially Implemented, Not Connected

### What Works:

✅ Accuracy computation (RMSE, MAE, hit_rate, bias)
✅ Source reliability tracking (in memory)
✅ Upweight/downweight methods

### What's Missing:

❌ Source reliability **persistence** (stored in-memory, not in DB)
❌ Source reliability **loading** (not fetched from DB on startup)
❌ Source weights **applied in projection** (not fetched/used)
❌ Feedback loop **orchestration** (no code wires post-slate → weight update → next build)

### Missing Pipeline:

```
Post-Game (Currently Missing):
  1. Fetch projections for slate
  2. Fetch actual results
  3. Compute accuracies
  4. Group by source
  5. Compute source reliability
  6. Update evaluation_source_reliability table  ← Missing
  7. Return recommendations

Next Projection Build (Currently Missing):
  1. Fetch source reliability scores from DB  ← Missing
  2. Apply weights to baseline selection
  3. Build projections with weighted inputs
  4. Store updated projections
```

---

## SUMMARY TABLE: GAP ANALYSIS

| Component              | Category            | Status        | Evidence                                                  | Action Required                                     |
| ---------------------- | ------------------- | ------------- | --------------------------------------------------------- | --------------------------------------------------- |
| **4-Tier Schema**      | ARCHITECTURE        | ✅ Correct    | All 4 tiers properly partitioned in migrations.py         | None                                                |
| **RAW Tier**           | DATA MODEL          | ✅ Correct    | Immutable, file_hash dedup, JSON preserved                | None                                                |
| **DERIVED Tier**       | DATA MODEL          | ✅ Correct    | Canonical dimensions, fact tables                         | Add dimension versioning (SCD Type 2)               |
| **OPERATIONAL Tier**   | DATA MODEL          | ⚠️ Incomplete | Schema correct, decision_snapshots never populated        | Populate decision_snapshots during projection build |
| **EVALUATION Tier**    | DATA MODEL          | ⚠️ Incomplete | Schema correct, bias table population unclear             | Implement bias computation & persistence            |
| **Signal Spec**        | SIGNALS             | ✅ Correct    | All fields present, decay/validity, scope                 | None                                                |
| **Signal Storage**     | SIGNALS             | ✅ Correct    | Schema supports temporal queries                          | None                                                |
| **Signal Retrieval**   | SIGNALS             | ❌ Missing    | No time-range queries, no decay application               | Implement temporal signal queries                   |
| **Signal Enforcement** | SIGNALS             | ❌ Missing    | Signals stored, never fetched in projection build         | Wire signal retrieval into projection builder       |
| **Signal Overrides**   | SIGNALS             | ❌ Missing    | Engine exists, never used                                 | Call OverrideEngine in projection builder           |
| **Starter Logic**      | STARTER OPPORTUNITY | ✅ Correct    | Opportunity expansion (not efficiency), correct modifiers | Verify position-specific handling                   |
| **Temporal Build**     | TEMPORAL            | ❌ Missing    | No code builds projections "as_of time T"                 | Implement ProjectionBuilder.build_at_time()         |
| **Feature Snapshots**  | TEMPORAL            | ❌ Missing    | Features computed on-the-fly, not stored                  | Create feature_snapshots table & populate           |
| **Inputs Hash**        | TEMPORAL            | ⚠️ Missing    | Field exists, never computed                              | Implement deterministic hash computation            |
| **Decision Snapshots** | TEMPORAL            | ❌ Missing    | Table exists, never populated                             | Populate during projection build                    |
| **Accuracy Metrics**   | EVALUATION          | ✅ Correct    | RMSE, MAE, hit_rate, bias computed correctly              | None                                                |
| **Source Reliability** | EVALUATION          | ⚠️ Incomplete | Tracked in memory, not persisted to DB                    | Persist reliability to database                     |
| **Source Weighting**   | EVALUATION          | ❌ Missing    | Scores computed, never applied to next build              | Apply weights in projection builder                 |
| **Feedback Loop**      | SELF-CORRECTION     | ❌ Missing    | No orchestration, no wiring                               | Create feedback loop pipeline                       |

---

## CATEGORIZED BY ACTION TYPE

### ✅ IMPLEMENTED CORRECTLY (No Changes Needed)

1. 4-tier schema (RAW/DERIVED/OPERATIONAL/EVALUATION)
2. Signal specification (all fields, decay, validity)
3. Signal storage (schema supports temporal queries)
4. Starter opportunity logic (correctly expands ceiling, not efficiency)
5. Accuracy computation (RMSE, MAE, hit_rate, bias all correct)

### ⚠️ IMPLEMENTED BUT INCOMPLETE (Targeted Fixes Needed)

1. **Signal Retrieval**: Schema correct, but no time-range query methods
2. **Source Reliability**: Tracks correctly, but doesn't persist to DB
3. **Decision Snapshots**: Table exists, never populated
4. **Feature Handling**: Computed correctly, but not stored for reproducibility
5. **Inputs Hash**: Field exists, never computed

### ❌ MISSING CRITICAL LOGIC (Must Implement)

1. **Temporal Projection Building**: No code builds projections "as_of time T"
2. **Signal Enforcement**: Signals never fetched during projection build
3. **Signal Override Application**: OverrideEngine never called
4. **Feedback Loop Orchestration**: Post-game → weight update → next build not wired
5. **Feature Snapshots**: Features not stored with version/timestamp
6. **Source Weight Application**: Reliability scores never used in next build

### 🔧 NEEDS REFACTOR (Not Rewrite, Just Wiring)

1. **Starter Signals**: Should use `operational_lineups` table consistently
2. **Signal Decay**: Applied in SignalSpec but not when retrieving
3. **Projection Builder**: Needs to fetch signals, apply them, store decision snapshot
4. **Source Reliability Persistence**: Add DB serialization/deserialization

---

## NEXT ACTIONS (STEP 6 WILL ADDRESS)

Once audit complete, fixes will be sequenced as:

**Phase 1 — Critical Path (Minimal, Focused)**

- Wire signal retrieval into projection building
- Populate decision snapshots
- Persist source reliability to database
- Create feedback loop orchestrator

**Phase 2 — Reproducibility**

- Implement inputs_hash computation
- Create feature snapshots table
- Implement temporal projection building

**Phase 3 — Polish**

- Implement dimension versioning (SCD Type 2)
- Implement bias computation
- Add position-specific starter handling

---

**END OF AUDIT**

This audit is complete. Awaiting instruction to proceed to STEP 2 detailed fixes (if requested) or STEP 6 implementation plan.
