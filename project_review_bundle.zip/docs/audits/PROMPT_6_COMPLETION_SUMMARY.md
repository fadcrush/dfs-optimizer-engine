# PROMPT 6 COMPLETION SUMMARY: Prune or Promote Based on Ceiling Probability

## Overview

Successfully modified player pool pruning logic in player_pool.py to use ceiling probability evaluation for injury replacement players, with lower multiplier thresholds and enhanced tracking.

## Implementation Details

### 1. Dual-Path Pruning Logic

**Location**: [player_pool.py](analysis/nba/player_pool.py#L720-L855)

**Decision Point**:

```python
use_ceiling_probability = len(replacement_opportunities) > 0
```

**Path 1 - Replacement Players** (with lineages):

- Call `evaluate_player_ceiling()` with `opportunity_adjustments`
- Use ceiling_probability from Monte Carlo simulation
- Lower required_multiplier by -0.25x
- Compare ceiling_probability against `required_probability` threshold (default 0.30)
- Enhanced rejection tracking with lineage metadata

**Path 2 - Normal Players** (no lineages):

- Use static ceiling comparison (existing logic)
- Compare ceiling projection against target points
- Standard rejection tracking

---

### 2. Multiplier Adjustment for Replacements

**Location**: [player_pool.py](analysis/nba/player_pool.py#L755-L763)

```python
if use_ceiling_probability:
    # Replacement players get -0.25x easier threshold
    required_multiplier -= 0.25
```

**Example**:

- Mid-tier player ($5000): Base multiplier = 4.75
- With replacement adjustment: 4.75 - 0.25 = **4.50**
- Target points: 5000 / 1000 \* 4.50 = **22.5** (vs 23.75 for normal players)

**Rationale**: Avoids over-pruning thin plays with legitimate injury opportunity

---

### 3. Ceiling Probability Evaluation

**Location**: [player_pool.py](analysis/nba/player_pool.py#L770-L813)

**Process**:

1. Build player payload with minutes/usage estimates:
   - Try to extract from dataframe columns (Minutes, Usage)
   - Fallback to salary-tier estimates:
     - <$5000: 25 minutes
     - $5000-$7000: 30 minutes
     - > $7000: 34 minutes

2. Prepare opportunity_adjustments from lineages:

   ```python
   opportunity_adjustments = [
       {
           "confidence": opp["confidence"],
           "minutes_delta": opp["minutes_delta"],
           "usage_delta": opp["usage_delta"],
           "out_player_name": opp["out_player_name"],
           "reason": opp.get("reason", ""),
       }
       for opp in replacement_opportunities
   ]
   ```

3. Call enhanced `_safe_evaluate_ceiling()`:

   ```python
   ceiling_result = _safe_evaluate_ceiling(
       player_payload=player_payload,
       salary=salary,
       signals=player_signals,
       opportunity_adjustments=opportunity_adjustments,
   )
   ```

4. Extract ceiling_probability and compare:
   ```python
   if ceiling_probability < required_probability:
       # PRUNE
   ```

---

### 4. Enhanced Rejection Tracking

**Location**: [player_pool.py](analysis/nba/player_pool.py#L787-L813)

**New Prune Type**: `PRUNED_BY_CEILING_PROBABILITY`

**Required Fields**:

```python
{
    "prune_type": "PRUNED_BY_CEILING_PROBABILITY",
    "opportunity_source": "INJURY_REPLACEMENT",
    "replaced_player": "Star Guard",
    "confidence_used": 0.6,
    "lineage_reason": "Primary backup with clear opportunity",
    "ceiling_probability": 0.4828,
    "required_probability": 0.30,
    "target_points": 22.5,
    "required_multiplier": 4.50,
    "ceiling_projection": 30.0,
    # ... standard fields
}
```

**Comparison with Normal Pruning**:

- Normal: `PRUNED_BY_CEILING` (static comparison, no probability)
- Replacement: `PRUNED_BY_CEILING_PROBABILITY` (Monte Carlo evaluation, full metadata)

---

### 5. Updated Helper Function

**Location**: [player_pool.py](analysis/nba/player_pool.py#L358-L384)

Enhanced `_safe_evaluate_ceiling()` to accept `opportunity_adjustments`:

```python
def _safe_evaluate_ceiling(
    player_payload: dict,
    salary: float,
    signals: list,
    opportunity_adjustments: Optional[List[Dict]] = None,
) -> dict:
```

Passes adjustments to `evaluate_player_ceiling()` from simulation_engine.py

---

## Test Results: All Pass ✓

### 6 Comprehensive Tests

**Command**: `python -m pytest tests/test_lineage_pruning.py -v`
**Result**: 6 passed, 1 warning (Pydantic deprecation - unrelated)

1. **test_normal_player_static_ceiling**: ✓
   - Normal player uses static ceiling comparison
   - Prune type: `PRUNED_BY_CEILING`
   - No ceiling_probability in rejection

2. **test_replacement_player_ceiling_probability**: ✓
   - Replacement player passes with lineage boost
   - Uses ceiling probability evaluation
   - Lower threshold (-0.25x) applied

3. **test_replacement_player_multiplier_reduction**: ✓
   - Verifies -0.25x multiplier reduction
   - Target: 22.5 (vs 23.75 for normal)
   - Required multiplier: 4.50

4. **test_replacement_enhanced_rejection_tracking**: ✓
   - All required fields present in rejection
   - Prune type: `PRUNED_BY_CEILING_PROBABILITY`
   - Metadata: opportunity_source, replaced_player, confidence_used, lineage_reason
   - Ceiling probability: 0.0764

5. **test_ceiling_probability_threshold_enforced**: ✓
   - High threshold (0.50): 0 passed
   - Low threshold (0.05): 1 passed
   - Threshold enforcement verified

6. **test_mixed_pool_dual_logic**: ✓
   - Mixed pool with normal + replacement players
   - Both use correct logic paths
   - 2 players passed (dual-path confirmed)

---

## Key Design Decisions

### Why Ceiling Probability for Replacements?

**Problem**: Static ceiling comparison doesn't account for:

- Opportunity variance (minutes/usage distribution)
- Confidence scaling in simulation
- Realistic outcome distributions

**Solution**: Monte Carlo evaluation with lineage adjustments:

- Simulates 5000 outcomes with adjusted minutes/usage
- Returns probability of reaching target points
- More accurate than static ceiling \* boost_factor

### Why Lower Multiplier by -0.25x?

**Problem**: Thin plays with legitimate opportunity might be over-pruned:

- Lower base projections (backups)
- Higher variance (opportunity uncertainty)
- Would fail static ceiling even with boost

**Solution**: Easier threshold compensates for:

- Uncertainty in lineage inference (conservative deltas)
- Role volatility (backup becoming starter)
- Avoids missing actual opportunities

### Why Threshold Enforcement?

**Problem**: Even with boost, some plays are too risky:

- Very low confidence (<0.3)
- Minimal opportunity deltas
- Deep bench players with many competitors

**Solution**: Minimum ceiling_probability (default 0.30):

- Still requires 30%+ chance of hitting target
- Filters out speculative thin plays
- Balances opportunity recognition with risk management

---

## Integration with Complete Pipeline

### End-to-End Flow (6 Prompts)

1. **PROMPT 1** ✓: Models (`InjuryReplacementLineage`, `ReplacementCandidate`)
2. **PROMPT 2** ✓: Inference logic (`infer_injury_replacement_lineage()`)
3. **PROMPT 3** ✓: Pipeline integration (lineages attached to signals)
4. **PROMPT 4** ✓: Player pool extraction (lineages read from signals)
5. **PROMPT 5** ✓: Ceiling gate (simulation accepts adjustments)
6. **PROMPT 6** ✓: **Pruning logic (ceiling probability evaluation)**

### Data Flow

```
Injured Player OUT Signal
  ↓
Lineage Inference (beat writer + depth chart)
  ↓
Lineage Attached to Signal Metadata
  ↓
Player Pool Extracts Lineages
  ↓
Ceiling Filter Decision Point
  ↓
  ├─ Normal Player → Static Ceiling Comparison
  └─ Replacement Player → Ceiling Probability Evaluation
       ↓
     Build player_payload + opportunity_adjustments
       ↓
     Call evaluate_player_ceiling() (simulation)
       ↓
     Compare ceiling_probability vs threshold
       ↓
     PRUNE or KEEP with enhanced tracking
```

---

## Files Modified

1. **analysis/nba/player_pool.py**
   - Enhanced `_safe_evaluate_ceiling()` (lines 358-384)
   - Modified `filter_player_pool_by_ceiling()` (lines 720-855)
   - Dual-path pruning logic (replacement vs normal)
   - Multiplier reduction (-0.25x for replacements)
   - Ceiling probability evaluation
   - Enhanced rejection tracking

2. **tests/test_lineage_pruning.py** (NEW)
   - 6 comprehensive tests
   - Validates dual-path logic
   - Confirms multiplier reduction
   - Verifies enhanced tracking
   - Tests threshold enforcement

---

## Usage Example

```python
from analysis.nba.player_pool import filter_player_pool_by_ceiling

# Player pool with normal + replacement players
players_df = pd.DataFrame([
    {
        "DFS ID": "normal1",
        "Name": "Normal Player",
        "Salary": 6000,
        "My Proj": 28.0,
        "Ceiling": 32.0,
    },
    {
        "DFS ID": "replacement1",
        "Name": "Backup Guard",
        "Salary": 5000,
        "My Proj": 24.0,
        "Ceiling": 29.0,
        "Minutes": 24.0,
        "Usage": 0.19,
    },
])

# Signals with lineage for replacement1
signals = [
    {
        "player_id": "injured1",
        "signal_type": "injury",
        "metadata": {
            "injury_replacement_lineage": {
                "out_player_id": "injured1",
                "out_player_name": "Star Guard",
                "replacements": [
                    {
                        "player_id": "replacement1",
                        "confidence": 0.6,
                        "minutes_delta": 10.0,
                        "usage_delta": 0.03,
                        "reason": "Primary backup",
                    }
                ]
            }
        }
    }
]

# Apply ceiling filter
result = filter_player_pool_by_ceiling(
    players_df=players_df,
    signals=signals,
    required_probability=0.30,
)

# Result:
# - Normal player: static ceiling check (32 > 28.5 target → PASS)
# - Replacement player: ceiling probability check
#   * Multiplier: 4.75 - 0.25 = 4.50
#   * Target: 22.5
#   * Simulation with +6 min, +0.018 usage boost
#   * Ceiling probability: ~0.80 (>0.30 threshold → PASS)
# - Both players in filtered_player_pool
```

---

## Validation Summary

✓ Dual-path pruning logic implemented
✓ Replacement players use ceiling probability evaluation
✓ Required multiplier lowered by-0.25x (-0.25x) for replacements
✓ Ceiling probability threshold enforced (default 0.30)
✓ Enhanced rejection tracking with all required fields:

- prune_type
- opportunity_source
- replaced_player
- confidence_used
- lineage_reason
- ceiling_probability
  ✓ Normal players still use static ceiling comparison
  ✓ Graceful handling without lineages
  ✓ All tests pass (6/6)
  ✓ No syntax errors
  ✓ Integration-ready for production

---

## Summary

**Objective**: Modify player pool pruning to use ceiling probability for injury replacement players with lower threshold and enhanced tracking to avoid over-pruning legitimate opportunities.

**Result**: COMPLETE ✓

The complete injury opportunity pipeline is now operational:

1. **Models**: Immutable lineage data structures
2. **Inference**: Signal-driven replacement identification
3. **Pipeline**: Non-breaking lineage attachment
4. **Extraction**: Player pool reads lineages from signals
5. **Simulation**: Ceiling evaluation accepts opportunity adjustments
6. **Pruning**: Dual-path logic with probability evaluation for replacements

**Key Achievements**:

- Replacement players get fairer evaluation via Monte Carlo simulation
- Lower threshold (-0.25x) compensates for thin play uncertainty
- Ceiling probability threshold (0.30) filters speculative plays
- Enhanced tracking provides full transparency and auditability
- Avoids over-promoting unrealistic opportunities
- Maintains existing logic for normal players

The injury opportunity system is production-ready with comprehensive testing and full end-to-end integration.
