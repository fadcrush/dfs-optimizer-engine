# DFS Edge Pro — Operations Guide

This document covers day-to-day operations, incident response, and maintenance.

---

## Health Monitoring

### Endpoints

| Endpoint                  | Use                            |
| ------------------------- | ------------------------------ |
| `GET /api/health`         | Load balancer liveness probe   |
| `GET /api/health/db`      | Schema / Alembic version check |
| `GET /api/health/metrics` | Run counters, uptime           |

### Interpreting `/api/health/db`

```json
{
  "status": "ok", // "ok" | "degraded" | "error"
  "connection": "ok",
  "missing_tables": [], // Non-empty = migration not applied
  "alembic_revision": "a1b2c3d4"
}
```

If `status` is `degraded` or `error`:

1. Check `docker compose ps postgres` — is it healthy?
2. Run `docker compose run --rm backend alembic -c alembic.ini upgrade head`
3. Restart backend: `docker compose restart backend`

---

## Log Management

Logs are JSON to stdout:

```bash
# Stream live logs
docker compose logs -f backend worker

# Filter errors only
docker compose logs backend | jq 'select(.level == "ERROR")'

# Filter by run_id
docker compose logs worker | jq 'select(.run_id == "abc123")'

# Count slow requests (>1s)
docker compose logs backend | jq 'select(.duration_ms > 1000) | .path' | sort | uniq -c
```

Each log record includes `request_id` — use this to correlate frontend errors
with backend logs.

---

## Database Maintenance

### Backup

```bash
# Manual backup
docker compose exec postgres \
  pg_dump -U dfs dfs_db | gzip > backups/dfs_$(date +%Y%m%d_%H%M).sql.gz

# Automated backup (add to cron)
0 3 * * * docker compose -f /opt/dfs/docker-compose.yml exec -T postgres \
  pg_dump -U dfs dfs_db | gzip > /opt/dfs/backups/dfs_$(date +%Y%m%d).sql.gz
```

### Vacuum / bloat

```bash
docker compose exec postgres psql -U dfs -d dfs_db -c "VACUUM ANALYZE;"
```

### Query performance

```bash
# Check slow queries
docker compose exec postgres psql -U dfs -d dfs_db -c "
  SELECT query, mean_exec_time, calls
  FROM pg_stat_statements
  ORDER BY mean_exec_time DESC LIMIT 20;
"
```

---

## Upload Cleanup

Uploaded CSV files are automatically purged at startup for files older
than `UPLOAD_MAX_AGE_HOURS` (default 24h).

To run manually:

```bash
docker compose run --rm backend python -m tasks.cleanup_tasks
```

To change the age threshold:

```bash
UPLOAD_MAX_AGE_HOURS=48 docker compose run --rm backend python -m tasks.cleanup_tasks
```

---

## Worker Operations

### Restart workers

```bash
docker compose restart worker
```

### Scale workers (PostgreSQL only — not DuckDB)

```bash
docker compose up --scale worker=3 -d
```

### Check queue depth (Redis)

```bash
docker compose exec redis redis-cli LLEN "dramatiq:optimizer.msgs"
```

### Drain queue (emergency)

```bash
docker compose exec redis redis-cli DEL "dramatiq:optimizer.msgs"
```

---

## Incident Runbook

### Runs stuck in "queued"

1. Check worker is running: `docker compose ps worker`
2. Check Redis: `docker compose exec redis redis-cli ping`
3. Check queue depth: `docker compose exec redis redis-cli LLEN "dramatiq:optimizer.msgs"`
4. Restart worker: `docker compose restart worker`
5. If Redis queue is empty but runs are queued → runs were created before worker started.
   Manually resubmit via `POST /api/runs`.

### Alembic version mismatch on startup

```
RuntimeError: DB_REQUIRED=true but alembic_version is missing or empty.
```

Fix:

```bash
docker compose run --rm backend alembic -c alembic.ini upgrade head
docker compose restart backend
```

### DuckDB file lock error

```
duckdb.IOException: Could not set lock on file ... (DUCKDB_FILE_LOCK)
```

Fix: only one process may open a file-based DuckDB.

```bash
# Ensure single worker
docker compose up --scale worker=1
# Or switch to in-memory DuckDB for testing:
DATABASE_URL=duckdb:///:memory: docker compose up backend
```

### Frontend CORS error

```
Access to fetch at 'https://api.domain.com/api/runs'
from origin 'https://app.domain.com' has been blocked by CORS policy
```

Fix: add your frontend domain to `ALLOWED_ORIGINS` and restart:

```bash
# In .env:
ALLOWED_ORIGINS=https://app.domain.com,http://localhost:3000
docker compose restart backend
```

### High exposure query latency

Check that the denormalised indexes exist:

```sql
SELECT indexname FROM pg_indexes
WHERE tablename = 'lineup_entries';
-- Expected: ix_lineup_entries_lineup_id, ix_lineup_entries_player_id, ix_lineup_entries_slate_id
```

If missing, re-run migrations: `alembic upgrade head`.

---

## Migrations

### Apply

```bash
docker compose run --rm backend alembic -c alembic.ini upgrade head
```

### Rollback one step

```bash
docker compose run --rm backend alembic -c alembic.ini downgrade -1
```

### Generate new migration

```bash
docker compose run --rm backend alembic -c alembic.ini revision \
  --autogenerate -m "add_new_column"
# Review the generated file in backend/alembic/versions/ before applying.
```

### Check for pending changes

```bash
docker compose run --rm backend alembic -c alembic.ini check
# "No new upgrade operations detected" = schema is in sync
```

---

## Performance Tuning

### PostgreSQL connection pool

The default SQLAlchemy pool is 5 connections. Increase for high-concurrency:

```python
# backend/src/database/db.py
engine = create_engine(url, pool_size=10, max_overflow=20)
```

### Optimizer memory

The LP solver is memory-intensive for large slates (200+ players).
Reduce `num_lineups` or increase container memory:

```yaml
# docker-compose.yml
worker:
  mem_limit: 2g
```

### Exposure aggregate query

Exposure is computed with `GROUP BY player_id` in a single SQL query
(not N+1) via `_exposure_from_db()` in `routers/results.py`.
If it's slow, verify the `ix_lineup_entries_lineup_id` index exists.

---

## Useful Commands Reference

```bash
# Full stack restart
docker compose down && docker compose up -d

# View all container statuses
docker compose ps

# Run pipeline smoke test
python scripts/verify_pipeline.py

# Drop into backend shell
docker compose run --rm backend python

# Run tests
docker compose run --rm backend \
  bash -c "cd /app && PYTHONPATH=src pytest tests/ -q --ignore=tests/test_simulation_engine.py"

# Check Alembic current revision
docker compose run --rm backend alembic -c alembic.ini current

# List Dramatiq queues
docker compose exec redis redis-cli KEYS "dramatiq:*"
```
