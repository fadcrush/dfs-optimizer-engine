# API Integration Guide

This guide covers the external API integrations used by DFS Edge Pro.

## Quick Setup

1. Copy `.env.example` to `.env`
2. Add your API keys
3. Run the test script to verify: `python scripts/utilities/test_api_connections.py`

---

## The Odds API (Vegas Lines)

### Purpose
- Real-time Vegas betting lines for NBA/NFL games
- Game totals (over/under) - **the #1 predictor of fantasy scoring**
- Point spreads for implied team totals
- Moneylines for game context

### Sign Up
1. Go to [https://the-odds-api.com/](https://the-odds-api.com/)
2. Create a free account (no credit card required)
3. Copy your API key from the dashboard

### Free Tier Limits
- **500 requests per month**
- Sufficient for ~16 slates per month (assuming 30 requests per slate)

### Usage in Code
```python
from backend.services.vegas_service import VegasOddsService

service = VegasOddsService()
games = service.get_nba_odds()

for game in games:
    print(f"{game['away_team']} @ {game['home_team']}")
    print(f"  Total: {game['total']}")
    print(f"  Implied: {game['away_implied_points']} | {game['home_implied_points']}")
```

### How We Use It
- **Projection Adjustment**: Players on teams with high implied totals get boosted projections
- **Game Environment**: High total games (230+) indicate shootout potential
- **Stacking**: We prioritize stacking players from high-total games

---

## SportsData.io (Player Data & Injuries)

### Purpose
- Real-time injury updates
- Player rosters and info
- Live game stats (optional)
- Historical game logs (optional)

### Sign Up
1. Go to [https://sportsdata.io/](https://sportsdata.io/)
2. Create a free account
3. Subscribe to NBA (and/or NFL) API
4. Copy your API key

### Free Tier Limits
- **1,000 requests per month** (may vary by plan)
- Sufficient for daily injury checks

### Usage in Code
```python
from backend.services.injury_service import InjuryService

service = InjuryService()
injuries = await service.get_current_injuries()

for player in injuries:
    print(f"{player['name']}: {player['status']} ({player['injury']})")
```

### How We Use It
- **Injury Adjustments**: Reduce projections for injured players
  - OUT: 0% of projection
  - Doubtful: 20% of projection
  - Questionable: 70% of projection
  - Probable: 90% of projection
- **Beneficiary Detection**: Identify players who gain usage when starters are out

---

## NBA Stats API (Free - No Key Required)

### Purpose
- Historical player game logs
- Advanced stats (usage, efficiency)
- Schedule information

### Usage in Code
```python
from nba_api.stats.endpoints import playergamelog

# Get Luka Doncic's game log
log = playergamelog.PlayerGameLog(player_id=1629029)
df = log.get_data_frames()[0]
```

### Notes
- No API key required
- Rate limited (be respectful)
- We use `nba_api` Python package

---

## OpenWeather API (Optional - NFL Only)

### Purpose
- Weather conditions for outdoor NFL games
- Wind, temperature, precipitation

### Sign Up
1. Go to [https://openweathermap.org/api](https://openweathermap.org/api)
2. Create a free account
3. Copy your API key

### Free Tier Limits
- **1,000 calls per day**
- More than enough for NFL slates

### How We Use It
- Wind >15mph: Reduce passing projections
- Cold weather: Adjust game flow expectations
- Rain/snow: Increase run game projections

---

## Testing Your API Connections

Run the test script to verify all APIs are working:

```bash
python scripts/utilities/test_api_connections.py
```

Expected output:
```
=== API Connection Tests ===

[1] The Odds API (Vegas Lines)
    Status: CONNECTED
    Games found: 7 NBA games

[2] SportsData.io (Injuries)
    Status: CONNECTED
    Injuries found: 45 records

[3] NBA Stats API
    Status: CONNECTED (no key required)

[4] OpenWeather API
    Status: NOT CONFIGURED (optional)

All required APIs are connected!
```

---

## API Usage Best Practices

### Rate Limiting
- Cache API responses (especially Vegas odds)
- Don't call APIs on every page refresh
- The system has built-in caching (15-minute default)

### Error Handling
- All services gracefully handle API failures
- Fallback to cached data when APIs are down
- Projections still work without Vegas data (just less accurate)

### Cost Management
- Monitor your API usage in each provider's dashboard
- Free tiers are sufficient for personal use
- Consider paid plans for high-volume usage

---

## Troubleshooting

### "No API key found"
- Check your `.env` file exists
- Verify key names match exactly (case-sensitive)
- Restart the application after changing `.env`

### "API returned 401/403"
- API key is invalid or expired
- Check your subscription status
- Regenerate key if needed

### "API returned 429"
- Rate limit exceeded
- Wait a few minutes and retry
- Consider caching more aggressively

### No data returned
- Off-season (no games scheduled)
- API service is down (check status page)
- Network/firewall issues
