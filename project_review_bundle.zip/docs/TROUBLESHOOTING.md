# docs/TROUBLESHOOTING.md

# DFS Edge Pro — Troubleshooting Guide

Common failure patterns, root causes, and recovery procedures.

---

## Quick Reference

| Symptom | Most likely cause | Jump to |
|---------|------------------|---------|
| 503 on all endpoints | DB schema missing | [DB Not Ready](#db-not-ready) |
| Run stuck in `running` | Worker crash | [Stale Run Recovery](#stale-run-recovery) |
| Run stays `queued` | Worker not running | [Worker Not Processing](#worker-not-processing) |
| `alembic upgrade head` fails | Migration conflict | [Migration Issues](#migration-issues) |
| `verify_pipeline.py` fails at ownership | `slate_id` mismatch | [Ownership Upload Fails](#ownership-upload-fails) |
| Optimizer timeout (504) | Too many lineups / slow DB | [Optimizer Timeout](#optimizer-timeout) |
| Frontend shows no lineups | Wrong run_id or status | [Frontend Data Issues](#frontend-data-issues) |
| DuckDB "file locked" error | Multiple workers | [DuckDB Lock Error](#duckdb-lock-error) |

---

## DB Not Ready

**Symptom:** `GET /api/health/db` returns `status='degraded'` or `missing_tables` is non-empty.

**Cause:** Alembic migrations have not been applied.

**Fix:**
```bash
cd backend
alembic upgrade head
# Verify
curl http://localhost:8000/api/health/db
```

If `alembic_version` table is present but `missing_tables` is non-empty, the migration
partially completed. Check `alembic history --verbose` for the revision chain.

---

## Stale Run Recovery

**Symptom:** Run stuck in `running` status after worker restart. Status never reaches `completed`.

**Cause:** Worker process was killed mid-job without cleanup.

**Automatic fix:** Recovery runs automatically at every backend startup.
```
# Startup logs will show:
Stale run recovery: 1 run(s) marked failed: ['<run_id>']
```

**Manual fix:**
```bash
# Mark stale runs failed via SQL
psql $DATABASE_URL -c "
  UPDATE runs
  SET status='failed',
      error_message='manual recovery',
      completed_at=NOW()
  WHERE status='running'
    AND started_at < NOW() - INTERVAL '15 minutes';"
```

**Configure threshold:**
```bash
export STALE_RUN_THRESHOLD_MINUTES=15  # default
```

---

## Worker Not Processing

**Symptom:** Runs created but they sit in `queued` status indefinitely.

**Cause:** Dramatiq worker is not running, or Redis is not reachable.

**Diagnosis:**
```bash
redis-cli -u $REDIS_URL PING          # Must return PONG
redis-cli -u $REDIS_URL LLEN optimizer # > 0 means jobs queued
```

**Fix:**
```bash
# Start the worker
cd backend
python -m dramatiq tasks.optimizer_tasks --processes 1 --threads 2

# Or via Docker Compose
docker compose up -d worker
```

---

## Migration Issues

**Symptom:** `alembic upgrade head` fails with "table already exists" or "conflict".

**Diagnosis:**
```bash
cd backend
alembic current          # Show current DB revision
alembic history          # Show all revisions
alembic heads            # Show head revision(s)
```

**Fix (development only — never on production with data):**
```bash
# Reset to clean state
alembic downgrade base
alembic upgrade head
```

**Fix (production — preserve data):**
1. Identify the conflicting migration
2. Check `alembic_version` table directly
3. Manually stamp the DB to a safe state: `alembic stamp <revision>`
4. Re-run `alembic upgrade head`

---

## Ownership Upload Fails

**Symptom:** `POST /api/ownership/upload-to-db` returns `matched=0`.

**Causes:**
- Wrong `slate_id` query parameter
- Player names in ownership CSV don't match player names in projections CSV
- Ownership CSV uploaded before projections CSV

**Fix:**
1. Upload projections first: `POST /api/projections/upload-slate-to-db`
2. Copy `slate_id` from the response
3. Upload ownership: `POST /api/ownership/upload-to-db?slate_id=<from_step_1>`
4. Check player name format — try exact match first, then fuzzy

---

## Optimizer Timeout

**Symptom:** `POST /api/runs` returns 504 with "Optimizer did not finish within Xs".

**Causes:**
- Too many lineups requested for the time limit
- PuLP/CBC not installed; optimizer using slow fallback
- DB write bottleneck

**Fix:**
```bash
# Increase timeout
export OPTIMIZER_TIMEOUT_SECONDS=600   # 10 min

# Use async mode to avoid HTTP timeout
# POST /api/runs with "async_mode": true
# Then poll GET /api/runs/{run_id}/status
```

**Verify PuLP/CBC installation:**
```bash
python -c "import pulp; print(pulp.listSolvers(onlyAvailable=True))"
# Should include: ['PULP_CBC_CMD']
```

---

## Frontend Data Issues

**Symptom:** Frontend shows empty lineups or exposure table.

**Fix steps:**
1. Confirm run status is `completed`: `GET /api/runs/{run_id}/status`
2. Confirm lineups exist: `GET /api/results/{run_id}/lineups`
3. Confirm exposure data: `GET /api/results/{run_id}/exposure`
4. Check browser console for 404/CORS errors

**CORS errors:**
```bash
# Add frontend origin to allowed list
export ALLOWED_ORIGINS="http://localhost:3000,https://yourdomain.com"
```

---

## DuckDB Lock Error

**Symptom:** `RuntimeError: DuckDB file-based database cannot be used with multiple workers`.

**Cause:** `DATABASE_URL` points to a DuckDB file and `WEB_CONCURRENCY > 1`.

**Fix (production):** Use PostgreSQL:
```bash
export DATABASE_URL=postgresql://user:pass@host:5432/dfs_edge
```

**Fix (local dev):** Force single worker:
```bash
export WEB_CONCURRENCY=1
# Or use in-memory DuckDB (no persistence):
export DATABASE_URL=duckdb:///:memory:
# Or use file but single process:
export USE_DUCKDB_FALLBACK=true
```

---

## Log Analysis

**Find all failed runs in logs:**
```bash
tail -f logs/api.log | python -c "
import sys, json
for line in sys.stdin:
    try:
        r = json.loads(line)
        if 'fail' in r.get('msg','').lower() or r.get('level') == 'ERROR':
            print(line.rstrip())
    except: pass
"
```

**Find slow requests (> 1000ms):**
```bash
grep '"duration_ms"' logs/api.log | python -c "
import sys, json
for line in sys.stdin:
    try:
        r = json.loads(line)
        if r.get('duration_ms', 0) > 1000:
            print(f'{r[\"duration_ms\"]:.0f}ms  {r.get(\"path\",\"?\")}')
    except: pass
"
```

---

## Recovery Procedures

### Full system recovery after outage

```bash
# 1. Verify infrastructure
psql $DATABASE_URL -c "SELECT 1"
redis-cli -u $REDIS_URL PING

# 2. Apply any pending migrations
cd backend && alembic upgrade head

# 3. Start API (stale run recovery runs automatically)
uvicorn main:app --host 0.0.0.0 --port 8000

# 4. Start worker
python -m dramatiq tasks.optimizer_tasks --processes 1

# 5. Validate
python scripts/verify_pipeline.py --base-url http://localhost:8000
```

### Reprocess a failed run

```bash
# Re-create the run with the same slate_id
curl -X POST http://localhost:8000/api/runs \
  -H "Content-Type: application/json" \
  -d '{"slate_id": "<id>", "num_lineups": 20, "platform": "fanduel",
       "contest_type": "small_gpp", "max_exposure": 0.35,
       "min_salary": 49000, "max_salary": 60000, "async_mode": true}'
```

### Clear all pending jobs from Redis

```bash
# WARNING: discards all queued optimizer jobs
redis-cli -u $REDIS_URL DEL optimizer
```
