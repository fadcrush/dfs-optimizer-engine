/** @type {import('next').NextConfig} */
const nextConfig = {
  // Environment variables available at build time
  env: {
    NEXT_PUBLIC_API_URL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000',
    NEXT_PUBLIC_API_PREFIX: process.env.NEXT_PUBLIC_API_PREFIX || '/api',
  },

  // API rewrites for development (proxies /api/* and /backend/* to backend)
  async rewrites() {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000'

    return [
      // Primary: /api/* → backend /api/*
      {
        source: '/api/:path*',
        destination: `${apiUrl}/api/:path*`,
      },
      // Legacy compat: /backend/docs → /api/docs, /backend/* → /api/*
      // This resolves the original "GET /backend/docs → 404" symptom.
      {
        source: '/backend/docs',
        destination: `${apiUrl}/api/docs`,
      },
      {
        source: '/backend/redoc',
        destination: `${apiUrl}/api/redoc`,
      },
      {
        source: '/backend/:path*',
        destination: `${apiUrl}/api/:path*`,
      },
    ]
  },

  // Security headers
  async headers() {
    return [
      {
        source: '/:path*',
        headers: [
          {
            key: 'X-Frame-Options',
            value: 'DENY',
          },
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff',
          },
          {
            key: 'Referrer-Policy',
            value: 'origin-when-cross-origin',
          },
        ],
      },
    ]
  },

  // Optimize images
  images: {
    domains: ['localhost'],
  },

  // Enable strict mode for better debugging
  reactStrictMode: true,

  eslint: {
    dirs: ['src'],
  },
}

module.exports = nextConfig
