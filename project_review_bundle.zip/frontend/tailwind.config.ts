import type { Config } from 'tailwindcss'

const config: Config = {
  darkMode: 'class',
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        // DFS-friendly dark mode palette
        foreground: 'rgb(var(--foreground) / <alpha-value>)',
        background: {
          DEFAULT: '#0a0a0f',
          secondary: '#12121a',
          tertiary: '#1a1a24',
        },
        surface: {
          DEFAULT: '#1e1e2e',
          hover: '#252536',
          active: '#2d2d42',
        },
        border: {
          DEFAULT: '#2d2d42',
          subtle: '#1e1e2e',
        },
        // Accent colors for DFS states
        positive: {
          DEFAULT: '#22c55e',
          muted: '#166534',
        },
        negative: {
          DEFAULT: '#ef4444',
          muted: '#991b1b',
        },
        warning: {
          DEFAULT: '#f59e0b',
          muted: '#92400e',
        },
        info: {
          DEFAULT: '#3b82f6',
          muted: '#1e40af',
        },
        // Platform colors
        fanduel: '#1493ff',
        draftkings: '#53d337',
        // Sport colors
        nba: '#c9082a',
        nfl: '#013369',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      fontSize: {
        'xxs': '0.625rem',
      },
      spacing: {
        '18': '4.5rem',
        '88': '22rem',
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'slide-in': 'slideIn 0.2s ease-out',
      },
      keyframes: {
        slideIn: {
          '0%': { transform: 'translateY(-10px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
      },
    },
  },
  plugins: [],
}

export default config
