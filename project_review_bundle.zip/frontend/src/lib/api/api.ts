// ============================================================================
// DFS Edge Pro — Backend API Client
// All calls go through Next.js rewrites: /api/* → http://localhost:8000/api/*
// ============================================================================

const API_BASE = '/api'

// ---------------------------------------------------------------------------
// Generic response wrapper
// ---------------------------------------------------------------------------

export interface ApiResponse<T = unknown> {
  success: boolean
  data?: T
  error?: string
}

// ---------------------------------------------------------------------------
// Auth types
// ---------------------------------------------------------------------------

export interface AuthUser {
  id: string
  email: string
  full_name: string
}

interface AuthPayload {
  access_token: string
  token_type: string
  user: AuthUser
}

// ── Token storage ────────────────────────────────────────────────────────────

let _token: string | null =
  typeof window !== 'undefined' ? localStorage.getItem('auth_token') : null

export function getAuthToken(): string | null {
  return _token
}

function _setToken(token: string | null) {
  _token = token
  if (typeof window !== 'undefined') {
    if (token) localStorage.setItem('auth_token', token)
    else localStorage.removeItem('auth_token')
  }
}

// ── Base fetch helper ────────────────────────────────────────────────────────

async function apiFetch<T>(
  path: string,
  options: RequestInit = {}
): Promise<ApiResponse<T>> {
  const headers: HeadersInit = {
    ...(options.body instanceof FormData ? {} : { 'Content-Type': 'application/json' }),
    ...(options.headers as Record<string, string> | undefined),
  }
  if (_token) {
    (headers as Record<string, string>)['Authorization'] = `Bearer ${_token}`
  }

  try {
    const res = await fetch(`${API_BASE}${path}`, { ...options, headers })
    if (!res.ok) {
      let errorMsg = `HTTP ${res.status}`
      try {
        const body = await res.json()
        errorMsg = body?.detail || body?.message || errorMsg
      } catch {
        // non-JSON error body
      }
      return { success: false, error: errorMsg }
    }
    const data: T = await res.json()
    return { success: true, data }
  } catch (err) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Network error',
    }
  }
}

// ── File download helper (returns a Blob) ────────────────────────────────────

async function apiFetchBlob(path: string): Promise<ApiResponse<Blob>> {
  const headers: HeadersInit = {}
  if (_token) {
    (headers as Record<string, string>)['Authorization'] = `Bearer ${_token}`
  }
  try {
    const res = await fetch(`${API_BASE}${path}`, { headers })
    if (!res.ok) {
      return { success: false, error: `HTTP ${res.status}` }
    }
    const blob = await res.blob()
    return { success: true, data: blob }
  } catch (err) {
    return {
      success: false,
      error: err instanceof Error ? err.message : 'Network error',
    }
  }
}

// ---------------------------------------------------------------------------
// Auth endpoints
// ---------------------------------------------------------------------------

export async function login(
  email: string,
  password: string
): Promise<ApiResponse<{ access_token: string; user: AuthUser }>> {
  const result = await apiFetch<AuthPayload>('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  })
  if (result.success && result.data) {
    _setToken(result.data.access_token)
    return { success: true, data: { access_token: result.data.access_token, user: result.data.user } }
  }
  return { success: false, error: result.error }
}

export async function signup(
  email: string,
  password: string,
  fullName: string
): Promise<ApiResponse<{ access_token: string; user: AuthUser }>> {
  const result = await apiFetch<AuthPayload>('/auth/signup', {
    method: 'POST',
    body: JSON.stringify({ email, password, full_name: fullName }),
  })
  if (result.success && result.data) {
    _setToken(result.data.access_token)
    return { success: true, data: { access_token: result.data.access_token, user: result.data.user } }
  }
  return { success: false, error: result.error }
}

export function logout(): void {
  _setToken(null)
}

export async function getCurrentUser(): Promise<ApiResponse<AuthUser>> {
  return apiFetch<AuthUser>('/auth/me')
}

// ---------------------------------------------------------------------------
// Slate / projection upload
// ---------------------------------------------------------------------------

export interface SlateData {
  /** Unique slate ID — may be server-assigned or filename-derived */
  id?: string
  fileName: string
  /** ISO date string e.g. "2024-01-15" */
  date?: string
  platform: string
  sport: string
  slateType?: string
  games?: import('@/types').Game[]
  players: import('@/types').Player[]
  lockTime?: string
  uploadedAt?: string
}

export async function uploadSlate(file: File): Promise<ApiResponse<SlateData>> {
  const form = new FormData()
  form.append('file', file)
  return apiFetch<SlateData>('/projections/upload-slate', {
    method: 'POST',
    body: form,
  })
}

export interface DetectResult {
  platform: string
  sport: string
}

export async function detectSlateType(file: File): Promise<ApiResponse<DetectResult>> {
  // Detection is done locally from CSV headers — no round-trip needed.
  // File name and column sniffing give us platform/sport without a server call.
  const content = await file.text()
  const firstLine = content.split(/\r?\n/)[0] || ''
  const lower = firstLine.toLowerCase()

  const platform = lower.includes('fppg') || lower.includes('injury indicator')
    ? 'fanduel'
    : lower.includes('avgpointspergame') || lower.includes('roster position')
    ? 'draftkings'
    : 'fanduel'

  const sport =
    lower.includes('qb') || lower.includes('rb') || lower.includes('wr') ? 'nfl' : 'nba'

  return { success: true, data: { platform, sport } }
}

// ---------------------------------------------------------------------------
// Projection generation
// ---------------------------------------------------------------------------

export interface ProjectionResult {
  projections: Record<string, unknown>[]
  stats: Record<string, unknown>
}

export async function generateProjections(
  fileName: string
): Promise<ApiResponse<{ result: ProjectionResult }>> {
  return apiFetch<{ result: ProjectionResult }>(
    `/projections/generate?file_name=${encodeURIComponent(fileName)}`,
    { method: 'POST' }
  )
}

// ---------------------------------------------------------------------------
// Lineup generation (main DFS build flow)
// ---------------------------------------------------------------------------

export interface LineupStats {
  avgProjection: number
  avgSalary: number
  avgOwnership: number
  projectionRange?: string
  projection_range?: string
  [key: string]: unknown
}

export interface LineupGenerationResult {
  lineups: Record<string, unknown>[]
  stats: LineupStats
  total_lineups: number
  download_file: string
  analytics_run_id?: string
}

/** Full request object variant (used by SettingsPage) */
export interface LineupGenerationRequest {
  slateId: string
  numLineups: number
  contestType: string
  maxExposure: number
  minSalary: number
  maxSalary: number
  lockedPlayers?: string[]
  fadedPlayers?: string[]
}

/**
 * Generate lineups.
 * Accepts either a fileName string + options object, or a full request object.
 */
export async function generateLineups(
  fileNameOrRequest: string | LineupGenerationRequest,
  options: {
    numLineups?: number
    platform?: string
    contestType?: string
    maxExposure?: number
    minSalary?: number
  } = {}
): Promise<ApiResponse<LineupGenerationResult>> {
  let fileName: string
  let mergedOptions = options

  if (typeof fileNameOrRequest === 'string') {
    fileName = fileNameOrRequest
  } else {
    // Full request object: extract file name and options
    const req = fileNameOrRequest
    fileName = req.slateId
    mergedOptions = {
      numLineups: req.numLineups,
      contestType: req.contestType,
      maxExposure: req.maxExposure,
      minSalary: req.minSalary,
    }
  }

  const params = new URLSearchParams({
    file_name: fileName,
    num_lineups: String(mergedOptions.numLineups ?? 150),
    platform: mergedOptions.platform ?? 'fanduel',
    contest_type: mergedOptions.contestType ?? 'small_gpp',
    max_exposure: String(mergedOptions.maxExposure ?? 0.35),
    min_salary: String(mergedOptions.minSalary ?? 49000),
  })
  return apiFetch<LineupGenerationResult>(`/optimizer/generate?${params}`, {
    method: 'POST',
  })
}

// ---------------------------------------------------------------------------
// Ownership prediction
// ---------------------------------------------------------------------------

export async function generateOwnership(
  fileName: string
): Promise<ApiResponse<Record<string, unknown>>> {
  return apiFetch<Record<string, unknown>>(
    `/ownership/predict?file_name=${encodeURIComponent(fileName)}`,
    { method: 'POST' }
  )
}

// ---------------------------------------------------------------------------
// FanDuel direct-upload optimizer (used by /optimizer page)
// ---------------------------------------------------------------------------

export interface FDLineup {
  // Indexed position slots (used by optimizer page)
  PG: string
  PG_2: string
  SG: string
  SG_2: string
  SF: string
  SF_2: string
  PF: string
  PF_2: string
  C: string
  // Salary / projection fields (snake_case from backend)
  salary?: number
  projection?: number
  total_salary: number
  projected_points: number
  lineup_num: number
  [slot: string]: string | number | undefined
}

export interface FDOptimizerResponse {
  message: string
  lineups: FDLineup[]
  stats: Record<string, unknown>
  total_lineups: number
  download_file: string
  algorithm?: string
  note?: string
  analytics_run_id?: string
}

export async function runFDOptimizer(
  file: File,
  options: {
    numLineups?: number
    minSalary?: number
    maxSalary?: number
    maxExposure?: number
    platform?: string
    contestType?: string
  } = {}
): Promise<ApiResponse<FDOptimizerResponse>> {
  const params = new URLSearchParams({
    num_lineups: String(options.numLineups ?? 20),
    min_salary: String(options.minSalary ?? 59000),
    max_salary: String(options.maxSalary ?? 60000),
    max_exposure: String(options.maxExposure ?? 0.35),
    platform: options.platform ?? 'fanduel',
    contest_type: options.contestType ?? 'small_gpp',
  })
  const form = new FormData()
  form.append('projections', file)
  return apiFetch<FDOptimizerResponse>(
    `/optimizer/optimize-from-projections?${params}`,
    { method: 'POST', body: form }
  )
}

// ---------------------------------------------------------------------------
// File download helpers
// ---------------------------------------------------------------------------

export async function downloadLineups(fileName: string): Promise<ApiResponse<Blob>> {
  return apiFetchBlob(`/optimizer/download/${encodeURIComponent(fileName)}`)
}

/** Trigger a browser download of a Blob. */
export function downloadFile(blob: Blob, fileName: string): void {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = fileName
  document.body.appendChild(a)
  a.click()
  setTimeout(() => {
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }, 100)
}

// ---------------------------------------------------------------------------
// Injury / late-swap
// ---------------------------------------------------------------------------

export interface InjuryUpdate {
  playerId: string
  name: string
  status: string
  team: string
  updatedAt: string
}

export async function getInjuryUpdates(): Promise<ApiResponse<InjuryUpdate[]>> {
  // Signals endpoint — falls back to empty array if module not yet enabled
  const result = await apiFetch<{ players: InjuryUpdate[] }>('/signals/injuries')
  if (result.success && result.data) {
    return { success: true, data: result.data.players ?? [] }
  }
  // Degrade gracefully: return empty array rather than crashing the UI
  return { success: true, data: [] }
}

// ---------------------------------------------------------------------------
// DB-first SaaS workflow  (slate_id → run_id → lineups / exposure)
// ---------------------------------------------------------------------------

// ── Upload ──────────────────────────────────────────────────────────────────

export interface SlateIngestResult {
  slate_id: string
  platform: string
  sport: string
  player_count: number
  projection_count: number
  message: string
}

/** Upload a projections CSV to the DB-first ingestion endpoint. */
export async function uploadSlateToDB(
  file: File,
  sport?: string,
): Promise<ApiResponse<SlateIngestResult>> {
  const form = new FormData()
  form.append('file', file)
  const qs = sport ? `?sport=${encodeURIComponent(sport)}` : ''
  return apiFetch<SlateIngestResult>(`/projections/upload-slate-to-db${qs}`, {
    method: 'POST',
    body: form,
  })
}

export interface OwnershipIngestResult {
  slate_id: string
  matched: number
  unmatched: number
  total: number
  message: string
}

/** Upload an ownership CSV and link it to an already-ingested slate. */
export async function uploadOwnershipToDB(
  file: File,
  slateId: string,
  source = 'upload',
): Promise<ApiResponse<OwnershipIngestResult>> {
  const form = new FormData()
  form.append('file', file)
  const qs = `?slate_id=${encodeURIComponent(slateId)}&source=${encodeURIComponent(source)}`
  return apiFetch<OwnershipIngestResult>(`/ownership/upload-to-db${qs}`, {
    method: 'POST',
    body: form,
  })
}

// ── Runs ────────────────────────────────────────────────────────────────────

export interface CreateRunParams {
  slateId: string
  numLineups?: number
  platform?: string
  contestType?: string
  maxExposure?: number
  minSalary?: number
  maxSalary?: number
  excludeInjured?: boolean
  asyncMode?: boolean
}

export interface RunCreatedResult {
  run_id: string
  status: string
  async_mode: boolean
  message: string
}

/** Submit a new optimizer run for a slate. */
export async function createRun(
  params: CreateRunParams,
): Promise<ApiResponse<RunCreatedResult>> {
  return apiFetch<RunCreatedResult>('/runs', {
    method: 'POST',
    body: JSON.stringify({
      slate_id: params.slateId,
      num_lineups: params.numLineups ?? 150,
      platform: params.platform ?? 'fanduel',
      contest_type: params.contestType ?? 'small_gpp',
      max_exposure: params.maxExposure ?? 0.35,
      min_salary: params.minSalary ?? 49000,
      max_salary: params.maxSalary ?? 60000,
      exclude_injured: params.excludeInjured ?? true,
      async_mode: params.asyncMode ?? true,
    }),
  })
}

export interface RunStatusResult {
  run_id: string
  status: 'queued' | 'running' | 'completed' | 'failed' | string
  num_lineups: number
  error_message: string | null
}

/** Fast polling endpoint — call every 2–5 s until status is 'completed' or 'failed'. */
export async function pollRunStatus(
  runId: string,
): Promise<ApiResponse<RunStatusResult>> {
  return apiFetch<RunStatusResult>(`/runs/${encodeURIComponent(runId)}/status`)
}

/** Full run details (settings, timestamps, etc.) */
export async function getRun(runId: string) {
  return apiFetch<Record<string, unknown>>(`/runs/${encodeURIComponent(runId)}`)
}

// ── Results ─────────────────────────────────────────────────────────────────

export interface LineupPlayer {
  player_id: string
  name: string
  position: string
  team: string
  salary: number
}

export interface LineupRow {
  lineup_id: string
  lineup_number: number
  total_salary: number
  total_projection: number
  players: LineupPlayer[]
}

export interface RunLineupsResult {
  run_id: string
  total_lineups: number
  lineups: LineupRow[]
}

/** Fetch all lineups with full player details for a completed run. */
export async function getRunLineups(
  runId: string,
): Promise<ApiResponse<RunLineupsResult>> {
  return apiFetch<RunLineupsResult>(
    `/results/${encodeURIComponent(runId)}/lineups`,
  )
}

export interface ExposurePlayer {
  player_id: string
  name: string
  team: string
  position: string
  salary: number
  count: number
  exposure_pct: number
  avg_projection: number
  leverage: number | null
}

export interface RunExposureResult {
  run_id: string
  total_lineups: number
  players: ExposurePlayer[]
}

/** Fetch per-player exposure statistics for a completed run. */
export async function getRunExposure(
  runId: string,
): Promise<ApiResponse<RunExposureResult>> {
  return apiFetch<RunExposureResult>(
    `/results/${encodeURIComponent(runId)}/exposure`,
  )
}

// ── Slates ──────────────────────────────────────────────────────────────────

export interface SlateRow {
  slate_id: string
  platform: string
  sport: string
  slate_date: string | null
  player_count: number
  created_at: string
}

/** List recent slates, optionally filtered by sport or platform. */
export async function listSlates(opts?: {
  sport?: string
  platform?: string
  limit?: number
}): Promise<ApiResponse<{ slates: SlateRow[]; total: number }>> {
  const q = new URLSearchParams()
  if (opts?.sport) q.set('sport', opts.sport)
  if (opts?.platform) q.set('platform', opts.platform)
  if (opts?.limit) q.set('limit', String(opts.limit))
  const qs = q.toString() ? `?${q}` : ''
  return apiFetch(`/slates${qs}`)
}

/** Get a slate by ID. */
export async function getSlate(slateId: string) {
  return apiFetch(`/slates/${encodeURIComponent(slateId)}`)
}

/** Get a slate's player+projection list. */
export async function getSlateProjections(slateId: string) {
  return apiFetch(`/slates/${encodeURIComponent(slateId)}/projections`)
}

/** Get a slate's ownership data (if uploaded). */
export async function getSlateOwnership(slateId: string) {
  return apiFetch(`/slates/${encodeURIComponent(slateId)}/ownership`)
}

// ── Health ──────────────────────────────────────────────────────────────────

export interface DbHealthResult {
  status: 'ok' | 'degraded' | 'error'
  connection: boolean
  missing_tables: string[]
  alembic_revision: string | null
  hint?: string
}

export async function checkDbHealth(): Promise<ApiResponse<DbHealthResult>> {
  return apiFetch<DbHealthResult>('/health/db')
}
