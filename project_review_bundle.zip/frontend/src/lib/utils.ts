// ============================================================================
// DFS Edge Pro - Utility Functions
// ============================================================================

import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

// ============================================================================
// Tailwind Class Merging
// ============================================================================

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// ============================================================================
// Formatting Utilities
// ============================================================================

export function formatCurrency(value: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value)
}

export function formatSalary(salary: number): string {
  if (salary >= 1000) {
    return `$${(salary / 1000).toFixed(1)}K`
  }
  return `$${salary}`
}

export function formatPercentage(value: number, decimals: number = 1): string {
  return `${(value * 100).toFixed(decimals)}%`
}

export function formatProjection(value: number): string {
  return value.toFixed(1)
}

export function formatOwnership(value: number): string {
  return `${(value * 100).toFixed(1)}%`
}

export function formatValue(projection: number, salary: number): string {
  if (salary === 0) return '0.0x'
  const value = projection / (salary / 1000)
  return `${value.toFixed(1)}x`
}

// ============================================================================
// Date/Time Utilities
// ============================================================================

export function formatLockTime(dateString: string): string {
  const date = new Date(dateString)
  return new Intl.DateTimeFormat('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
    timeZoneName: 'short',
  }).format(date)
}

export function formatDate(dateString: string): string {
  const date = new Date(dateString)
  return new Intl.DateTimeFormat('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  }).format(date)
}

export function getTimeUntilLock(lockTime: string): string {
  const lock = new Date(lockTime)
  const now = new Date()
  const diff = lock.getTime() - now.getTime()

  if (diff <= 0) return 'Locked'

  const hours = Math.floor(diff / (1000 * 60 * 60))
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))

  if (hours > 0) {
    return `${hours}h ${minutes}m`
  }
  return `${minutes}m`
}

// ============================================================================
// Validation Utilities
// ============================================================================

export function validateLineup(
  players: { salary: number; position: string }[],
  platform: 'fanduel' | 'draftkings'
): { valid: boolean; errors: string[] } {
  const errors: string[] = []

  // Salary validation
  const totalSalary = players.reduce((sum, p) => sum + p.salary, 0)
  const maxSalary = 60000
  const minSalary = platform === 'fanduel' ? 49000 : 48000

  if (totalSalary > maxSalary) {
    errors.push(`Salary over cap: $${totalSalary.toLocaleString()} / $${maxSalary.toLocaleString()}`)
  }
  if (totalSalary < minSalary) {
    errors.push(`Salary under minimum: $${totalSalary.toLocaleString()} / $${minSalary.toLocaleString()}`)
  }

  // Roster size validation
  const expectedSize = platform === 'fanduel' ? 9 : 8
  if (players.length !== expectedSize) {
    errors.push(`Wrong roster size: ${players.length} / ${expectedSize}`)
  }

  // Position validation
  if (platform === 'fanduel') {
    const positions = players.map((p) => p.position.split('/')[0])
    const counts: Record<string, number> = {}
    positions.forEach((pos) => {
      counts[pos] = (counts[pos] || 0) + 1
    })

    const required = { PG: 2, SG: 2, SF: 2, PF: 2, C: 1 }
    for (const [pos, count] of Object.entries(required)) {
      if ((counts[pos] || 0) !== count) {
        errors.push(`Invalid ${pos} count: ${counts[pos] || 0} / ${count}`)
      }
    }
  }

  return {
    valid: errors.length === 0,
    errors,
  }
}

// ============================================================================
// DFS Calculation Utilities
// ============================================================================

export function calculateExposure(
  playerId: string,
  lineups: { players: { id: string }[] }[]
): number {
  if (lineups.length === 0) return 0

  const count = lineups.filter((lineup) =>
    lineup.players.some((p) => p.id === playerId)
  ).length

  return count / lineups.length
}

export function calculateLineupOwnership(
  players: { ownership: number }[]
): number {
  if (players.length === 0) return 0
  return players.reduce((sum, p) => sum + p.ownership, 0) / players.length
}

export function calculateLeverage(projection: number, ownership: number): number {
  if (ownership === 0) return 0
  return projection / (ownership * 100 + 0.01)
}

// ============================================================================
// Color Utilities
// ============================================================================

export function getOwnershipColor(ownership: number): string {
  if (ownership >= 0.4) return 'text-red-400'      // Chalk
  if (ownership >= 0.25) return 'text-orange-400'  // High
  if (ownership >= 0.15) return 'text-yellow-400'  // Medium
  if (ownership >= 0.05) return 'text-green-400'   // Low
  return 'text-emerald-400'                         // Contrarian
}

export function getValueColor(value: number): string {
  if (value >= 6.0) return 'text-emerald-400'
  if (value >= 5.5) return 'text-green-400'
  if (value >= 5.0) return 'text-yellow-400'
  if (value >= 4.5) return 'text-orange-400'
  return 'text-red-400'
}

export function getProjectionColor(projection: number, position: string): string {
  // Position-adjusted thresholds
  const thresholds: Record<string, { high: number; mid: number }> = {
    PG: { high: 40, mid: 30 },
    SG: { high: 38, mid: 28 },
    SF: { high: 35, mid: 25 },
    PF: { high: 38, mid: 28 },
    C: { high: 42, mid: 32 },
  }

  const t = thresholds[position] || { high: 35, mid: 25 }

  if (projection >= t.high) return 'text-emerald-400'
  if (projection >= t.mid) return 'text-green-400'
  return 'text-gray-400'
}

export function getInjuryColor(status: string): string {
  const statusUpper = status.toUpperCase()
  if (statusUpper === 'OUT' || statusUpper === 'O') return 'text-red-500'
  if (statusUpper === 'DOUBTFUL' || statusUpper === 'D') return 'text-red-400'
  if (statusUpper === 'QUESTIONABLE' || statusUpper === 'Q') return 'text-orange-400'
  if (statusUpper === 'PROBABLE' || statusUpper === 'P') return 'text-yellow-400'
  if (statusUpper === 'GTD') return 'text-orange-400'
  return 'text-green-400'
}

// ============================================================================
// Array Utilities
// ============================================================================

export function groupBy<T>(array: T[], key: keyof T): Record<string, T[]> {
  return array.reduce(
    (result, item) => {
      const group = String(item[key])
      if (!result[group]) {
        result[group] = []
      }
      result[group].push(item)
      return result
    },
    {} as Record<string, T[]>
  )
}

export function sortByKey<T>(
  array: T[],
  key: keyof T,
  direction: 'asc' | 'desc' = 'desc'
): T[] {
  return [...array].sort((a, b) => {
    const aVal = a[key]
    const bVal = b[key]

    if (typeof aVal === 'number' && typeof bVal === 'number') {
      return direction === 'asc' ? aVal - bVal : bVal - aVal
    }

    const aStr = String(aVal)
    const bStr = String(bVal)
    return direction === 'asc'
      ? aStr.localeCompare(bStr)
      : bStr.localeCompare(aStr)
  })
}

// ============================================================================
// ID Generation
// ============================================================================

export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
}
