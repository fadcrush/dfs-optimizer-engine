/**
 * useRunPoller.ts — Auto-stopping run status polling hook.
 *
 * Polls GET /api/runs/{runId}/status every `intervalMs` milliseconds.
 * Automatically stops when status transitions to 'completed' or 'failed'.
 * Exposes a manual abort function for cleanup on unmount.
 *
 * Usage:
 *   const { status, numLineups, error, isPolling } = useRunPoller(runId)
 */

import { useCallback, useEffect, useRef, useState } from 'react'
import { pollRunStatus, type RunStatusResult } from '@/lib/api/api'

export type PollState = {
  status: RunStatusResult['status'] | null
  numLineups: number
  errorMessage: string | null
  isPolling: boolean
  lastPolledAt: Date | null
}

const TERMINAL_STATUSES = new Set(['completed', 'failed'])

export function useRunPoller(
  runId: string | null,
  {
    intervalMs = 2_000,
    maxAttempts = 120,   // 120 × 2s = 4 min ceiling
    onComplete,
    onFailed,
  }: {
    intervalMs?: number
    maxAttempts?: number
    onComplete?: (result: RunStatusResult) => void
    onFailed?: (result: RunStatusResult) => void
  } = {},
): PollState & { abort: () => void } {
  const [state, setState] = useState<PollState>({
    status: null,
    numLineups: 0,
    errorMessage: null,
    isPolling: false,
    lastPolledAt: null,
  })

  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const attemptRef = useRef(0)
  const abortedRef = useRef(false)

  const abort = useCallback(() => {
    abortedRef.current = true
    if (timerRef.current !== null) {
      clearTimeout(timerRef.current)
      timerRef.current = null
    }
    setState((prev) => ({ ...prev, isPolling: false }))
  }, [])

  useEffect(() => {
    if (!runId) return

    abortedRef.current = false
    attemptRef.current = 0

    const poll = async () => {
      if (abortedRef.current) return
      if (attemptRef.current >= maxAttempts) {
        setState((prev) => ({
          ...prev,
          isPolling: false,
          errorMessage: `Polling timed out after ${maxAttempts} attempts`,
        }))
        return
      }

      attemptRef.current += 1
      setState((prev) => ({ ...prev, isPolling: true }))

      try {
        const result = await pollRunStatus(runId)

        if (abortedRef.current) return

        setState({
          status: result.status,
          numLineups: result.num_lineups ?? 0,
          errorMessage: result.error_message ?? null,
          isPolling: !TERMINAL_STATUSES.has(result.status),
          lastPolledAt: new Date(),
        })

        if (result.status === 'completed') {
          onComplete?.(result)
          return  // stop polling
        }

        if (result.status === 'failed') {
          onFailed?.(result)
          return  // stop polling
        }

        // Schedule next poll
        timerRef.current = setTimeout(poll, intervalMs)
      } catch (err) {
        if (abortedRef.current) return
        const msg = err instanceof Error ? err.message : String(err)
        setState((prev) => ({
          ...prev,
          isPolling: false,
          errorMessage: `Polling error: ${msg}`,
        }))
      }
    }

    // Kick off first poll immediately
    poll()

    return abort
  }, [runId, intervalMs, maxAttempts, onComplete, onFailed, abort])

  return { ...state, abort }
}
