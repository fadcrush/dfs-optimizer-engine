// ============================================================================
// DFS Edge Pro - Core Type Definitions
// ============================================================================

// Platform and Sport Types
export type Platform = 'fanduel' | 'draftkings'
export type Sport = 'nba' | 'nfl'
export type ContestType = 'cash' | 'small_gpp' | 'large_gpp' | 'satellite' | 'showdown'

// ============================================================================
// Player Types
// ============================================================================

export interface Player {
  id: string
  name: string
  position: string
  positions: string[]  // Multi-position eligibility
  team: string
  opponent: string
  salary: number
  projection: number
  floor: number
  ceiling: number
  ownership: number
  value: number
  leverage: number
  game: string
  injuryStatus?: InjuryStatus
  isLocked?: boolean
  isFaded?: boolean
}

export type InjuryStatus = 'HEALTHY' | 'PROBABLE' | 'QUESTIONABLE' | 'DOUBTFUL' | 'OUT' | 'GTD'

export interface PlayerExposure {
  playerId: string
  playerName: string
  exposure: number  // 0.0 to 1.0
  lineupCount: number
  minExposure: number
  maxExposure: number
}

// ============================================================================
// Slate Types
// ============================================================================

export interface Slate {
  id: string
  platform: Platform
  sport: Sport
  date: string
  lockTime: string
  slateType: string  // 'Main', 'Turbo', 'Showdown', etc.
  games: Game[]
  players: Player[]
  fileName: string
  uploadedAt: string
}

export interface Game {
  id: string
  homeTeam: string
  awayTeam: string
  startTime: string
  vegasTotal?: number
  homeSpread?: number
  homeImpliedPoints?: number
  awayImpliedPoints?: number
}

// ============================================================================
// Lineup Types
// ============================================================================

export interface Lineup {
  id: string
  lineupNumber: number
  players: LineupPlayer[]
  totalSalary: number
  projectedPoints: number
  ownership: number
  leverage: number
  isValid: boolean
  validationErrors?: string[]
}

export interface LineupPlayer {
  slotPosition: string  // 'PG', 'PG_2', 'SG', etc.
  player: Player
}

export interface LineupGenerationRequest {
  slateId: string
  numLineups: number
  contestType: ContestType
  maxExposure: number
  minSalary: number
  maxSalary: number
  lockedPlayers: string[]
  fadedPlayers: string[]
  minUniqueness?: number
}

export interface LineupGenerationResponse {
  success: boolean
  lineups: Lineup[]
  stats: LineupStats
  algorithm: string
  analytics_run_id?: string
  error?: string
}

export interface LineupStats {
  totalLineups: number
  avgProjection: number
  avgSalary: number
  avgOwnership: number
  projectionRange: string
  maxExposure: number
  platform: string
  databaseBoosts: number
}

// ============================================================================
// Projection Types
// ============================================================================

export interface Projection {
  playerId: string
  playerName: string
  position: string
  team: string
  opponent: string
  salary: number
  projection: number
  floor: number
  ceiling: number
  value: number
  gamesPlayed: number
  source: string
}

export interface ProjectionRequest {
  slateFilePath: string
}

export interface ProjectionResponse {
  success: boolean
  projections: Projection[]
  stats: {
    totalPlayers: number
    playersWithHistory: number
    avgProjection: number
    databaseUsed: string
  }
  algorithm: string
}

// ============================================================================
// Ownership Types
// ============================================================================

export interface OwnershipPrediction {
  playerId: string
  playerName: string
  predictedOwnership: number
  leverage: number
  ownershipFactors: string
}

export interface OwnershipResponse {
  success: boolean
  ownershipPredictions: OwnershipPrediction[]
  stats: {
    totalPlayers: number
    avgOwnership: number
    highOwnedCount: number
    lowOwnedCount: number
    topLeveragePlays: OwnershipPrediction[]
  }
}

// ============================================================================
// Settings Types
// ============================================================================

export interface OptimizerSettings {
  maxExposure: number
  minSalary: number
  maxSalary: number
  minUniqueness: number
  contestType: ContestType
  requireStack: boolean
  minStackSize: number
  maxStackSize: number
  bringBackCount: number
}

export interface PlayerLock {
  playerId: string
  type: 'lock' | 'fade'
  minExposure?: number
  maxExposure?: number
}

// ============================================================================
// API Response Types
// ============================================================================

export interface ApiResponse<T> {
  success: boolean
  data?: T
  error?: string
  message?: string
}

export interface ApiError {
  code: string
  message: string
  details?: Record<string, unknown>
}

// ============================================================================
// UI State Types
// ============================================================================

export interface Toast {
  id: string
  type: 'success' | 'error' | 'warning' | 'info'
  title: string
  message?: string
  duration?: number
}

export interface WorkflowStep {
  id: string
  name: string
  status: 'pending' | 'in_progress' | 'completed' | 'error'
  error?: string
}

// ============================================================================
// Late Swap Types
// ============================================================================

export interface LateSwapRecommendation {
  playerId: string
  playerName: string
  currentStatus: InjuryStatus
  recommendation: 'keep' | 'swap_out' | 'swap_in'
  reason: string
  replacementOptions?: Player[]
  urgency: 'low' | 'medium' | 'high' | 'critical'
}

export interface LiveGame {
  gameId: string
  homeTeam: string
  awayTeam: string
  homeScore: number
  awayScore: number
  quarter: number
  timeRemaining: string
  status: 'not_started' | 'in_progress' | 'final'
}
