'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Zap } from 'lucide-react'

export default function Home() {
  const router = useRouter()

  useEffect(() => {
    // Redirect to build flow
    router.push('/build/import')
  }, [router])

  return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="text-center">
        <div className="w-16 h-16 rounded-full bg-gradient-to-br from-info to-positive flex items-center justify-center mx-auto mb-4 animate-pulse">
          <Zap className="w-8 h-8 text-white" />
        </div>
        <p className="text-gray-400">Loading DFS Edge Pro...</p>
      </div>
    </div>
  )
}
