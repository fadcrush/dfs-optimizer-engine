'use client'

import { ElementType, ReactNode } from 'react'
import { cn } from '@/lib/utils'

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface TabDef {
  id: string
  label: string
  /** Accept JSX (e.g. <List size={16} />) or a Lucide component reference (e.g. Grid) */
  icon?: ReactNode | ElementType
  badge?: number
  disabled?: boolean
}

interface TabsProps {
  tabs: TabDef[]
  activeTab: string
  onTabChange: (id: string) => void
  className?: string
  children?: ReactNode
}

export interface TabPanelProps {
  /** Primary identifier — matches the `id` in TabDef */
  id?: string
  /** Alias accepted from legacy code that used `tabId` prop */
  tabId?: string
  activeTab: string
  children: ReactNode
  className?: string
}

// ---------------------------------------------------------------------------
// Tabs – horizontal tab bar
// ---------------------------------------------------------------------------

export function Tabs({ tabs, activeTab, onTabChange, className }: TabsProps) {
  return (
    <div className={cn('flex border-b border-gray-700', className)}>
      {tabs.map((tab) => {
        const isActive = tab.id === activeTab
        // Support both JSX element and component reference for icon
        const IconContent: ReactNode =
          tab.icon && typeof tab.icon === 'function'
            ? (() => {
                const Ic = tab.icon as ElementType
                return <Ic size={16} />
              })()
            : (tab.icon as ReactNode) ?? null
        return (
          <button
            key={tab.id}
            onClick={() => !tab.disabled && onTabChange(tab.id)}
            disabled={tab.disabled}
            className={cn(
              'flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors border-b-2 -mb-px',
              isActive
                ? 'border-blue-500 text-blue-400'
                : 'border-transparent text-gray-400 hover:text-gray-200',
              tab.disabled && 'opacity-40 cursor-not-allowed'
            )}
          >
            {IconContent}
            {tab.label}
            {tab.badge !== undefined && (
              <span className="ml-1 px-1.5 py-0.5 rounded-full bg-gray-700 text-xs text-gray-300">
                {tab.badge}
              </span>
            )}
          </button>
        )
      })}
    </div>
  )
}

// ---------------------------------------------------------------------------
// TabPanel – renders children only when active
// Accepts both `id` and legacy `tabId` prop.
// ---------------------------------------------------------------------------

export function TabPanel({ id, tabId, activeTab, children, className }: TabPanelProps) {
  const panelId = id ?? tabId ?? ''
  if (panelId !== activeTab) return null
  return <div className={className}>{children}</div>
}
