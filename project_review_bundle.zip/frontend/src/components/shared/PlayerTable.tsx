'use client'

import { useState, useMemo } from 'react'
import {
  Lock,
  Ban,
  ChevronUp,
  ChevronDown,
  Search,
  Filter,
} from 'lucide-react'
import {
  cn,
  formatSalary,
  formatProjection,
  formatOwnership,
  getOwnershipColor,
  getValueColor,
  getInjuryColor,
} from '@/lib/utils'
import {
  useSettingsStore,
  useIsPlayerLocked,
  useIsPlayerFaded,
} from '@/store'
import type { Player } from '@/types'

interface PlayerTableProps {
  players: Player[]
  showProjections?: boolean
  showOwnership?: boolean
  showLockControls?: boolean
  onPlayerClick?: (player: Player) => void
}

type SortKey = 'name' | 'position' | 'salary' | 'projection' | 'ownership' | 'value'
type SortDir = 'asc' | 'desc'

export function PlayerTable({
  players,
  showProjections = false,
  showOwnership = false,
  showLockControls = true,
  onPlayerClick,
}: PlayerTableProps) {
  const [sortKey, setSortKey] = useState<SortKey>('projection')
  const [sortDir, setSortDir] = useState<SortDir>('desc')
  const [searchQuery, setSearchQuery] = useState('')
  const [positionFilter, setPositionFilter] = useState<string | null>(null)

  const { lockPlayer, fadePlayer, unlockPlayer } = useSettingsStore()

  // Get unique positions
  const positions = useMemo(() => {
    const posSet = new Set<string>()
    players.forEach((p) => {
      p.position.split('/').forEach((pos) => posSet.add(pos.trim()))
    })
    return Array.from(posSet).sort()
  }, [players])

  // Filter and sort players
  const filteredPlayers = useMemo(() => {
    let result = [...players]

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      result = result.filter(
        (p) =>
          p.name.toLowerCase().includes(query) ||
          p.team.toLowerCase().includes(query)
      )
    }

    // Position filter
    if (positionFilter) {
      result = result.filter((p) => p.position.includes(positionFilter))
    }

    // Sort
    result.sort((a, b) => {
      let aVal: number | string
      let bVal: number | string

      switch (sortKey) {
        case 'name':
          aVal = a.name
          bVal = b.name
          break
        case 'position':
          aVal = a.position
          bVal = b.position
          break
        case 'salary':
          aVal = a.salary
          bVal = b.salary
          break
        case 'projection':
          aVal = a.projection
          bVal = b.projection
          break
        case 'ownership':
          aVal = a.ownership
          bVal = b.ownership
          break
        case 'value':
          aVal = a.value
          bVal = b.value
          break
        default:
          aVal = a.projection
          bVal = b.projection
      }

      if (typeof aVal === 'string' && typeof bVal === 'string') {
        return sortDir === 'asc'
          ? aVal.localeCompare(bVal)
          : bVal.localeCompare(aVal)
      }

      return sortDir === 'asc'
        ? (aVal as number) - (bVal as number)
        : (bVal as number) - (aVal as number)
    })

    return result
  }, [players, searchQuery, positionFilter, sortKey, sortDir])

  const handleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortDir(sortDir === 'desc' ? 'asc' : 'desc')
    } else {
      setSortKey(key)
      setSortDir('desc')
    }
  }

  const SortIcon = ({ columnKey }: { columnKey: SortKey }) => {
    if (sortKey !== columnKey) return null
    return sortDir === 'desc' ? (
      <ChevronDown className="w-3 h-3" />
    ) : (
      <ChevronUp className="w-3 h-3" />
    )
  }

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <input
            type="text"
            placeholder="Search players or teams..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="input pl-10"
          />
        </div>

        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-gray-500" />
          <div className="flex gap-1">
            <button
              onClick={() => setPositionFilter(null)}
              className={cn(
                'px-3 py-1.5 rounded text-sm',
                positionFilter === null
                  ? 'bg-info text-white'
                  : 'bg-surface text-gray-400 hover:bg-surface-hover'
              )}
            >
              All
            </button>
            {positions.map((pos) => (
              <button
                key={pos}
                onClick={() => setPositionFilter(pos)}
                className={cn(
                  'px-3 py-1.5 rounded text-sm',
                  positionFilter === pos
                    ? 'bg-info text-white'
                    : 'bg-surface text-gray-400 hover:bg-surface-hover'
                )}
              >
                {pos}
              </button>
            ))}
          </div>
        </div>

        <span className="text-sm text-gray-500">
          {filteredPlayers.length} players
        </span>
      </div>

      {/* Table */}
      <div className="table-container max-h-[600px] overflow-y-auto">
        <table className="table">
          <thead className="table-header sticky top-0 bg-surface z-10">
            <tr>
              {showLockControls && <th className="w-20">Lock/Fade</th>}
              <th
                className="cursor-pointer hover:text-white"
                onClick={() => handleSort('name')}
              >
                <div className="flex items-center gap-1">
                  Player <SortIcon columnKey="name" />
                </div>
              </th>
              <th
                className="cursor-pointer hover:text-white"
                onClick={() => handleSort('position')}
              >
                <div className="flex items-center gap-1">
                  Pos <SortIcon columnKey="position" />
                </div>
              </th>
              <th
                className="cursor-pointer hover:text-white"
                onClick={() => handleSort('salary')}
              >
                <div className="flex items-center gap-1">
                  Salary <SortIcon columnKey="salary" />
                </div>
              </th>
              {showProjections && (
                <>
                  <th
                    className="cursor-pointer hover:text-white"
                    onClick={() => handleSort('projection')}
                  >
                    <div className="flex items-center gap-1">
                      Proj <SortIcon columnKey="projection" />
                    </div>
                  </th>
                  <th
                    className="cursor-pointer hover:text-white"
                    onClick={() => handleSort('value')}
                  >
                    <div className="flex items-center gap-1">
                      Value <SortIcon columnKey="value" />
                    </div>
                  </th>
                </>
              )}
              {showOwnership && (
                <th
                  className="cursor-pointer hover:text-white"
                  onClick={() => handleSort('ownership')}
                >
                  <div className="flex items-center gap-1">
                    Own% <SortIcon columnKey="ownership" />
                  </div>
                </th>
              )}
              <th>Team</th>
              <th>Opp</th>
            </tr>
          </thead>
          <tbody className="table-body">
            {filteredPlayers.map((player) => (
              <PlayerRow
                key={player.id}
                player={player}
                showProjections={showProjections}
                showOwnership={showOwnership}
                showLockControls={showLockControls}
                onLock={() => lockPlayer(player.id)}
                onFade={() => fadePlayer(player.id)}
                onUnlock={() => unlockPlayer(player.id)}
                onClick={onPlayerClick ? () => onPlayerClick(player) : undefined}
              />
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

// Individual player row component
function PlayerRow({
  player,
  showProjections,
  showOwnership,
  showLockControls,
  onLock,
  onFade,
  onUnlock,
  onClick,
}: {
  player: Player
  showProjections: boolean
  showOwnership: boolean
  showLockControls: boolean
  onLock: () => void
  onFade: () => void
  onUnlock: () => void
  onClick?: () => void
}) {
  const isLocked = useIsPlayerLocked(player.id)
  const isFaded = useIsPlayerFaded(player.id)

  const positionClass = `pos-${player.position.split('/')[0].toLowerCase()}`

  return (
    <tr
      className={cn(
        'player-row',
        isLocked && 'player-row-locked',
        isFaded && 'player-row-faded',
        player.injuryStatus && player.injuryStatus !== 'HEALTHY' && 'player-row-injured',
        onClick && 'cursor-pointer'
      )}
      onClick={onClick}
    >
      {showLockControls && (
        <td className="w-20">
          <div className="flex items-center gap-1">
            <button
              onClick={(e) => {
                e.stopPropagation()
                if (isLocked) onUnlock(); else onLock()
              }}
              className={cn(
                'p-1.5 rounded hover:bg-surface-active',
                isLocked ? 'text-positive' : 'text-gray-500'
              )}
              title={isLocked ? 'Unlock' : 'Lock'}
              type="button"
            >
              <Lock className="w-4 h-4" />
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation()
                if (isFaded) onUnlock(); else onFade()
              }}
              className={cn(
                'p-1.5 rounded hover:bg-surface-active',
                isFaded ? 'text-negative' : 'text-gray-500'
              )}
              title={isFaded ? 'Unfade' : 'Fade'}
              type="button"
            >
              <Ban className="w-4 h-4" />
            </button>
          </div>
        </td>
      )}
      <td>
        <div className="flex items-center gap-2">
          <span className="text-white font-medium">{player.name}</span>
          {player.injuryStatus && player.injuryStatus !== 'HEALTHY' && (
            <span className={cn('badge badge-negative text-xxs', getInjuryColor(player.injuryStatus))}>
              {player.injuryStatus}
            </span>
          )}
        </div>
      </td>
      <td>
        <span className={cn('font-medium', positionClass)}>{player.position}</span>
      </td>
      <td className="font-mono">{formatSalary(player.salary)}</td>
      {showProjections && (
        <>
          <td className="font-mono text-positive font-medium">
            {formatProjection(player.projection)}
          </td>
          <td className={cn('font-mono', getValueColor(player.value))}>
            {player.value.toFixed(1)}x
          </td>
        </>
      )}
      {showOwnership && (
        <td className={cn('font-mono', getOwnershipColor(player.ownership))}>
          {formatOwnership(player.ownership)}
        </td>
      )}
      <td className="text-gray-400">{player.team}</td>
      <td className="text-gray-500">{player.opponent}</td>
    </tr>
  )
}
