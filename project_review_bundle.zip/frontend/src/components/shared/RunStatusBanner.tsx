/**
 * RunStatusBanner.tsx — Displays live run status with auto-polling.
 *
 * Props:
 *   runId          — UUID of the run to track
 *   onComplete     — callback when run reaches 'completed'
 *   onFailed       — callback when run reaches 'failed'
 *   className      — optional extra Tailwind classes
 */

'use client'

import { useCallback } from 'react'
import { CheckCircle, XCircle, Loader2, Clock, AlertTriangle } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useRunPoller } from '@/lib/hooks/useRunPoller'
import type { RunStatusResult } from '@/lib/api/api'

interface RunStatusBannerProps {
  runId: string | null
  onComplete?: (result: RunStatusResult) => void
  onFailed?: (result: RunStatusResult) => void
  className?: string
}

const STATUS_CONFIG = {
  queued: {
    icon: Clock,
    bg: 'bg-yellow-50 border-yellow-200',
    text: 'text-yellow-800',
    iconColor: 'text-yellow-500',
    label: 'Queued',
  },
  running: {
    icon: Loader2,
    bg: 'bg-blue-50 border-blue-200',
    text: 'text-blue-800',
    iconColor: 'text-blue-500',
    label: 'Optimizing…',
  },
  completed: {
    icon: CheckCircle,
    bg: 'bg-green-50 border-green-200',
    text: 'text-green-800',
    iconColor: 'text-green-500',
    label: 'Complete',
  },
  failed: {
    icon: XCircle,
    bg: 'bg-red-50 border-red-200',
    text: 'text-red-800',
    iconColor: 'text-red-500',
    label: 'Failed',
  },
} as const

export function RunStatusBanner({
  runId,
  onComplete,
  onFailed,
  className,
}: RunStatusBannerProps) {
  const { status, numLineups, errorMessage, isPolling } = useRunPoller(runId, {
    onComplete,
    onFailed,
  })

  if (!runId || status === null) return null

  const cfg = STATUS_CONFIG[status as keyof typeof STATUS_CONFIG] ?? STATUS_CONFIG.queued
  const Icon = cfg.icon
  const spinning = status === 'running' || isPolling

  return (
    <div
      className={cn(
        'flex items-start gap-3 rounded-lg border px-4 py-3 text-sm',
        cfg.bg,
        className,
      )}
      role="status"
      aria-live="polite"
    >
      <Icon
        className={cn('mt-0.5 h-4 w-4 flex-shrink-0', cfg.iconColor, spinning && 'animate-spin')}
      />
      <div className="min-w-0 flex-1">
        <span className={cn('font-semibold', cfg.text)}>{cfg.label}</span>
        {status === 'completed' && numLineups > 0 && (
          <span className={cn('ml-2', cfg.text)}>— {numLineups} lineups ready</span>
        )}
        {status === 'failed' && errorMessage && (
          <p className={cn('mt-1 break-words', cfg.text)}>
            <AlertTriangle className="mr-1 inline h-3 w-3" />
            {errorMessage}
          </p>
        )}
        {(status === 'queued' || status === 'running') && (
          <span className={cn('ml-2 text-xs opacity-70', cfg.text)}>
            {isPolling ? 'Polling…' : ''}
          </span>
        )}
      </div>
    </div>
  )
}
