'use client'

import {
  Upload,
  Settings,
  BarChart3,
  Clock,
  ChevronLeft,
  ChevronRight,
  Zap,
  Activity,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { useUIStore, useSlateStore, useLineupStore } from '@/store'

interface SidebarProps {
  activeTab?: string
  onTabChange?: (tab: string) => void
  isOpen?: boolean
}

const navItems = [
  {
    id: 'upload',
    label: 'Upload Slate',
    icon: Upload,
    description: 'Import DK/FD CSV',
  },
  {
    id: 'settings',
    label: 'Settings',
    icon: Settings,
    description: 'Configure optimizer',
  },
  {
    id: 'results',
    label: 'Results',
    icon: BarChart3,
    description: 'View lineups',
  },
  {
    id: 'late-swap',
    label: 'Late Swap',
    icon: Clock,
    description: 'Live adjustments',
  },
  {
    id: 'signals',
    label: 'Signals',
    icon: Activity,
    description: 'Intelligence pipeline',
  },
]

export function Sidebar({ activeTab: activeProp, onTabChange, isOpen: isOpenProp }: SidebarProps) {
  const { toggleSidebar, sidebarOpen, activeTab: storeActiveTab, setActiveTab } = useUIStore()
  const { currentSlate } = useSlateStore()
  const { lineups } = useLineupStore()

  // Props override store values when provided (standalone usage), otherwise use store
  const activeTab = activeProp ?? storeActiveTab
  const isOpen = isOpenProp ?? sidebarOpen
  const handleTabChange = onTabChange ?? setActiveTab

  return (
    <aside
      className={cn(
        'fixed top-0 left-0 z-40 h-screen bg-background-secondary border-r border-border transition-all duration-300',
        isOpen ? 'w-64' : 'w-16'
      )}
    >
      {/* Logo */}
      <div className="flex items-center h-16 px-4 border-b border-border">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-info to-positive flex items-center justify-center">
            <Zap className="w-5 h-5 text-white" />
          </div>
          {isOpen && (
            <div className="animate-fade-in">
              <h1 className="text-lg font-bold text-white">DFS Edge</h1>
              <p className="text-xxs text-gray-500 -mt-1">Professional</p>
            </div>
          )}
        </div>
      </div>

      {/* Navigation */}
      <nav className="p-2 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon
          const isActive = activeTab === item.id

          // Show badges for certain tabs
          let badge = null
          if (item.id === 'results' && lineups.length > 0) {
            badge = lineups.length
          }

          return (
            <button
              key={item.id}
              onClick={() => handleTabChange(item.id)}
              className={cn(
                'w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all',
                isActive
                  ? 'bg-info/20 text-info'
                  : 'text-gray-400 hover:bg-surface-hover hover:text-white'
              )}
            >
              <Icon className="w-5 h-5 flex-shrink-0" />
              {isOpen && (
                <div className="flex-1 text-left animate-fade-in">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">{item.label}</span>
                    {badge && (
                      <span className="px-1.5 py-0.5 text-xs bg-info/30 text-info rounded">
                        {badge}
                      </span>
                    )}
                  </div>
                  <span className="text-xs text-gray-500">{item.description}</span>
                </div>
              )}
            </button>
          )
        })}
      </nav>

      {/* Slate Status */}
      {isOpen && currentSlate && (
        <div className="absolute bottom-20 left-0 right-0 px-4">
          <div className="p-3 bg-surface rounded-lg border border-border">
            <div className="flex items-center gap-2 mb-2">
              <div className="status-dot-positive" />
              <span className="text-xs font-medium text-gray-300">Slate Loaded</span>
            </div>
            <p className="text-sm text-white truncate">{currentSlate.fileName}</p>
            <div className="flex gap-2 mt-2">
              <span className={cn(
                'badge',
                currentSlate.platform === 'fanduel' ? 'badge-fanduel' : 'badge-draftkings'
              )}>
                {currentSlate.platform === 'fanduel' ? 'FD' : 'DK'}
              </span>
              <span className={cn(
                'badge',
                (currentSlate.sport ?? 'nba') === 'nba' ? 'badge-nba' : 'badge-nfl'
              )}>
                {(currentSlate.sport ?? 'nba').toUpperCase()}
              </span>
              <span className="badge badge-neutral">
                {currentSlate.players?.length ?? 0} players
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Collapse Toggle */}
      <button
        onClick={toggleSidebar}
        className="absolute bottom-4 left-0 right-0 mx-2 flex items-center justify-center gap-2 py-2 text-gray-400 hover:text-white hover:bg-surface-hover rounded-lg transition-colors"
      >
        {isOpen ? (
          <>
            <ChevronLeft className="w-4 h-4" />
            <span className="text-sm">Collapse</span>
          </>
        ) : (
          <ChevronRight className="w-4 h-4" />
        )}
      </button>
    </aside>
  )
}
