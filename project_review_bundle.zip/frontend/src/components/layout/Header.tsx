'use client'

import { Bell, RefreshCw, AlertTriangle, CheckCircle } from 'lucide-react'
import { useSlateStore, useLineupStore, useUIStore } from '@/store'
import { getTimeUntilLock } from '@/lib/utils'
import { useState, useEffect } from 'react'

export function Header() {
  const { currentSlate, isLoading } = useSlateStore()
  const { lineups, isGenerating } = useLineupStore()
  const { addToast } = useUIStore()
  const [currentTime, setCurrentTime] = useState<Date | null>(null)

  // Update time every minute (client-side only)
  useEffect(() => {
    // Initialize time on client
    setCurrentTime(new Date())
    
    const interval = setInterval(() => {
      setCurrentTime(new Date())
    }, 60000)
    return () => clearInterval(interval)
  }, [])

  const handleRefresh = () => {
    addToast({
      type: 'info',
      title: 'Refreshing data...',
      message: 'Fetching latest projections and ownership',
    })
    // TODO: Implement refresh logic
  }

  return (
    <header className="sticky top-0 z-30 bg-background-secondary/80 backdrop-blur border-b border-border">
      <div className="flex items-center justify-between h-14 px-6">
        {/* Left: Status */}
        <div className="flex items-center gap-4">
          {isLoading || isGenerating ? (
            <div className="flex items-center gap-2 text-info">
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span className="text-sm">
                {isGenerating ? 'Generating lineups...' : 'Loading...'}
              </span>
            </div>
          ) : currentSlate ? (
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-positive" />
                <span className="text-sm text-gray-300">
                  {currentSlate.players.length} players loaded
                </span>
              </div>
              {currentSlate.lockTime && (
                <div className="flex items-center gap-2 text-warning">
                  <AlertTriangle className="w-4 h-4" />
                  <span className="text-sm">
                    Lock: {getTimeUntilLock(currentSlate.lockTime)}
                  </span>
                </div>
              )}
            </div>
          ) : (
            <span className="text-sm text-gray-500">No slate loaded</span>
          )}
        </div>

        {/* Center: Quick Stats */}
        {lineups.length > 0 && (
          <div className="flex items-center gap-6">
            <div className="text-center">
              <p className="text-xs text-gray-500 uppercase">Lineups</p>
              <p className="text-lg font-semibold text-white">{lineups.length}</p>
            </div>
            <div className="text-center">
              <p className="text-xs text-gray-500 uppercase">Avg Proj</p>
              <p className="text-lg font-semibold text-positive">
                {(
                  lineups.reduce((sum, l) => sum + l.projectedPoints, 0) /
                  lineups.length
                ).toFixed(1)}
              </p>
            </div>
            <div className="text-center">
              <p className="text-xs text-gray-500 uppercase">Avg Salary</p>
              <p className="text-lg font-semibold text-white">
                $
                {Math.round(
                  lineups.reduce((sum, l) => sum + l.totalSalary, 0) /
                    lineups.length
                ).toLocaleString()}
              </p>
            </div>
          </div>
        )}

        {/* Right: Actions */}
        <div className="flex items-center gap-2">
          {currentSlate && (
            <button
              onClick={handleRefresh}
              className="btn-icon text-gray-400 hover:text-white"
              title="Refresh data"
            >
              <RefreshCw className="w-5 h-5" />
            </button>
          )}
          <button
            className="btn-icon text-gray-400 hover:text-white relative"
            title="Notifications"
          >
            <Bell className="w-5 h-5" />
            {/* Notification badge */}
            <span className="absolute top-1 right-1 w-2 h-2 bg-negative rounded-full" />
          </button>
          <div className="ml-2 pl-4 border-l border-border">
            {currentTime ? (
              <>
                <p className="text-xs text-gray-500">
                  {currentTime.toLocaleDateString('en-US', {
                    weekday: 'short',
                    month: 'short',
                    day: 'numeric',
                  })}
                </p>
                <p className="text-sm font-medium text-white">
                  {currentTime.toLocaleTimeString('en-US', {
                    hour: 'numeric',
                    minute: '2-digit',
                    hour12: true,
                  })}
                </p>
              </>
            ) : (
              <div className="h-10"></div>
            )}
          </div>
        </div>
      </div>

      {/* Progress bar for generation */}
      {isGenerating && (
        <div className="h-1 bg-surface">
          <div
            className="h-full bg-gradient-to-r from-info to-positive transition-all duration-300"
            style={{ width: '60%' }} // TODO: Connect to actual progress
          />
        </div>
      )}
    </header>
  )
}
