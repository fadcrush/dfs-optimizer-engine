'use client'

import { useEffect, useState } from 'react'
import { BarChart3, RefreshCw } from 'lucide-react'

// ---------------------------------------------------------------------------
// LineupAnalytics — displays post-run exposure stats for a given run ID
// ---------------------------------------------------------------------------

interface ExposureRow {
  player: string
  count: number
  pct: number
}

interface AnalyticsData {
  run_id: string
  total_lineups: number
  exposure: ExposureRow[]
}

export interface LineupAnalyticsProps {
  runId: string
  /** Optional callback invoked once analytics data has loaded */
  onLoad?: () => void
}

export function LineupAnalytics({ runId, onLoad }: LineupAnalyticsProps) {
  const [data, setData] = useState<AnalyticsData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!runId) return
    let cancelled = false

    async function load() {
      setLoading(true)
      setError(null)
      try {
        const res = await fetch(`/api/results/${encodeURIComponent(runId)}/exposure`, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('auth_token') ?? ''}`,
          },
        })
        if (cancelled) return
        if (!res.ok) {
          setError(`Could not load analytics (HTTP ${res.status})`)
          return
        }
        const json: AnalyticsData = await res.json()
        if (!cancelled) {
          setData(json)
          onLoad?.()
        }
      } catch (err) {
        if (!cancelled)
          setError(err instanceof Error ? err.message : 'Failed to load analytics')
      } finally {
        if (!cancelled) setLoading(false)
      }
    }

    load()
    return () => {
      cancelled = true
    }
  }, [runId])

  if (loading) {
    return (
      <div className="flex items-center gap-2 text-gray-400 py-8 justify-center">
        <RefreshCw className="w-4 h-4 animate-spin" />
        Loading analytics…
      </div>
    )
  }

  if (error) {
    return (
      <div className="text-center py-8 text-gray-400">
        <BarChart3 size={48} className="mx-auto mb-4 opacity-30" />
        <p className="text-sm text-red-400">{error}</p>
      </div>
    )
  }

  if (!data || !data.exposure?.length) {
    return (
      <div className="text-center py-8 text-gray-400">
        <BarChart3 size={48} className="mx-auto mb-4 opacity-30" />
        <p>No exposure data available for this run.</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="text-sm text-gray-400">
        Run <span className="font-mono text-gray-300">{data.run_id}</span> &mdash;{' '}
        {data.total_lineups} lineups
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-gray-700 text-left text-gray-400">
              <th className="pb-2 pr-4">Player</th>
              <th className="pb-2 pr-4">Lineups</th>
              <th className="pb-2">Exposure</th>
            </tr>
          </thead>
          <tbody>
            {data.exposure.map((row) => (
              <tr key={row.player} className="border-b border-gray-700/40">
                <td className="py-1.5 pr-4 text-gray-200">{row.player}</td>
                <td className="py-1.5 pr-4 tabular-nums">{row.count}</td>
                <td className="py-1.5">
                  <div className="flex items-center gap-2">
                    <div className="w-24 bg-gray-700 rounded-full h-1.5">
                      <div
                        className="bg-blue-500 h-1.5 rounded-full"
                        style={{ width: `${Math.min(row.pct * 100, 100).toFixed(1)}%` }}
                      />
                    </div>
                    <span className="tabular-nums text-gray-300">
                      {(row.pct * 100).toFixed(1)}%
                    </span>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
