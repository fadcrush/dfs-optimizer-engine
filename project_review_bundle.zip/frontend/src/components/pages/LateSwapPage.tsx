'use client'

import { useState, useEffect } from 'react'
import {
  Clock,
  AlertTriangle,
  RefreshCw,
  CheckCircle,
  ArrowRight,
  Activity,
} from 'lucide-react'
import { cn, getTimeUntilLock, getInjuryColor } from '@/lib/utils'
import { useSlateStore, useLineupStore, useUIStore } from '@/store'
import { getInjuryUpdates } from '@/lib/api/api'
import type { LateSwapRecommendation, LiveGame, InjuryStatus } from '@/types'

export function LateSwapPage() {
  const { currentSlate, players } = useSlateStore()
  const { lineups } = useLineupStore()
  const { addToast, setActiveTab } = useUIStore()

  const [isRefreshing, setIsRefreshing] = useState(false)
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null)
  const [recommendations, setRecommendations] = useState<LateSwapRecommendation[]>([])
  const [liveGames, _setLiveGames] = useState<LiveGame[]>([])
  // Mock data for demonstration
  useEffect(() => {
    if (currentSlate) {
      // Generate mock recommendations based on players
      const mockRecommendations: LateSwapRecommendation[] = players
        .filter((p) => p.injuryStatus && p.injuryStatus !== 'HEALTHY')
        .slice(0, 5)
        .map((p) => ({
          playerId: p.id,
          playerName: p.name,
          currentStatus: p.injuryStatus as InjuryStatus,
          recommendation: p.injuryStatus === 'OUT' ? 'swap_out' : 'keep',
          reason:
            p.injuryStatus === 'OUT'
              ? 'Player confirmed OUT - immediate swap recommended'
              : 'Monitoring - game-time decision expected',
          urgency:
            p.injuryStatus === 'OUT'
              ? 'critical'
              : p.injuryStatus === 'DOUBTFUL'
              ? 'high'
              : 'medium',
        }))

      setRecommendations(mockRecommendations)
      setLastUpdated(new Date())
    }
  }, [currentSlate, players])

  const handleRefresh = async () => {
    setIsRefreshing(true)
    try {
      const result = await getInjuryUpdates()
      if (result.success) {
        setLastUpdated(new Date())
        addToast({
          type: 'success',
          title: 'Data refreshed',
          message: 'Latest injury and lineup updates loaded',
        })
      }
    } catch (_err) {
      addToast({
        type: 'error',
        title: 'Refresh failed',
        message: 'Could not fetch latest updates',
      })
    } finally {
      setIsRefreshing(false)
    }
  }

  if (!currentSlate || lineups.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] text-center">
        <Clock className="w-16 h-16 text-gray-600 mb-4" />
        <h2 className="text-xl font-semibold text-white mb-2">Late Swap</h2>
        <p className="text-gray-400 mb-6">
          Generate lineups first to use the late swap assistant
        </p>
        <button onClick={() => setActiveTab('settings')} className="btn-primary">
          Go to Settings
        </button>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Late Swap Assistant</h1>
          <p className="text-gray-400 mt-1">
            Monitor live updates and swap recommendations
          </p>
        </div>

        <div className="flex items-center gap-4">
          {lastUpdated && (
            <span className="text-sm text-gray-500">
              Updated {lastUpdated.toLocaleTimeString()}
            </span>
          )}
          <button
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="btn-secondary"
          >
            <RefreshCw
              className={cn('w-4 h-4', isRefreshing && 'animate-spin')}
            />
            Refresh
          </button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Recommendations Panel */}
        <div className="col-span-2 space-y-4">
          <div className="card">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-medium text-white flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-warning" />
                Swap Recommendations
              </h3>
              <span className="badge badge-warning">
                {recommendations.filter((r) => r.urgency === 'critical').length} critical
              </span>
            </div>

            {recommendations.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <CheckCircle className="w-12 h-12 mx-auto mb-3 text-positive" />
                <p>All players are healthy and confirmed to play</p>
              </div>
            ) : (
              <div className="space-y-3">
                {recommendations.map((rec) => (
                  <div
                    key={rec.playerId}
                    className={cn(
                      'p-4 rounded-lg border',
                      rec.urgency === 'critical'
                        ? 'bg-negative/10 border-negative/50'
                        : rec.urgency === 'high'
                        ? 'bg-warning/10 border-warning/50'
                        : 'bg-surface border-border'
                    )}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div
                          className={cn(
                            'w-2 h-2 rounded-full',
                            rec.urgency === 'critical'
                              ? 'bg-negative animate-pulse'
                              : rec.urgency === 'high'
                              ? 'bg-warning animate-pulse'
                              : 'bg-info'
                          )}
                        />
                        <div>
                          <p className="font-medium text-white">{rec.playerName}</p>
                          <p className={cn('text-sm', getInjuryColor(rec.currentStatus))}>
                            {rec.currentStatus}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <span
                          className={cn(
                            'badge',
                            rec.recommendation === 'swap_out'
                              ? 'badge-negative'
                              : rec.recommendation === 'swap_in'
                              ? 'badge-positive'
                              : 'badge-info'
                          )}
                        >
                          {rec.recommendation === 'swap_out'
                            ? 'Swap Out'
                            : rec.recommendation === 'swap_in'
                            ? 'Swap In'
                            : 'Monitor'}
                        </span>
                      </div>
                    </div>

                    <p className="text-sm text-gray-400 mt-2">{rec.reason}</p>

                    {rec.recommendation === 'swap_out' && rec.replacementOptions && (
                      <div className="mt-3 pt-3 border-t border-border/50">
                        <p className="text-xs text-gray-500 mb-2">Replacement Options:</p>
                        <div className="flex gap-2">
                          {rec.replacementOptions.slice(0, 3).map((player) => (
                            <button
                              key={player.id}
                              className="px-3 py-1.5 bg-surface hover:bg-surface-hover rounded text-sm text-white"
                            >
                              {player.name}
                              <span className="text-positive ml-2">
                                {player.projection.toFixed(1)}
                              </span>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Affected Lineups */}
          <div className="card">
            <h3 className="font-medium text-white mb-4">Affected Lineups</h3>
            <div className="space-y-2">
              {recommendations
                .filter((r) => r.recommendation === 'swap_out')
                .map((rec) => {
                  const affectedCount = lineups.filter((l) =>
                    l.players.some((p) => p.player.id === rec.playerId)
                  ).length

                  return (
                    <div
                      key={rec.playerId}
                      className="flex items-center justify-between p-3 bg-surface rounded-lg"
                    >
                      <span className="text-white">{rec.playerName}</span>
                      <div className="flex items-center gap-3">
                        <span className="text-sm text-gray-400">
                          {affectedCount} lineups affected
                        </span>
                        <button className="btn-ghost text-info text-sm">
                          Auto-swap <ArrowRight className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  )
                })}
              {recommendations.filter((r) => r.recommendation === 'swap_out').length ===
                0 && (
                <p className="text-center text-gray-500 py-4">
                  No lineups need immediate attention
                </p>
              )}
            </div>
          </div>
        </div>

        {/* Right Sidebar */}
        <div className="space-y-4">
          {/* Lock Time */}
          <div className="card">
            <h3 className="font-medium text-white mb-4 flex items-center gap-2">
              <Clock className="w-5 h-5 text-warning" />
              Time Until Lock
            </h3>
            {currentSlate.lockTime ? (
              <div className="text-center">
                <p className="text-4xl font-bold text-warning">
                  {getTimeUntilLock(currentSlate.lockTime)}
                </p>
                <p className="text-sm text-gray-500 mt-2">
                  {new Date(currentSlate.lockTime).toLocaleTimeString()}
                </p>
              </div>
            ) : (
              <p className="text-center text-gray-500">Lock time not set</p>
            )}
          </div>

          {/* Live Games */}
          <div className="card">
            <h3 className="font-medium text-white mb-4 flex items-center gap-2">
              <Activity className="w-5 h-5 text-positive" />
              Live Games
            </h3>
            {liveGames.length === 0 ? (
              <p className="text-center text-gray-500 py-4">No games in progress</p>
            ) : (
              <div className="space-y-3">
                {liveGames.map((game) => (
                  <div
                    key={game.gameId}
                    className="p-3 bg-surface rounded-lg"
                  >
                    <div className="flex justify-between items-center">
                      <span className="text-white">{game.awayTeam}</span>
                      <span className="font-mono text-lg">{game.awayScore}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-white">{game.homeTeam}</span>
                      <span className="font-mono text-lg">{game.homeScore}</span>
                    </div>
                    <p className="text-xs text-gray-500 mt-2 text-center">
                      Q{game.quarter} - {game.timeRemaining}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Quick Stats */}
          <div className="card">
            <h3 className="font-medium text-white mb-4">Lineup Health</h3>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-400">Total Lineups</span>
                <span className="text-white">{lineups.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Healthy</span>
                <span className="text-positive">
                  {lineups.length -
                    lineups.filter((l) =>
                      l.players.some((p) =>
                        recommendations.some(
                          (r) =>
                            r.playerId === p.player.id && r.recommendation === 'swap_out'
                        )
                      )
                    ).length}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Need Swap</span>
                <span className="text-negative">
                  {
                    lineups.filter((l) =>
                      l.players.some((p) =>
                        recommendations.some(
                          (r) =>
                            r.playerId === p.player.id && r.recommendation === 'swap_out'
                        )
                      )
                    ).length
                  }
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
