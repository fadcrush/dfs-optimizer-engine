'use client'

import { useCallback, useState } from 'react'
import { useDropzone } from 'react-dropzone'
import {
  Upload,
  FileSpreadsheet,
  AlertTriangle,
  Loader2,
  ArrowRight,
  Trash2,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { useSlateStore, useUIStore } from '@/store'
import { uploadSlate, detectSlateType, generateProjections } from '@/lib/api/api'
import type { Platform, Sport, Player } from '@/types'
import { PlayerTable } from '@/components/shared/PlayerTable'

export function UploadPage() {
  const { currentSlate, setSlate, setPlayers, setLoading, setError, clearSlate, isLoading, error } =
    useSlateStore()
  const { addToast, setActiveTab } = useUIStore()
  const [_detectedPlatform, setDetectedPlatform] = useState<Platform | null>(null)
  const [_detectedSport, setDetectedSport] = useState<Sport | null>(null)
  const [_uploadedFile, setUploadedFile] = useState<File | null>(null)
  const [step, setStep] = useState<'upload' | 'preview' | 'ready'>('upload')

  const onDrop = useCallback(
    async (acceptedFiles: File[]) => {
      const file = acceptedFiles[0]
      if (!file) return

      // Validate file type
      if (!file.name.endsWith('.csv')) {
        addToast({
          type: 'error',
          title: 'Invalid file type',
          message: 'Please upload a CSV file from DraftKings or FanDuel',
        })
        return
      }

      setLoading(true)
      setUploadedFile(file)

      try {
        // Auto-detect platform and sport
        const detection = await detectSlateType(file)
        if (detection.success && detection.data) {
          setDetectedPlatform(detection.data.platform as Platform)
          setDetectedSport(detection.data.sport as Sport)
        }

        // Upload and process the slate
        const result = await uploadSlate(file)

        if (result.success && result.data) {
          const apiSlate = result.data
          // Adapt SlateData → Slate (fill in required fields with sensible defaults)
          const slate: import('@/types').Slate = {
            id: apiSlate.id ?? apiSlate.fileName,
            date: apiSlate.date ?? new Date().toISOString().slice(0, 10),
            slateType: apiSlate.slateType ?? 'Main',
            games: apiSlate.games ?? [],
            uploadedAt: apiSlate.uploadedAt ?? new Date().toISOString(),
            fileName: apiSlate.fileName,
            platform: apiSlate.platform as import('@/types').Platform,
            sport: apiSlate.sport as import('@/types').Sport,
            lockTime: apiSlate.lockTime ?? '',
            players: apiSlate.players ?? [],
          }
          setSlate(slate)
          setPlayers(slate.players ?? [])
          setStep('preview')

          addToast({
            type: 'success',
            title: 'Slate uploaded',
            message: `Loaded ${slate.players?.length ?? 0} players`,
          })
        } else {
          setError(result.error || 'Failed to upload slate')
          addToast({
            type: 'error',
            title: 'Upload failed',
            message: result.error,
          })
        }
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Unknown error'
        setError(message)
        addToast({
          type: 'error',
          title: 'Upload failed',
          message,
        })
      } finally {
        setLoading(false)
      }
    },
    [setSlate, setPlayers, setLoading, setError, addToast]
  )

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/csv': ['.csv'],
    },
    maxFiles: 1,
  })

  const handleGenerateProjections = async () => {
    if (!currentSlate) return

    setLoading(true)
    try {
      const result = await generateProjections(currentSlate.fileName)

      // The backend wraps projections inside result.data.result
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const raw = result.data as any
      const inner = raw?.result as
        | { projections?: Record<string, unknown>[]; stats?: Record<string, unknown> }
        | undefined

      const projections = inner?.projections
      const stats = inner?.stats

      if (result.success && projections) {
        const projectedPlayers = projections.map((p) => ({
          id: String(p.id ?? ''),
          name: String(p.name ?? ''),
          position: String(p.position ?? 'UTIL'),
          positions: [String(p.position ?? 'UTIL')],
          team: String(p.team ?? ''),
          opponent: String(p.opponent ?? ''),
          salary: Number(p.salary ?? 0),
          projection: Number(p.projection ?? 0),
          floor: Number(p.floor ?? 0),
          ceiling: Number(p.ceiling ?? 0),
          value: Number(p.value ?? 0),
          ownership: 0,
          leverage: 0,
          game: '',
        })) as Player[]

        setPlayers(projectedPlayers)
        setStep('ready')

        const withHistory = stats?.players_with_history ?? projectedPlayers.length
        addToast({
          type: 'success',
          title: 'Projections generated',
          message: `${withHistory} players with historical data`,
        })
      }
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Projection failed',
        message: err instanceof Error ? err.message : 'Unknown error',
      })
    } finally {
      setLoading(false)
    }
  }

  const handleClearSlate = () => {
    clearSlate()
    setUploadedFile(null)
    setDetectedPlatform(null)
    setDetectedSport(null)
    setStep('upload')
  }

  const handleProceedToSettings = () => {
    setActiveTab('settings')
  }

  // Upload Step
  if (step === 'upload' || !currentSlate) {
    return (
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-2xl font-bold text-white mb-2">Upload Slate</h1>
          <p className="text-gray-400">
            Import your DraftKings or FanDuel CSV to get started
          </p>
        </div>

        {/* Dropzone */}
        <div
          {...getRootProps()}
          className={cn(
            'relative border-2 border-dashed rounded-xl p-12 text-center cursor-pointer transition-all',
            isDragActive
              ? 'border-info bg-info/10'
              : 'border-border hover:border-gray-600 hover:bg-surface-hover',
            isLoading && 'pointer-events-none opacity-50'
          )}
        >
          <input {...getInputProps()} />

          {isLoading ? (
            <div className="flex flex-col items-center gap-4">
              <Loader2 className="w-12 h-12 text-info animate-spin" />
              <p className="text-gray-300">Processing slate...</p>
            </div>
          ) : isDragActive ? (
            <div className="flex flex-col items-center gap-4">
              <Upload className="w-12 h-12 text-info" />
              <p className="text-info font-medium">Drop your CSV here</p>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-surface flex items-center justify-center">
                <FileSpreadsheet className="w-8 h-8 text-gray-400" />
              </div>
              <div>
                <p className="text-white font-medium mb-1">
                  Drag & drop your slate CSV
                </p>
                <p className="text-sm text-gray-500">
                  or click to browse files
                </p>
              </div>
              <div className="flex gap-4 mt-4">
                <div className="px-3 py-1.5 bg-fanduel/20 text-fanduel rounded-md text-sm">
                  FanDuel
                </div>
                <div className="px-3 py-1.5 bg-draftkings/20 text-draftkings rounded-md text-sm">
                  DraftKings
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Error */}
        {error && (
          <div className="mt-4 p-4 bg-negative/20 border border-negative/50 rounded-lg flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-negative flex-shrink-0" />
            <p className="text-sm text-negative">{error}</p>
          </div>
        )}

        {/* Instructions */}
        <div className="mt-8 grid grid-cols-2 gap-4">
          <div className="card">
            <h3 className="font-medium text-white mb-2">FanDuel</h3>
            <ol className="text-sm text-gray-400 space-y-1">
              <li>1. Go to the contest lobby</li>
              <li>2. Click "Enter a contest"</li>
              <li>3. Download "Players List (CSV)"</li>
            </ol>
          </div>
          <div className="card">
            <h3 className="font-medium text-white mb-2">DraftKings</h3>
            <ol className="text-sm text-gray-400 space-y-1">
              <li>1. Go to draft page</li>
              <li>2. Click "Export to CSV"</li>
              <li>3. Use the downloaded file</li>
            </ol>
          </div>
        </div>
      </div>
    )
  }

  // Preview Step
  return (
    <div className="space-y-6">
      {/* Slate Info Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Slate Preview</h1>
          <div className="flex items-center gap-3 mt-2">
            <span
              className={cn(
                'badge',
                currentSlate.platform === 'fanduel' ? 'badge-fanduel' : 'badge-draftkings'
              )}
            >
              {currentSlate.platform === 'fanduel' ? 'FanDuel' : 'DraftKings'}
            </span>
            <span
              className={cn(
                'badge',
                currentSlate.sport === 'nba' ? 'badge-nba' : 'badge-nfl'
              )}
            >
              {(currentSlate.sport ?? 'nba').toUpperCase()}
            </span>
            <span className="text-sm text-gray-400">
              {currentSlate.players?.length ?? 0} players • {currentSlate.games?.length ?? 0} games
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button onClick={handleClearSlate} className="btn-ghost text-negative">
            <Trash2 className="w-4 h-4" />
            Clear
          </button>

          {step === 'preview' ? (
            <button
              onClick={handleGenerateProjections}
              disabled={isLoading}
              className="btn-primary"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  Generate Projections
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          ) : (
            <button onClick={handleProceedToSettings} className="btn-success">
              Continue to Settings
              <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Player Table */}
      <PlayerTable
        players={currentSlate.players ?? []}
        showProjections={step === 'ready'}
      />
    </div>
  )
}
