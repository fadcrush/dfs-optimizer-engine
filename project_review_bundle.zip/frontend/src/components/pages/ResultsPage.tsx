'use client'

import { useMemo, useState } from 'react'
import {
  Download,
  BarChart3,
  Table,
  Grid,
  CheckSquare,
  Square,
  Trash2,
  AlertCircle,
  Sparkles,
  Zap,
} from 'lucide-react'
import {
  cn,
} from '@/lib/utils'
import { useLineupStore, useUIStore } from '@/store'
import type { Lineup } from '@/types'
import { Tabs, TabPanel } from '@/components/ui/Tabs'
import { LineupAnalytics } from '@/components/analytics'

type ViewMode = 'table' | 'grid' | 'exposure'

export function ResultsPage() {
  const { lineups, selectedLineups, toggleLineupSelection, selectAllLineups, deselectAllLineups, clearLineups, stats, analytics_run_id } = useLineupStore()
  const { addToast, setActiveTab } = useUIStore()

  const [viewMode, setViewMode] = useState<ViewMode>('table')
  const [sortBy, setSortBy] = useState<'projection' | 'salary' | 'ownership'>('projection')
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc')
  const [activeTab, setActiveResultTab] = useState('lineups')
  const [analyticsLoaded, setAnalyticsLoaded] = useState(false)

  // Calculate exposure for each player
  const playerExposures = useMemo(() => {
    if (lineups.length === 0) return []

    const exposureMap = new Map<string, { name: string; count: number; avgProj: number }>()

    lineups.forEach((lineup) => {
      lineup.players.forEach((lp) => {
        const existing = exposureMap.get(lp.player.id) || {
          name: lp.player.name,
          count: 0,
          avgProj: 0,
        }
        existing.count++
        existing.avgProj += lp.player.projection
        exposureMap.set(lp.player.id, existing)
      })
    })

    return Array.from(exposureMap.entries())
      .map(([id, data]) => ({
        id,
        name: data.name,
        exposure: data.count / lineups.length,
        lineupCount: data.count,
        avgProjection: data.avgProj / data.count,
      }))
      .sort((a, b) => b.exposure - a.exposure)
  }, [lineups])

  // Sort lineups
  const sortedLineups = useMemo(() => {
    return [...lineups].sort((a, b) => {
      let aVal: number, bVal: number

      switch (sortBy) {
        case 'projection':
          aVal = a.projectedPoints
          bVal = b.projectedPoints
          break
        case 'salary':
          aVal = a.totalSalary
          bVal = b.totalSalary
          break
        case 'ownership':
          aVal = a.ownership
          bVal = b.ownership
          break
        default:
          aVal = a.projectedPoints
          bVal = b.projectedPoints
      }

      return sortDir === 'desc' ? bVal - aVal : aVal - bVal
    })
  }, [lineups, sortBy, sortDir])

  const handleExport = async () => {
    const selectedIds = Array.from(selectedLineups)
    const lineupsToExport = selectedIds.length > 0
      ? lineups.filter((l) => selectedIds.includes(l.id))
      : lineups

    // Create CSV content (FanDuel format)
    const headers = ['entry_id', 'contest_id', 'contest_name', 'entry_fee', 'PG', 'PG', 'SG', 'SG', 'SF', 'SF', 'PF', 'PF', 'C']
    const rows = lineupsToExport.map((lineup) => {
      const positions: Record<string, string[]> = { PG: [], SG: [], SF: [], PF: [], C: [] }

      lineup.players.forEach((lp) => {
        const pos = lp.slotPosition.replace('_2', '')
        if (positions[pos]) {
          positions[pos].push(lp.player.id)
        }
      })

      return [
        '', '', '', '',
        positions.PG[0] || '',
        positions.PG[1] || '',
        positions.SG[0] || '',
        positions.SG[1] || '',
        positions.SF[0] || '',
        positions.SF[1] || '',
        positions.PF[0] || '',
        positions.PF[1] || '',
        positions.C[0] || '',
      ]
    })

    const csv = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n')

    // Download
    const blob = new Blob([csv], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `lineups_${new Date().toISOString().slice(0, 10)}.csv`
    a.click()
    URL.revokeObjectURL(url)

    addToast({
      type: 'success',
      title: 'Lineups exported',
      message: `Downloaded ${lineupsToExport.length} lineups`,
    })
  }

  if (lineups.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] text-center">
        <AlertCircle className="w-16 h-16 text-gray-600 mb-4" />
        <h2 className="text-xl font-semibold text-white mb-2">No Lineups Generated</h2>
        <p className="text-gray-400 mb-6">
          Configure your settings and generate optimized lineups
        </p>
        <button onClick={() => setActiveTab('settings')} className="btn-primary">
          Go to Settings
        </button>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Generated Lineups</h1>
          <p className="text-gray-400 mt-1">
            {lineups.length} lineups • Avg projection: {stats?.avgProjection.toFixed(1)}
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* View Mode Toggle - Only show in Lineups tab */}
          {activeTab === 'lineups' && (
            <div className="flex bg-surface rounded-lg p-1">
              <button
                onClick={() => setViewMode('table')}
                className={cn(
                  'px-3 py-1.5 rounded text-sm',
                  viewMode === 'table' ? 'bg-info text-white' : 'text-gray-400'
                )}
              >
                <Table className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('grid')}
                className={cn(
                  'px-3 py-1.5 rounded text-sm',
                  viewMode === 'grid' ? 'bg-info text-white' : 'text-gray-400'
                )}
              >
                <Grid className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode('exposure')}
                className={cn(
                  'px-3 py-1.5 rounded text-sm',
                  viewMode === 'exposure' ? 'bg-info text-white' : 'text-gray-400'
                )}
              >
                <BarChart3 className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Selection Actions - Only show in Lineups tab */}
          {activeTab === 'lineups' && selectedLineups.size > 0 && (
            <div className="flex items-center gap-2 px-3 py-1.5 bg-surface rounded-lg">
              <span className="text-sm text-gray-300">{selectedLineups.size} selected</span>
              <button
                onClick={deselectAllLineups}
                className="text-gray-400 hover:text-white"
              >
                <Square className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Export Button - Only show in Lineups tab */}
          {activeTab === 'lineups' && (
            <button onClick={handleExport} className="btn-primary">
              <Download className="w-4 h-4" />
              Export {selectedLineups.size > 0 ? `(${selectedLineups.size})` : 'All'}
            </button>
          )}

          {/* Clear Button */}
          <button onClick={clearLineups} className="btn-ghost text-negative">
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Tabs */}
      <Tabs
        tabs={[
          { id: 'lineups', label: 'Lineups', icon: Grid },
          { 
            id: 'analytics', 
            label: 'Analytics', 
            icon: Sparkles,
            disabled: !analytics_run_id
          },
          { id: 'intel', label: 'Intel', icon: Zap, disabled: true },
        ]}
        activeTab={activeTab}
        onTabChange={setActiveResultTab}
      >
        {/* Lineups Tab */}
        <TabPanel tabId="lineups" activeTab={activeTab}>
          <div className="space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-4 gap-4">
              <div className="card">
                <p className="text-sm text-gray-400">Total Lineups</p>
                <p className="text-2xl font-bold text-white">{lineups.length}</p>
              </div>
              <div className="card">
                <p className="text-sm text-gray-400">Avg Projection</p>
                <p className="text-2xl font-bold text-positive">
                  {stats?.avgProjection.toFixed(1)}
                </p>
              </div>
              <div className="card">
                <p className="text-sm text-gray-400">Avg Salary</p>
                <p className="text-2xl font-bold text-white">
                  ${stats?.avgSalary.toLocaleString()}
                </p>
              </div>
              <div className="card">
                <p className="text-sm text-gray-400">Avg Ownership</p>
                <p className="text-2xl font-bold text-warning">
                  {stats?.avgOwnership.toFixed(1)}%
                </p>
              </div>
            </div>

            {/* Content */}
            {viewMode === 'table' && (
              <LineupsTable
                lineups={sortedLineups}
                selectedLineups={selectedLineups}
                onToggleSelection={toggleLineupSelection}
                onSelectAll={selectAllLineups}
                sortBy={sortBy}
                sortDir={sortDir}
                onSort={(key) => {
                  if (sortBy === key) {
                    setSortDir(sortDir === 'desc' ? 'asc' : 'desc')
                  } else {
                    setSortBy(key)
                    setSortDir('desc')
                  }
                }}
              />
            )}

            {viewMode === 'grid' && (
              <LineupsGrid
                lineups={sortedLineups}
                selectedLineups={selectedLineups}
                onToggleSelection={toggleLineupSelection}
              />
            )}

            {viewMode === 'exposure' && (
              <ExposureView exposures={playerExposures} totalLineups={lineups.length} />
            )}
          </div>
        </TabPanel>

        {/* Analytics Tab */}
        <TabPanel tabId="analytics" activeTab={activeTab}>
          {analytics_run_id ? (
            <LineupAnalytics
              runId={analytics_run_id}
              onLoad={() => setAnalyticsLoaded(true)}
            />
          ) : (
            <div className="flex flex-col items-center justify-center h-64 text-center">
              <BarChart3 className="w-16 h-16 text-gray-600 mb-4" />
              <h3 className="text-lg font-semibold text-white mb-2">
                No Analytics Available
              </h3>
              <p className="text-gray-400">
                Analytics will be available after generating lineups
              </p>
            </div>
          )}
        </TabPanel>

        {/* Intel Tab */}
        <TabPanel tabId="intel" activeTab={activeTab}>
          <div className="flex flex-col items-center justify-center h-64 text-center">
            <Zap className="w-16 h-16 text-gray-600 mb-4" />
            <h3 className="text-lg font-semibold text-white mb-2">
              Intel Coming Soon
            </h3>
            <p className="text-gray-400">
              Advanced lineup intelligence and insights
            </p>
          </div>
        </TabPanel>
      </Tabs>
    </div>
  )
}

// Table View Component
function LineupsTable({
  lineups,
  selectedLineups,
  onToggleSelection,
  onSelectAll,
  sortBy,
  sortDir,
  onSort,
}: {
  lineups: Lineup[]
  selectedLineups: Set<string>
  onToggleSelection: (id: string) => void
  onSelectAll: () => void
  sortBy: string
  sortDir: 'asc' | 'desc'
  onSort: (key: 'projection' | 'salary' | 'ownership') => void
}) {
  return (
    <div className="table-container">
      <table className="table">
        <thead className="table-header">
          <tr>
            <th className="w-10">
              <button onClick={onSelectAll}>
                <CheckSquare className="w-4 h-4 text-gray-400" />
              </button>
            </th>
            <th>#</th>
            <th>Players</th>
            <th
              className="cursor-pointer hover:text-white"
              onClick={() => onSort('projection')}
            >
              Projection {sortBy === 'projection' && (sortDir === 'desc' ? '↓' : '↑')}
            </th>
            <th
              className="cursor-pointer hover:text-white"
              onClick={() => onSort('salary')}
            >
              Salary {sortBy === 'salary' && (sortDir === 'desc' ? '↓' : '↑')}
            </th>
            <th
              className="cursor-pointer hover:text-white"
              onClick={() => onSort('ownership')}
            >
              Ownership {sortBy === 'ownership' && (sortDir === 'desc' ? '↓' : '↑')}
            </th>
          </tr>
        </thead>
        <tbody className="table-body">
          {lineups.map((lineup, idx) => (
            <tr key={lineup.id}>
              <td>
                <button onClick={() => onToggleSelection(lineup.id)}>
                  {selectedLineups.has(lineup.id) ? (
                    <CheckSquare className="w-4 h-4 text-info" />
                  ) : (
                    <Square className="w-4 h-4 text-gray-500" />
                  )}
                </button>
              </td>
              <td className="font-mono text-gray-400">{idx + 1}</td>
              <td>
                <div className="flex flex-wrap gap-1">
                  {lineup.players.map((lp) => (
                    <span
                      key={lp.slotPosition}
                      className="px-2 py-0.5 bg-surface text-xs rounded"
                    >
                      {lp.player.name.split(' ').pop()}
                    </span>
                  ))}
                </div>
              </td>
              <td className="font-mono text-positive">
                {lineup.projectedPoints.toFixed(1)}
              </td>
              <td className="font-mono">${lineup.totalSalary.toLocaleString()}</td>
              <td className="font-mono text-warning">
                {(lineup.ownership * 100).toFixed(1)}%
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

// Grid View Component
function LineupsGrid({
  lineups,
  selectedLineups,
  onToggleSelection,
}: {
  lineups: Lineup[]
  selectedLineups: Set<string>
  onToggleSelection: (id: string) => void
}) {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
      {lineups.slice(0, 50).map((lineup, idx) => (
        <div
          key={lineup.id}
          onClick={() => onToggleSelection(lineup.id)}
          className={cn(
            'card cursor-pointer transition-all',
            selectedLineups.has(lineup.id) && 'ring-2 ring-info'
          )}
        >
          <div className="flex justify-between items-center mb-3">
            <span className="text-sm font-medium text-gray-400">#{idx + 1}</span>
            <span className="text-lg font-bold text-positive">
              {lineup.projectedPoints.toFixed(1)}
            </span>
          </div>
          <div className="space-y-1">
            {lineup.players.map((lp) => (
              <div
                key={lp.slotPosition}
                className="flex justify-between text-sm"
              >
                <span className="text-gray-400">{lp.slotPosition.replace('_2', '2')}</span>
                <span className="text-white truncate ml-2">
                  {lp.player.name}
                </span>
              </div>
            ))}
          </div>
          <div className="mt-3 pt-3 border-t border-border flex justify-between text-sm">
            <span className="text-gray-400">${lineup.totalSalary.toLocaleString()}</span>
            <span className="text-warning">{(lineup.ownership * 100).toFixed(1)}% own</span>
          </div>
        </div>
      ))}
    </div>
  )
}

// Exposure View Component
function ExposureView({
  exposures,
  totalLineups: _totalLineups,
}: {
  exposures: Array<{
    id: string
    name: string
    exposure: number
    lineupCount: number
    avgProjection: number
  }>
  totalLineups: number
}) {
  return (
    <div className="space-y-4">
      <div className="card">
        <h3 className="font-medium text-white mb-4">Player Exposure Distribution</h3>
        <div className="space-y-3">
          {exposures.slice(0, 20).map((player) => (
            <div key={player.id} className="flex items-center gap-4">
              <div className="w-40 truncate text-sm text-white">{player.name}</div>
              <div className="flex-1">
                <div className="h-4 bg-surface rounded-full overflow-hidden">
                  <div
                    className={cn(
                      'h-full rounded-full transition-all',
                      player.exposure > 0.5
                        ? 'bg-negative'
                        : player.exposure > 0.3
                        ? 'bg-warning'
                        : 'bg-positive'
                    )}
                    style={{ width: `${player.exposure * 100}%` }}
                  />
                </div>
              </div>
              <div className="w-16 text-right font-mono text-sm text-gray-400">
                {(player.exposure * 100).toFixed(1)}%
              </div>
              <div className="w-12 text-right font-mono text-sm text-gray-500">
                ({player.lineupCount})
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
