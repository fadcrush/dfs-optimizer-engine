'use client'

import { useState } from 'react'
import {
  Settings,
  Sliders,
  Users,
  Lock,
  Ban,
  Play,
  ChevronDown,
  ChevronUp,
  AlertCircle,
  Loader2,
} from 'lucide-react'
import { cn, formatPercentage, formatSalary } from '@/lib/utils'
import {
  useSettingsStore,
  useSlateStore,
  useLineupStore,
  useUIStore,
} from '@/store'
import { generateLineups, generateOwnership } from '@/lib/api/api'
import type { ContestType } from '@/types'

const contestTypes: { id: ContestType; label: string; description: string }[] = [
  {
    id: 'cash',
    label: 'Cash Games',
    description: '50/50s, Double-Ups, H2H',
  },
  {
    id: 'small_gpp',
    label: 'Small GPP',
    description: 'Single entry, <1K entries',
  },
  {
    id: 'large_gpp',
    label: 'Large GPP',
    description: '3-max, Milly Maker',
  },
  {
    id: 'showdown',
    label: 'Showdown',
    description: 'Single game contests',
  },
]

export function SettingsPage() {
  const { settings, updateSettings, playerLocks, clearAllLocks } = useSettingsStore()
  const { currentSlate } = useSlateStore()
  const { setLineups, setGenerating, setStats, setAnalyticsRunId, isGenerating } = useLineupStore()
  const { addToast, setActiveTab } = useUIStore()

  const [expandedSection, setExpandedSection] = useState<string | null>('contest')
  const [numLineups, setNumLineups] = useState(150)

  const toggleSection = (section: string) => {
    setExpandedSection(expandedSection === section ? null : section)
  }

  const handleGenerate = async () => {
    if (!currentSlate) {
      addToast({
        type: 'error',
        title: 'No slate loaded',
        message: 'Please upload a slate first',
      })
      return
    }

    setGenerating(true)

    try {
      // Generate ownership predictions first
      const ownershipResult = await generateOwnership(currentSlate.fileName)
      if (!ownershipResult.success) {
        console.warn('Ownership generation failed:', ownershipResult.error)
      }

      // Generate lineups
      const result = await generateLineups({
        slateId: currentSlate.fileName,
        numLineups,
        contestType: settings.contestType,
        maxExposure: settings.maxExposure,
        minSalary: settings.minSalary,
        maxSalary: settings.maxSalary,
        lockedPlayers: playerLocks.filter((l) => l.type === 'lock').map((l) => l.playerId),
        fadedPlayers: playerLocks.filter((l) => l.type === 'fade').map((l) => l.playerId),
      })

      if (result.success && result.data) {
        // Cast backend lineup records to the store Lineup type
        setLineups(result.data.lineups as unknown as import('@/types').Lineup[])
        setStats({
          avgProjection: (result.data.stats?.avgProjection as number) ?? 0,
          avgSalary: (result.data.stats?.avgSalary as number) ?? 0,
          avgOwnership: (result.data.stats?.avgOwnership as number) ?? 0,
        })
        setAnalyticsRunId((result.data.analytics_run_id as string | undefined) || null)

        addToast({
          type: 'success',
          title: 'Lineups generated',
          message: `Created ${result.data.lineups.length} optimized lineups`,
        })

        setActiveTab('results')
      } else {
        addToast({
          type: 'error',
          title: 'Generation failed',
          message: result.error || 'Unknown error',
        })
      }
    } catch (err) {
      addToast({
        type: 'error',
        title: 'Generation failed',
        message: err instanceof Error ? err.message : 'Unknown error',
      })
    } finally {
      setGenerating(false)
    }
  }

  if (!currentSlate) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] text-center">
        <AlertCircle className="w-16 h-16 text-gray-600 mb-4" />
        <h2 className="text-xl font-semibold text-white mb-2">No Slate Loaded</h2>
        <p className="text-gray-400 mb-6">
          Upload a DraftKings or FanDuel CSV to configure optimization settings
        </p>
        <button onClick={() => setActiveTab('upload')} className="btn-primary">
          Upload Slate
        </button>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-3 gap-6">
      {/* Left: Settings Panels */}
      <div className="col-span-2 space-y-4">
        {/* Contest Type */}
        <SettingsSection
          title="Contest Type"
          icon={<Users className="w-5 h-5" />}
          isExpanded={expandedSection === 'contest'}
          onToggle={() => toggleSection('contest')}
        >
          <div className="grid grid-cols-2 gap-3">
            {contestTypes.map((type) => (
              <button
                key={type.id}
                onClick={() => updateSettings({ contestType: type.id })}
                className={cn(
                  'p-4 rounded-lg border-2 text-left transition-all',
                  settings.contestType === type.id
                    ? 'border-info bg-info/10'
                    : 'border-border hover:border-gray-600'
                )}
              >
                <span className="font-medium text-white">{type.label}</span>
                <p className="text-sm text-gray-400 mt-1">{type.description}</p>
              </button>
            ))}
          </div>
        </SettingsSection>

        {/* Exposure Settings */}
        <SettingsSection
          title="Exposure & Diversity"
          icon={<Sliders className="w-5 h-5" />}
          isExpanded={expandedSection === 'exposure'}
          onToggle={() => toggleSection('exposure')}
        >
          <div className="space-y-6">
            {/* Max Exposure Slider */}
            <div>
              <div className="flex justify-between mb-2">
                <label className="text-sm font-medium text-gray-300">
                  Max Player Exposure
                </label>
                <span className="text-sm text-info font-mono">
                  {formatPercentage(settings.maxExposure)}
                </span>
              </div>
              <input
                type="range"
                min="0.1"
                max="1"
                step="0.05"
                value={settings.maxExposure}
                onChange={(e) =>
                  updateSettings({ maxExposure: parseFloat(e.target.value) })
                }
                className="slider"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>10%</span>
                <span>100%</span>
              </div>
            </div>

            {/* Min Uniqueness */}
            <div>
              <div className="flex justify-between mb-2">
                <label className="text-sm font-medium text-gray-300">
                  Minimum Unique Players
                </label>
                <span className="text-sm text-info font-mono">
                  {settings.minUniqueness}
                </span>
              </div>
              <input
                type="range"
                min="1"
                max="5"
                step="1"
                value={settings.minUniqueness}
                onChange={(e) =>
                  updateSettings({ minUniqueness: parseInt(e.target.value) })
                }
                className="slider"
              />
              <p className="text-xs text-gray-500 mt-2">
                Each lineup must differ by at least {settings.minUniqueness} player(s)
              </p>
            </div>

            {/* Number of Lineups */}
            <div>
              <label className="text-sm font-medium text-gray-300 block mb-2">
                Number of Lineups
              </label>
              <div className="flex gap-2">
                {[20, 50, 100, 150, 200].map((num) => (
                  <button
                    key={num}
                    onClick={() => setNumLineups(num)}
                    className={cn(
                      'px-4 py-2 rounded-md text-sm font-medium transition-colors',
                      numLineups === num
                        ? 'bg-info text-white'
                        : 'bg-surface-hover text-gray-300 hover:bg-surface-active'
                    )}
                  >
                    {num}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </SettingsSection>

        {/* Salary Settings */}
        <SettingsSection
          title="Salary Constraints"
          icon={<Settings className="w-5 h-5" />}
          isExpanded={expandedSection === 'salary'}
          onToggle={() => toggleSection('salary')}
        >
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-gray-300 block mb-2">
                Minimum Salary
              </label>
              <input
                type="number"
                value={settings.minSalary}
                onChange={(e) =>
                  updateSettings({ minSalary: parseInt(e.target.value) })
                }
                className="input"
                min={40000}
                max={60000}
                step={1000}
              />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-300 block mb-2">
                Maximum Salary
              </label>
              <input
                type="number"
                value={settings.maxSalary}
                onChange={(e) =>
                  updateSettings({ maxSalary: parseInt(e.target.value) })
                }
                className="input"
                min={50000}
                max={60000}
                step={100}
              />
            </div>
          </div>
          <p className="text-xs text-gray-500 mt-3">
            Cap: ${currentSlate.platform === 'fanduel' ? '60,000' : '50,000'}
          </p>
        </SettingsSection>

        {/* Stacking Settings (GPP only) */}
        {(settings.contestType === 'small_gpp' ||
          settings.contestType === 'large_gpp') && (
          <SettingsSection
            title="Stacking Rules"
            icon={<Users className="w-5 h-5" />}
            isExpanded={expandedSection === 'stacking'}
            onToggle={() => toggleSection('stacking')}
          >
            <div className="space-y-4">
              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={settings.requireStack}
                  onChange={(e) =>
                    updateSettings({ requireStack: e.target.checked })
                  }
                  className="w-4 h-4 rounded bg-surface border-border"
                />
                <span className="text-sm text-gray-300">Require game stack</span>
              </label>

              {settings.requireStack && (
                <div className="grid grid-cols-2 gap-4 mt-4">
                  <div>
                    <label className="text-sm font-medium text-gray-300 block mb-2">
                      Min Stack Size
                    </label>
                    <input
                      type="number"
                      value={settings.minStackSize}
                      onChange={(e) =>
                        updateSettings({ minStackSize: parseInt(e.target.value) })
                      }
                      className="input"
                      min={2}
                      max={5}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-300 block mb-2">
                      Max Stack Size
                    </label>
                    <input
                      type="number"
                      value={settings.maxStackSize}
                      onChange={(e) =>
                        updateSettings({ maxStackSize: parseInt(e.target.value) })
                      }
                      className="input"
                      min={2}
                      max={6}
                    />
                  </div>
                </div>
              )}
            </div>
          </SettingsSection>
        )}
      </div>

      {/* Right: Summary & Generate */}
      <div className="space-y-4">
        {/* Generate Button */}
        <div className="card">
          <button
            onClick={handleGenerate}
            disabled={isGenerating}
            className="w-full btn-success py-4 text-lg"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Play className="w-5 h-5" />
                Generate {numLineups} Lineups
              </>
            )}
          </button>
        </div>

        {/* Settings Summary */}
        <div className="card">
          <h3 className="font-medium text-white mb-4">Configuration Summary</h3>
          <div className="space-y-3 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-400">Contest Type</span>
              <span className="text-white capitalize">
                {settings.contestType.replace('_', ' ')}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Max Exposure</span>
              <span className="text-white">{formatPercentage(settings.maxExposure)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Salary Range</span>
              <span className="text-white">
                {formatSalary(settings.minSalary)} - {formatSalary(settings.maxSalary)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-400">Stacking</span>
              <span className="text-white">
                {settings.requireStack
                  ? `${settings.minStackSize}-${settings.maxStackSize} players`
                  : 'Disabled'}
              </span>
            </div>
          </div>
        </div>

        {/* Locks/Fades Summary */}
        {playerLocks.length > 0 && (
          <div className="card">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-medium text-white">Player Rules</h3>
              <button
                onClick={clearAllLocks}
                className="text-xs text-negative hover:underline"
              >
                Clear All
              </button>
            </div>
            <div className="space-y-2">
              {playerLocks.filter((l) => l.type === 'lock').length > 0 && (
                <div className="flex items-center gap-2 text-positive">
                  <Lock className="w-4 h-4" />
                  <span className="text-sm">
                    {playerLocks.filter((l) => l.type === 'lock').length} locked
                  </span>
                </div>
              )}
              {playerLocks.filter((l) => l.type === 'fade').length > 0 && (
                <div className="flex items-center gap-2 text-negative">
                  <Ban className="w-4 h-4" />
                  <span className="text-sm">
                    {playerLocks.filter((l) => l.type === 'fade').length} faded
                  </span>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

// Collapsible Settings Section Component
function SettingsSection({
  title,
  icon,
  isExpanded,
  onToggle,
  children,
}: {
  title: string
  icon: React.ReactNode
  isExpanded: boolean
  onToggle: () => void
  children: React.ReactNode
}) {
  return (
    <div className="card">
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between"
      >
        <div className="flex items-center gap-3">
          <span className="text-gray-400">{icon}</span>
          <h3 className="font-medium text-white">{title}</h3>
        </div>
        {isExpanded ? (
          <ChevronUp className="w-5 h-5 text-gray-400" />
        ) : (
          <ChevronDown className="w-5 h-5 text-gray-400" />
        )}
      </button>
      {isExpanded && <div className="mt-4 pt-4 border-t border-border">{children}</div>}
    </div>
  )
}
