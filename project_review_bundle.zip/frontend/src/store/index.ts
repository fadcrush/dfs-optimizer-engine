// ============================================================================
// DFS Edge Pro - Global State Store (Zustand)
// ============================================================================

import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type {
  Slate,
  Player,
  Lineup,
  OptimizerSettings,
  PlayerLock,
  Toast,
  WorkflowStep,
} from '@/types'
import {
  type AuthUser,
  login as apiLogin,
  signup as apiSignup,
  logout as apiLogout,
  getCurrentUser,
  getAuthToken,
} from '@/lib/api/api'

// ============================================================================
// Auth Store - User Authentication State
// ============================================================================

interface AuthState {
  user: AuthUser | null
  isAuthenticated: boolean
  isLoading: boolean
  error: string | null

  // Actions
  login: (email: string, password: string) => Promise<boolean>
  signup: (email: string, password: string, fullName: string) => Promise<boolean>
  logout: () => void
  checkAuth: () => Promise<void>
  clearError: () => void
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,
      isLoading: false,
      error: null,

      login: async (email, password) => {
        set({ isLoading: true, error: null })
        const result = await apiLogin(email, password)
        if (result.success && result.data) {
          set({
            user: result.data.user,
            isAuthenticated: true,
            isLoading: false,
          })
          return true
        }
        set({
          error: result.error || 'Login failed',
          isLoading: false,
        })
        return false
      },

      signup: async (email, password, fullName) => {
        set({ isLoading: true, error: null })
        const result = await apiSignup(email, password, fullName)
        if (result.success && result.data) {
          set({
            user: result.data.user,
            isAuthenticated: true,
            isLoading: false,
          })
          return true
        }
        set({
          error: result.error || 'Signup failed',
          isLoading: false,
        })
        return false
      },

      logout: () => {
        apiLogout()
        set({
          user: null,
          isAuthenticated: false,
          error: null,
        })
      },

      checkAuth: async () => {
        const token = getAuthToken()
        if (!token) {
          set({ user: null, isAuthenticated: false })
          return
        }
        set({ isLoading: true })
        const result = await getCurrentUser()
        if (result.success && result.data) {
          set({
            user: result.data,
            isAuthenticated: true,
            isLoading: false,
          })
        } else {
          set({
            user: null,
            isAuthenticated: false,
            isLoading: false,
          })
        }
      },

      clearError: () => set({ error: null }),
    }),
    {
      name: 'dfs-auth',
      partialize: (state) => ({
        user: state.user,
        isAuthenticated: state.isAuthenticated,
      }),
    }
  )
)

// ============================================================================
// Slate Store - Current Slate State
// ============================================================================

interface SlateState {
  currentSlate: Slate | null
  players: Player[]
  projections: Player[]
  isLoading: boolean
  error: string | null

  // Actions
  setSlate: (slate: Slate) => void
  setPlayers: (players: Player[]) => void
  setProjections: (projections: Player[]) => void
  clearSlate: () => void
  setLoading: (loading: boolean) => void
  setError: (error: string | null) => void
}

export const useSlateStore = create<SlateState>((set) => ({
  currentSlate: null,
  players: [],
  projections: [],
  isLoading: false,
  error: null,

  setSlate: (slate) => set({ currentSlate: slate, error: null }),
  setPlayers: (players) => set({ players }),
  setProjections: (projections) => set({ projections }),
  clearSlate: () => set({ currentSlate: null, players: [], projections: [] }),
  setLoading: (isLoading) => set({ isLoading }),
  setError: (error) => set({ error }),
}))

// ============================================================================
// Lineup Store - Generated Lineups
// ============================================================================

interface LineupState {
  lineups: Lineup[]
  selectedLineups: Set<string>
  isGenerating: boolean
  generationProgress: number
  analytics_run_id: string | null
  stats: {
    avgProjection: number
    avgSalary: number
    avgOwnership: number
  } | null

  // Actions
  setLineups: (lineups: Lineup[]) => void
  addLineups: (lineups: Lineup[]) => void
  clearLineups: () => void
  toggleLineupSelection: (lineupId: string) => void
  selectAllLineups: () => void
  deselectAllLineups: () => void
  setGenerating: (generating: boolean) => void
  setProgress: (progress: number) => void
  setStats: (stats: LineupState['stats']) => void
  setAnalyticsRunId: (runId: string | null) => void
}

export const useLineupStore = create<LineupState>((set, _get) => ({
  lineups: [],
  selectedLineups: new Set(),
  isGenerating: false,
  generationProgress: 0,
  analytics_run_id: null,
  stats: null,

  setLineups: (lineups) => set({ lineups, selectedLineups: new Set() }),
  addLineups: (newLineups) =>
    set((state) => ({ lineups: [...state.lineups, ...newLineups] })),
  clearLineups: () =>
    set({ lineups: [], selectedLineups: new Set(), stats: null, analytics_run_id: null }),
  toggleLineupSelection: (lineupId) =>
    set((state) => {
      const newSelection = new Set(state.selectedLineups)
      if (newSelection.has(lineupId)) {
        newSelection.delete(lineupId)
      } else {
        newSelection.add(lineupId)
      }
      return { selectedLineups: newSelection }
    }),
  selectAllLineups: () =>
    set((state) => ({
      selectedLineups: new Set(state.lineups.map((l) => l.id)),
    })),
  deselectAllLineups: () => set({ selectedLineups: new Set() }),
  setGenerating: (isGenerating) => set({ isGenerating }),
  setProgress: (generationProgress) => set({ generationProgress }),
  setStats: (stats) => set({ stats }),
  setAnalyticsRunId: (analytics_run_id) => set({ analytics_run_id }),
}))

// ============================================================================
// Settings Store - Optimizer Settings (Persisted)
// ============================================================================

interface SettingsState {
  settings: OptimizerSettings
  playerLocks: PlayerLock[]

  // Actions
  updateSettings: (updates: Partial<OptimizerSettings>) => void
  resetSettings: () => void
  lockPlayer: (playerId: string) => void
  fadePlayer: (playerId: string) => void
  unlockPlayer: (playerId: string) => void
  setPlayerExposure: (
    playerId: string,
    minExposure: number,
    maxExposure: number
  ) => void
  clearAllLocks: () => void
}

const defaultSettings: OptimizerSettings = {
  maxExposure: 0.35,
  minSalary: 49000,
  maxSalary: 60000,
  minUniqueness: 1,
  contestType: 'small_gpp',
  requireStack: true,
  minStackSize: 2,
  maxStackSize: 4,
  bringBackCount: 1,
}

export const useSettingsStore = create<SettingsState>()(
  persist(
    (set, _get) => ({
      settings: defaultSettings,
      playerLocks: [],

      updateSettings: (updates) =>
        set((state) => ({
          settings: { ...state.settings, ...updates },
        })),

      resetSettings: () => set({ settings: defaultSettings, playerLocks: [] }),

      lockPlayer: (playerId) =>
        set((state) => {
          const existing = state.playerLocks.find((l) => l.playerId === playerId)
          if (existing) {
            return {
              playerLocks: state.playerLocks.map((l) =>
                l.playerId === playerId ? { ...l, type: 'lock' } : l
              ),
            }
          }
          return {
            playerLocks: [...state.playerLocks, { playerId, type: 'lock' }],
          }
        }),

      fadePlayer: (playerId) =>
        set((state) => {
          const existing = state.playerLocks.find((l) => l.playerId === playerId)
          if (existing) {
            return {
              playerLocks: state.playerLocks.map((l) =>
                l.playerId === playerId ? { ...l, type: 'fade' } : l
              ),
            }
          }
          return {
            playerLocks: [...state.playerLocks, { playerId, type: 'fade' }],
          }
        }),

      unlockPlayer: (playerId) =>
        set((state) => ({
          playerLocks: state.playerLocks.filter((l) => l.playerId !== playerId),
        })),

      setPlayerExposure: (playerId, minExposure, maxExposure) =>
        set((state) => {
          const existing = state.playerLocks.find((l) => l.playerId === playerId)
          if (existing) {
            return {
              playerLocks: state.playerLocks.map((l) =>
                l.playerId === playerId ? { ...l, minExposure, maxExposure } : l
              ),
            }
          }
          return {
            playerLocks: [
              ...state.playerLocks,
              { playerId, type: 'lock', minExposure, maxExposure },
            ],
          }
        }),

      clearAllLocks: () => set({ playerLocks: [] }),
    }),
    {
      name: 'dfs-settings',
    }
  )
)

// ============================================================================
// UI Store - Toasts, Modals, Workflow
// ============================================================================

interface UIState {
  toasts: Toast[]
  workflowSteps: WorkflowStep[]
  sidebarOpen: boolean
  activeTab: string

  // Actions
  addToast: (toast: Omit<Toast, 'id'>) => void
  removeToast: (id: string) => void
  setWorkflowSteps: (steps: WorkflowStep[]) => void
  updateWorkflowStep: (stepId: string, updates: Partial<WorkflowStep>) => void
  toggleSidebar: () => void
  setActiveTab: (tab: string) => void
}

export const useUIStore = create<UIState>((set) => ({
  toasts: [],
  workflowSteps: [],
  sidebarOpen: true,
  activeTab: 'upload',

  addToast: (toast) =>
    set((state) => ({
      toasts: [
        ...state.toasts,
        { ...toast, id: `toast-${Date.now()}-${Math.random()}` },
      ],
    })),

  removeToast: (id) =>
    set((state) => ({
      toasts: state.toasts.filter((t) => t.id !== id),
    })),

  setWorkflowSteps: (workflowSteps) => set({ workflowSteps }),

  updateWorkflowStep: (stepId, updates) =>
    set((state) => ({
      workflowSteps: state.workflowSteps.map((step) =>
        step.id === stepId ? { ...step, ...updates } : step
      ),
    })),

  toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),

  setActiveTab: (activeTab) => set({ activeTab }),
}))

// ============================================================================
// Helper Hooks
// ============================================================================

// Get locked player IDs
export const useLockedPlayerIds = () =>
  useSettingsStore((state) =>
    state.playerLocks.filter((l) => l.type === 'lock').map((l) => l.playerId)
  )

// Get faded player IDs
export const useFadedPlayerIds = () =>
  useSettingsStore((state) =>
    state.playerLocks.filter((l) => l.type === 'fade').map((l) => l.playerId)
  )

// Check if a player is locked
export const useIsPlayerLocked = (playerId: string) =>
  useSettingsStore((state) =>
    state.playerLocks.some((l) => l.playerId === playerId && l.type === 'lock')
  )

// Check if a player is faded
export const useIsPlayerFaded = (playerId: string) =>
  useSettingsStore((state) =>
    state.playerLocks.some((l) => l.playerId === playerId && l.type === 'fade')
  )
