"""
Tests for injury-enrichment fail-mode configuration.

Covers:
  - enrich_with_injury_data() in both 'open' and 'closed' modes
  - Error classification: missing_key, invalid_key, rate_limited, network_failure
  - OUT filtering is never fully disabled (always applied)
  - Integration: optimizer router returns HTTP 503 in closed mode
  - Integration: optimizer router continues (and logs WARNING) in open mode

Run with:
    cd <repo-root>
    $env:PYTHONPATH = "backend/src"
    .venv/Scripts/pytest tests/test_injury_enrichment.py -v
"""

from __future__ import annotations

import sys
import os
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch, PropertyMock
import logging

# Ensure backend/src is importable
SRC = Path(__file__).resolve().parent.parent / "backend" / "src"
sys.path.insert(0, str(SRC))

os.environ.setdefault("USE_DUCKDB_FALLBACK", "true")
os.environ.setdefault("DATABASE_URL", "duckdb:///:memory:")

import pandas as pd
import pytest
from fastapi.testclient import TestClient


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _make_pool(rows: int = 5, has_injury_col: bool = False) -> pd.DataFrame:
    """Return a minimal player-pool DataFrame for use in enrich_with_injury_data unit tests."""
    data = {
        "Name": [f"Player {i}" for i in range(rows)],
        "Salary": [7000 + i * 100 for i in range(rows)],
        "Projection": [30.0 + i for i in range(rows)],
        "Position": ["PG", "SG", "SF", "PF", "C"][:rows],
        "Team": ["LAL"] * rows,
        "ID": [f"p{i}" for i in range(rows)],
    }
    if has_injury_col:
        data["Injury Status"] = ["", "", "OUT", "", ""]
    return pd.DataFrame(data)


def _make_large_pool(has_injury_col: bool = False) -> pd.DataFrame:
    """
    Return a pool with 3 players per position — enough for build_player_pool()
    to pass position-coverage validation even after one player is filtered OUT.
    """
    positions = ["PG", "PG", "PG", "SG", "SG", "SG",
                 "SF", "SF", "SF", "PF", "PF", "PF", "C", "C", "C"]
    n = len(positions)
    data = {
        "Name": [f"Player {i}" for i in range(n)],
        "Salary": [7000 + i * 100 for i in range(n)],
        "Projection": [30.0 + i for i in range(n)],
        "Position": positions,
        "Team": ["LAL"] * n,
        "ID": [f"p{i}" for i in range(n)],
    }
    if has_injury_col:
        # Player 6 is the first SF — mark OUT; two SFs remain after filtering
        statuses = [""] * n
        statuses[6] = "OUT"
        data["Injury Status"] = statuses
    return pd.DataFrame(data)


def _patch_settings(fail_mode: str = "open", required: bool = False):
    """
    Return a context manager that patches get_settings() at its DEFINITION site.

    enrich_with_injury_data does a lazy `from core.config import get_settings`
    *inside* the function body, so patching the module-level name on
    services.optimizer_service would fail (it has no such attribute).
    We must patch core.config.get_settings directly.
    """
    mock_settings = MagicMock()
    mock_settings.injury_data_fail_mode = fail_mode
    mock_settings.injury_data_required = required
    return patch("core.config.get_settings", return_value=mock_settings)


# ---------------------------------------------------------------------------
# Unit tests: enrich_with_injury_data
# ---------------------------------------------------------------------------

class TestEnrichWithInjuryDataOpenMode:
    """open fail-mode: failures produce a WARNING and return df unchanged."""

    def _enrich(self, side_effect: Any = None, api_key: str = "fake-key") -> pd.DataFrame:
        from services.optimizer_service import enrich_with_injury_data

        df = _make_pool()
        mock_service = MagicMock()
        mock_service.api_key = api_key
        mock_service.get_injury_updates.side_effect = side_effect

        with _patch_settings("open", required=False):
            with patch("services.injury_service.InjuryService", return_value=mock_service):
                return enrich_with_injury_data(df.copy(), run_id="test-run-open")

    # ── missing / invalid key ──────────────────────────────────────────────

    def test_missing_api_key_adds_empty_status_column(self):
        """No API key → open mode → Injury Status column added (all empty), no exception."""
        df = _make_pool()
        mock_service = MagicMock()
        mock_service.api_key = ""  # empty key

        from services.optimizer_service import enrich_with_injury_data

        with _patch_settings("open"):
            with patch("services.injury_service.InjuryService", return_value=mock_service):
                result = enrich_with_injury_data(df.copy(), run_id="no-key-run")

        assert "Injury Status" in result.columns
        assert (result["Injury Status"] == "").all()

    def test_missing_api_key_logs_warning(self, caplog):
        """No API key in open mode emits a WARNING."""
        df = _make_pool()
        mock_service = MagicMock()
        mock_service.api_key = ""

        from services.optimizer_service import enrich_with_injury_data

        with caplog.at_level(logging.WARNING, logger="services.optimizer_service"):
            with _patch_settings("open"):
                with patch("services.injury_service.InjuryService", return_value=mock_service):
                    enrich_with_injury_data(df.copy(), run_id="warn-run")

        assert any("missing_key" in r.message or "SPORTSDATA_API_KEY" in r.message for r in caplog.records)

    # ── network failure ────────────────────────────────────────────────────

    def test_network_failure_open_mode_continues(self):
        """Network error in open mode: Injury Status added as empty, no exception."""
        import requests

        result = self._enrich(side_effect=requests.exceptions.ConnectionError("unreachable"))

        assert "Injury Status" in result.columns
        assert (result["Injury Status"] == "").all()

    def test_network_failure_open_mode_logs_warning(self, caplog):
        import requests
        from services.optimizer_service import enrich_with_injury_data

        df = _make_pool()
        mock_service = MagicMock()
        mock_service.api_key = "fake-key"
        mock_service.get_injury_updates.side_effect = requests.exceptions.ConnectionError("no route")

        with caplog.at_level(logging.WARNING, logger="services.optimizer_service"):
            with _patch_settings("open"):
                with patch("services.injury_service.InjuryService", return_value=mock_service):
                    enrich_with_injury_data(df.copy(), run_id="net-fail-run")

        assert any("network_failure" in r.message for r in caplog.records)

    # ── rate-limit (HTTP 429) ──────────────────────────────────────────────

    def test_rate_limited_open_mode_continues(self):
        """HTTP 429 in open mode: Injury Status added as empty, no exception."""
        import requests

        mock_resp = MagicMock()
        mock_resp.status_code = 429
        exc = requests.exceptions.HTTPError(response=mock_resp)

        result = self._enrich(side_effect=exc)

        assert "Injury Status" in result.columns
        assert (result["Injury Status"] == "").all()

    def test_rate_limited_logs_correct_reason(self, caplog):
        import requests
        from services.optimizer_service import enrich_with_injury_data

        mock_resp = MagicMock()
        mock_resp.status_code = 429
        exc = requests.exceptions.HTTPError(response=mock_resp)

        df = _make_pool()
        mock_service = MagicMock()
        mock_service.api_key = "fake-key"
        mock_service.get_injury_updates.side_effect = exc

        with caplog.at_level(logging.WARNING, logger="services.optimizer_service"):
            with _patch_settings("open"):
                with patch("services.injury_service.InjuryService", return_value=mock_service):
                    enrich_with_injury_data(df.copy(), run_id="rl-run")

        assert any("rate_limited" in r.message for r in caplog.records)

    # ── invalid key (HTTP 401) ─────────────────────────────────────────────

    def test_invalid_key_open_mode_logs_correct_reason(self, caplog):
        import requests
        from services.optimizer_service import enrich_with_injury_data

        mock_resp = MagicMock()
        mock_resp.status_code = 401
        exc = requests.exceptions.HTTPError(response=mock_resp)

        df = _make_pool()
        mock_service = MagicMock()
        mock_service.api_key = "bad-key"
        mock_service.get_injury_updates.side_effect = exc

        with caplog.at_level(logging.WARNING, logger="services.optimizer_service"):
            with _patch_settings("open"):
                with patch("services.injury_service.InjuryService", return_value=mock_service):
                    enrich_with_injury_data(df.copy(), run_id="badkey-run")

        assert any("invalid_key" in r.message for r in caplog.records)

    # ── required=True escalates to ERROR ──────────────────────────────────

    def test_required_true_escalates_to_error(self, caplog):
        """open mode + INJURY_DATA_REQUIRED=True → logs at ERROR level."""
        import requests
        from services.optimizer_service import enrich_with_injury_data

        df = _make_pool()
        mock_service = MagicMock()
        mock_service.api_key = "fake-key"
        mock_service.get_injury_updates.side_effect = requests.exceptions.ConnectionError("timeout")

        with caplog.at_level(logging.DEBUG, logger="services.optimizer_service"):
            with _patch_settings("open", required=True):
                with patch("services.injury_service.InjuryService", return_value=mock_service):
                    enrich_with_injury_data(df.copy(), run_id="req-run")

        error_records = [r for r in caplog.records if r.levelno >= logging.ERROR]
        assert error_records, "Expected at least one ERROR log when INJURY_DATA_REQUIRED=True"

    # ── run_id appears in log messages ────────────────────────────────────

    def test_run_id_present_in_log_message(self, caplog):
        from services.optimizer_service import enrich_with_injury_data

        df = _make_pool()
        mock_service = MagicMock()
        mock_service.api_key = ""  # triggers missing_key

        with caplog.at_level(logging.WARNING, logger="services.optimizer_service"):
            with _patch_settings("open"):
                with patch("services.injury_service.InjuryService", return_value=mock_service):
                    enrich_with_injury_data(df.copy(), run_id="my-unique-run-id-xyz")

        assert any("my-unique-run-id-xyz" in r.message for r in caplog.records)


class TestEnrichWithInjuryDataClosedMode:
    """closed fail-mode: failures raise InjuryEnrichmentError."""

    def _enrich_closed(self, side_effect: Any = None, api_key: str = "fake-key") -> None:
        """Run enrich_with_injury_data in closed mode; caller expects exception."""
        from services.optimizer_service import enrich_with_injury_data

        df = _make_pool()
        mock_service = MagicMock()
        mock_service.api_key = api_key
        mock_service.get_injury_updates.side_effect = side_effect

        with _patch_settings("closed"):
            with patch("services.injury_service.InjuryService", return_value=mock_service):
                enrich_with_injury_data(df.copy(), run_id="closed-run")

    def test_missing_key_raises_injury_enrichment_error(self):
        from core.exceptions import InjuryEnrichmentError

        df = _make_pool()
        mock_service = MagicMock()
        mock_service.api_key = ""

        from services.optimizer_service import enrich_with_injury_data

        with pytest.raises(InjuryEnrichmentError) as exc_info:
            with _patch_settings("closed"):
                with patch("services.injury_service.InjuryService", return_value=mock_service):
                    enrich_with_injury_data(df.copy(), run_id="closed-nokey")

        assert exc_info.value.reason == "missing_key"
        assert "SPORTSDATA_API_KEY" in exc_info.value.detail

    def test_network_failure_raises_with_reason(self):
        from core.exceptions import InjuryEnrichmentError
        import requests

        with pytest.raises(InjuryEnrichmentError) as exc_info:
            self._enrich_closed(side_effect=requests.exceptions.ConnectionError("no route"))

        assert exc_info.value.reason == "network_failure"
        assert exc_info.value.run_id == "closed-run"

    def test_rate_limited_raises_with_reason_and_hint(self):
        from core.exceptions import InjuryEnrichmentError
        import requests

        mock_resp = MagicMock()
        mock_resp.status_code = 429
        exc = requests.exceptions.HTTPError(response=mock_resp)

        with pytest.raises(InjuryEnrichmentError) as exc_info:
            self._enrich_closed(side_effect=exc)

        assert exc_info.value.reason == "rate_limited"
        assert "429" in exc_info.value.detail or "rate limit" in exc_info.value.detail.lower()

    def test_invalid_key_403_raises_with_correct_reason(self):
        from core.exceptions import InjuryEnrichmentError
        import requests

        mock_resp = MagicMock()
        mock_resp.status_code = 403
        exc = requests.exceptions.HTTPError(response=mock_resp)

        with pytest.raises(InjuryEnrichmentError) as exc_info:
            self._enrich_closed(side_effect=exc)

        assert exc_info.value.reason == "invalid_key"

    def test_error_contains_actionable_message(self):
        """The raised exception detail must be a non-empty, human-readable string."""
        from core.exceptions import InjuryEnrichmentError

        df = _make_pool()
        mock_service = MagicMock()
        mock_service.api_key = ""

        from services.optimizer_service import enrich_with_injury_data

        with pytest.raises(InjuryEnrichmentError) as exc_info:
            with _patch_settings("closed"):
                with patch("services.injury_service.InjuryService", return_value=mock_service):
                    enrich_with_injury_data(df.copy(), run_id="detail-run")

        assert len(exc_info.value.detail) > 20, "Detail message must be actionable (> 20 chars)"


# ---------------------------------------------------------------------------
# Unit tests: OUT filtering is never fully disabled
# ---------------------------------------------------------------------------

class TestOutFilteringNeverDisabled:
    """OUT filtering block in build_player_pool always executes."""

    def test_out_players_removed_when_status_column_present(self):
        """Players with OUT status in CSV are excluded after build_player_pool."""
        from services.optimizer_service import build_player_pool

        # _make_large_pool: 3 players per position → after removing 1 SF, 2 SFs remain
        df_with_out = _make_large_pool(has_injury_col=True)
        # Player 6 is the first SF, marked OUT
        assert df_with_out.loc[6, "Injury Status"] == "OUT"
        out_name = df_with_out.loc[6, "Name"]  # "Player 6"

        pool = build_player_pool(df_with_out.copy(), platform="fanduel")

        assert out_name not in pool["Name"].values, (
            "OUT player must be removed by the injury filter in build_player_pool"
        )

    def test_open_mode_enrichment_failure_filter_runs_as_noop(self):
        """
        open mode: enrichment fails → all Injury Status = "" → filter runs but
        removes NO players (safe no-op, not a skip).
        """
        from services.optimizer_service import build_player_pool

        df = _make_large_pool()  # no injury column — DK-style slate; 3 per position
        original_count = len(df)

        mock_service = MagicMock()
        mock_service.api_key = ""  # triggers missing_key

        with _patch_settings("open"):
            with patch("services.injury_service.InjuryService", return_value=mock_service):
                pool = build_player_pool(df.copy(), platform="fanduel", run_id="noop-run")

        # Pool has all players (no one removed) because all statuses are ""
        assert len(pool) == original_count, (
            "open mode enrichment failure must not drop any players "
            "(filter runs but is a no-op)"
        )
        # Injury Status column must exist (filter can run)
        assert "Injury Status" in pool.columns

    def test_closed_mode_enrichment_failure_propagates_before_filter(self):
        """
        closed mode: InjuryEnrichmentError propagates out of build_player_pool
        BEFORE any lineups are generated (filter never even reached).
        """
        from core.exceptions import InjuryEnrichmentError
        from services.optimizer_service import build_player_pool

        df = _make_large_pool()  # 3 per position; error raised before pool validation
        mock_service = MagicMock()
        mock_service.api_key = ""  # triggers missing_key

        with pytest.raises(InjuryEnrichmentError):
            with _patch_settings("closed"):
                with patch("services.injury_service.InjuryService", return_value=mock_service):
                    build_player_pool(df.copy(), platform="fanduel", run_id="propagate-run")


# ---------------------------------------------------------------------------
# Integration smoke tests: optimizer router → HTTP 503 in closed mode
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def client():
    import main
    with TestClient(main.app, raise_server_exceptions=False) as c:
        yield c


# Minimal valid FanDuel slate CSV (has Injury Status column → no enrichment needed)
_MINIMAL_FD_CSV = (
    "Name,Salary,FPPG,Position,Team,Injury Status,ID\n"
    "PG1,8000,45,PG,LAL,,p1\n"
    "PG2,7500,40,PG,GSW,,p2\n"
    "PG3,7000,38,PG,BOS,,p3\n"
    "SG1,8200,46,SG,LAL,,p4\n"
    "SG2,7800,42,SG,GSW,,p5\n"
    "SG3,7200,39,SG,BOS,,p6\n"
    "SF1,8400,48,SF,LAL,,p7\n"
    "SF2,7600,43,SF,GSW,,p8\n"
    "SF3,7100,37,SF,BOS,,p9\n"
    "PF1,8100,44,PF,LAL,,p10\n"
    "PF2,7700,41,PF,GSW,,p11\n"
    "PF3,6900,36,PF,BOS,,p12\n"
    "C1,9000,52,C,LAL,,p13\n"
    "C2,8500,49,C,GSW,,p14\n"
    "C3,7300,40,C,BOS,,p15\n"
)


class TestRouterInjuryFailMode:
    """Integration tests for closed/open mode handling in the optimizer router."""

    def _upload_fd_csv(self, client: TestClient, csv_content: str = _MINIMAL_FD_CSV):
        """Helper: POST a CSV to /optimize-from-projections and return the response."""
        from io import BytesIO
        import main  # ensure app is imported

        return client.post(
            "/api/optimizer/optimize-from-projections",
            files={"projections": ("test_slate.csv", BytesIO(csv_content.encode()), "text/csv")},
            params={"num_lineups": 1},
        )

    def test_closed_mode_returns_503_on_missing_key(self, client: TestClient):
        """
        With INJURY_DATA_FAIL_MODE=closed and no API key, the optimizer
        must return HTTP 503 instead of generating lineups.

        We use a DraftKings-style CSV (no Injury Status column) to force enrichment.
        """
        dk_csv = _MINIMAL_FD_CSV.replace(",Injury Status,", ",").replace(
            ",Injury Status\n", "\n"
        )
        # Remove the Injury Status column from data rows
        rows = dk_csv.split("\n")
        header = rows[0]
        # DK slate: strip injury status column
        dk_csv_no_injury = "\n".join(rows)  # Already has no injury col after replace

        # Build a slate CSV that truly has no Injury Status column
        dk_no_inj = (
            "Name,Salary,FPPG,Position,Team,ID\n"
            "PG1,8000,45,PG,LAL,p1\n"
            "PG2,7500,40,PG,GSW,p2\n"
            "PG3,7000,38,PG,BOS,p3\n"
            "SG1,8200,46,SG,LAL,p4\n"
            "SG2,7800,42,SG,GSW,p5\n"
            "SG3,7200,39,SG,BOS,p6\n"
            "SF1,8400,48,SF,LAL,p7\n"
            "SF2,7600,43,SF,GSW,p8\n"
            "SF3,7100,37,SF,BOS,p9\n"
            "PF1,8100,44,PF,LAL,p10\n"
            "PF2,7700,41,PF,GSW,p11\n"
            "PF3,6900,36,PF,BOS,p12\n"
            "C1,9000,52,C,LAL,p13\n"
            "C2,8500,49,C,GSW,p14\n"
            "C3,7300,40,C,BOS,p15\n"
        )

        mock_settings = MagicMock()
        mock_settings.injury_data_fail_mode = "closed"
        mock_settings.injury_data_required = True

        mock_service = MagicMock()
        mock_service.api_key = ""  # no key → missing_key

        with patch("core.config.get_settings", return_value=mock_settings):
            with patch("services.injury_service.InjuryService", return_value=mock_service):
                r = self._upload_fd_csv(client, csv_content=dk_no_inj)

        assert r.status_code == 503, (
            f"Expected HTTP 503 in closed mode, got {r.status_code}: {r.text[:300]}"
        )
        body = r.json()
        detail = body.get("detail", {})
        if isinstance(detail, dict):
            assert detail.get("code") == "missing_key"
            assert "SPORTSDATA_API_KEY" in detail.get("message", "")

    def test_open_mode_returns_200_on_fd_slate_with_injury_col(self, client: TestClient):
        """
        FanDuel slate already has Injury Status column: enrichment is never
        triggered + optimization completes with 200.
        """
        mock_settings = MagicMock()
        mock_settings.injury_data_fail_mode = "open"
        mock_settings.injury_data_required = False

        with patch("core.config.get_settings", return_value=mock_settings):
            r = self._upload_fd_csv(client)

        # CSV has Injury Status → no enrichment call → open/closed irrelevant
        # Expect either 200 (success) or 500 (optimizer config issue) but NOT 503
        assert r.status_code != 503, (
            f"503 must never occur when slate already has Injury Status column;\n{r.text[:300]}"
        )
