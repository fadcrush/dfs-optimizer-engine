"""
test_runs.py — Tests for run lifecycle and lineup persistence.

Covers:
  - create_run / start_run / complete_run / fail_run
  - persist_lineups: player matching, salary/projection totals
  - LineupEntry denormalisation (slate_id column)
  - get_run / get_run_or_404
"""

from __future__ import annotations

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from models.base import DFSBase
from models.lineup import Lineup
from models.lineup_entry import LineupEntry
from models.player import Player
from models.projection import Projection
from models.run import Run, STATUS_QUEUED, STATUS_RUNNING, STATUS_COMPLETED, STATUS_FAILED
from models.slate import Slate
from services.run_service import (
    create_run,
    start_run,
    complete_run,
    fail_run,
    persist_lineups,
    get_run,
    get_run_or_404,
)

import uuid
from datetime import datetime, timezone


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def db_session():
    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    DFSBase.metadata.create_all(engine, checkfirst=True)
    factory = sessionmaker(bind=engine, autoflush=False, autocommit=False)
    session = factory()
    yield session
    session.close()
    DFSBase.metadata.drop_all(engine)


@pytest.fixture()
def slate_with_players(db_session):
    """Create a slate with 5 players + projections; return (slate, players)."""
    slate = Slate(
        id=str(uuid.uuid4()),
        sport="nba",
        platform="fanduel",
    )
    db_session.add(slate)
    db_session.flush()

    players = []
    for i in range(5):
        p = Player(
            id=str(uuid.uuid4()),
            slate_id=slate.id,
            external_id=f"FD{i+100}",
            name=f"Player {i+1}",
            position="PG" if i % 2 == 0 else "SG",
            team="LAL",
            salary=8000 - i * 100,
        )
        db_session.add(p)
        db_session.flush()

        pr = Projection(
            id=str(uuid.uuid4()),
            slate_id=slate.id,
            player_id=p.id,
            projection=35.0 + i,
            floor=25.0,
            ceiling=50.0,
            value=4.0,
        )
        db_session.add(pr)
        players.append(p)

    db_session.commit()
    return slate, players


# ---------------------------------------------------------------------------
# Run lifecycle
# ---------------------------------------------------------------------------

class TestRunLifecycle:
    def test_create_run_defaults(self, db_session):
        run = create_run(db_session)
        assert run.id is not None
        assert run.status == STATUS_QUEUED
        assert run.num_lineups == 0

    def test_create_run_with_slate(self, db_session, slate_with_players):
        slate, _ = slate_with_players
        run = create_run(db_session, slate_id=slate.id, num_lineups=10)
        assert run.slate_id == slate.id
        assert run.num_lineups == 10

    def test_start_run(self, db_session):
        run = create_run(db_session)
        updated = start_run(db_session, run.id)
        assert updated.status == STATUS_RUNNING
        assert updated.started_at is not None

    def test_complete_run(self, db_session):
        run = create_run(db_session)
        start_run(db_session, run.id)
        updated = complete_run(db_session, run.id)
        assert updated.status == STATUS_COMPLETED
        assert updated.completed_at is not None

    def test_fail_run(self, db_session):
        run = create_run(db_session)
        updated = fail_run(db_session, run.id, reason="optimizer exploded")
        assert updated.status == STATUS_FAILED
        assert "optimizer exploded" in updated.error_message

    def test_get_run_exists(self, db_session):
        run = create_run(db_session)
        fetched = get_run(db_session, run.id)
        assert fetched is not None
        assert fetched.id == run.id

    def test_get_run_missing(self, db_session):
        assert get_run(db_session, "nonexistent-id") is None

    def test_get_run_or_404_raises(self, db_session):
        with pytest.raises(ValueError, match="not found"):
            get_run_or_404(db_session, "bad-id")

    def test_start_missing_run_raises(self, db_session):
        with pytest.raises(ValueError):
            start_run(db_session, "bad-run-id")


# ---------------------------------------------------------------------------
# Lineup persistence
# ---------------------------------------------------------------------------

class TestPersistLineups:
    def _raw_lineups(self, players: list[Player], lineup_count: int = 3) -> list:
        """Generate simple fake optimizer output."""
        lineups = []
        for _n in range(lineup_count):
            lineup_players = [
                {
                    "Name": p.name,
                    "ID": p.external_id,
                    "Salary": p.salary,
                    "Projection": 40.0,
                    "Position": p.position,
                }
                for p in players[:5]
            ]
            lineups.append(lineup_players)
        return lineups

    def test_persist_creates_lineup_rows(self, db_session, slate_with_players):
        slate, players = slate_with_players
        run = create_run(db_session, slate_id=slate.id)
        written = persist_lineups(db_session, run.id, slate.id, self._raw_lineups(players))
        assert written == 3
        assert db_session.query(Lineup).filter_by(run_id=run.id).count() == 3

    def test_persist_creates_entry_rows(self, db_session, slate_with_players):
        slate, players = slate_with_players
        run = create_run(db_session, slate_id=slate.id)
        persist_lineups(db_session, run.id, slate.id, self._raw_lineups(players, 1))
        entries = db_session.query(LineupEntry).all()
        assert len(entries) == 5  # 5 players per lineup

    def test_entry_denormalised_slate_id(self, db_session, slate_with_players):
        slate, players = slate_with_players
        run = create_run(db_session, slate_id=slate.id)
        persist_lineups(db_session, run.id, slate.id, self._raw_lineups(players, 1))
        entries = db_session.query(LineupEntry).all()
        for entry in entries:
            assert entry.slate_id == slate.id

    def test_lineup_salary_total(self, db_session, slate_with_players):
        slate, players = slate_with_players
        run = create_run(db_session, slate_id=slate.id)
        persist_lineups(db_session, run.id, slate.id, self._raw_lineups(players, 1))
        lineup = db_session.query(Lineup).filter_by(run_id=run.id).one()
        expected_salary = sum(p.salary for p in players[:5])
        assert lineup.total_salary == expected_salary

    def test_lineup_projection_total(self, db_session, slate_with_players):
        slate, players = slate_with_players
        run = create_run(db_session, slate_id=slate.id)
        persist_lineups(db_session, run.id, slate.id, self._raw_lineups(players, 1))
        lineup = db_session.query(Lineup).filter_by(run_id=run.id).one()
        assert lineup.total_projection == pytest.approx(200.0)  # 5 * 40.0

    def test_name_fallback_when_no_external_id(self, db_session, slate_with_players):
        slate, players = slate_with_players
        run = create_run(db_session, slate_id=slate.id)
        raw = [
            [
                {"Name": players[0].name, "Salary": players[0].salary, "Projection": 30.0, "Position": "PG"},
            ]
        ]
        written = persist_lineups(db_session, run.id, slate.id, raw)
        assert written == 1
        entry = db_session.query(LineupEntry).first()
        assert entry.player_id == players[0].id

    def test_run_num_lineups_updated(self, db_session, slate_with_players):
        slate, players = slate_with_players
        run = create_run(db_session, slate_id=slate.id)
        persist_lineups(db_session, run.id, slate.id, self._raw_lineups(players, 7))
        db_session.refresh(run)
        assert run.num_lineups == 7
