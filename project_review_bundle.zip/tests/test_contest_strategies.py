"""
Tests for contest_strategies.py
"""

import pytest
from pathlib import Path
import sys

# Add backend to path
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT / "backend"))


class TestContestStrategyProfiles:
    """Test contest strategy profiles"""

    def test_cash_game_profile(self):
        """Test cash game strategy configuration"""
        cash_strategy = {
            'projection_weight': 0.8,
            'floor_weight': 0.7,
            'ceiling_weight': 0.0,
            'max_exposure': 1.0,
            'min_stack_size': 0,
            'max_stack_size': 0,
            'leverage_weight': 0.0,
            'randomness': 0.0
        }

        # Cash games prioritize projection and floor
        assert cash_strategy['projection_weight'] >= 0.7, "Cash should prioritize projection"
        assert cash_strategy['floor_weight'] >= 0.5, "Cash should prioritize floor"
        assert cash_strategy['max_exposure'] == 1.0, "Cash can repeat best players"
        assert cash_strategy['randomness'] == 0.0, "Cash should have no randomness"

    def test_small_gpp_profile(self):
        """Test small GPP strategy configuration"""
        small_gpp = {
            'projection_weight': 0.6,
            'floor_weight': 0.0,
            'ceiling_weight': 0.4,
            'max_exposure': 0.35,
            'min_stack_size': 2,
            'max_stack_size': 3,
            'leverage_weight': 0.3,
            'randomness': 0.15
        }

        # Small GPP balances projection and ceiling
        assert small_gpp['projection_weight'] + small_gpp['ceiling_weight'] == 1.0
        assert small_gpp['max_exposure'] <= 0.4, "Should diversify"
        assert small_gpp['min_stack_size'] >= 2, "Should require stacking"

    def test_large_gpp_profile(self):
        """Test large GPP (Milly Maker) strategy"""
        large_gpp = {
            'projection_weight': 0.4,
            'floor_weight': 0.0,
            'ceiling_weight': 0.6,
            'max_exposure': 0.20,
            'min_stack_size': 3,
            'max_stack_size': 5,
            'leverage_weight': 0.8,
            'randomness': 0.40
        }

        # Large GPP prioritizes ceiling and leverage
        assert large_gpp['ceiling_weight'] > large_gpp['projection_weight'], "Large GPP should chase upside"
        assert large_gpp['max_exposure'] <= 0.25, "Need heavy diversification"
        assert large_gpp['leverage_weight'] >= 0.5, "Should prioritize contrarian plays"
        assert large_gpp['randomness'] >= 0.3, "Should have significant randomness"


class TestStrategySelection:
    """Test strategy selection logic"""

    def test_strategy_by_contest_size(self):
        """Test selecting strategy based on contest size"""
        def get_strategy(num_entries):
            if num_entries < 100:
                return 'cash'
            elif num_entries < 10000:
                return 'small_gpp'
            else:
                return 'large_gpp'

        assert get_strategy(50) == 'cash'
        assert get_strategy(1000) == 'small_gpp'
        assert get_strategy(100000) == 'large_gpp'

    def test_strategy_by_payout_structure(self):
        """Test selecting strategy based on payout structure"""
        def get_strategy(top_heavy_payout):
            if top_heavy_payout:
                return 'large_gpp'  # Winner-take-all type
            else:
                return 'small_gpp'  # Flatter payout

        assert get_strategy(True) == 'large_gpp'
        assert get_strategy(False) == 'small_gpp'


class TestExposureLimits:
    """Test exposure limit calculations"""

    def test_exposure_by_strategy(self):
        """Test exposure limits per strategy"""
        strategies = {
            'cash': {'max_exposure': 1.0},
            'small_gpp': {'max_exposure': 0.35},
            'large_gpp': {'max_exposure': 0.20}
        }

        # More conservative as contest size increases
        assert strategies['cash']['max_exposure'] > strategies['small_gpp']['max_exposure']
        assert strategies['small_gpp']['max_exposure'] > strategies['large_gpp']['max_exposure']

    def test_exposure_calculation(self):
        """Test player exposure calculation across lineups"""
        num_lineups = 100
        player_appearances = {
            'Jokic': 85,
            'Luka': 60,
            'Trae': 25,
            'Random': 5
        }

        for player, appearances in player_appearances.items():
            exposure = appearances / num_lineups
            assert 0 <= exposure <= 1.0

        # Check specific exposures
        assert player_appearances['Jokic'] / num_lineups == 0.85
        assert player_appearances['Random'] / num_lineups == 0.05


class TestStackingRules:
    """Test stacking requirements by strategy"""

    def test_cash_no_stacking(self):
        """Test that cash games don't require stacking"""
        cash_config = {
            'min_stack_size': 0,
            'max_stack_size': 0,
            'require_stack': False
        }

        assert cash_config['require_stack'] == False

    def test_gpp_stacking(self):
        """Test GPP stacking requirements"""
        gpp_config = {
            'min_stack_size': 2,
            'max_stack_size': 4,
            'require_stack': True,
            'stack_from_same_game': True
        }

        assert gpp_config['require_stack'] == True
        assert gpp_config['min_stack_size'] >= 2
        assert gpp_config['stack_from_same_game'] == True

    def test_stack_validation(self):
        """Test stack validation logic"""
        lineup = {
            'players': ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I'],
            'games': {
                'A': 'GAME1', 'B': 'GAME1', 'C': 'GAME1',  # 3-stack
                'D': 'GAME2', 'E': 'GAME2',  # 2-stack
                'F': 'GAME3', 'G': 'GAME3',  # 2-stack
                'H': 'GAME4',
                'I': 'GAME5'
            }
        }

        # Count players per game
        game_counts = {}
        for player, game in lineup['games'].items():
            game_counts[game] = game_counts.get(game, 0) + 1

        # Check for valid stacks
        stacks = [count for count in game_counts.values() if count >= 2]
        assert len(stacks) >= 1, "Should have at least one stack"
        assert max(game_counts.values()) >= 2, "Largest stack should be at least 2"


class TestCorrelationLogic:
    """Test correlation-based strategy adjustments"""

    def test_positive_correlation(self):
        """Test positive correlation between teammates"""
        # Teammates in high-scoring games should correlate positively
        teammate_correlation = 0.65

        assert teammate_correlation > 0, "Teammates should have positive correlation"
        assert teammate_correlation < 1.0, "Correlation should be < 1"

    def test_negative_correlation(self):
        """Test correlation between opposing players"""
        # Players on opposing teams have weaker/negative correlation
        opponent_correlation = -0.15

        # Opponents can still go off together in shootouts
        assert opponent_correlation > -0.5, "Opponent correlation shouldn't be strongly negative"

    def test_game_stack_boost(self):
        """Test boosting projections for correlated stacks"""
        base_projection = 40.0
        correlation_boost = 1.05  # 5% boost for correlated stack

        boosted = base_projection * correlation_boost
        assert boosted > base_projection, "Stack should boost projection"
