"""
Pytest fixtures and configuration for DFS Edge Pro tests
"""

import pytest
import pandas as pd
import tempfile
import os
from pathlib import Path

# Add project root to path
import sys
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))
sys.path.insert(0, str(PROJECT_ROOT / "backend"))


@pytest.fixture
def sample_slate_df():
    """Create a sample FanDuel slate DataFrame for testing"""
    return pd.DataFrame({
        'Id': ['125017-1234', '125017-5678', '125017-9012', '125017-3456',
               '125017-7890', '125017-1111', '125017-2222', '125017-3333', '125017-4444'],
        'Position': ['PG', 'PG', 'SG', 'SG', 'SF', 'SF', 'PF', 'PF', 'C'],
        'Nickname': ['Luka Doncic', 'Trae Young', 'Devin Booker', 'Anthony Edwards',
                     'LeBron James', 'Kevin Durant', 'Giannis Antetokounmpo', 'Jayson Tatum', 'Nikola Jokic'],
        'First Name': ['Luka', 'Trae', 'Devin', 'Anthony', 'LeBron', 'Kevin', 'Giannis', 'Jayson', 'Nikola'],
        'Last Name': ['Doncic', 'Young', 'Booker', 'Edwards', 'James', 'Durant', 'Antetokounmpo', 'Tatum', 'Jokic'],
        'FPPG': [55.2, 42.1, 35.8, 38.5, 45.2, 42.0, 52.1, 40.5, 58.3],
        'Salary': [11500, 9200, 8100, 8500, 10200, 9800, 11200, 9500, 12000],
        'Game': ['DAL@PHX', 'ATL@MIA', 'PHX@DAL', 'MIN@DEN', 'LAL@GSW',
                 'PHX@DAL', 'MIL@BOS', 'BOS@MIL', 'DEN@MIN'],
        'Team': ['DAL', 'ATL', 'PHX', 'MIN', 'LAL', 'PHX', 'MIL', 'BOS', 'DEN'],
        'Opponent': ['PHX', 'MIA', 'DAL', 'DEN', 'GSW', 'DAL', 'BOS', 'MIL', 'MIN'],
        'Injury Indicator': ['', '', '', '', '', '', '', '', ''],
        'Roster Position': ['PG', 'PG', 'SG', 'SG', 'SF', 'SF', 'PF', 'PF', 'C']
    })


@pytest.fixture
def sample_projections_df():
    """Create sample projections DataFrame for testing"""
    return pd.DataFrame({
        'player_name': ['Luka Doncic', 'Trae Young', 'Devin Booker', 'Anthony Edwards',
                        'LeBron James', 'Kevin Durant', 'Giannis Antetokounmpo', 'Jayson Tatum', 'Nikola Jokic'],
        'position': ['PG', 'PG', 'SG', 'SG', 'SF', 'SF', 'PF', 'PF', 'C'],
        'salary': [11500, 9200, 8100, 8500, 10200, 9800, 11200, 9500, 12000],
        'team': ['DAL', 'ATL', 'PHX', 'MIN', 'LAL', 'PHX', 'MIL', 'BOS', 'DEN'],
        'opponent': ['PHX', 'MIA', 'DAL', 'DEN', 'GSW', 'DAL', 'BOS', 'MIL', 'MIN'],
        'projection': [55.0, 42.0, 36.0, 38.0, 45.0, 42.0, 52.0, 40.0, 58.0],
        'floor': [45.0, 32.0, 28.0, 30.0, 38.0, 34.0, 42.0, 32.0, 48.0],
        'ceiling': [70.0, 55.0, 48.0, 50.0, 58.0, 52.0, 65.0, 52.0, 72.0]
    })


@pytest.fixture
def sample_ownership_df():
    """Create sample ownership DataFrame for testing"""
    return pd.DataFrame({
        'player_name': ['Luka Doncic', 'Nikola Jokic', 'Giannis Antetokounmpo'],
        'salary': [11500, 12000, 11200],
        'projection': [55.0, 58.0, 52.0],
        'ownership_pct': [25.5, 28.0, 22.0],
        'leverage': [2.16, 2.07, 2.36]
    })


@pytest.fixture
def temp_slate_file(sample_slate_df):
    """Create a temporary slate CSV file for testing"""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
        sample_slate_df.to_csv(f, index=False)
        temp_path = f.name
    yield temp_path
    os.unlink(temp_path)


@pytest.fixture
def temp_projections_file(sample_projections_df):
    """Create a temporary projections CSV file for testing"""
    with tempfile.NamedTemporaryFile(mode='w', suffix='.csv', delete=False) as f:
        sample_projections_df.to_csv(f, index=False)
        temp_path = f.name
    yield temp_path
    os.unlink(temp_path)
