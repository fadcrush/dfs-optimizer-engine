"""
test_exposure.py — Tests for the DB-first exposure calculation.

Exercises the _exposure_from_db() helper in routers/results.py
using in-memory SQLite with the full DFS schema.
"""

from __future__ import annotations

import uuid

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from models.base import DFSBase
from models.lineup import Lineup
from models.lineup_entry import LineupEntry
from models.player import Player
from models.projection import Projection
from models.run import Run, STATUS_COMPLETED
from models.slate import Slate
from routers.results import _exposure_from_db


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def db_session():
    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    DFSBase.metadata.create_all(engine, checkfirst=True)
    factory = sessionmaker(bind=engine, autoflush=False, autocommit=False)
    session = factory()
    yield session
    session.close()
    DFSBase.metadata.drop_all(engine)


def _seed(db_session, num_lineups: int = 5):
    """
    Create a slate → run → N lineups each containing the same 3 players.
    Returns (run, player_a, player_b, player_c).
    """
    slate = Slate(id=str(uuid.uuid4()), sport="nba", platform="fanduel")
    db_session.add(slate)
    db_session.flush()

    players = []
    for i in range(3):
        p = Player(
            id=str(uuid.uuid4()),
            slate_id=slate.id,
            external_id=f"FD{i}",
            name=f"Player {i+1}",
            position="PG" if i == 0 else "SG",
            team="LAL",
            salary=8000 - i * 200,
        )
        db_session.add(p)
        db_session.flush()

        pr = Projection(
            id=str(uuid.uuid4()),
            slate_id=slate.id,
            player_id=p.id,
            projection=40.0 - i * 2,
            ownership_pct=20.0 + i * 5 if i < 2 else None,  # player 3 has no ownership
        )
        db_session.add(pr)
        players.append((p, pr))

    run = Run(id=str(uuid.uuid4()), slate_id=slate.id, status=STATUS_COMPLETED)
    db_session.add(run)
    db_session.flush()

    for n in range(num_lineups):
        lineup = Lineup(
            id=str(uuid.uuid4()),
            run_id=run.id,
            lineup_number=n + 1,
            total_salary=24000,
            total_projection=114.0,
        )
        db_session.add(lineup)
        db_session.flush()

        for (p, _proj) in players:
            entry = LineupEntry(
                id=str(uuid.uuid4()),
                lineup_id=lineup.id,
                player_id=p.id,
                slate_id=slate.id,
            )
            db_session.add(entry)

    db_session.commit()
    return run, players


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestExposureFromDB:
    def test_returns_none_for_missing_run(self, db_session):
        assert _exposure_from_db(db_session, "no-such-run") is None

    def test_returns_none_for_run_with_no_lineups(self, db_session):
        run = Run(id=str(uuid.uuid4()), status="queued")
        db_session.add(run)
        db_session.commit()
        assert _exposure_from_db(db_session, run.id) is None

    def test_total_lineups_correct(self, db_session):
        run, _ = _seed(db_session, num_lineups=7)
        result = _exposure_from_db(db_session, run.id)
        assert result["total_lineups"] == 7

    def test_all_players_present(self, db_session):
        run, players = _seed(db_session, num_lineups=5)
        result = _exposure_from_db(db_session, run.id)
        assert len(result["players"]) == 3

    def test_full_exposure_when_in_every_lineup(self, db_session):
        run, players = _seed(db_session, num_lineups=10)
        result = _exposure_from_db(db_session, run.id)
        for row in result["players"]:
            assert row["exposure_pct"] == pytest.approx(1.0)
            assert row["count"] == 10

    def test_sorted_by_exposure_descending(self, db_session):
        # Create a run where only player0 is in all lineups; players 1,2 are in half.
        slate = Slate(id=str(uuid.uuid4()), sport="nba", platform="fanduel")
        db_session.add(slate)
        db_session.flush()

        p_high = Player(
            id=str(uuid.uuid4()), slate_id=slate.id,
            external_id="HIGH", name="High", position="PG", team="LA", salary=9000,
        )
        p_low = Player(
            id=str(uuid.uuid4()), slate_id=slate.id,
            external_id="LOW", name="Low", position="SG", team="LA", salary=7000,
        )
        db_session.add_all([p_high, p_low])

        proj_high = Projection(id=str(uuid.uuid4()), slate_id=slate.id, player_id=p_high.id, projection=50.0)
        proj_low = Projection(id=str(uuid.uuid4()), slate_id=slate.id, player_id=p_low.id, projection=30.0)
        db_session.add_all([proj_high, proj_low])

        run = Run(id=str(uuid.uuid4()), slate_id=slate.id, status=STATUS_COMPLETED)
        db_session.add(run)
        db_session.flush()

        for n in range(4):
            lineup = Lineup(
                id=str(uuid.uuid4()), run_id=run.id, lineup_number=n+1,
                total_salary=16000, total_projection=80.0,
            )
            db_session.add(lineup)
            db_session.flush()

            # p_high in all 4 lineups; p_low in only 2
            db_session.add(LineupEntry(
                id=str(uuid.uuid4()), lineup_id=lineup.id,
                player_id=p_high.id, slate_id=slate.id,
            ))
            if n < 2:
                db_session.add(LineupEntry(
                    id=str(uuid.uuid4()), lineup_id=lineup.id,
                    player_id=p_low.id, slate_id=slate.id,
                ))

        db_session.commit()

        result = _exposure_from_db(db_session, run.id)
        assert result["players"][0]["name"] == "High"
        assert result["players"][0]["exposure_pct"] == pytest.approx(1.0)
        assert result["players"][1]["name"] == "Low"
        assert result["players"][1]["exposure_pct"] == pytest.approx(0.5)

    def test_leverage_computed_when_ownership_present(self, db_session):
        run, players = _seed(db_session, num_lineups=5)
        result = _exposure_from_db(db_session, run.id)
        # Players 0 and 1 have ownership_pct set; player 2 does not.
        names_with_leverage = {
            r["name"]: r["leverage"]
            for r in result["players"]
        }
        assert names_with_leverage.get("Player 1") is not None
        assert names_with_leverage.get("Player 2") is not None
        assert names_with_leverage.get("Player 3") is None  # no ownership

    def test_player_metadata_populated(self, db_session):
        run, players = _seed(db_session, num_lineups=3)
        result = _exposure_from_db(db_session, run.id)
        names = {r["name"] for r in result["players"]}
        assert "Player 1" in names
        first = next(r for r in result["players"] if r["name"] == "Player 1")
        assert first["team"] == "LAL"
        assert first["salary"] == 8000
