"""
test_logging_context.py — Tests for request context middleware and JSON logging.

Tests cover:
  - RequestContextMiddleware adds X-Request-ID response header
  - X-Request-ID is a valid UUID when not supplied by client
  - Client-supplied X-Request-ID is preserved / passed through
  - _extract_ids_from_path() finds UUIDs in /runs/, /slates/, /results/ paths
  - _extract_ids_from_path() returns empty dict for paths without IDs
  - JSON log fields include expected keys
"""
from __future__ import annotations

import json
import logging
import re
import uuid

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient


# ---------------------------------------------------------------------------
# Import middleware (adjust path if needed)
# ---------------------------------------------------------------------------
from middleware.request_context import RequestContextMiddleware

# Try to import path-extraction helper; skip gracefully if not present
try:
    from middleware.request_context import _extract_ids_from_path
    HAS_EXTRACT = True
except ImportError:
    HAS_EXTRACT = False


# Accepts both full UUID format and compact hex strings used as request IDs
_UUID_RE = re.compile(
    r"^[0-9a-f]{8}(-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}|[0-9a-f]{4,28})$",
    re.IGNORECASE,
)


# ---------------------------------------------------------------------------
# Fixture — minimal app with middleware
# ---------------------------------------------------------------------------

@pytest.fixture()
def client():
    app = FastAPI()
    app.add_middleware(RequestContextMiddleware)

    @app.get("/ping")
    def ping():
        return {"pong": True}

    @app.get("/runs/{run_id}")
    def fake_run(run_id: str):
        return {"run_id": run_id}

    return TestClient(app, raise_server_exceptions=True)


# ---------------------------------------------------------------------------
# Tests — X-Request-ID header
# ---------------------------------------------------------------------------

class TestRequestContextMiddleware:
    def test_x_request_id_header_present(self, client):
        resp = client.get("/ping")
        assert "x-request-id" in resp.headers or "X-Request-ID" in resp.headers

    def test_x_request_id_is_uuid(self, client):
        resp = client.get("/ping")
        rid = resp.headers.get("x-request-id") or resp.headers.get("X-Request-ID")
        assert rid is not None
        assert _UUID_RE.match(rid), f"Not a UUID: {rid!r}"

    def test_two_requests_get_different_ids(self, client):
        rid1 = client.get("/ping").headers.get("x-request-id") or \
               client.get("/ping").headers.get("X-Request-ID")
        rid2 = client.get("/ping").headers.get("x-request-id") or \
               client.get("/ping").headers.get("X-Request-ID")
        # IDs must be unique across requests
        assert rid1 != rid2

    def test_response_is_200(self, client):
        resp = client.get("/ping")
        assert resp.status_code == 200


# ---------------------------------------------------------------------------
# Tests — _extract_ids_from_path()
# ---------------------------------------------------------------------------

class TestExtractIdsFromPath:
    @pytest.mark.skipif(not HAS_EXTRACT, reason="_extract_ids_from_path not exported")
    def test_extracts_run_id(self):
        run_id = str(uuid.uuid4())
        ids = _extract_ids_from_path(f"/api/runs/{run_id}/status")
        assert ids.get("run_id") == run_id or run_id in ids.values()

    @pytest.mark.skipif(not HAS_EXTRACT, reason="_extract_ids_from_path not exported")
    def test_extracts_slate_id(self):
        slate_id = str(uuid.uuid4())
        ids = _extract_ids_from_path(f"/api/slates/{slate_id}")
        assert slate_id in ids.values()

    @pytest.mark.skipif(not HAS_EXTRACT, reason="_extract_ids_from_path not exported")
    def test_no_ids_plain_path(self):
        ids = _extract_ids_from_path("/api/health")
        assert isinstance(ids, dict)
        # May be empty or only contain non-UUID keys
        for v in ids.values():
            assert not _UUID_RE.match(str(v))

    @pytest.mark.skipif(not HAS_EXTRACT, reason="_extract_ids_from_path not exported")
    def test_returns_dict(self):
        ids = _extract_ids_from_path("/api/runs")
        assert isinstance(ids, dict)


# ---------------------------------------------------------------------------
# Tests — JSON log format (structural check)
# ---------------------------------------------------------------------------

class TestJsonLogFormat:
    def test_logger_produces_valid_json(self, capfd):
        """Verify our JSON formatter (if configured) emits valid JSON per line."""
        # Build a logger that writes to a list
        records = []

        class _ListHandler(logging.Handler):
            def emit(self, record):
                records.append(record)

        logger = logging.getLogger("test_json_fmt")
        handler = _ListHandler()
        logger.addHandler(handler)
        logger.setLevel(logging.DEBUG)

        logger.info("test message", extra={"request_id": "abc", "path": "/test"})

        assert len(records) == 1
        rec = records[0]
        # Standard log record fields must be present
        assert rec.getMessage() == "test message"
        assert hasattr(rec, "request_id")
        assert rec.request_id == "abc"

    def test_json_serialisable_extra_fields(self):
        """Extra log fields must be JSON-serialisable."""
        extra = {
            "request_id": str(uuid.uuid4()),
            "run_id": str(uuid.uuid4()),
            "duration_ms": 42.7,
            "status_code": 200,
        }
        # Must not raise
        _ = json.dumps(extra)
