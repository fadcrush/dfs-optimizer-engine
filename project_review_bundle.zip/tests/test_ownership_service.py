"""
Tests for ownership_simulator.py and ownership_service.py
"""

import pytest
import pandas as pd
from pathlib import Path
import sys

# Add backend to path
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT / "backend"))


class TestOwnershipSimulation:
    """Test ownership simulation logic"""

    def test_ownership_range(self, sample_ownership_df):
        """Test that ownership percentages are in valid range"""
        assert (sample_ownership_df['ownership_pct'] >= 0).all(), "Ownership can't be negative"
        assert (sample_ownership_df['ownership_pct'] <= 100).all(), "Ownership can't exceed 100%"

    def test_ownership_total_reasonable(self, sample_projections_df):
        """Test that total ownership across all players is reasonable"""
        # In a 9-player lineup, we expect ~900% total ownership
        # (100% for each slot, distributed across players)
        sample_projections_df['ownership_pct'] = [25, 28, 22, 15, 18, 12, 8, 6, 5]
        total_ownership = sample_projections_df['ownership_pct'].sum()

        # Should be less than 900% (some players rarely used)
        assert total_ownership < 900, f"Total ownership {total_ownership}% seems too high"

    def test_leverage_calculation(self, sample_ownership_df):
        """Test leverage score calculation"""
        # Leverage = Projection / Ownership
        calculated_leverage = sample_ownership_df['projection'] / sample_ownership_df['ownership_pct']

        # Leverage should be positive
        assert (calculated_leverage > 0).all(), "Leverage should be positive"


class TestOwnershipFactors:
    """Test individual ownership factors"""

    def test_salary_factor(self):
        """Test salary-based ownership factor"""
        # Sweet spots typically at $4-5.5K and $8.5-11.5K

        def salary_factor(salary):
            if 4000 <= salary <= 5500:
                return 1.3  # Value tier boost
            elif 8500 <= salary <= 11500:
                return 1.2  # Stud tier boost
            elif salary < 4000:
                return 0.7  # Punt plays less popular
            else:
                return 1.0

        assert salary_factor(4500) == 1.3, "Value tier should be boosted"
        assert salary_factor(10000) == 1.2, "Stud tier should be boosted"
        assert salary_factor(3500) == 0.7, "Punt tier should be reduced"
        assert salary_factor(7000) == 1.0, "Mid tier should be neutral"

    def test_value_factor(self, sample_projections_df):
        """Test value-based ownership factor"""
        sample_projections_df['value'] = sample_projections_df['projection'] / (sample_projections_df['salary'] / 1000)

        # High value players should have higher ownership
        high_value = sample_projections_df[sample_projections_df['value'] > 5.0]
        low_value = sample_projections_df[sample_projections_df['value'] < 4.0]

        # This is conceptual - actual test would check simulated ownership
        assert len(high_value) >= 0, "Should identify high value players"

    def test_position_factor(self):
        """Test position-based ownership factor"""
        # C position typically has fewer options
        position_weights = {
            'PG': 1.0,
            'SG': 1.0,
            'SF': 1.0,
            'PF': 1.0,
            'C': 1.2  # Higher concentration at C
        }

        assert position_weights['C'] > position_weights['PG'], "C should have higher concentration"

    def test_narrative_factor(self):
        """Test narrative-based ownership adjustments"""
        # Players with recent big games or injury replacements get boosted

        def narrative_boost(recent_performance, is_injury_replacement):
            boost = 1.0
            if recent_performance > 50:  # Big game last time
                boost *= 1.2
            if is_injury_replacement:
                boost *= 1.3
            return boost

        assert narrative_boost(55, False) == 1.2, "Recent big game should boost ownership"
        assert narrative_boost(30, True) == 1.3, "Injury replacement should boost ownership"
        assert narrative_boost(55, True) == 1.56, "Both factors should compound"


class TestLeverageAnalysis:
    """Test leverage analysis for GPP strategy"""

    def test_high_leverage_identification(self, sample_projections_df):
        """Test identification of high leverage plays"""
        sample_projections_df['ownership_pct'] = [25, 15, 10, 8, 12, 6, 18, 5, 22]
        sample_projections_df['leverage'] = sample_projections_df['projection'] / sample_projections_df['ownership_pct']

        # High leverage = high projection, low ownership
        high_leverage = sample_projections_df.nlargest(3, 'leverage')

        assert len(high_leverage) == 3, "Should identify top 3 leverage plays"
        # Top leverage should have leverage > 2.0 typically
        assert high_leverage['leverage'].min() > 1.5, "High leverage plays should have leverage > 1.5"

    def test_chalk_identification(self, sample_projections_df):
        """Test identification of chalk plays"""
        sample_projections_df['ownership_pct'] = [35, 30, 28, 25, 20, 15, 10, 8, 5]

        # Chalk = high ownership
        chalk_plays = sample_projections_df[sample_projections_df['ownership_pct'] > 25]

        assert len(chalk_plays) >= 2, "Should identify chalk plays (>25% owned)"

    def test_contrarian_strategy(self, sample_projections_df):
        """Test contrarian strategy logic"""
        sample_projections_df['ownership_pct'] = [30, 25, 20, 15, 12, 10, 8, 5, 3]
        sample_projections_df['is_contrarian'] = sample_projections_df['ownership_pct'] < 10

        contrarian_players = sample_projections_df[sample_projections_df['is_contrarian']]

        assert len(contrarian_players) >= 3, "Should have some contrarian options (<10% owned)"


class TestOwnershipOutput:
    """Test ownership output format"""

    def test_ownership_output_columns(self, sample_ownership_df):
        """Test that ownership output has required columns"""
        required_columns = ['player_name', 'ownership_pct']
        for col in required_columns:
            assert col in sample_ownership_df.columns, f"Missing required column: {col}"

    def test_leverage_output(self, sample_ownership_df):
        """Test that leverage is calculated correctly"""
        for _, row in sample_ownership_df.iterrows():
            expected_leverage = row['projection'] / row['ownership_pct']
            assert abs(row['leverage'] - expected_leverage) < 0.1, "Leverage calculation mismatch"
