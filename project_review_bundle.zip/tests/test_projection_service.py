"""
Tests for projection_service.py
"""

import pytest
import pandas as pd
from pathlib import Path
import sys

# Add backend to path
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT / "backend"))


class TestProjectionService:
    """Tests for the projection service"""

    def test_projections_output_format(self, sample_projections_df):
        """Test that projections have required columns"""
        required_columns = ['player_name', 'position', 'salary', 'projection', 'floor', 'ceiling']
        for col in required_columns:
            assert col in sample_projections_df.columns, f"Missing required column: {col}"

    def test_projections_values_positive(self, sample_projections_df):
        """Test that projections are positive numbers"""
        assert (sample_projections_df['projection'] > 0).all(), "Projections should be positive"
        assert (sample_projections_df['salary'] > 0).all(), "Salaries should be positive"

    def test_floor_ceiling_relationship(self, sample_projections_df):
        """Test that floor <= projection <= ceiling"""
        assert (sample_projections_df['floor'] <= sample_projections_df['projection']).all(), \
            "Floor should be <= projection"
        assert (sample_projections_df['projection'] <= sample_projections_df['ceiling']).all(), \
            "Projection should be <= ceiling"

    def test_salary_range_valid(self, sample_projections_df):
        """Test that salaries are in valid FanDuel range"""
        assert (sample_projections_df['salary'] >= 3500).all(), "Salary should be >= 3500"
        assert (sample_projections_df['salary'] <= 15000).all(), "Salary should be <= 15000"


class TestProjectionCalculations:
    """Test projection calculation logic"""

    def test_value_calculation(self, sample_projections_df):
        """Test value (pts per $1K) calculation"""
        sample_projections_df['value'] = sample_projections_df['projection'] / (sample_projections_df['salary'] / 1000)

        # Value should be reasonable (2-8 pts per $1K for NBA)
        assert (sample_projections_df['value'] >= 2).all(), "Value seems too low"
        assert (sample_projections_df['value'] <= 10).all(), "Value seems too high"

    def test_injury_adjustment(self):
        """Test that injury adjustments reduce projections appropriately"""
        base_projection = 40.0

        # OUT players should have 0 projection
        out_adj = base_projection * 0.0
        assert out_adj == 0.0

        # QUESTIONABLE players reduced by 30%
        q_adj = base_projection * 0.7
        assert q_adj == pytest.approx(28.0, 0.01)

        # PROBABLE players reduced by 10%
        p_adj = base_projection * 0.9
        assert p_adj == pytest.approx(36.0, 0.01)

    def test_vegas_adjustment(self):
        """Test Vegas total adjustment logic"""
        base_projection = 40.0
        league_avg_total = 220.0

        # High scoring game (240 total) should boost projection
        high_total = 240.0
        high_adj = base_projection * (high_total / league_avg_total)
        assert high_adj > base_projection, "High total should boost projection"

        # Low scoring game (200 total) should reduce projection
        low_total = 200.0
        low_adj = base_projection * (low_total / league_avg_total)
        assert low_adj < base_projection, "Low total should reduce projection"


class TestSlateProcessing:
    """Test slate CSV processing"""

    def test_slate_required_columns(self, sample_slate_df):
        """Test that slate has required FanDuel columns"""
        required = ['Id', 'Nickname', 'Position', 'Salary', 'Team']
        for col in required:
            assert col in sample_slate_df.columns, f"Missing required column: {col}"

    def test_slate_player_count(self, sample_slate_df):
        """Test that slate has minimum number of players"""
        assert len(sample_slate_df) >= 9, "Need at least 9 players to fill a roster"

    def test_slate_positions_covered(self, sample_slate_df):
        """Test that all required positions are covered"""
        positions = set(sample_slate_df['Position'].unique())
        required_positions = {'PG', 'SG', 'SF', 'PF', 'C'}
        assert required_positions.issubset(positions), "Missing required positions"
