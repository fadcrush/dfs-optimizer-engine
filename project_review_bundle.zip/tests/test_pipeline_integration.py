"""
test_pipeline_integration.py — Full pipeline integration tests.

Exercises the complete DB-first workflow:
  Upload CSV → Ownership → Create Run → Lineups → Exposure

All DB operations use in-memory SQLite.
Optimizer execution is mocked so the test does not require PuLP/CBC.
"""
from __future__ import annotations

import io
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List
from unittest.mock import patch

import pandas as pd
import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from models.base import DFSBase
from models.lineup import Lineup
from models.lineup_entry import LineupEntry
from models.player import Player
from models.projection import Projection
from models.run import Run, STATUS_COMPLETED
from models.slate import Slate


# ---------------------------------------------------------------------------
# Minimal FanDuel NBA CSV helpers
# ---------------------------------------------------------------------------

def _fd_projections_csv(num_players: int = 10) -> bytes:
    """Generate a valid FanDuel NBA projection CSV."""
    positions = ["PG", "SG", "SF", "PF", "C", "PG", "SG", "SF", "PF", "C"]
    rows = []
    for i in range(num_players):
        rows.append({
            "Nickname": f"Player{i+1} Test",
            "Id": f"FD{1000+i}",
            "Position": positions[i % len(positions)],
            "Salary": 9500 - i * 300,
            "Team": "LAL" if i % 2 == 0 else "GSW",
            "Opponent": "GSW" if i % 2 == 0 else "LAL",
            "Game": "LAL@GSW 07:30PM ET",
            "FPPG": 45.0 - i * 1.5,
            "Injury Indicator": "",
        })
    buf = io.StringIO()
    pd.DataFrame(rows).to_csv(buf, index=False)
    return buf.getvalue().encode()


def _ownership_csv(player_names: List[str]) -> bytes:
    rows = [{"Player": n, "Own%": 20.0 - i*1.5} for i, n in enumerate(player_names)]
    buf = io.StringIO()
    pd.DataFrame(rows).to_csv(buf, index=False)
    return buf.getvalue().encode()


# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def engine():
    eng = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    DFSBase.metadata.create_all(eng, checkfirst=True)
    yield eng
    DFSBase.metadata.drop_all(eng)


@pytest.fixture()
def db(engine):
    factory = sessionmaker(bind=engine, autoflush=False, autocommit=False)
    sess = factory()
    yield sess
    sess.rollback()
    sess.close()


def _make_test_app(db):
    from database.db import get_db
    from routers import projections, ownership, results
    from routers.runs import router as runs_router

    app = FastAPI()
    app.include_router(projections.router, prefix="/api")
    app.include_router(ownership.router, prefix="/api")
    app.include_router(runs_router, prefix="/api")
    app.include_router(results.router, prefix="/api")
    app.dependency_overrides[get_db] = lambda: db
    return app


@pytest.fixture()
def client(db):
    app = _make_test_app(db)
    return TestClient(app)


# ---------------------------------------------------------------------------
# Helper: seed a completed run with lineups in DB
# ---------------------------------------------------------------------------

def _seed_completed_run(db, num_lineups: int = 3, players_per_lineup: int = 5):
    slate = Slate(id=str(uuid.uuid4()), sport="nba", platform="fanduel")
    db.add(slate)
    db.flush()

    players = []
    for i in range(players_per_lineup):
        p = Player(
            id=str(uuid.uuid4()),
            slate_id=slate.id,
            external_id=f"FD{i}",
            name=f"Seed Player {i+1}",
            position=["PG", "SG", "SF", "PF", "C"][i % 5],
            team="LAL",
            salary=8000 - i * 200,
        )
        db.add(p)
        proj = Projection(
            id=str(uuid.uuid4()),
            slate_id=slate.id,
            player_id=p.id,
            projection=30.0 - i,
            ownership_pct=15.0 - i,
        )
        db.add(proj)
        players.append(p)
    db.flush()

    run = Run(
        id=str(uuid.uuid4()),
        slate_id=slate.id,
        status=STATUS_COMPLETED,
        num_lineups=num_lineups,
        created_at=datetime.now(timezone.utc).replace(tzinfo=None),
        completed_at=datetime.now(timezone.utc).replace(tzinfo=None),
    )
    db.add(run)
    db.flush()

    for ln_num in range(1, num_lineups + 1):
        lineup = Lineup(
            id=str(uuid.uuid4()),
            run_id=run.id,
            lineup_number=ln_num,
            total_salary=sum(p.salary for p in players),
            total_projection=sum(30.0 - i for i in range(len(players))),
        )
        db.add(lineup)
        db.flush()
        for pl in players:
            entry = LineupEntry(
                id=str(uuid.uuid4()),
                lineup_id=lineup.id,
                player_id=pl.id,
                slate_id=slate.id,
                position=pl.position,
            )
            db.add(entry)
    db.commit()
    return run, slate, players


# ---------------------------------------------------------------------------
# Phase 1: Projection upload → slate_id
# ---------------------------------------------------------------------------

class TestProjectionUpload:
    def test_upload_returns_slate_id(self, client):
        csv_bytes = _fd_projections_csv(10)
        resp = client.post(
            "/api/projections/upload-slate-to-db",
            files={"file": ("slate.csv", csv_bytes, "text/csv")},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert "slate_id" in data
        assert data["player_count"] >= 8

    def test_upload_detects_fanduel(self, client):
        resp = client.post(
            "/api/projections/upload-slate-to-db",
            files={"file": ("slate.csv", _fd_projections_csv(5), "text/csv")},
        )
        assert resp.json()["platform"] == "fanduel"

    def test_empty_file_raises_400(self, client):
        resp = client.post(
            "/api/projections/upload-slate-to-db",
            files={"file": ("empty.csv", b"", "text/csv")},
        )
        assert resp.status_code in (400, 422)

    def test_non_csv_raises_400(self, client):
        resp = client.post(
            "/api/projections/upload-slate-to-db",
            files={"file": ("data.txt", b"not a csv", "text/plain")},
        )
        assert resp.status_code == 400


# ---------------------------------------------------------------------------
# Phase 2: Ownership upload → links to slate
# ---------------------------------------------------------------------------

class TestOwnershipUpload:
    def test_upload_ownership(self, client, db):
        # First create a slate
        slate = Slate(id=str(uuid.uuid4()), sport="nba", platform="fanduel")
        db.add(slate)
        p = Player(
            id=str(uuid.uuid4()),
            slate_id=slate.id,
            name="Integration Player",
            position="PG",
            team="LAL",
            salary=8000,
            external_id="FD_INTEGRATION_1",
        )
        db.add(p)
        db.commit()

        csv_bytes = _ownership_csv(["Integration Player"])
        resp = client.post(
            f"/api/ownership/upload-to-db?slate_id={slate.id}",
            files={"file": ("own.csv", csv_bytes, "text/csv")},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert "matched" in data
        assert data["matched"] >= 1

    def test_missing_slate_id_raises_400(self, client):
        resp = client.post(
            "/api/ownership/upload-to-db",
            files={"file": ("own.csv", _ownership_csv(["Player"]), "text/csv")},
        )
        assert resp.status_code == 400


# ---------------------------------------------------------------------------
# Phase 3+: Run creation → lineups → exposure
# ---------------------------------------------------------------------------

class TestRunLifecycle:
    def test_get_lineups_for_completed_run(self, client, db):
        run, slate, players = _seed_completed_run(db, num_lineups=3, players_per_lineup=5)

        resp = client.get(f"/api/results/{run.id}/lineups")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total_lineups"] == 3
        assert len(data["lineups"]) == 3

        lineup0 = data["lineups"][0]
        assert "lineup_number" in lineup0
        assert "total_salary" in lineup0
        assert "total_projection" in lineup0
        assert len(lineup0["players"]) == 5

    def test_lineup_players_have_required_fields(self, client, db):
        run, _s, _p = _seed_completed_run(db, num_lineups=1, players_per_lineup=3)
        resp = client.get(f"/api/results/{run.id}/lineups")
        players = resp.json()["lineups"][0]["players"]
        for player in players:
            assert "player_id" in player
            assert "name" in player
            assert "position" in player
            assert "team" in player
            assert "salary" in player

    def test_get_exposure_for_completed_run(self, client, db):
        run, slate, players = _seed_completed_run(db, num_lineups=4, players_per_lineup=5)

        resp = client.get(f"/api/results/{run.id}/exposure")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total_lineups"] == 4
        assert len(data["players"]) > 0

        # All players in every lineup → 100% exposure
        for p_row in data["players"]:
            assert p_row["exposure_pct"] == pytest.approx(1.0)

    def test_get_lineups_404_for_unknown_run(self, client):
        resp = client.get(f"/api/results/{uuid.uuid4()}/lineups")
        assert resp.status_code == 404

    def test_get_exposure_404_for_unknown_run(self, client, db):
        # Mock file helpers to return None (no file exists)
        with patch("routers.results.get_run_file", return_value=None), \
             patch("routers.results.get_analytics_report", return_value=None):
            resp = client.get(f"/api/results/{uuid.uuid4()}/exposure")
        assert resp.status_code == 404

    def test_run_status_endpoint(self, client, db):
        run, _s, _p = _seed_completed_run(db, num_lineups=2)
        resp = client.get(f"/api/runs/{run.id}/status")
        assert resp.status_code == 200
        data = resp.json()
        assert data["run_id"] == run.id
        assert data["status"] == STATUS_COMPLETED
        assert data["num_lineups"] == 2

    def test_lineups_ordered_by_number(self, client, db):
        run, _s, _p = _seed_completed_run(db, num_lineups=5)
        resp = client.get(f"/api/results/{run.id}/lineups")
        nums = [l["lineup_number"] for l in resp.json()["lineups"]]
        assert nums == sorted(nums)
