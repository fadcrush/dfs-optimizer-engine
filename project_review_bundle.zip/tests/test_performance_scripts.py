"""
test_performance_scripts.py — Unit tests for scripts/performance_check.py
and scripts/check_indexes.py.

These tests do NOT spin up a live server.  They test:
  - _prom_line() builds valid Prometheus exposition text
  - Threshold comparison logic (pass / fail)
  - ASCII bar rendering (_row / _bar helpers)
  - check_indexes.py index-name extraction helpers
  - Missing-index SQL generation is well-formed
"""
from __future__ import annotations

import importlib
import sys
import types
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# Locate the scripts directory and import as modules
# ---------------------------------------------------------------------------

SCRIPTS_DIR = Path(__file__).parent.parent / "scripts"


def _load_script(name: str) -> types.ModuleType:
    """Load a script from scripts/ without running its __main__ block."""
    path = SCRIPTS_DIR / name
    if not path.exists():
        pytest.skip(f"Script not found: {path}")
    spec = importlib.util.spec_from_file_location(name.replace(".py", ""), str(path))
    module = importlib.util.module_from_spec(spec)
    # Prevent argparse / sys.exit in __main__ block from running
    with patch("sys.argv", ["script"]):
        try:
            spec.loader.exec_module(module)
        except SystemExit:
            pass
    return module


# ---------------------------------------------------------------------------
# prom_metrics._prom_line helper (reimport from router)
# ---------------------------------------------------------------------------

class TestPromLine:
    def test_includes_help_line(self):
        from routers.prom_metrics import _prom_line
        output = _prom_line("my_metric", 42, help_text="A test metric")
        assert "# HELP my_metric A test metric" in output

    def test_includes_type_line(self):
        from routers.prom_metrics import _prom_line
        output = _prom_line("my_metric", 42, type_hint="counter")
        assert "# TYPE my_metric counter" in output

    def test_includes_value_line(self):
        from routers.prom_metrics import _prom_line
        output = _prom_line("my_metric", 99)
        assert "my_metric 99" in output

    def test_label_included_in_value_line(self):
        from routers.prom_metrics import _prom_line
        output = _prom_line("my_metric", 5, labels='status="ok"')
        assert 'my_metric{status="ok"} 5' in output

    def test_no_help_when_not_provided(self):
        from routers.prom_metrics import _prom_line
        output = _prom_line("my_metric", 1)
        assert "# HELP" not in output

    def test_output_is_multiline_string(self):
        from routers.prom_metrics import _prom_line
        output = _prom_line("my_metric", 1, help_text="h", type_hint="gauge")
        assert "\n" in output


# ---------------------------------------------------------------------------
# performance_check.py — threshold logic
# ---------------------------------------------------------------------------

class TestPerformanceCheckThresholds:
    def setup_method(self):
        self.mod = _load_script("performance_check.py")

    def test_timing_under_threshold_passes(self):
        """A result with elapsed < threshold should not be flagged."""
        if not hasattr(self.mod, "THRESHOLDS"):
            pytest.skip("THRESHOLDS not exported from performance_check.py")
        for stage, limit in self.mod.THRESHOLDS.items():
            assert limit > 0, f"Threshold for {stage} must be positive"

    def test_all_threshold_keys_present(self):
        """Verify expected stage names exist in THRESHOLDS map."""
        if not hasattr(self.mod, "THRESHOLDS"):
            pytest.skip("THRESHOLDS not exported")
        required_stages = {"ingestion", "optimizer"}
        missing = required_stages - set(self.mod.THRESHOLDS.keys())
        assert not missing, f"Missing stages in THRESHOLDS: {missing}"

    def test_module_has_main_guard(self):
        """Script must have __name__ guard or argparse setup."""
        src = (SCRIPTS_DIR / "performance_check.py").read_text()
        assert 'if __name__' in src or 'ArgumentParser' in src


# ---------------------------------------------------------------------------
# check_indexes.py — SQL generation
# ---------------------------------------------------------------------------

class TestCheckIndexes:
    def setup_method(self):
        self.mod = _load_script("check_indexes.py")

    def test_required_indexes_defined(self):
        """Module must define a list/tuple of required index specs."""
        if not hasattr(self.mod, "REQUIRED_INDEXES"):
            pytest.skip("REQUIRED_INDEXES not exported")
        assert len(self.mod.REQUIRED_INDEXES) >= 4

    def test_required_indexes_have_table_and_column(self):
        if not hasattr(self.mod, "REQUIRED_INDEXES"):
            pytest.skip("REQUIRED_INDEXES not exported")
        for item in self.mod.REQUIRED_INDEXES:
            # Each entry should reference a table name and column name
            combined = str(item).lower()
            assert any(tbl in combined for tbl in ("run", "lineup", "projection", "ownership")), \
                f"Index spec does not reference a known table: {item}"

    def test_create_index_sql_is_valid(self):
        """CREATE INDEX SQL should be parseable (basic check)."""
        if not hasattr(self.mod, "REQUIRED_INDEXES"):
            pytest.skip("REQUIRED_INDEXES not exported")
        src = (SCRIPTS_DIR / "check_indexes.py").read_text()
        assert "CREATE INDEX" in src

    def test_module_has_database_url_arg(self):
        src = (SCRIPTS_DIR / "check_indexes.py").read_text()
        assert "database-url" in src or "database_url" in src.lower()


# ---------------------------------------------------------------------------
# deploy_validate.sh — basic content check
# ---------------------------------------------------------------------------

class TestDeployValidateScript:
    def test_script_exists(self):
        script = SCRIPTS_DIR / "deploy_validate.sh"
        assert script.exists(), "deploy_validate.sh not found"

    def _read_script(self) -> str:
        return (SCRIPTS_DIR / "deploy_validate.sh").read_text(encoding="utf-8", errors="replace")

    def test_script_references_alembic(self):
        assert "alembic" in self._read_script()

    def test_script_references_verify_pipeline(self):
        assert "verify_pipeline" in self._read_script()

    def test_script_checks_health_endpoint(self):
        assert "health" in self._read_script()

    def test_script_has_exit_on_failure(self):
        script = self._read_script()
        assert "exit 1" in script or "set -e" in script
