"""
Tests for FastAPI endpoints
"""

import pytest
from pathlib import Path
import sys

# Add backend to path
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT / "backend"))


class TestHealthEndpoints:
    """Test health check endpoints"""

    def test_root_response_structure(self):
        """Test root endpoint returns expected structure"""
        expected_keys = ['message', 'version', 'status', 'docs']

        # Mock response
        response = {
            'message': 'DFS Edge Pro API',
            'version': '1.0.0',
            'status': 'healthy',
            'docs': '/docs'
        }

        for key in expected_keys:
            assert key in response, f"Missing key: {key}"

    def test_health_endpoint_structure(self):
        """Test health endpoint returns status"""
        response = {
            'status': 'healthy',
            'day': 'Day 3 - Projections'
        }

        assert response['status'] == 'healthy'


class TestProjectionEndpoints:
    """Test projection API endpoints"""

    def test_upload_slate_response(self):
        """Test slate upload endpoint response"""
        response = {
            'success': True,
            'message': 'Slate uploaded successfully',
            'file_id': 'abc123',
            'player_count': 150
        }

        assert response['success'] == True
        assert 'file_id' in response
        assert response['player_count'] > 0

    def test_generate_projections_response(self):
        """Test projection generation response"""
        response = {
            'success': True,
            'projections_file': 'projections_20260120.csv',
            'player_count': 150,
            'avg_projection': 32.5
        }

        assert response['success'] == True
        assert 'projections_file' in response


class TestOptimizerEndpoints:
    """Test optimizer API endpoints"""

    def test_generate_lineups_response(self):
        """Test lineup generation response"""
        response = {
            'success': True,
            'num_lineups': 150,
            'lineups_file': 'lineups_20260120.csv',
            'avg_projection': 295.5,
            'avg_salary': 59200
        }

        assert response['success'] == True
        assert response['num_lineups'] == 150
        assert 'lineups_file' in response

    def test_optimizer_parameters_validation(self):
        """Test optimizer parameter constraints"""
        valid_params = {
            'num_lineups': 150,
            'platform': 'fanduel',
            'max_exposure': 0.35
        }

        # Validate ranges
        assert 1 <= valid_params['num_lineups'] <= 150
        assert valid_params['platform'] in ['fanduel', 'draftkings']
        assert 0 <= valid_params['max_exposure'] <= 1.0

    def test_invalid_num_lineups(self):
        """Test rejection of invalid lineup count"""
        invalid_counts = [-1, 0, 151, 1000]

        for count in invalid_counts:
            is_valid = 1 <= count <= 150
            assert not is_valid, f"Count {count} should be invalid"


class TestOwnershipEndpoints:
    """Test ownership API endpoints"""

    def test_predict_ownership_response(self):
        """Test ownership prediction response"""
        response = {
            'success': True,
            'ownership_file': 'ownership_20260120.csv',
            'players_analyzed': 150,
            'avg_ownership': 6.67
        }

        assert response['success'] == True
        assert 'ownership_file' in response


class TestAuthEndpoints:
    """Test authentication endpoints"""

    def test_signup_response(self):
        """Test user signup response"""
        response = {
            'success': True,
            'message': 'User created successfully',
            'user_id': 'user_abc123'
        }

        assert response['success'] == True
        assert 'user_id' in response

    def test_login_response(self):
        """Test user login response"""
        response = {
            'access_token': 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...',
            'token_type': 'bearer',
            'expires_in': 3600
        }

        assert 'access_token' in response
        assert response['token_type'] == 'bearer'

    def test_invalid_credentials(self):
        """Test invalid login credentials handling"""
        error_response = {
            'detail': 'Invalid email or password',
            'status_code': 401
        }

        assert error_response['status_code'] == 401


class TestRateLimiting:
    """Test rate limiting behavior"""

    def test_rate_limit_headers(self):
        """Test rate limit response headers"""
        headers = {
            'X-RateLimit-Limit': '60',
            'X-RateLimit-Remaining': '58',
            'X-RateLimit-Reset': '1705729200'
        }

        assert int(headers['X-RateLimit-Limit']) == 60
        assert int(headers['X-RateLimit-Remaining']) <= 60

    def test_rate_limit_exceeded(self):
        """Test rate limit exceeded response"""
        error_response = {
            'detail': 'Too many requests',
            'status_code': 429
        }

        assert error_response['status_code'] == 429


class TestSecurityHeaders:
    """Test security header presence"""

    def test_security_headers_present(self):
        """Test that security headers are set"""
        expected_headers = {
            'X-Content-Type-Options': 'nosniff',
            'X-Frame-Options': 'DENY',
            'X-XSS-Protection': '1; mode=block',
            'Strict-Transport-Security': 'max-age=31536000; includeSubDomains'
        }

        for header, value in expected_headers.items():
            assert value is not None, f"Missing header: {header}"

    def test_cors_configuration(self):
        """Test CORS is properly configured"""
        allowed_origins = [
            'http://localhost:3000',
            'http://localhost:8000',
            'http://127.0.0.1:3000',
            'http://127.0.0.1:8000'
        ]

        # Should not allow wildcard in production
        assert '*' not in allowed_origins
