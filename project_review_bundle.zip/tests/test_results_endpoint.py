"""
Tests for analytics persistence and the /api/results/{run_id}/exposure endpoint.

Run with:
    cd <repo-root>
    pytest tests/test_results_endpoint.py -v
"""

import json
import sys
import tempfile
from pathlib import Path

# Ensure backend/src is on the path
SRC = Path(__file__).resolve().parent.parent / "backend" / "src"
sys.path.insert(0, str(SRC))

import os
os.environ.setdefault("USE_DUCKDB_FALLBACK", "true")
os.environ.setdefault("DATABASE_URL", "duckdb:///:memory:")

import pytest
from fastapi.testclient import TestClient

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def client():
    import main
    with TestClient(main.app, raise_server_exceptions=False) as c:
        yield c


# ---------------------------------------------------------------------------
# Unit tests: analytics.build_lineup_analytics
# ---------------------------------------------------------------------------

class TestBuildLineupAnalytics:
    """Unit tests for analytics.build_lineup_analytics()."""

    def test_compact_format_counts(self):
        """Compact format (player_ids list) produces correct exposure counts."""
        from analytics import build_lineup_analytics

        lineups = [
            {"player_ids": ["p1", "p2", "p3"], "total_salary": 60000},
            {"player_ids": ["p1", "p3", "p4"], "total_salary": 59800},
        ]
        result = build_lineup_analytics(lineups, run_id="test-001")

        assert result["run_id"] == "test-001"
        assert result["total_lineups"] == 2

        by_id = {row["player_id"]: row for row in result["exposure"]}
        assert by_id["p1"]["count"] == 2
        assert abs(by_id["p1"]["pct"] - 1.0) < 1e-4  # 2/2
        assert by_id["p2"]["count"] == 1
        assert abs(by_id["p2"]["pct"] - 0.5) < 1e-4  # 1/2

    def test_flat_format_counts(self):
        """Flat format (string values) is parsed as player identifiers."""
        from analytics import build_lineup_analytics

        lineups = [
            {"PG": "Alice", "SG": "Bob", "SF": "Carol"},
            {"PG": "Alice", "SG": "Dave", "SF": "Carol"},
        ]
        result = build_lineup_analytics(lineups, run_id="test-002")

        assert result["total_lineups"] == 2
        by_player = {row["player"]: row for row in result["exposure"]}
        assert by_player["Alice"]["count"] == 2
        assert by_player["Bob"]["count"] == 1

    def test_metadata_enrichment(self):
        """Player metadata is merged into exposure rows."""
        from analytics import build_lineup_analytics

        lineups = [
            {"player_ids": ["p1", "p2"]},
            {"player_ids": ["p1", "p3"]},
        ]
        players = {
            "p1": {"name": "LeBron James", "team": "LAL", "position": "SF",
                   "salary": 10500, "projection": 52.4},
            "p2": {"name": "Steph Curry", "team": "GSW", "position": "PG",
                   "salary": 9800, "projection": 48.1},
        }
        result = build_lineup_analytics(lineups, players=players, run_id="test-003")

        by_player = {row["player"]: row for row in result["exposure"]}
        assert by_player["LeBron James"]["team"] == "LAL"
        assert by_player["LeBron James"]["salary"] == 10500
        assert abs(by_player["LeBron James"]["avg_projection"] - 52.4) < 0.01
        # p3 has no metadata → falls back to player_id as name, empty enrichment
        assert "p3" in by_player
        assert by_player["p3"]["team"] == ""

    def test_empty_lineups(self):
        """Empty lineup list returns zero exposure rows without crashing."""
        from analytics import build_lineup_analytics

        result = build_lineup_analytics([], run_id="test-empty")
        assert result["total_lineups"] == 0
        assert result["exposure"] == []


# ---------------------------------------------------------------------------
# Unit tests: analytics.save_analytics_report / get_analytics_report round-trip
# ---------------------------------------------------------------------------

class TestAnalyticsPersistence:
    """save_analytics_report + get_analytics_report round-trip."""

    def test_roundtrip(self, tmp_path):
        """Saved report is loadable and identical."""
        from analytics import save_analytics_report, get_analytics_report

        report = {
            "run_id": "rt-001",
            "total_lineups": 5,
            "exposure": [{"player": "X", "player_id": "X", "count": 3, "pct": 0.6}],
        }
        path = save_analytics_report(report, output_dir=tmp_path)
        assert path is not None and path.exists()

        loaded = get_analytics_report("rt-001", output_dir=tmp_path)
        assert loaded is not None
        assert loaded["run_id"] == "rt-001"
        assert loaded["total_lineups"] == 5

    def test_run_id_extracted_from_dict(self, tmp_path):
        """run_id is extracted from the analytics dict when not passed explicitly."""
        from analytics import save_analytics_report, get_analytics_report

        report = {"run_id": "auto-id", "total_lineups": 1, "exposure": []}
        save_analytics_report(report, output_dir=tmp_path)
        loaded = get_analytics_report("auto-id", output_dir=tmp_path)
        assert loaded is not None

    def test_missing_returns_none(self, tmp_path):
        """get_analytics_report returns None for an unknown run_id."""
        from analytics import get_analytics_report

        result = get_analytics_report("does-not-exist", output_dir=tmp_path)
        assert result is None


# ---------------------------------------------------------------------------
# Integration smoke tests: GET /api/results/{run_id}/exposure
# ---------------------------------------------------------------------------

class TestResultsEndpoint:
    """Integration tests for the /api/results/{run_id}/exposure endpoint."""

    def _seed_run_file(self, run_id: str, num_lineups: int = 10) -> None:
        """Write a fake run file to outputs/runs/ (new schema)."""
        from analytics import _RUNS_DIR

        _RUNS_DIR.mkdir(parents=True, exist_ok=True)
        run_data = {
            "run_id": run_id,
            "total_lineups": num_lineups,
            "players": [
                {
                    "player_id": "pA",
                    "name": "Test Player A",
                    "team": "MIL",
                    "position": "PG",
                    "salary": 8000,
                    "count": 7,
                    "exposure_pct": 0.7,
                    "avg_projection": 40.0,
                    "leverage": None,
                },
                {
                    "player_id": "pB",
                    "name": "Test Player B",
                    "team": "BOS",
                    "position": "SG",
                    "salary": 6000,
                    "count": 3,
                    "exposure_pct": 0.3,
                    "avg_projection": 30.0,
                    "leverage": None,
                },
            ],
        }
        path = _RUNS_DIR / f"{run_id}.json"
        path.write_text(json.dumps(run_data), encoding="utf-8")

    def test_exposure_200_shape(self, client: TestClient):
        """Seeded run returns 200 with correct schema."""
        self._seed_run_file("smoke-run-001", num_lineups=10)
        r = client.get("/api/results/smoke-run-001/exposure")
        assert r.status_code == 200, r.text

        body = r.json()
        assert body["run_id"] == "smoke-run-001"
        assert body["total_lineups"] == 10
        assert isinstance(body["players"], list)
        assert len(body["players"]) == 2

        row = body["players"][0]
        assert "player_id" in row
        assert "name" in row
        assert "count" in row
        assert "exposure_pct" in row

    def test_exposure_enriched_fields(self, client: TestClient):
        """Exposure rows include salary, team, position, avg_projection."""
        self._seed_run_file("smoke-run-002")
        r = client.get("/api/results/smoke-run-002/exposure")
        assert r.status_code == 200

        rows = {row["name"]: row for row in r.json()["players"]}
        assert rows["Test Player A"]["team"] == "MIL"
        assert rows["Test Player A"]["salary"] == 8000
        assert rows["Test Player A"]["position"] == "PG"

    def test_exposure_pct_in_range(self, client: TestClient):
        """exposure_pct must be in [0, 1]."""
        self._seed_run_file("smoke-run-pct")
        r = client.get("/api/results/smoke-run-pct/exposure")
        assert r.status_code == 200
        for row in r.json()["players"]:
            assert 0.0 <= row["exposure_pct"] <= 1.0, (
                f"exposure_pct out of range: {row['exposure_pct']}"
            )

    def test_leverage_field_present(self, client: TestClient):
        """leverage field must always be present (null when no ownership data)."""
        self._seed_run_file("smoke-run-lev")
        r = client.get("/api/results/smoke-run-lev/exposure")
        assert r.status_code == 200
        for row in r.json()["players"]:
            assert "leverage" in row  # may be null

    def test_legacy_analytics_fallback(self, client: TestClient):
        """Endpoint falls back to legacy analytics_{run_id}.json transparently."""
        from analytics import _OUTPUTS_DIR

        _OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)
        legacy = {
            "run_id": "legacy-001",
            "total_lineups": 5,
            "exposure": [
                {"player": "Old Player", "player_id": "op1", "count": 3,
                 "pct": 0.6, "avg_projection": 25.0, "salary": 5000,
                 "team": "LAC", "position": "C"},
            ],
        }
        (_OUTPUTS_DIR / "analytics_legacy-001.json").write_text(
            json.dumps(legacy), encoding="utf-8"
        )

        r = client.get("/api/results/legacy-001/exposure")
        assert r.status_code == 200

        body = r.json()
        assert body["run_id"] == "legacy-001"
        assert body["total_lineups"] == 5
        assert len(body["players"]) == 1
        row = body["players"][0]
        assert row["name"] == "Old Player"
        assert abs(row["exposure_pct"] - 0.6) < 1e-4  # mapped from pct

    def test_results_router_in_openapi(self, client: TestClient):
        """/api/results routes appear in the OpenAPI schema."""
        r = client.get("/api/openapi.json")
        assert r.status_code == 200
        paths = r.json().get("paths", {})
        results_paths = [p for p in paths if "/results" in p]
        assert results_paths, "No /results paths found in OpenAPI schema"

    def test_unknown_run_id_404(self, client: TestClient):
        """Unknown run_id returns HTTP 404."""
        r = client.get("/api/results/definitely-does-not-exist-xyz/exposure")
        assert r.status_code == 404
        assert "run_id" in r.json().get("detail", "")


# ---------------------------------------------------------------------------
# Unit tests: analytics.save_run_file / get_run_file round-trip (tmp_path)
# ---------------------------------------------------------------------------

class TestRunFilePersistence:
    """save_run_file + get_run_file round-trip, isolated to tmp_path."""

    def _lineups(self) -> list:
        return [
            {"player_ids": ["p1", "p2", "p3"], "total_salary": 60000},
            {"player_ids": ["p1", "p3", "p4"], "total_salary": 59500},
        ]

    def _players(self) -> dict:
        return {
            "p1": {"name": "LeBron James", "team": "LAL", "position": "SF",
                   "salary": 10500, "projection": 52.4},
            "p2": {"name": "Steph Curry",  "team": "GSW", "position": "PG",
                   "salary":  9800, "projection": 48.1},
            "p3": {"name": "Giannis A.",   "team": "MIL", "position": "PF",
                   "salary": 11000, "projection": 58.0},
            "p4": {"name": "Nikola Jokic", "team": "DEN", "position": "C",
                   "salary": 10800, "projection": 55.5},
        }

    def test_roundtrip_schema(self, tmp_path):
        """Saved run file loads back with correct top-level keys."""
        from analytics import save_run_file, get_run_file

        path = save_run_file("rt-run-001", self._lineups(), self._players(),
                             output_dir=tmp_path)
        assert path is not None and path.exists()

        loaded = get_run_file("rt-run-001", output_dir=tmp_path)
        assert loaded is not None
        assert loaded["run_id"] == "rt-run-001"
        assert loaded["total_lineups"] == 2
        assert isinstance(loaded["players"], list)

    def test_exposure_pct_values(self, tmp_path):
        """exposure_pct is computed correctly from counts / total_lineups."""
        from analytics import save_run_file, get_run_file

        save_run_file("rt-run-002", self._lineups(), self._players(),
                      output_dir=tmp_path)
        data = get_run_file("rt-run-002", output_dir=tmp_path)
        by_id = {r["player_id"]: r for r in data["players"]}

        # p1 appears in both lineups → exposure_pct = 1.0
        assert abs(by_id["p1"]["exposure_pct"] - 1.0) < 1e-4
        # p2 appears in 1 of 2 lineups → exposure_pct = 0.5
        assert abs(by_id["p2"]["exposure_pct"] - 0.5) < 1e-4

    def test_player_metadata_present(self, tmp_path):
        """Saved rows carry name, team, position, salary, avg_projection."""
        from analytics import save_run_file, get_run_file

        save_run_file("rt-run-003", self._lineups(), self._players(),
                      output_dir=tmp_path)
        data = get_run_file("rt-run-003", output_dir=tmp_path)
        by_id = {r["player_id"]: r for r in data["players"]}

        lebron = by_id["p1"]
        assert lebron["name"] == "LeBron James"
        assert lebron["team"] == "LAL"
        assert lebron["position"] == "SF"
        assert lebron["salary"] == 10500
        assert abs(lebron["avg_projection"] - 52.4) < 0.01

    def test_leverage_field_is_none(self, tmp_path):
        """leverage is null in the saved file (populated externally)."""
        from analytics import save_run_file, get_run_file

        save_run_file("rt-run-004", self._lineups(), self._players(),
                      output_dir=tmp_path)
        data = get_run_file("rt-run-004", output_dir=tmp_path)
        for row in data["players"]:
            assert row["leverage"] is None

    def test_missing_run_id_returns_none(self, tmp_path):
        """get_run_file returns None for a run_id that was never saved."""
        from analytics import get_run_file

        result = get_run_file("does-not-exist", output_dir=tmp_path)
        assert result is None

    def test_file_written_under_run_id_json(self, tmp_path):
        """The run file is named exactly {run_id}.json (not analytics_{run_id}.json)."""
        from analytics import save_run_file

        save_run_file("naming-check", self._lineups(), output_dir=tmp_path)
        assert (tmp_path / "naming-check.json").exists()
        assert not (tmp_path / "analytics_naming-check.json").exists()

