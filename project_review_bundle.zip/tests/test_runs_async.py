"""
test_runs_async.py — Unit tests for the runs router endpoints.

Tests cover:
  - POST /api/runs  (create run, validates slate exists, dispatches sync)
  - GET /api/runs/{run_id}  (full detail)
  - GET /api/runs/{run_id}/status  (fast polling)
  - 404 for unknown run_id
  - 404 when slate_id does not exist
  - run_to_dict serialisation
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from models.base import DFSBase
from models.run import Run, STATUS_QUEUED, STATUS_COMPLETED
from models.slate import Slate


# ---------------------------------------------------------------------------
# In-process test app  (mirrors conftest pattern used elsewhere)
# ---------------------------------------------------------------------------

def _make_app(db_session):
    """Build a minimal FastAPI app that uses the provided session."""
    from fastapi import FastAPI
    from database.db import get_db
    from routers.runs import router

    app = FastAPI()
    app.include_router(router, prefix="/api")

    app.dependency_overrides[get_db] = lambda: db_session
    return app


@pytest.fixture()
def db_session():
    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    DFSBase.metadata.create_all(engine, checkfirst=True)
    factory = sessionmaker(bind=engine, autoflush=False, autocommit=False)
    sess = factory()
    yield sess
    sess.close()
    DFSBase.metadata.drop_all(engine)


@pytest.fixture()
def client(db_session):
    app = _make_app(db_session)
    return TestClient(app)


@pytest.fixture()
def slate(db_session):
    s = Slate(id=str(uuid.uuid4()), sport="nba", platform="fanduel")
    db_session.add(s)
    db_session.commit()
    return s


@pytest.fixture()
def run(db_session, slate):
    r = Run(
        id=str(uuid.uuid4()),
        slate_id=slate.id,
        status=STATUS_COMPLETED,
        num_lineups=5,
        settings='{"num_lineups": 5}',
        created_at=datetime.now(timezone.utc).replace(tzinfo=None),
        completed_at=datetime.now(timezone.utc).replace(tzinfo=None),
    )
    db_session.add(r)
    db_session.commit()
    return r


# ---------------------------------------------------------------------------
# GET /{run_id}
# ---------------------------------------------------------------------------

class TestGetRun:
    def test_returns_run_details(self, client, run):
        resp = client.get(f"/api/runs/{run.id}")
        assert resp.status_code == 200
        data = resp.json()
        assert data["run_id"] == run.id
        assert data["slate_id"] == run.slate_id
        assert data["status"] == STATUS_COMPLETED
        assert data["num_lineups"] == 5

    def test_404_for_unknown_id(self, client):
        resp = client.get(f"/api/runs/{uuid.uuid4()}")
        assert resp.status_code == 404
        assert "not found" in resp.json()["detail"].lower()

    def test_includes_timestamps(self, client, run):
        resp = client.get(f"/api/runs/{run.id}")
        data = resp.json()
        assert "created_at" in data
        assert "completed_at" in data
        assert data["completed_at"] is not None

    def test_includes_settings(self, client, run):
        resp = client.get(f"/api/runs/{run.id}")
        # settings may come back as dict or empty dict
        assert "settings" in resp.json()


# ---------------------------------------------------------------------------
# GET /{run_id}/status
# ---------------------------------------------------------------------------

class TestGetRunStatus:
    def test_returns_status_fields(self, client, run):
        resp = client.get(f"/api/runs/{run.id}/status")
        assert resp.status_code == 200
        data = resp.json()
        assert data["run_id"] == run.id
        assert data["status"] == STATUS_COMPLETED
        assert data["num_lineups"] == 5
        assert "error_message" in data

    def test_404_for_unknown_id(self, client):
        resp = client.get(f"/api/runs/{uuid.uuid4()}/status")
        assert resp.status_code == 404

    def test_queued_run_shows_zero_lineups(self, db_session, client, slate):
        r = Run(
            id=str(uuid.uuid4()),
            slate_id=slate.id,
            status=STATUS_QUEUED,
            num_lineups=0,
        )
        db_session.add(r)
        db_session.commit()

        resp = client.get(f"/api/runs/{r.id}/status")
        assert resp.status_code == 200
        assert resp.json()["num_lineups"] == 0
        assert resp.json()["status"] == STATUS_QUEUED


# ---------------------------------------------------------------------------
# POST /  (create run)
# ---------------------------------------------------------------------------

class TestCreateRun:
    def test_returns_run_id_and_status(self, client, slate):
        payload = {
            "slate_id": slate.id,
            "num_lineups": 3,
            "platform": "fanduel",
            "contest_type": "small_gpp",
            "max_exposure": 0.5,
            "min_salary": 49000,
            "max_salary": 60000,
            "async_mode": False,  # inline — patch optimizer so no real DB needed
        }
        # Patch the optimizer task to be a no-op (avoids DuckDB dependency)
        with patch("tasks.optimizer_tasks.run_optimizer_task", return_value=None):
            resp = client.post("/api/runs", json=payload)
        assert resp.status_code == 200
        data = resp.json()
        assert "run_id" in data
        assert "status" in data
        assert uuid.UUID(data["run_id"])  # valid UUID

    def test_404_for_missing_slate(self, client):
        payload = {
            "slate_id": str(uuid.uuid4()),
            "num_lineups": 3,
            "platform": "fanduel",
            "contest_type": "small_gpp",
            "max_exposure": 0.5,
            "min_salary": 49000,
            "max_salary": 60000,
            "async_mode": False,
        }
        resp = client.post("/api/runs", json=payload)
        assert resp.status_code == 404
        assert "slate" in resp.json()["detail"].lower()

    def test_invalid_platform_rejected(self, client, slate):
        payload = {
            "slate_id": slate.id,
            "num_lineups": 3,
            "platform": "bad_platform",
            "contest_type": "small_gpp",
            "max_exposure": 0.5,
            "min_salary": 49000,
            "max_salary": 60000,
            "async_mode": False,
        }
        resp = client.post("/api/runs", json=payload)
        assert resp.status_code == 422  # validation error

    def test_num_lineups_bounds_validated(self, client, slate):
        payload = {
            "slate_id": slate.id,
            "num_lineups": 999,           # exceeds max of 150
            "platform": "fanduel",
            "contest_type": "small_gpp",
            "max_exposure": 0.5,
            "min_salary": 49000,
            "max_salary": 60000,
            "async_mode": False,
        }
        resp = client.post("/api/runs", json=payload)
        assert resp.status_code == 422
