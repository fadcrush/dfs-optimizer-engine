"""
test_frontend_contracts.py — API shape / contract tests.

Verify that every endpoint consumed by the frontend returns the exact fields
the TypeScript `api.ts` client expects.  These tests act as a type-safety
bridge between the Python backend and the TypeScript frontend.

Running these tests catches:
  - Missing fields in JSON responses
  - Field name changes (snake_case vs camelCase mismatches)
  - Wrong HTTP status codes
  - Incorrect content types
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from models.base import DFSBase
from models.lineup import Lineup
from models.lineup_entry import LineupEntry
from models.player import Player
from models.projection import Projection
from models.run import Run, STATUS_COMPLETED, STATUS_QUEUED
from models.slate import Slate


# ---------------------------------------------------------------------------
# Shared test infrastructure
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def engine():
    eng = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    DFSBase.metadata.create_all(eng, checkfirst=True)
    yield eng
    DFSBase.metadata.drop_all(eng)


@pytest.fixture()
def db(engine):
    factory = sessionmaker(bind=engine, autoflush=False, autocommit=False)
    sess = factory()
    yield sess
    sess.rollback()
    sess.close()


@pytest.fixture()
def client(db):
    from database.db import get_db
    from routers.runs import router as runs_router
    from routers.results import router as results_router
    from routers.slates import router as slates_router

    app = FastAPI()
    app.include_router(runs_router, prefix="/api")
    app.include_router(results_router, prefix="/api")
    app.include_router(slates_router, prefix="/api")
    app.dependency_overrides[get_db] = lambda: db
    return TestClient(app)


def _mk_slate(db) -> Slate:
    s = Slate(
        id=str(uuid.uuid4()),
        sport="nba",
        platform="fanduel",
        slate_date=None,
    )
    db.add(s)
    db.flush()
    return s


def _mk_players(db, slate_id: str, n: int = 5):
    players = []
    for i in range(n):
        p = Player(
            id=str(uuid.uuid4()),
            slate_id=slate_id,
            external_id=f"FD{2000+i}",
            name=f"Contract Player {i+1}",
            position=["PG", "SG", "SF", "PF", "C"][i % 5],
            team="LAL" if i % 2 == 0 else "GSW",
            salary=8000 - i * 200,
        )
        db.add(p)
        pr = Projection(
            id=str(uuid.uuid4()),
            slate_id=slate_id,
            player_id=p.id,
            projection=35.0 - i,
            ownership_pct=20.0 - i,
        )
        db.add(pr)
        players.append(p)
    db.flush()
    return players


def _mk_completed_run(db, num_lineups: int = 2) -> Run:
    slate = _mk_slate(db)
    players = _mk_players(db, slate.id, 5)
    run = Run(
        id=str(uuid.uuid4()),
        slate_id=slate.id,
        status=STATUS_COMPLETED,
        num_lineups=num_lineups,
        created_at=datetime.now(timezone.utc).replace(tzinfo=None),
        completed_at=datetime.now(timezone.utc).replace(tzinfo=None),
    )
    db.add(run)
    db.flush()
    for ln_n in range(1, num_lineups + 1):
        lineup = Lineup(
            id=str(uuid.uuid4()),
            run_id=run.id,
            lineup_number=ln_n,
            total_salary=sum(p.salary for p in players),
            total_projection=sum(35.0 - i for i in range(len(players))),
        )
        db.add(lineup)
        db.flush()
        for pl in players:
            db.add(LineupEntry(
                id=str(uuid.uuid4()),
                lineup_id=lineup.id,
                player_id=pl.id,
                slate_id=slate.id,
                position=pl.position,
            ))
    db.commit()
    return run


# ---------------------------------------------------------------------------
# Contract: GET /api/runs/{run_id}  →  getRun()
# ---------------------------------------------------------------------------

class TestGetRunContract:
    """Validates shape of RunCreatedResult / run detail response."""

    REQUIRED_FIELDS = {"run_id", "slate_id", "status", "num_lineups",
                       "settings", "error_message", "created_at",
                       "started_at", "completed_at"}

    def test_response_has_all_required_fields(self, client, db):
        run = _mk_completed_run(db)
        resp = client.get(f"/api/runs/{run.id}")
        assert resp.status_code == 200
        data = resp.json()
        missing = self.REQUIRED_FIELDS - set(data.keys())
        assert not missing, f"Missing fields: {missing}"

    def test_run_id_is_string_uuid(self, client, db):
        run = _mk_completed_run(db)
        data = client.get(f"/api/runs/{run.id}").json()
        assert isinstance(data["run_id"], str)
        uuid.UUID(data["run_id"])  # raises if invalid

    def test_status_is_valid_string(self, client, db):
        run = _mk_completed_run(db)
        data = client.get(f"/api/runs/{run.id}").json()
        assert data["status"] in ("queued", "running", "completed", "failed")


# ---------------------------------------------------------------------------
# Contract: GET /api/runs/{run_id}/status  →  pollRunStatus()
# ---------------------------------------------------------------------------

class TestPollRunStatusContract:
    """Validates RunStatusResult shape."""

    REQUIRED_FIELDS = {"run_id", "status", "num_lineups", "error_message"}

    def test_has_all_required_fields(self, client, db):
        run = _mk_completed_run(db)
        resp = client.get(f"/api/runs/{run.id}/status")
        assert resp.status_code == 200
        data = resp.json()
        missing = self.REQUIRED_FIELDS - set(data.keys())
        assert not missing, f"Missing fields: {missing}"

    def test_num_lineups_is_integer(self, client, db):
        run = _mk_completed_run(db)
        data = client.get(f"/api/runs/{run.id}/status").json()
        assert isinstance(data["num_lineups"], int)

    def test_error_message_is_null_or_string(self, client, db):
        run = _mk_completed_run(db)
        data = client.get(f"/api/runs/{run.id}/status").json()
        assert data["error_message"] is None or isinstance(data["error_message"], str)


# ---------------------------------------------------------------------------
# Contract: GET /api/results/{run_id}/lineups  →  getRunLineups()
# ---------------------------------------------------------------------------

class TestGetRunLineupsContract:
    """Validates RunLineupsResult { run_id, total_lineups, lineups [] } shape."""

    def test_top_level_fields(self, client, db):
        run = _mk_completed_run(db, num_lineups=2)
        resp = client.get(f"/api/results/{run.id}/lineups")
        assert resp.status_code == 200
        data = resp.json()
        assert "run_id" in data
        assert "total_lineups" in data
        assert "lineups" in data
        assert isinstance(data["lineups"], list)

    def test_lineup_row_fields(self, client, db):
        run = _mk_completed_run(db, num_lineups=1)
        resp = client.get(f"/api/results/{run.id}/lineups")
        lineup = resp.json()["lineups"][0]
        for field in ("lineup_id", "lineup_number", "total_salary",
                      "total_projection", "players"):
            assert field in lineup, f"Missing field in lineup row: {field}"

    def test_player_slot_fields(self, client, db):
        run = _mk_completed_run(db, num_lineups=1)
        resp = client.get(f"/api/results/{run.id}/lineups")
        player = resp.json()["lineups"][0]["players"][0]
        for field in ("player_id", "name", "position", "team", "salary"):
            assert field in player, f"Missing field in player slot: {field}"

    def test_salary_is_integer(self, client, db):
        run = _mk_completed_run(db, num_lineups=1)
        resp = client.get(f"/api/results/{run.id}/lineups")
        salary = resp.json()["lineups"][0]["players"][0]["salary"]
        assert isinstance(salary, int)

    def test_total_lineups_matches_array_length(self, client, db):
        run = _mk_completed_run(db, num_lineups=3)
        data = client.get(f"/api/results/{run.id}/lineups").json()
        assert data["total_lineups"] == len(data["lineups"])


# ---------------------------------------------------------------------------
# Contract: GET /api/results/{run_id}/exposure  →  getRunExposure()
# ---------------------------------------------------------------------------

class TestGetRunExposureContract:
    """Validates RunExposureResult { run_id, total_lineups, players [] } shape."""

    def test_top_level_fields(self, client, db):
        run = _mk_completed_run(db, num_lineups=2)
        resp = client.get(f"/api/results/{run.id}/exposure")
        assert resp.status_code == 200
        data = resp.json()
        assert "run_id" in data
        assert "total_lineups" in data
        assert "players" in data

    def test_player_exposure_row_fields(self, client, db):
        run = _mk_completed_run(db, num_lineups=2)
        resp = client.get(f"/api/results/{run.id}/exposure")
        player = resp.json()["players"][0]
        for field in ("player_id", "name", "team", "position", "salary",
                      "count", "exposure_pct", "avg_projection"):
            assert field in player, f"Missing field: {field}"

    def test_exposure_pct_between_0_and_1(self, client, db):
        run = _mk_completed_run(db, num_lineups=2)
        resp = client.get(f"/api/results/{run.id}/exposure")
        for p in resp.json()["players"]:
            assert 0.0 <= p["exposure_pct"] <= 1.0

    def test_leverage_is_float_or_null(self, client, db):
        run = _mk_completed_run(db, num_lineups=1)
        resp = client.get(f"/api/results/{run.id}/exposure")
        for p in resp.json()["players"]:
            assert p["leverage"] is None or isinstance(p["leverage"], (int, float))


# ---------------------------------------------------------------------------
# Contract: GET /api/slates  →  listSlates()
# ---------------------------------------------------------------------------

class TestListSlatesContract:
    def test_returns_slates_and_total(self, client, db):
        # Ensure at least one slate exists
        _mk_slate(db)
        db.commit()
        resp = client.get("/api/slates")
        assert resp.status_code == 200
        data = resp.json()
        # Router returns a plain list (not a wrapped dict)
        assert isinstance(data, list)
        assert len(data) >= 1

    def test_slate_row_has_required_fields(self, client, db):
        _mk_slate(db)
        db.commit()
        resp = client.get("/api/slates")
        data = resp.json()
        if data:
            row = data[0]
            # Must have at minimum id/slate_id, platform, sport
            has_id = "id" in row or "slate_id" in row
            assert has_id, f"Row missing id field. Keys: {list(row.keys())}"
            for field in ("platform", "sport"):
                assert field in row, f"Missing field: {field}"


# ---------------------------------------------------------------------------
# Contract: error shapes
# ---------------------------------------------------------------------------

class TestErrorContracts:
    def test_404_has_detail_field(self, client):
        resp = client.get(f"/api/runs/{uuid.uuid4()}")
        assert resp.status_code == 404
        assert "detail" in resp.json()

    def test_422_has_detail_field(self, client, db):
        slate = _mk_slate(db)
        db.commit()
        resp = client.post("/api/runs", json={"slate_id": slate.id, "num_lineups": -1,
                                               "platform": "fanduel", "contest_type": "small_gpp",
                                               "max_exposure": 0.5, "min_salary": 49000,
                                               "max_salary": 60000})
        assert resp.status_code == 422
        assert "detail" in resp.json()
