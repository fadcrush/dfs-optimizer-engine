"""
Smoke tests — verify the backend starts and critical endpoints are reachable.

Run with:
    cd backend/src
    pytest ../../tests/test_smoke.py -v

These tests start a live test server using TestClient, so no uvicorn process
is required.
"""

import sys
from pathlib import Path

# Ensure backend/src is on the path
SRC = Path(__file__).resolve().parent.parent / "backend" / "src"
sys.path.insert(0, str(SRC))

import os
os.environ.setdefault("USE_DUCKDB_FALLBACK", "true")
# Use an in-memory DuckDB so we don't need the real data file
os.environ.setdefault("DATABASE_URL", "duckdb:///:memory:")

import pytest
from fastapi.testclient import TestClient


@pytest.fixture(scope="module")
def client():
    """Create a FastAPI TestClient backed by the real app."""
    import main  # backend/src/main.py
    with TestClient(main.app, raise_server_exceptions=False) as c:
        yield c


def test_openapi_json_200(client: TestClient):
    """GET /api/openapi.json must return 200."""
    r = client.get("/api/openapi.json")
    assert r.status_code == 200, f"Expected 200, got {r.status_code}: {r.text[:200]}"
    schema = r.json()
    assert "openapi" in schema or "paths" in schema


def test_openapi_redirect(client: TestClient):
    """GET /openapi.json must redirect to /api/openapi.json (307)."""
    r = client.get("/openapi.json", follow_redirects=False)
    assert r.status_code in (307, 308), f"Expected redirect, got {r.status_code}"


def test_docs_200(client: TestClient):
    """GET /api/docs must return 200 (Swagger UI)."""
    r = client.get("/api/docs")
    assert r.status_code == 200


def test_docs_redirect(client: TestClient):
    """GET /docs must redirect to /api/docs."""
    r = client.get("/docs", follow_redirects=False)
    assert r.status_code in (307, 308)


def test_health_check(client: TestClient):
    """GET /api/health must return {status: healthy}."""
    r = client.get("/api/health")
    assert r.status_code == 200
    body = r.json()
    assert body.get("status") == "healthy"


def test_projections_router_registered(client: TestClient):
    """/api/projections routes must appear in the OpenAPI schema."""
    r = client.get("/api/openapi.json")
    paths = r.json().get("paths", {})
    projections_paths = [p for p in paths if "/projections" in p]
    assert projections_paths, "No /projections paths found in OpenAPI schema"


def test_optimizer_router_registered(client: TestClient):
    """/api/optimizer routes must appear in the OpenAPI schema."""
    r = client.get("/api/openapi.json")
    paths = r.json().get("paths", {})
    optimizer_paths = [p for p in paths if "/optimizer" in p]
    assert optimizer_paths, "No /optimizer paths found in OpenAPI schema"


# ---------------------------------------------------------------------------
# DuckDB concurrency guardrail unit tests
# (pure unit tests — no TestClient / HTTP required)
# ---------------------------------------------------------------------------

class TestDuckDBConcurrencyGuardrail:
    """
    assert_single_worker_for_duckdb() must:
    - raise RuntimeError for file-based DuckDB + workers > 1
    - be silent for single worker, in-memory DuckDB, or non-DuckDB backends
    """

    def _check(self, database_url: str, workers: str) -> None:
        """Run the guardrail with the given env overrides."""
        from db.engine import assert_single_worker_for_duckdb
        import os
        env = {"DATABASE_URL": database_url, "WEB_CONCURRENCY": workers}
        # Scrub UVICORN_WORKERS so it doesn't interfere
        clean = {k: v for k, v in os.environ.items() if k != "UVICORN_WORKERS"}
        clean.update(env)
        import unittest.mock as mock
        with mock.patch.dict(os.environ, clean, clear=True):
            assert_single_worker_for_duckdb()

    # ── cases that MUST raise ────────────────────────────────────────────────

    def test_file_duckdb_multi_worker_raises(self):
        """File-based DuckDB + WEB_CONCURRENCY=4 → RuntimeError."""
        with pytest.raises(RuntimeError, match="UNSAFE"):
            self._check("duckdb:///data/dfs_edge.duckdb", "4")

    def test_file_duckdb_two_workers_raises(self):
        """Even WEB_CONCURRENCY=2 must be rejected for file-based DuckDB."""
        with pytest.raises(RuntimeError, match="STARTUP ABORTED"):
            self._check("duckdb:///some/file.duckdb", "2")

    def test_error_message_contains_remediation(self):
        """The RuntimeError message must include all three remediation options."""
        with pytest.raises(RuntimeError) as exc_info:
            self._check("duckdb:///data/dfs_edge.duckdb", "8")
        msg = str(exc_info.value)
        assert "WEB_CONCURRENCY=1" in msg, "Remediation 1 (single worker) missing"
        assert "postgresql://" in msg, "Remediation 2 (PostgreSQL) missing"
        assert ":memory:" in msg, "Remediation 3 (in-memory DuckDB) missing"

    # ── cases that must NOT raise ────────────────────────────────────────────

    def test_file_duckdb_single_worker_ok(self):
        """File-based DuckDB + WEB_CONCURRENCY=1 → no error."""
        self._check("duckdb:///data/dfs_edge.duckdb", "1")  # must not raise

    def test_memory_duckdb_multi_worker_ok(self):
        """
        duckdb:///:memory: is per-process — no shared file-lock.
        Multi-worker must be allowed.
        """
        self._check("duckdb:///:memory:", "16")  # must not raise

    def test_postgres_multi_worker_ok(self):
        """PostgreSQL handles multi-worker natively — guardrail is a no-op."""
        self._check("postgresql://user:pass@localhost/db", "16")  # must not raise

    def test_uvicorn_workers_env_var_also_checked(self):
        """
        UVICORN_WORKERS (alternative env var) is also inspected when
        WEB_CONCURRENCY is absent.
        """
        from db.engine import assert_single_worker_for_duckdb
        import os
        import unittest.mock as mock
        clean = {k: v for k, v in os.environ.items()
                 if k not in ("WEB_CONCURRENCY", "UVICORN_WORKERS")}
        clean["DATABASE_URL"] = "duckdb:///data/test.duckdb"
        clean["UVICORN_WORKERS"] = "4"
        with mock.patch.dict(os.environ, clean, clear=True):
            with pytest.raises(RuntimeError, match="UNSAFE"):
                assert_single_worker_for_duckdb()
