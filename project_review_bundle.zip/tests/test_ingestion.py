"""
test_ingestion.py — Integration tests for the DB-first ingestion pipeline.

Tests cover:
  - Projection CSV → slate + player + projection rows
  - Platform detection (FanDuel vs DraftKings)
  - Ownership CSV → ownership_data rows + projection mirror
  - Empty / malformed CSV error handling
"""

from __future__ import annotations

import io
from datetime import date

import pandas as pd
import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from models.base import DFSBase
from models.player import Player
from models.projection import Projection
from models.ownership_model import OwnershipData
from models.slate import Slate
from services.projection_ingestion import ingest_projections_csv, detect_platform
from services.ownership_ingestion import ingest_ownership_csv


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def db_session():
    """In-memory SQLite session backed by the DFS schema."""
    engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False})
    DFSBase.metadata.create_all(engine, checkfirst=True)
    factory = sessionmaker(bind=engine, autoflush=False, autocommit=False)
    session = factory()
    yield session
    session.close()
    DFSBase.metadata.drop_all(engine)


def _make_fd_csv(names: list[str] | None = None) -> bytes:
    """Build a minimal FanDuel-style slate CSV."""
    if names is None:
        names = ["LeBron James", "Anthony Davis", "Stephen Curry"]
    rows = []
    for i, name in enumerate(names):
        rows.append({
            "Nickname": name,
            "Id": f"FD{i+100}",
            "Position": "PF" if i % 2 == 0 else "C",
            "Salary": 9500 - i * 200,
            "Team": "LAL" if i < 2 else "GSW",
            "Opponent": "GSW" if i < 2 else "LAL",
            "Game": "LAL@GSW 07:30PM ET",
            "FPPG": 45.0 + i * 2,
            "Injury Indicator": "",
        })
    df = pd.DataFrame(rows)
    buf = io.StringIO()
    df.to_csv(buf, index=False)
    return buf.getvalue().encode()


def _make_dk_csv(names: list[str] | None = None) -> bytes:
    """Build a minimal DraftKings-style slate CSV."""
    if names is None:
        names = ["Nikola Jokic", "Joel Embiid"]
    rows = []
    for i, name in enumerate(names):
        rows.append({
            "Name": name,
            "ID": f"DK{i+200}",
            "Position": "C",
            "Roster Position": "C/UTIL",
            "Salary": 10000 - i * 500,
            "TeamAbbrev": "DEN" if i == 0 else "PHI",
            "Game Info": "DEN@PHI 08:00PM ET",
            "AvgPointsPerGame": 60.0 - i * 5,
        })
    df = pd.DataFrame(rows)
    buf = io.StringIO()
    df.to_csv(buf, index=False)
    return buf.getvalue().encode()


def _make_ownership_csv(names_pcts: dict[str, float]) -> bytes:
    rows = [{"Name": name, "Ownership": pct} for name, pct in names_pcts.items()]
    df = pd.DataFrame(rows)
    buf = io.StringIO()
    df.to_csv(buf, index=False)
    return buf.getvalue().encode()


# ---------------------------------------------------------------------------
# Platform detection
# ---------------------------------------------------------------------------

class TestPlatformDetection:
    def test_fanduel_detected(self):
        columns = ["Nickname", "Id", "Position", "Salary", "Team", "FPPG", "Injury Indicator"]
        assert detect_platform(columns) == "fanduel"

    def test_draftkings_detected(self):
        columns = ["Name", "ID", "Roster Position", "Salary", "TeamAbbrev", "AvgPointsPerGame"]
        assert detect_platform(columns) == "draftkings"

    def test_unknown_defaults_to_fanduel(self):
        columns = ["Player", "Proj", "Cost"]
        assert detect_platform(columns) == "fanduel"


# ---------------------------------------------------------------------------
# Projection ingestion
# ---------------------------------------------------------------------------

class TestProjectionIngestion:
    def test_fanduel_creates_slate_and_players(self, db_session):
        result = ingest_projections_csv(
            db=db_session,
            csv_bytes=_make_fd_csv(),
            filename="fd_slate.csv",
        )
        assert result["platform"] == "fanduel"
        assert result["sport"] == "nba"
        assert result["player_count"] == 3

        slate = db_session.query(Slate).filter_by(id=result["slate_id"]).one()
        assert slate.platform == "fanduel"
        assert slate.source_filename == "fd_slate.csv"

        players = db_session.query(Player).filter_by(slate_id=result["slate_id"]).all()
        assert len(players) == 3
        names = {p.name for p in players}
        assert "LeBron James" in names

    def test_fanduel_creates_projections(self, db_session):
        result = ingest_projections_csv(db=db_session, csv_bytes=_make_fd_csv())
        projs = db_session.query(Projection).filter_by(slate_id=result["slate_id"]).all()
        assert len(projs) == 3
        for p in projs:
            assert p.projection > 0
            assert p.floor > 0
            assert p.ceiling > p.projection

    def test_draftkings_creates_slate_and_players(self, db_session):
        result = ingest_projections_csv(
            db=db_session,
            csv_bytes=_make_dk_csv(),
            filename="dk_slate.csv",
        )
        assert result["platform"] == "draftkings"
        assert result["player_count"] == 2

        player = (
            db_session.query(Player)
            .filter_by(slate_id=result["slate_id"], name="Nikola Jokic")
            .one()
        )
        assert player.salary == 10000
        assert player.external_id == "DK200"

    def test_re_ingestion_updates_existing_rows(self, db_session):
        """Uploading the same slate twice should upsert, not duplicate."""
        names = ["LeBron James", "Anthony Davis"]
        csv = _make_fd_csv(names)
        r1 = ingest_projections_csv(db=db_session, csv_bytes=csv)
        r2 = ingest_projections_csv(db=db_session, csv_bytes=csv)
        # Two slates created (each upload = new slate by design)
        assert r1["slate_id"] != r2["slate_id"]
        total_slates = db_session.query(Slate).count()
        assert total_slates == 2
        # Each slate has its own players
        assert db_session.query(Player).filter_by(slate_id=r1["slate_id"]).count() == 2
        assert db_session.query(Player).filter_by(slate_id=r2["slate_id"]).count() == 2

    def test_empty_csv_raises(self, db_session):
        with pytest.raises(ValueError, match="empty"):
            ingest_projections_csv(db=db_session, csv_bytes=b"")

    def test_sport_override(self, db_session):
        result = ingest_projections_csv(
            db=db_session,
            csv_bytes=_make_fd_csv(),
            sport="nfl",
        )
        slate = db_session.query(Slate).get(result["slate_id"])
        assert slate.sport == "nfl"

    def test_slate_date_stored(self, db_session):
        d = date(2025, 1, 15)
        result = ingest_projections_csv(
            db=db_session,
            csv_bytes=_make_fd_csv(),
            slate_date=d,
        )
        slate = db_session.query(Slate).get(result["slate_id"])
        assert slate.slate_date == d


# ---------------------------------------------------------------------------
# Ownership ingestion
# ---------------------------------------------------------------------------

class TestOwnershipIngestion:
    def _slate_with_players(self, db_session):
        result = ingest_projections_csv(
            db=db_session,
            csv_bytes=_make_fd_csv(["LeBron James", "Anthony Davis", "Stephen Curry"]),
        )
        return result["slate_id"]

    def test_ownership_rows_created(self, db_session):
        slate_id = self._slate_with_players(db_session)
        own_csv = _make_ownership_csv({
            "LeBron James": 32.5,
            "Anthony Davis": 28.0,
        })
        result = ingest_ownership_csv(
            db=db_session, csv_bytes=own_csv, slate_id=slate_id
        )
        assert result["matched"] == 2
        assert result["unmatched"] == 0
        rows = db_session.query(OwnershipData).filter_by(slate_id=slate_id).all()
        assert len(rows) == 2

    def test_unmatched_players_reported(self, db_session):
        slate_id = self._slate_with_players(db_session)
        own_csv = _make_ownership_csv({"Ghost Player": 10.0})
        result = ingest_ownership_csv(
            db=db_session, csv_bytes=own_csv, slate_id=slate_id
        )
        assert result["matched"] == 0
        assert result["unmatched"] == 1
        assert "Ghost Player" in result["unmatched_names"]

    def test_ownership_mirrored_to_projection(self, db_session):
        slate_id = self._slate_with_players(db_session)
        own_csv = _make_ownership_csv({"LeBron James": 35.0})
        ingest_ownership_csv(
            db=db_session,
            csv_bytes=own_csv,
            slate_id=slate_id,
            mirror_to_projection=True,
        )
        player = (
            db_session.query(Player)
            .filter_by(slate_id=slate_id, name="LeBron James")
            .one()
        )
        proj = (
            db_session.query(Projection)
            .filter_by(slate_id=slate_id, player_id=player.id)
            .one()
        )
        assert proj.ownership_pct == pytest.approx(35.0)

    def test_empty_csv_raises(self, db_session):
        slate_id = self._slate_with_players(db_session)
        with pytest.raises(ValueError, match="empty"):
            ingest_ownership_csv(db=db_session, csv_bytes=b"", slate_id=slate_id)
