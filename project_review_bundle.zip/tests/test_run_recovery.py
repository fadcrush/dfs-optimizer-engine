"""
test_run_recovery.py — Unit tests for services/run_recovery.py

Tests cover:
  - recover_stale_runs() marks old 'running' runs as 'failed'
  - Threshold boundary: exactly AT threshold is NOT recovered
  - One millisecond over threshold IS recovered
  - Already 'failed' / 'completed' / 'queued' runs are untouched
  - Multiple stale runs all recovered in one call
  - Returned list contains the correct run IDs
  - Run.error_message contains expected recovery text
  - Run.completed_at is set after recovery
"""
from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from models.base import DFSBase
from models.run import Run, STATUS_COMPLETED, STATUS_FAILED, STATUS_QUEUED, STATUS_RUNNING
from models.slate import Slate
from services.run_recovery import _utcnow, recover_stale_runs


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_slate(db, slate_id: str | None = None) -> Slate:
    s = Slate(
        id=slate_id or str(uuid.uuid4()),
        platform="fanduel",
        sport="nfl",
        player_count=10,
    )
    db.add(s)
    db.flush()
    return s


def _make_run(
    db,
    slate_id: str,
    status: str,
    started_at: datetime | None = None,
) -> Run:
    r = Run(
        id=str(uuid.uuid4()),
        slate_id=slate_id,
        status=status,
        num_lineups=10,
        started_at=started_at,
    )
    db.add(r)
    db.flush()
    return r


# ---------------------------------------------------------------------------
# Fixture
# ---------------------------------------------------------------------------

@pytest.fixture()
def db():
    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    DFSBase.metadata.create_all(engine, checkfirst=True)
    factory = sessionmaker(bind=engine, autoflush=False, autocommit=False)
    sess = factory()
    yield sess
    sess.close()
    DFSBase.metadata.drop_all(engine)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestRecoverStaleRuns:
    def test_stale_run_is_marked_failed(self, db):
        slate = _make_slate(db)
        old_start = _utcnow() - timedelta(minutes=20)
        run = _make_run(db, slate.id, STATUS_RUNNING, started_at=old_start)

        recovered = recover_stale_runs(db, threshold_minutes=15)

        assert run.id in recovered
        assert run.status == STATUS_FAILED

    def test_error_message_contains_recovery_text(self, db):
        slate = _make_slate(db)
        run = _make_run(db, slate.id, STATUS_RUNNING,
                        started_at=_utcnow() - timedelta(minutes=30))
        recover_stale_runs(db, threshold_minutes=15)
        assert "worker crash recovery" in run.error_message

    def test_completed_at_is_set(self, db):
        slate = _make_slate(db)
        run = _make_run(db, slate.id, STATUS_RUNNING,
                        started_at=_utcnow() - timedelta(minutes=20))
        assert run.completed_at is None
        recover_stale_runs(db, threshold_minutes=15)
        assert run.completed_at is not None

    def test_fresh_running_run_not_recovered(self, db):
        """A run that started 5 min ago with a 15-min threshold must be left alone."""
        slate = _make_slate(db)
        run = _make_run(db, slate.id, STATUS_RUNNING,
                        started_at=_utcnow() - timedelta(minutes=5))
        recovered = recover_stale_runs(db, threshold_minutes=15)
        assert run.id not in recovered
        assert run.status == STATUS_RUNNING

    def test_threshold_boundary_not_recovered(self, db):
        """A run started exactly at threshold seconds ago is NOT over threshold → not recovered."""
        slate = _make_slate(db)
        # Use threshold=1 minute, started exactly 60 seconds ago → < cutoff by a hair
        run = _make_run(db, slate.id, STATUS_RUNNING,
                        started_at=_utcnow() - timedelta(seconds=60))
        recovered = recover_stale_runs(db, threshold_minutes=2)  # need > 2 min
        assert run.id not in recovered

    def test_just_over_threshold_recovered(self, db):
        """A run clearly over the threshold is recovered."""
        slate = _make_slate(db)
        run = _make_run(db, slate.id, STATUS_RUNNING,
                        started_at=_utcnow() - timedelta(minutes=3))
        recovered = recover_stale_runs(db, threshold_minutes=2)
        assert run.id in recovered

    def test_failed_run_not_touched(self, db):
        slate = _make_slate(db)
        run = _make_run(db, slate.id, STATUS_FAILED,
                        started_at=_utcnow() - timedelta(minutes=30))
        run.error_message = "original error"
        recover_stale_runs(db, threshold_minutes=15)
        assert run.error_message == "original error"

    def test_completed_run_not_touched(self, db):
        slate = _make_slate(db)
        run = _make_run(db, slate.id, STATUS_COMPLETED,
                        started_at=_utcnow() - timedelta(minutes=30))
        recovered = recover_stale_runs(db, threshold_minutes=15)
        assert run.id not in recovered
        assert run.status == STATUS_COMPLETED

    def test_queued_run_not_touched(self, db):
        slate = _make_slate(db)
        run = _make_run(db, slate.id, STATUS_QUEUED, started_at=None)
        recovered = recover_stale_runs(db, threshold_minutes=15)
        assert run.id not in recovered

    def test_multiple_stale_runs_all_recovered(self, db):
        slate = _make_slate(db)
        old = _utcnow() - timedelta(minutes=60)
        runs = [_make_run(db, slate.id, STATUS_RUNNING, started_at=old) for _ in range(5)]
        recovered = recover_stale_runs(db, threshold_minutes=15)
        for r in runs:
            assert r.id in recovered

    def test_returns_only_recovered_ids(self, db):
        slate = _make_slate(db)
        stale = _make_run(db, slate.id, STATUS_RUNNING,
                          started_at=_utcnow() - timedelta(minutes=30))
        fresh = _make_run(db, slate.id, STATUS_RUNNING,
                          started_at=_utcnow() - timedelta(minutes=1))
        recovered = recover_stale_runs(db, threshold_minutes=15)
        assert stale.id in recovered
        assert fresh.id not in recovered

    def test_idempotent_second_call_returns_empty(self, db):
        slate = _make_slate(db)
        _make_run(db, slate.id, STATUS_RUNNING,
                  started_at=_utcnow() - timedelta(minutes=30))
        first = recover_stale_runs(db, threshold_minutes=15)
        assert len(first) == 1
        second = recover_stale_runs(db, threshold_minutes=15)
        assert len(second) == 0

    def test_run_without_started_at_not_recovered(self, db):
        """Runs with started_at=None are skipped (not yet dispatched)."""
        slate = _make_slate(db)
        run = _make_run(db, slate.id, STATUS_RUNNING, started_at=None)
        recovered = recover_stale_runs(db, threshold_minutes=0)
        assert run.id not in recovered
