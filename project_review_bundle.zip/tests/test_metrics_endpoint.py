"""
test_metrics_endpoint.py — Tests for GET /api/metrics (Prometheus exposition)

Tests cover:
  - Endpoint returns HTTP 200
  - Content-Type is text/plain
  - All required metric names are present in the response
  - dfs_uptime_seconds is a positive float
  - Metric blocks contain # HELP and # TYPE lines
  - Endpoint works with an empty database (no runs, no slates)
  - Status-specific gauge lines are present
"""
from __future__ import annotations

import re
import time

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from database.db import get_db
from models.base import DFSBase
from routers.prom_metrics import router as prom_router


# ---------------------------------------------------------------------------
# Fixture
# ---------------------------------------------------------------------------

@pytest.fixture()
def db_session():
    engine = create_engine(
        "sqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    DFSBase.metadata.create_all(engine, checkfirst=True)
    factory = sessionmaker(bind=engine, autoflush=False, autocommit=False)
    sess = factory()
    yield sess
    sess.close()
    DFSBase.metadata.drop_all(engine)


@pytest.fixture()
def client(db_session):
    app = FastAPI()
    app.include_router(prom_router)
    app.dependency_overrides[get_db] = lambda: db_session
    return TestClient(app)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

REQUIRED_METRICS = [
    "dfs_uptime_seconds",
    "dfs_runs_total",
    "dfs_slates_total",
    "dfs_lineups_total",
    "dfs_lineup_entries_total",
    "dfs_players_total",
]


class TestPrometheusMetrics:
    def test_returns_200(self, client):
        resp = client.get("/api/metrics")
        assert resp.status_code == 200

    def test_content_type_is_plain_text(self, client):
        resp = client.get("/api/metrics")
        assert "text/plain" in resp.headers["content-type"]

    def test_all_required_metrics_present(self, client):
        body = client.get("/api/metrics").text
        for metric in REQUIRED_METRICS:
            assert metric in body, f"Missing metric: {metric}"

    def test_uptime_is_positive_float(self, client):
        body = client.get("/api/metrics").text
        match = re.search(r"dfs_uptime_seconds\s+([\d.]+)", body)
        assert match, "dfs_uptime_seconds value line not found"
        value = float(match.group(1))
        assert value >= 0.0

    def test_help_and_type_lines_present(self, client):
        body = client.get("/api/metrics").text
        assert "# HELP dfs_uptime_seconds" in body
        assert "# TYPE dfs_uptime_seconds gauge" in body

    def test_run_status_gauges_present(self, client):
        body = client.get("/api/metrics").text
        for status in ("queued", "running", "completed", "failed"):
            assert f"dfs_runs_{status}" in body, f"Missing gauge for status: {status}"

    def test_empty_database_returns_zeros(self, client):
        body = client.get("/api/metrics").text
        # With empty DB, total runs should be 0
        match = re.search(r"dfs_runs_total\s+(\d+)", body)
        assert match, "dfs_runs_total not found"
        assert int(match.group(1)) == 0

    def test_response_is_valid_prometheus_format(self, client):
        """Each non-comment, non-empty line must be 'metric [value]'."""
        body = client.get("/api/metrics").text
        for line in body.strip().splitlines():
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            assert len(parts) >= 2, f"Invalid Prometheus line: {line!r}"
            # Value must be numeric
            try:
                float(parts[-1])
            except ValueError:
                pytest.fail(f"Non-numeric value in Prometheus line: {line!r}")

    def test_uptime_increases_between_calls(self, client):
        """Two sequential calls should show non-decreasing uptime."""
        v1 = float(re.search(
            r"dfs_uptime_seconds\s+([\d.]+)", client.get("/api/metrics").text
        ).group(1))
        time.sleep(0.01)
        v2 = float(re.search(
            r"dfs_uptime_seconds\s+([\d.]+)", client.get("/api/metrics").text
        ).group(1))
        assert v2 >= v1
