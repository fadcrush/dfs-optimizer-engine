# ============================================================================
# DFS MASTER DATABASE - CONFIGURATION
# ============================================================================
# 
# SETUP INSTRUCTIONS:
# 1. Copy this file to: config.py
# 2. Fill in your API keys below
# 3. Never commit config.py to git (it's in .gitignore)
#
# ============================================================================

import os
from pathlib import Path
from dotenv import load_dotenv

# Load .env files in order (backend/.env, then root .env)
load_dotenv("backend/.env")
load_dotenv(".env")

# ============================================================================
# DATABASE SETTINGS (Canonical Path Resolution)
# ============================================================================

def get_db_path() -> Path:
    """
    Canonical DB path resolution matching backend/src/db/engine.py.
    Resolution order:
      1. DUCKDB_PATH env var (absolute path)
      2. DATABASE_URL duckdb:/// extraction
      3. Walk-up discovery from cwd
      4. Fallback: <repo_root>/data/dfs_master.duckdb
    """
    # 1. Explicit env var
    if explicit := os.getenv("DUCKDB_PATH"):
        return Path(explicit)
    
    # 2. Extract from DATABASE_URL
    if db_url := os.getenv("DATABASE_URL"):
        if db_url.startswith("duckdb:///"):
            path_str = db_url.replace("duckdb:///", "")
            if path_str.startswith("./"):
                path_str = path_str[2:]
            return Path(path_str).resolve()
    
    # 3. Walk up from cwd to find data/dfs_master.duckdb
    current = Path.cwd()
    for _ in range(5):  # max 5 levels up
        candidate = current / "data" / "dfs_master.duckdb"
        if candidate.exists():
            return candidate
        current = current.parent
    
    # 4. Fallback to repo root
    repo_root = Path(__file__).parent  # config.py is in repo root
    return repo_root / "data" / "dfs_master.duckdb"

DATABASE_PATH = get_db_path()
BACKUP_PATH = DATABASE_PATH.parent / "backups"

# ============================================================================
# API KEYS (Read from .env for security)
# ============================================================================

# The Odds API (500 requests/month FREE)
# Get your key at: https://the-odds-api.com/
ODDS_API_KEY = os.getenv("THE_ODDS_API_KEY") or os.getenv("THEODDS_API_KEY", "")

# OpenWeather API (1,000 calls/day FREE)
# Get your key at: https://openweathermap.org/api
OPENWEATHER_API_KEY = os.getenv("WEATHER_API_KEY", "")

# SportsData.io (1,000 calls/month FREE - OPTIONAL)
# Get your key at: https://sportsdata.io/
SPORTSDATA_API_KEY = os.getenv("SPORTSDATA_API_KEY", "079f9d2ee3fa402f96b0ba043681cbbf")

# Twitter API v2 (FREE tier - for news monitoring)
# Get your keys at: https://developer.twitter.com/
TWITTER_API_KEY = os.getenv("Xv5dxXmOYiykpIOdqL1bCXeWN", "")
TWITTER_API_SECRET = os.getenv("LEXNmteOxsFJg62rFCqypTBq7BVFlCvOxd9QxRbsoYCIj2sVwR", "")
TWITTER_BEARER_TOKEN = os.getenv("AAAAAAAAAAAAAAAAAAAAAB6m7gEAAAAAoyJftGrn0ev1ZM4kpTiTRrMLIGg%3DdLtZoxv6rHAFWm9M8WhcKItW6GOoA8WSY1ldRfuVgr3mpO1TVg", "")

# ============================================================================
# API SETTINGS
# ============================================================================

# Rate limiting (requests per minute)
RATE_LIMITS = {
    'nba_stats': 20,  # NBA Stats API: ~20 req/min
    'odds_api': 10,   # The Odds API: be conservative
    'openweather': 60,  # 1,000/day = ~42/hour = plenty
    'sportsdata': 10,  # Free tier: be conservative
    'scraping': 1,    # Basketball-Reference: 1 req every 3-5 seconds
}

# Request delays (seconds)
REQUEST_DELAYS = {
    'nba_stats': 3,
    'odds_api': 6,
    'openweather': 1,
    'sportsdata': 6,
    'scraping': 5,
}

# ============================================================================
# DATA SOURCES
# ============================================================================

# NBA Stats API endpoints
NBA_STATS_BASE = 'https://stats.nba.com/stats'
NBA_STATS_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    'Referer': 'https://stats.nba.com/',
    'Origin': 'https://stats.nba.com'
}

# The Odds API endpoints
ODDS_API_BASE = 'https://api.the-odds-api.com/v4'
ODDS_SPORTS = {
    'NBA': 'basketball_nba',
    'NFL': 'americanfootball_nfl'
}

# OpenWeather API
OPENWEATHER_BASE = 'https://api.openweathermap.org/data/2.5'

# SportsData.io (if using)
SPORTSDATA_BASE = 'https://api.sportsdata.io/v3'

# ============================================================================
# SCRAPING TARGETS (Legal, with respect)
# ============================================================================

SCRAPING_SOURCES = {
    'basketball_reference': {
        'base_url': 'https://www.basketball-reference.com',
        'delay': 5,  # 5 seconds between requests
        'user_agent': 'DFS Research Bot (respectful scraping)',
    },
    'pro_football_reference': {
        'base_url': 'https://www.pro-football-reference.com',
        'delay': 5,
        'user_agent': 'DFS Research Bot (respectful scraping)',
    },
    'fantasypros': {
        'base_url': 'https://www.fantasypros.com',
        'delay': 5,
        'user_agent': 'DFS Research Bot (respectful scraping)',
    }
}

# ============================================================================
# UPDATE SCHEDULE
# ============================================================================

# Poll intervals (minutes)
TWITTER_POLL_INTERVAL = int(os.getenv("TWITTER_POLL_INTERVAL", "1"))  # minutes
SCRAPING_POLL_INTERVAL = int(os.getenv("SCRAPING_POLL_INTERVAL", "15"))

# NBA-specific update schedule (24-hour format)
NBA_UPDATE_SCHEDULE = {
    '08:00': [
        'fetch_vegas_odds',           # The Odds API
        'scrape_depth_charts',         # Basketball-Reference
        'poll_twitter_injuries',       # Twitter initial scan
    ],
    '11:00': [
        'poll_twitter_news',           # Mid-morning news check
        'scrape_starting_lineups',     # If available
    ],
    '14:00': [
        'fetch_vegas_odds',            # Line movement check
        'poll_twitter_news',
    ],
    '17:00': [
        'fetch_vegas_odds',            # Pre-lock odds
        'poll_twitter_lineups',        # Final lineup confirmations
        'run_projections',             # Generate projections
    ],
    '18:00': [
        'poll_twitter_news',           # Up to lock
    ],
    '23:00': [
        'scrape_game_results',         # Post-game stats
        'update_backtest_actuals',     # For validation
    ],
}

def get_enabled_commands(time_slot: str) -> list[str]:
    """Return enabled commands for a given time slot"""
    league = os.getenv("OPTIMIZER_LEAGUE", "NBA")
    if league != "NBA":
        return []
    
    commands = NBA_UPDATE_SCHEDULE.get(time_slot, [])
    filtered = []
    
    for cmd in commands:
        if 'twitter' in cmd and not FEATURES.get('twitter_enabled', False):
            continue
        if 'scrape' in cmd and not FEATURES.get('scraping_enabled', False):
            continue
        if not FEATURES.get('auto_update', False):
            continue
        filtered.append(cmd)
    
    return filtered

# ============================================================================
# ANALYSIS SETTINGS
# ============================================================================

# Minimum sample sizes for pattern detection
MIN_SAMPLE_SIZES = {
    'player_patterns': 10,      # Need 10+ games
    'team_patterns': 20,        # Need 20+ games
    'situational': 15,          # Need 15+ occurrences
}

# Statistical significance threshold
SIGNIFICANCE_LEVEL = 0.05  # p-value < 0.05

# Projection accuracy targets
ACCURACY_TARGETS = {
    'mae': 6.0,      # Target MAE under 6 points
    'r_squared': 0.80,  # Target R² above 0.80
}

# ============================================================================
# EXPORT SETTINGS
# ============================================================================

# Where to save outputs
OUTPUT_DIRS = {
    'projections': 'outputs/projections/',
    'lineups': 'outputs/lineups/',
    'reports': 'outputs/reports/',
    'insights': 'outputs/insights/',
}

# ============================================================================
# NOTIFICATION SETTINGS (Optional)
# ============================================================================

# Email notifications (optional - for alerts)
EMAIL_ENABLED = False
EMAIL_SMTP_SERVER = 'smtp.gmail.com'
EMAIL_SMTP_PORT = 587
EMAIL_FROM = 'your_email@gmail.com'
EMAIL_TO = 'your_email@gmail.com'
EMAIL_PASSWORD = 'your_app_password'  # Use app-specific password

# Alert triggers
ALERTS = {
    'big_injury': True,       # Alert on star player OUT
    'line_movement': True,    # Alert on big line moves (>3 pts)
    'value_found': True,      # Alert on discovered value plays
    'projection_error': True, # Alert if accuracy drops
}

# ============================================================================
# LOGGING
# ============================================================================

LOG_LEVEL = 'INFO'  # DEBUG, INFO, WARNING, ERROR
LOG_FILE = 'logs/dfs_master.log'
LOG_TO_CONSOLE = True

# ============================================================================
# FEATURE FLAGS (Read from .env)
# ============================================================================

FEATURES = {
    'auto_update': os.getenv("OPTIMIZER_SIGNALS_ENABLED", "true").lower() == "true",
    'twitter_enabled': os.getenv("OPTIMIZER_SIGNALS_TWITTER_ENABLED", "false").lower() == "true",
    'scraping_enabled': os.getenv("OPTIMIZER_SIGNALS_SCRAPING_ENABLED", "true").lower() == "true",
    'pattern_discovery': True,     # Auto-discover patterns
    'projection_generation': True, # Generate projections
    'lineup_optimization': True,   # Run optimizer
    'backtest_mode': os.getenv("BACKTEST_MODE", "false").lower() == "true",
}

LEAGUE = os.getenv("OPTIMIZER_LEAGUE", "NBA")

# ============================================================================
# DEVELOPMENT SETTINGS
# ============================================================================

# Use cache during development to avoid API calls
USE_CACHE = True
CACHE_DIR = 'data/cache/'
CACHE_EXPIRY_HOURS = 24

# Test mode (uses sample data)
TEST_MODE = False

# ============================================================================
# VALIDATION
# ============================================================================

def validate_config():
    """Comprehensive config validation for NBA DFS setup"""
    issues = []
    warnings = []
    
    print("\n" + "="*80)
    print("NBA DFS CONFIGURATION VALIDATION")
    print("="*80 + "\n")
    
    # 1. Database path
    print(f"Database Path: {DATABASE_PATH}")
    if DATABASE_PATH.exists():
        size_mb = DATABASE_PATH.stat().st_size / (1024 * 1024)
        print(f"  ✅ Exists ({size_mb:,.0f} MB)")
    else:
        warnings.append(f"⚠️  Database does not exist yet: {DATABASE_PATH}")
        print(f"  ⚠️  Will be created on first run")
    
    # 2. Backup directory
    if not BACKUP_PATH.exists():
        BACKUP_PATH.mkdir(parents=True, exist_ok=True)
        print(f"Backup Path: {BACKUP_PATH}")
        print(f"  ✅ Created")
    else:
        print(f"Backup Path: {BACKUP_PATH} ✅")
    
    # 3. Output directories
    for name, path in OUTPUT_DIRS.items():
        p = Path(path)
        if not p.exists():
            p.mkdir(parents=True, exist_ok=True)
        print(f"{name.title()} Output: {p} ✅")
    
    # 4. API keys (required vs optional)
    print("\nAPI Keys:")
    
    # Required for NBA
    if not ODDS_API_KEY:
        issues.append("❌ THE_ODDS_API_KEY required for NBA (get at https://the-odds-api.com/)")
    else:
        masked = '*' * 8 + ODDS_API_KEY[-4:] if len(ODDS_API_KEY) > 4 else '****'
        print(f"  The Odds API: {masked} ✅")
    
    # Optional but useful
    if not OPENWEATHER_API_KEY:
        warnings.append("⚠️  WEATHER_API_KEY not set (optional for NBA, required for NFL)")
    else:
        masked = '*' * 8 + OPENWEATHER_API_KEY[-4:] if len(OPENWEATHER_API_KEY) > 4 else '****'
        print(f"  OpenWeather: {masked} ✅")
    
    # Twitter (required if feature enabled)
    if FEATURES['twitter_enabled']:
        if not TWITTER_BEARER_TOKEN:
            issues.append("❌ TWITTER_BEARER_TOKEN required (twitter_enabled=true)")
        else:
            masked = '*' * 8 + TWITTER_BEARER_TOKEN[-4:] if len(TWITTER_BEARER_TOKEN) > 4 else '****'
            print(f"  Twitter API: {masked} ✅")
    else:
        print(f"  Twitter API: Not enabled")
    
    # 5. Feature flags
    print("\nFeature Flags:")
    print(f"  League: {LEAGUE}")
    print(f"  Auto Update: {FEATURES['auto_update']}")
    print(f"  Twitter Enabled: {FEATURES['twitter_enabled']}")
    print(f"  Scraping Enabled: {FEATURES['scraping_enabled']}")
    print(f"  Backtest Mode: {FEATURES['backtest_mode']}")
    
    # 6. Schedule preview
    if LEAGUE == "NBA" and FEATURES['auto_update']:
        print("\nScheduled Jobs (example for 17:00 slot):")
        for cmd in get_enabled_commands('17:00'):
            print(f"  - {cmd}")
    
    # 7. Report issues
    print("\n" + "="*80)
    if issues:
        print("CRITICAL ISSUES:")
        for issue in issues:
            print(issue)
        print("\n❌ Configuration invalid. Fix issues above.")
        print("="*80 + "\n")
        return False
    
    if warnings:
        print("WARNINGS:")
        for warning in warnings:
            print(warning)
        print()
    
    if not issues:
        print("✅ Configuration valid and ready for NBA DFS!")
    
    print("="*80 + "\n")
    return True

# ============================================================================
# USAGE INSTRUCTIONS
# ============================================================================

"""
QUICK START:

1. Get your FREE API keys:
   
   The Odds API (REQUIRED):
   - Go to: https://the-odds-api.com/
   - Sign up for free account
   - Get API key (500 requests/month)
   - Paste above in ODDS_API_KEY
   
   OpenWeather API (REQUIRED for NFL):
   - Go to: https://openweathermap.org/api
   - Sign up for free account  
   - Get API key (1,000 calls/day)
   - Paste above in OPENWEATHER_API_KEY

2. Save this file as: config.py

3. Run validation:
   python -c "import config; config.validate_config()"

4. Start using the database:
   python setup_database.py
   python update_data.py

That's it! You're ready to go!
"""

if __name__ == '__main__':
    validate_config()
